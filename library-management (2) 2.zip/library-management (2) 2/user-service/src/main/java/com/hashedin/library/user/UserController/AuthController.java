
package com.hashedin.library.user.UserController;

import com.hashedin.library.common.security.Role;
import com.hashedin.library.user.UserDto.User;
import com.hashedin.library.user.UserSecurity.JwtService;
import com.hashedin.library.user.UserService.UserService;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.Set;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    private final UserService userService;
    private final JwtService jwt;
    private final AuthenticationManager authMgr;

    public AuthController(UserService userService, JwtService jwt, AuthenticationManager authMgr) {
        this.userService = userService; this.jwt = jwt; this.authMgr = authMgr;
    }

    record RegisterReq(@Email String email, @NotBlank String name, @NotBlank String password, Set<Role> roles){}
    record LoginReq(@Email String email, @NotBlank String password){}
    record TokenRes(String token){}
    record LoginSuccessRes(String message, String email, String name){}
    record ForgotPasswordReq(@Email String email){}
    record ResetPasswordReq(@NotBlank String token, @NotBlank String newPassword){}


    @PostMapping("/register")
    public ResponseEntity<User> register(@RequestBody RegisterReq req){
        User u = userService.register(req.email(), req.name(), req.password(), req.roles());
        return ResponseEntity.ok(u);
    }

    @PostMapping("/User-login")
    public ResponseEntity<LoginSuccessRes> simpleLogin(@RequestBody LoginReq req){
        // Authenticate user with email and password (required for security)
        authMgr.authenticate(new UsernamePasswordAuthenticationToken(req.email(), req.password()));
        
        // Get user details from database
        User user = userService.findByEmail(req.email())
                .orElseThrow(() -> new RuntimeException("User not found"));
        
        return ResponseEntity.ok(new LoginSuccessRes(
                "Login successfully",
                user.getEmail(),
                user.getName()
        ));
    }

    @PostMapping("/login")
    public ResponseEntity<TokenRes> login(@RequestBody LoginReq req){
        Authentication a = authMgr.authenticate(new UsernamePasswordAuthenticationToken(req.email(), req.password()));
        UserDetails ud = (UserDetails)a.getPrincipal();
        String token = jwt.generateToken(ud.getUsername(), Map.of("roles", ud.getAuthorities().toString()));
        return ResponseEntity.ok(new TokenRes(token));
    }

    @PostMapping("/password/forgot")
    public ResponseEntity<Map<String,String>> forgot(@RequestBody ForgotPasswordReq req){
        String token = userService.createResetToken(req.email());
        return ResponseEntity.ok(Map.of("resetToken", token));
    }

    @PostMapping("/password/reset")
    public ResponseEntity<Map<String, String>> reset(@RequestBody ResetPasswordReq req) {
        userService.resetPassword(req.token(), req.newPassword());
        return ResponseEntity.ok(Map.of("message", "Password successfully reset"));
    }

}
