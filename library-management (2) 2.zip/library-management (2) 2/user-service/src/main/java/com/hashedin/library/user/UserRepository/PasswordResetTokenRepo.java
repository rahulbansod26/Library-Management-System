
package com.hashedin.library.user.UserRepository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.hashedin.library.user.UserDto.PasswordResetToken;

import java.util.Optional;
public interface PasswordResetTokenRepo extends JpaRepository<PasswordResetToken, String> {
    Optional<PasswordResetToken> findByToken(String token);
}
