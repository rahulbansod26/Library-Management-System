
package com.hashedin.library.user.UserController;

import com.hashedin.library.user.UserDto.User;
import com.hashedin.library.user.UserRepository.UserRepo;
import com.hashedin.library.user.UserService.UserService;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/profile")
public class ProfileController {
    private final UserService userService;
    private final UserRepo repo;

    public ProfileController(UserService userService, UserRepo repo){ this.userService=userService; this.repo=repo; }

    record GetProfileReq(@Email String email){}
    record UpdateProfileReq(@Email String email, @NotBlank String name){}

    @PostMapping("/get")
    public ResponseEntity<User> getByEmail(@RequestBody GetProfileReq req){
        return repo.findByEmail(req.email()).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    /*@GetMapping
    public ResponseEntity<User> getById(@RequestParam("id") String id){
        return repo.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }*/

    @PutMapping
    public ResponseEntity<User> update(@RequestBody UpdateProfileReq req){
        User user = repo.findByEmail(req.email()).orElseThrow(() -> new RuntimeException("User not found"));
        return ResponseEntity.ok(userService.updateProfile(user.getId(), req.name()));
    }
}


