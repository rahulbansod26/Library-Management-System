
package com.hashedin.library.user.UserService;

import com.hashedin.library.common.events.RoutingKeys;
import com.hashedin.library.common.events.UserPasswordResetEvent;
import com.hashedin.library.common.events.UserProfileChangedEvent;
import com.hashedin.library.common.events.UserRegisteredEvent;
import com.hashedin.library.common.security.Role;
import com.hashedin.library.user.UserDto.PasswordResetToken;
import com.hashedin.library.user.UserDto.User;
import com.hashedin.library.user.UserRepository.PasswordResetTokenRepo;
import com.hashedin.library.user.UserRepository.UserRepo;

import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class UserService implements UserDetailsService {
    private final UserRepo repo;
    private final PasswordResetTokenRepo tokenRepo;
    private final PasswordEncoder encoder;
    private final RabbitTemplate rabbit;
    private final TopicExchange exchange;

    public UserService(UserRepo repo, PasswordResetTokenRepo tokenRepo, PasswordEncoder encoder, RabbitTemplate rabbit, TopicExchange exchange) {
        this.repo = repo;
        this.tokenRepo = tokenRepo;
        this.encoder = encoder;
        this.rabbit = rabbit;
        this.exchange = exchange;
    }

    public User register(String email, String name, String rawPassword, Set<Role> roles){
        User u = new User();
        u.setEmail(email);
        u.setName(name);
        u.setPasswordHash(encoder.encode(rawPassword));
        if(roles==null || roles.isEmpty()) roles = Set.of(Role.USER);
        u.setRoles(roles);
        repo.save(u);
        rabbit.convertAndSend(exchange.getName(), RoutingKeys.USER_REGISTERED, new UserRegisteredEvent(u.getId(), u.getEmail(), u.getName()));
        //logger.info
        return u;

    }

    public String createResetToken(String email){
        User u = repo.findByEmail(email).orElseThrow();
        PasswordResetToken t = new PasswordResetToken();
        t.setUserId(u.getId());
        t.setToken(UUID.randomUUID().toString());
        t.setExpiresAt(Instant.now().plus(30, ChronoUnit.MINUTES));
        tokenRepo.save(t);
        rabbit.convertAndSend(exchange.getName(), RoutingKeys.USER_PASSWORD_RESET, new UserPasswordResetEvent(u.getId(), u.getEmail(), t.getToken()));
        return t.getToken();
    }

    public void resetPassword(String token, String newPassword){
        PasswordResetToken t = tokenRepo.findByToken(token).orElseThrow();
        if(t.getExpiresAt().isBefore(Instant.now())) throw new RuntimeException("Token expired");
        User u = repo.findById(t.getUserId()).orElseThrow();
        u.setPasswordHash(encoder.encode(newPassword));
        repo.save(u);
    }

    public User updateProfile(String userId, String newName){
        User u = repo.findById(userId).orElseThrow();
        u.setName(newName);
        repo.save(u);
        rabbit.convertAndSend(exchange.getName(), RoutingKeys.USER_PROFILE_CHANGED, new UserProfileChangedEvent(u.getId(), u.getEmail()));
        return u;
    }

    public Optional<User> findByEmail(String email){ return repo.findByEmail(email); }

    public UserDetails loadUserById(String id){
        return repo.findById(id).map(this::toUserDetails).orElse(null);
    }

    @Override
    public UserDetails loadUserByUsername(String username){
        return repo.findByEmail(username).map(this::toUserDetails).orElseThrow();
    }

    private UserDetails toUserDetails(User u){
        List<GrantedAuthority> auth = u.getRoles().stream().map(r-> new SimpleGrantedAuthority("ROLE_"+r.name())).collect(Collectors.toList());
        return new org.springframework.security.core.userdetails.User(u.getEmail(), u.getPasswordHash(), auth);
    }
}
