package com.hashedin.library.notification.config;

import com.hashedin.library.common.config.AmqpTopology;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

/**
 * Imports the shared TopicExchange bean (and any other AMQP topology)
 * defined in common-lib's AmqpTopology.
 */
@Configuration
@Import(AmqpTopology.class)
public class AmqpConfigImport {}
