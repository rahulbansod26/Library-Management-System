package com.hashedin.library.notification.service;

import java.time.LocalDate;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hashedin.library.notification.client.BorrowServiceClient;
import com.hashedin.library.notification.client.UserServiceClient;
import com.hashedin.library.notification.domain.Notification;
import com.hashedin.library.notification.repo.NotificationRepo;

@Service
public class NotificationReminderService {
    private static final Logger log = LoggerFactory.getLogger(NotificationReminderService.class);

    private final BorrowServiceClient borrowServiceClient;
    private final NotificationRepo notificationRepo;
    private final EmailService emailService;
    private final UserServiceClient userServiceClient;

    @Autowired
    public NotificationReminderService(BorrowServiceClient borrowServiceClient, 
                                      NotificationRepo notificationRepo,
                                      EmailService emailService,
                                      UserServiceClient userServiceClient) {
        this.borrowServiceClient = borrowServiceClient;
        this.notificationRepo = notificationRepo;
        this.emailService = emailService;
        this.userServiceClient = userServiceClient;
    }

    // Send reminders 3 days before due date - runs daily at 9 AM
    @Scheduled(cron = "0 0 9 * * *")
    @Async
    public void sendDueDateReminders() {
        try {
            log.info("[SCHEDULED] Checking for books due in 3 days...");
            List<com.hashedin.library.common.dto.BorrowRecordDTO> borrowsDueIn3Days = borrowServiceClient.getBorrowsDueInDays(3);
            
            for (com.hashedin.library.common.dto.BorrowRecordDTO borrow : borrowsDueIn3Days) {
                if (borrow.getUserId() != null && borrow.getBookId() != null && borrow.getEndDate() != null) {
                    sendDueDateReminder(borrow.getUserId(), borrow.getBookId(), borrow.getEndDate().toString(), 3);
                }
            }
            
            log.info("[SCHEDULED] Sent {} due date reminders (3 days)", borrowsDueIn3Days.size());
        } catch (Exception e) {
            log.error("[ERROR] Failed to send due date reminders: {}", e.getMessage(), e);
        }
    }

    // Send reminders 1 day before due date - runs daily at 9 AM
    @Scheduled(cron = "0 0 9 * * *")
    @Async
    public void sendFinalDueDateReminders() {
        try {
            log.info("[SCHEDULED] Checking for books due tomorrow...");
            List<com.hashedin.library.common.dto.BorrowRecordDTO> borrowsDueTomorrow = borrowServiceClient.getBorrowsDueInDays(1);
            
            for (com.hashedin.library.common.dto.BorrowRecordDTO borrow : borrowsDueTomorrow) {
                if (borrow.getUserId() != null && borrow.getBookId() != null && borrow.getEndDate() != null) {
                    sendDueDateReminder(borrow.getUserId(), borrow.getBookId(), borrow.getEndDate().toString(), 1);
                }
            }
            
            log.info("[SCHEDULED] Sent {} final due date reminders (1 day)", borrowsDueTomorrow.size());
        } catch (Exception e) {
            log.error("[ERROR] Failed to send final due date reminders: {}", e.getMessage(), e);
        }
    }

    // Send batch reminders for all active borrows - runs daily at 10 AM
    @Scheduled(cron = "0 0 10 * * *")
    @Async
    public void sendBatchDueDateReminders() {
        try {
            log.info("[SCHEDULED] Sending batch due date reminders...");
            List<com.hashedin.library.common.dto.BorrowRecordDTO> activeBorrows = borrowServiceClient.getActiveBorrows();
            
            int reminderCount = 0;
            LocalDate today = LocalDate.now();
            
            for (com.hashedin.library.common.dto.BorrowRecordDTO borrow : activeBorrows) {
                if (borrow.getUserId() != null && borrow.getBookId() != null && borrow.getEndDate() != null) {
                    try {
                        LocalDate endDate = borrow.getEndDate();
                        long daysUntilDue = java.time.temporal.ChronoUnit.DAYS.between(today, endDate);
                        
                        // Send reminder if due in 7 days or less (but not overdue)
                        if (daysUntilDue >= 0 && daysUntilDue <= 7) {
                            sendDueDateReminder(borrow.getUserId(), borrow.getBookId(), borrow.getEndDate().toString(), (int) daysUntilDue);
                            reminderCount++;
                        }
                    } catch (Exception e) {
                        log.error("Error processing borrow record: {}", e.getMessage(), e);
                    }
                }
            }
            
            log.info("[SCHEDULED] Sent {} batch due date reminders", reminderCount);
        } catch (Exception e) {
            log.error("[ERROR] Failed to send batch due date reminders: {}", e.getMessage(), e);
        }
    }

    @Transactional
    private void sendDueDateReminder(String userId, String bookId, String endDateStr, int daysUntilDue) {
        try {
            String subject;
            String message;
            String title;
            
            if (daysUntilDue == 1) {
                subject = "Final Reminder: Book Due Tomorrow";
                title = "Book Due Tomorrow";
                message = "REMINDER: Your borrowed book is due TOMORROW!\n\n" +
                        "Book ID: " + bookId + "\n" +
                        "Due Date: " + endDateStr + "\n\n" +
                        "Please return the book on or before the due date to avoid fines.\n\n" +
                        "Best regards,\n" +
                        "Library Management Team";
            } else if (daysUntilDue == 0) {
                subject = "Urgent: Book Due Today";
                title = "Book Due Today";
                message = "URGENT: Your borrowed book is due TODAY!\n\n" +
                        "Book ID: " + bookId + "\n" +
                        "Due Date: " + endDateStr + "\n\n" +
                        "Please return the book today to avoid fines.\n\n" +
                        "Best regards,\n" +
                        "Library Management Team";
            } else {
                subject = "Reminder: Book Due in " + daysUntilDue + " Days";
                title = "Book Due in " + daysUntilDue + " Days";
                message = "This is a friendly reminder that your borrowed book will be due soon.\n\n" +
                        "Book ID: " + bookId + "\n" +
                        "Due Date: " + endDateStr + "\n" +
                        "Days Remaining: " + daysUntilDue + "\n\n" +
                        "Please return the book by the due date to avoid fines.\n\n" +
                        "Best regards,\n" +
                        "Library Management Team";
            }
            
            // Fetch user email
            String userEmail = null;
            try {
                userEmail = userServiceClient.getUserEmailByUserId(userId);
            } catch (Exception e) {
                log.warn("Could not fetch email for user {}: {}", userId, e.getMessage());
            }
            
            // Send email if email service is configured
            if (userEmail != null && !userEmail.isEmpty() && emailService.isConfigured()) {
                try {
                    emailService.send(userEmail, subject, message);
                } catch (Exception mailEx) {
                    log.error("[EMAIL ERROR] Failed to send reminder email to {}: {}", userEmail, mailEx.getMessage());
                }
            }
            
            // Store notification
            Notification notification = new Notification();
            notification.setUserId(userId);
            notification.setType("DUE_DATE_REMINDER");
            notification.setTitle(title);
            notification.setMessage(message);
            notificationRepo.save(notification);
            
            log.info("[REMINDER SENT] {} for user {}, book {}", title, userId, bookId);
        } catch (Exception e) {
            log.error("[ERROR] Failed to send reminder for user {}, book {}: {}", userId, bookId, e.getMessage(), e);
        }
    }
}

