package com.hashedin.library.notification.config;

import com.hashedin.library.common.events.RoutingKeys;
import org.springframework.amqp.core.*;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Binds queues to the topic exchange using the concrete event routing keys
 * already defined in RoutingKeys.
 */
@Configuration
public class BindingsConfig {

    // --- Queues (non-durable + autoDelete for local dev; make durable in prod) ---
    @Bean
    public Queue userEventsQueue() {
        return QueueBuilder.nonDurable("user.events.q").autoDelete().build();
    }

    @Bean
    public Queue catalogEventsQueue() {
        return QueueBuilder.nonDurable("catalog.events.q").autoDelete().build();
    }

    @Bean
    public Queue borrowEventsQueue() {
        return QueueBuilder.nonDurable("borrow.events.q").autoDelete().build();
    }

    @Bean
    public Queue fineEventsQueue() {
        return QueueBuilder.nonDurable("fine.events.q").autoDelete().build();
    }

    // TopicExchange bean is provided by common-lib AmqpTopology.
    // Ensure each service imports it via your AmqpConfigImport.

    // --- USER events ---
    @Bean
    public Binding bindUserRegistered(@Qualifier("userEventsQueue") Queue q, TopicExchange libraryExchange) {
        return BindingBuilder.bind(q).to(libraryExchange).with(RoutingKeys.USER_REGISTERED);
    }

    @Bean
    public Binding bindUserPasswordReset(@Qualifier("userEventsQueue") Queue q, TopicExchange libraryExchange) {
        return BindingBuilder.bind(q).to(libraryExchange).with(RoutingKeys.USER_PASSWORD_RESET);
    }

    @Bean
    public Binding bindUserProfileChanged(@Qualifier("userEventsQueue") Queue q, TopicExchange libraryExchange) {
        return BindingBuilder.bind(q).to(libraryExchange).with(RoutingKeys.USER_PROFILE_CHANGED);
    }

    // --- CATALOG/BOOK events ---
    @Bean
    public Binding bindBookAdded(@Qualifier("catalogEventsQueue") Queue q, TopicExchange libraryExchange) {
        return BindingBuilder.bind(q).to(libraryExchange).with(RoutingKeys.BOOK_ADDED);
    }

    @Bean
    public Binding bindBookUpdated(@Qualifier("catalogEventsQueue") Queue q, TopicExchange libraryExchange) {
        return BindingBuilder.bind(q).to(libraryExchange).with(RoutingKeys.BOOK_UPDATED);
    }

    @Bean
    public Binding bindBookRemoved(@Qualifier("catalogEventsQueue") Queue q, TopicExchange libraryExchange) {
        return BindingBuilder.bind(q).to(libraryExchange).with(RoutingKeys.BOOK_REMOVED);
    }

    // --- BORROW/LENDING events ---
    @Bean
    public Binding bindBorrowRequested(@Qualifier("borrowEventsQueue") Queue q, TopicExchange libraryExchange) {
        return BindingBuilder.bind(q).to(libraryExchange).with(RoutingKeys.BORROW_REQUESTED);
    }

    @Bean
    public Binding bindBorrowApproved(@Qualifier("borrowEventsQueue") Queue q, TopicExchange libraryExchange) {
        return BindingBuilder.bind(q).to(libraryExchange).with(RoutingKeys.BORROW_APPROVED);
    }

    @Bean
    public Binding bindBookReturned(@Qualifier("borrowEventsQueue") Queue q, TopicExchange libraryExchange) {
        return BindingBuilder.bind(q).to(libraryExchange).with(RoutingKeys.BOOK_RETURNED);
    }

    @Bean
    public Binding bindBookOverdue(@Qualifier("borrowEventsQueue") Queue q, TopicExchange libraryExchange) {
        return BindingBuilder.bind(q).to(libraryExchange).with(RoutingKeys.BOOK_OVERDUE);
    }

    // --- FINES/PAYMENTS events ---
    @Bean
    public Binding bindFineUpdated(@Qualifier("fineEventsQueue") Queue q, TopicExchange libraryExchange) {
        return BindingBuilder.bind(q).to(libraryExchange).with(RoutingKeys.FINE_UPDATED);
    }

    @Bean
    public Binding bindPaymentRequested(@Qualifier("fineEventsQueue") Queue q, TopicExchange libraryExchange) {
        return BindingBuilder.bind(q).to(libraryExchange).with(RoutingKeys.PAYMENT_REQUESTED);
    }

    @Bean
    public Binding bindPaymentCompleted(@Qualifier("fineEventsQueue") Queue q, TopicExchange libraryExchange) {
        return BindingBuilder.bind(q).to(libraryExchange).with(RoutingKeys.PAYMENT_COMPLETED);
    }
}
