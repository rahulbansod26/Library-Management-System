//
//package com.hashedin.library.notification.service;
//
//import com.hashedin.library.common.events.*;
//import org.springframework.amqp.rabbit.annotation.RabbitListener;
//import org.springframework.messaging.handler.annotation.Payload;
//import org.springframework.stereotype.Service;
//
//@Service
//public class NotificationListener {
//
//    @RabbitListener(queues = "#{autoDeleteQueue1.name}")
//    public void onUserRegistered(@Payload UserRegisteredEvent e){
//        System.out.println("[EMAIL] Welcome "+e.getName()+"! ("+e.getEmail()+")");
//    }
//
//    @RabbitListener(queues = "#{autoDeleteQueue2.name}")
//    public void onPasswordReset(@Payload UserPasswordResetEvent e){
//        System.out.println("[EMAIL] Reset link token="+e.getResetToken()+" for "+e.getEmail());
//    }
//
//    @RabbitListener(queues = "#{autoDeleteQueue3.name}")
//    public void onProfileChanged(@Payload UserProfileChangedEvent e){
//        System.out.println("[EMAIL] Profile updated for "+e.getEmail());
//    }
//}



package com.hashedin.library.notification.service;

import com.hashedin.library.common.events.*;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class NotificationListener {

    @Autowired
    private JavaMailSender mailSender;

    // All three are USER-domain events; they are routed to "user.events.q"
    @RabbitListener(queues = "user.events.q")
    public void onUserRegistered(UserRegisteredEvent e){
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setTo(e.getEmail());
            message.setSubject("Welcome to Library Management System!");
            message.setText("Dear " + e.getName() + ",\n\n" +
                    "Welcome to our Library Management System! Your account has been successfully created.\n\n" +
                    "You can now:\n" +
                    "- Browse and search books\n" +
                    "- Borrow books\n" +
                    "- Manage your profile\n\n" +
                    "Thank you for joining us!\n\n" +
                    "Best regards,\n" +
                    "Library Management Team");
            
            mailSender.send(message);
            System.out.println("[EMAIL SENT] Welcome email sent to " + e.getEmail());
        } catch (Exception ex) {
            System.err.println("[EMAIL ERROR] Failed to send welcome email to " + e.getEmail() + ": " + ex.getMessage());
        }
    }

    @RabbitListener(queues = "user.events.q")
    public void onPasswordReset(UserPasswordResetEvent e){
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setTo(e.getEmail());
            message.setSubject("Password Reset Request");
            message.setText("Dear User,\n\n" +
                    "You have requested a password reset for your Library Management System account.\n\n" +
                    "Reset Token: " + e.getResetToken() + "\n\n" +
                    "Please use this token to reset your password. This token will expire in 30 minutes.\n\n" +
                    "If you did not request this reset, please ignore this email.\n\n" +
                    "Best regards,\n" +
                    "Library Management Team");
            
            mailSender.send(message);
            System.out.println("[EMAIL SENT] Password reset email sent to " + e.getEmail());
        } catch (Exception ex) {
            System.err.println("[EMAIL ERROR] Failed to send password reset email to " + e.getEmail() + ": " + ex.getMessage());
        }
    }

    @RabbitListener(queues = "user.events.q")
    public void onProfileChanged(UserProfileChangedEvent e){
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setTo(e.getEmail());
            message.setSubject("Profile Updated Successfully");
            message.setText("Dear User,\n\n" +
                    "Your profile has been successfully updated in the Library Management System.\n\n" +
                    "If you did not make this change, please contact our support team immediately.\n\n" +
                    "Best regards,\n" +
                    "Library Management Team");
            
            mailSender.send(message);
            System.out.println("[EMAIL SENT] Profile update notification sent to " + e.getEmail());
        } catch (Exception ex) {
            System.err.println("[EMAIL ERROR] Failed to send profile update email to " + e.getEmail() + ": " + ex.getMessage());
        }
    }
}
