
package com.hashedin.library.common.config;

import com.hashedin.library.common.events.RoutingKeys;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AmqpTopology {
    @Bean
    public TopicExchange libraryExchange(){
        return new TopicExchange(RoutingKeys.EXCHANGE, true, false);
    }
}
