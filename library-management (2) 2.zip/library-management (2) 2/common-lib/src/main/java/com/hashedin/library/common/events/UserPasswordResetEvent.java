
package com.hashedin.library.common.events;

public class UserPasswordResetEvent extends BaseEvent {
    private String userId;
    private String email;
    private String resetToken;

    public UserPasswordResetEvent() {}
    public UserPasswordResetEvent(String userId, String email, String resetToken) {
        this.userId = userId; this.email = email; this.resetToken = resetToken;
    }
    public String getUserId() { return userId; }
    public String getEmail() { return email; }
    public String getResetToken() { return resetToken; }
}
