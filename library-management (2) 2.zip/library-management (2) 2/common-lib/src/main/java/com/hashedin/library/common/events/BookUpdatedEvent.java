package com.hashedin.library.common.events;

public class BookUpdatedEvent extends BaseEvent {
    private String bookId;
    private String title;

    public BookUpdatedEvent() {}
    public BookUpdatedEvent(String bookId, String title) {
        this.bookId = bookId; this.title = title;
    }
    public String getBookId(){ return bookId; }
    public String getTitle(){ return title; }
}
