
package com.hashedin.library.common.events;

import java.io.Serializable;
import java.time.Instant;
import java.util.UUID;

public abstract class BaseEvent implements Serializable {
    private String id = UUID.randomUUID().toString();
    private Instant ts = Instant.now();
    public String getId() { return id; }
    public Instant getTs() { return ts; }
}
