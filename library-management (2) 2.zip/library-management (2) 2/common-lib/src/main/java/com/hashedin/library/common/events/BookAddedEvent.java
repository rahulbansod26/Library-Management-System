package com.hashedin.library.common.events;

public class BookAddedEvent extends BaseEvent {
    private String bookId;
    private String title;

    public BookAddedEvent() {}
    public BookAddedEvent(String bookId, String title) {
        this.bookId = bookId; this.title = title;
    }
    public String getBookId(){ return bookId; }
    public String getTitle(){ return title; }
}
