
package com.hashedin.library.common.events;

public final class RoutingKeys {
    public static final String EXCHANGE = "lib.events";
    public static final String USER_REGISTERED = "user.registered";
    public static final String USER_PASSWORD_RESET = "user.password.reset";
    public static final String USER_PROFILE_CHANGED = "user.profile.changed";

    public static final String BOOK_ADDED = "catalog.book.added";
    public static final String BOOK_UPDATED = "catalog.book.updated";
    public static final String BOOK_REMOVED = "catalog.book.removed";

    public static final String BORROW_REQUESTED = "borrow.requested";
    public static final String BORROW_APPROVED = "borrow.approved";
    public static final String BOOK_RETURNED = "borrow.returned";
    public static final String BOOK_OVERDUE = "borrow.overdue";

    public static final String FINE_UPDATED = "fine.updated";
    public static final String PAYMENT_REQUESTED = "payment.requested";
    public static final String PAYMENT_COMPLETED = "payment.completed";

    private RoutingKeys() {}
}
