package com.hashedin.library.common.events;

import java.math.BigDecimal;

public class FineUpdatedEvent extends BaseEvent {
    private String userId;
    private BigDecimal amount;

    public FineUpdatedEvent(){}
    public FineUpdatedEvent(String userId, BigDecimal amount){
        this.userId = userId; this.amount = amount;
    }
    public String getUserId(){ return userId; }
    public BigDecimal getAmount(){ return amount; }
}
