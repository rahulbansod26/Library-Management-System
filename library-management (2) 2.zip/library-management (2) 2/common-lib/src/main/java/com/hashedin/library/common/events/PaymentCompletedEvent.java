package com.hashedin.library.common.events;

import java.math.BigDecimal;

public class PaymentCompletedEvent extends BaseEvent {
    private String userId;
    private BigDecimal amount;
    private String paymentId;

    public PaymentCompletedEvent(){}
    public PaymentCompletedEvent(String userId, BigDecimal amount, String paymentId){
        this.userId = userId; this.amount = amount; this.paymentId = paymentId;
    }
    public String getUserId(){ return userId; }
    public BigDecimal getAmount(){ return amount; }
    public String getPaymentId(){ return paymentId; }
}
