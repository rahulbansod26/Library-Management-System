package com.hashedin.library.common.events;

public class BookRemovedEvent extends BaseEvent {
    private String bookId;
    private String title;

    public BookRemovedEvent() {}
    public BookRemovedEvent(String bookId, String title) {
        this.bookId = bookId; this.title = title;
    }
    public String getBookId(){ return bookId; }
    public String getTitle(){ return title; }
}
