
package com.hashedin.library.common.security;
public enum Role { USER, LIBRARIAN, ADMIN }
