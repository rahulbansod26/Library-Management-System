package com.hashedin.library.common.events;

import java.math.BigDecimal;

public class PaymentRequestedEvent extends BaseEvent {
    private String userId;
    private BigDecimal amount;

    public PaymentRequestedEvent(){}
    public PaymentRequestedEvent(String userId, BigDecimal amount){
        this.userId = userId; this.amount = amount;
    }
    public String getUserId(){ return userId; }
    public BigDecimal getAmount(){ return amount; }
}
