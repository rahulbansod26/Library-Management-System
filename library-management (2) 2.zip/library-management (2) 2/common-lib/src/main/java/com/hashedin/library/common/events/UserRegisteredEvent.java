
package com.hashedin.library.common.events;

public class UserRegisteredEvent extends BaseEvent {
    private String userId;
    private String email;
    private String name;

    public UserRegisteredEvent() {}
    public UserRegisteredEvent(String userId, String email, String name) {
        this.userId = userId; this.email = email; this.name = name;
    }
    public String getUserId() { return userId; }
    public String getEmail() { return email; }
    public String getName() { return name; }
}
