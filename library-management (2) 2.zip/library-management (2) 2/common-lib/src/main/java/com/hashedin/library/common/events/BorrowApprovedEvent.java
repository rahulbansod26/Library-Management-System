package com.hashedin.library.common.events;

import java.time.LocalDate;

public class BorrowApprovedEvent extends BaseEvent {
    private String userId;
    private String bookId;
    private LocalDate dueDate;

    public BorrowApprovedEvent(){}
    public BorrowApprovedEvent(String userId, String bookId, LocalDate dueDate){
        this.userId = userId; this.bookId = bookId; this.dueDate = dueDate;
    }
    public String getUserId(){ return userId; }
    public String getBookId(){ return bookId; }
    public LocalDate getDueDate(){ return dueDate; }
}
