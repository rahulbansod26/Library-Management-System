package com.hashedin.library.common.events;

public class BookReturnedEvent extends BaseEvent {
    private String userId;
    private String bookId;

    public BookReturnedEvent(){}
    public BookReturnedEvent(String userId, String bookId){
        this.userId = userId; this.bookId = bookId;
    }
    public String getUserId(){ return userId; }
    public String getBookId(){ return bookId; }
}
