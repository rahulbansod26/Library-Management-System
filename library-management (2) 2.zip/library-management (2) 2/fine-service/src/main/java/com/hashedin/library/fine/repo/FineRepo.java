
package com.hashedin.library.fine.repo;
import com.hashedin.library.fine.domain.Fine;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
public interface FineRepo extends JpaRepository<Fine, String> {
    Optional<Fine> findByUserId(String userId);
}
