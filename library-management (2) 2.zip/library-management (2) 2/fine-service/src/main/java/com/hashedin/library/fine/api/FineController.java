
package com.hashedin.library.fine.api;

import com.hashedin.library.fine.domain.Fine;
import com.hashedin.library.fine.service.FineService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/fines")
public class FineController {
    private final FineService service;
    public FineController(FineService service){ this.service=service; }

    @PostMapping("/{userId}/add")
    public ResponseEntity<Fine> add(@PathVariable String userId, @RequestParam BigDecimal amount){
        service.addFine(userId, amount);
        return ResponseEntity.ok(service.getOrCreate(userId));
    }

    @GetMapping("/{userId}")
    public ResponseEntity<Fine> get(@PathVariable String userId){
        return ResponseEntity.ok(service.getOrCreate(userId));
    }

    // Mock payment endpoints
    @PostMapping("/{userId}/pay")
    public ResponseEntity<Map<String,String>> pay(@PathVariable String userId){
        String paymentId = UUID.randomUUID().toString();
        return ResponseEntity.ok(Map.of("status","PAID","paymentId",paymentId));
    }
}
