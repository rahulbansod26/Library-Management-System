
package com.hashedin.library.fine.domain;

import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
public class Fine {
    @Id @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    private String userId;
    private BigDecimal amount = BigDecimal.ZERO;
    private boolean paid = false;

    public String getId(){return id;}
    public String getUserId(){return userId;} public void setUserId(String userId){this.userId=userId;}
    public BigDecimal getAmount(){return amount;} public void setAmount(BigDecimal amount){this.amount=amount;}
    public boolean isPaid(){return paid;} public void setPaid(boolean paid){this.paid=paid;}
}
