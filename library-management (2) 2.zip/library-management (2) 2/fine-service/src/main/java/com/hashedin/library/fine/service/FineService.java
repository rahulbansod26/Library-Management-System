
package com.hashedin.library.fine.service;

import com.hashedin.library.common.events.RoutingKeys;
import com.hashedin.library.fine.domain.Fine;
import com.hashedin.library.fine.repo.FineRepo;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@Service
public class FineService {
    private final FineRepo repo;
    private final RabbitTemplate rabbit;
    private final TopicExchange exchange;

    public FineService(FineRepo repo, RabbitTemplate rabbit, TopicExchange exchange){
        this.repo=repo; this.rabbit=rabbit; this.exchange=exchange;
    }

    public Fine getOrCreate(String userId){
        return repo.findByUserId(userId).orElseGet(()->{
            Fine f = new Fine(); f.setUserId(userId); return repo.save(f);
        });
    }

    public void addFine(String userId, BigDecimal amount){
        Fine f = getOrCreate(userId);
        f.setAmount(f.getAmount().add(amount));
        repo.save(f);
        rabbit.convertAndSend(exchange.getName(), RoutingKeys.FINE_UPDATED, f);
    }

    @Scheduled(cron = "0 15 * * * *")
    public void scheduledFineCalc(){
        // In a real app, load overdue from borrow-service via REST or AMQP.
    }
}
