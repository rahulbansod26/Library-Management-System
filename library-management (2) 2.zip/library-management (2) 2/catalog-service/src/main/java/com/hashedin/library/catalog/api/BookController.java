package com.hashedin.library.catalog.api;

import com.hashedin.library.catalog.domain.Book;
import com.hashedin.library.catalog.repo.BookRepo;
import com.hashedin.library.catalog.service.BookService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/books")
public class BookController {
    private final BookService service;
    private final BookRepo repo;

    public BookController(BookService service, BookRepo repo) {
        this.service = service;
        this.repo = repo;
    }

    @PostMapping
    public ResponseEntity<Book> add(@RequestBody Book req) {
        return ResponseEntity.ok(service.add(req));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Book> update(@PathVariable String id, @RequestBody Book req) {
        Book updated = repo.findById(id).map(existing -> {
            existing.setTitle(req.getTitle());
            existing.setAuthor(req.getAuthor());
            existing.setGenre(req.getGenre());
            existing.setDescription(req.getDescription());
            existing.setIsbn(req.getIsbn());
            existing.setQuantity(req.getQuantity());
            existing.setStatus(req.getStatus());
            return service.update(existing);
        }).orElseThrow(); // or .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND))
        return ResponseEntity.ok(updated);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> remove(@PathVariable String id) {
        service.remove(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/search")
    public List<Book> search(@RequestParam String q) {
        return service.search(q);
    }

    @GetMapping("/isbn/{isbn}")
    public ResponseEntity<Book> byIsbn(@PathVariable String isbn) {
        return service.byIsbn(isbn).map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
}
