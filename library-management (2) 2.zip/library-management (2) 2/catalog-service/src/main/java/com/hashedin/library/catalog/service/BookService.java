
package com.hashedin.library.catalog.service;

import com.hashedin.library.catalog.domain.Book;
import com.hashedin.library.catalog.repo.BookRepo;
import com.hashedin.library.common.events.RoutingKeys;
import com.hashedin.library.common.events.BookAddedEvent;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BookService {
    private final BookRepo repo;
    private final RabbitTemplate rabbit;
    private final TopicExchange exchange;

    public BookService(BookRepo repo, RabbitTemplate rabbit, TopicExchange exchange){
        this.repo=repo; this.rabbit=rabbit; this.exchange=exchange;
    }

    @CacheEvict(cacheNames = {"book_search","book_by_isbn"}, allEntries = true)
    public Book add(Book b){
        Book saved = repo.save(b);
        rabbit.convertAndSend(exchange.getName(), RoutingKeys.BOOK_ADDED, new BookAddedEvent(saved.getId(), saved.getTitle()));
        return saved;
    }

    @CacheEvict(cacheNames = {"book_search","book_by_isbn"}, allEntries = true)
    public Book update(Book b){ return repo.save(b); }

    @CacheEvict(cacheNames = {"book_search","book_by_isbn"}, allEntries = true)
    public void remove(String id){ repo.deleteById(id); }

    @Cacheable(cacheNames = "book_by_isbn", key = "#isbn")
    public Optional<Book> byIsbn(String isbn){ return repo.findByIsbn(isbn); }

    @Cacheable(cacheNames = "book_search", key = "#q")
    public List<Book> search(String q){ return repo.findByTitleContainingIgnoreCase(q); }
}
