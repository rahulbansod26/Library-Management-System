
package com.hashedin.library.borrow.api;

import com.hashedin.library.borrow.domain.BorrowRecord;
import com.hashedin.library.borrow.service.BorrowService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/borrow")
public class BorrowController {
    private final BorrowService service;
    public BorrowController(BorrowService service){ this.service=service; }

    @PostMapping
    public ResponseEntity<BorrowRecord> borrow(@RequestParam String userId, @RequestParam String bookId, @RequestParam(defaultValue = "14") int days){
        return ResponseEntity.ok(service.borrow(userId, bookId, days));
    }

    @PostMapping("/return/{recordId}")
    public ResponseEntity<BorrowRecord> returnBook(@RequestParam String userId, @PathVariable String recordId){
        return ResponseEntity.ok(service.returnBook(userId, recordId));
    }

    @GetMapping("/user/{userId}")
    public List<BorrowRecord> active(@PathVariable String userId){
        return service.activeForUser(userId);
    }
}
