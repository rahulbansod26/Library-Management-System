
package com.hashedin.library.borrow.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hashedin.library.borrow.domain.BorrowRecord;
import com.hashedin.library.borrow.domain.BorrowRequest;
import com.hashedin.library.borrow.service.BorrowService;
import com.hashedin.library.common.dto.ApproveRejectRequest;

@RestController
@RequestMapping("/api/borrow")
public class BorrowController {
    private final BorrowService service;
    public BorrowController(BorrowService service){ this.service=service; }

    record BorrowRequestDTO(String userId, String bookId, int days) {}

    record ReturnBookRequest(String userId) {}

    @PostMapping
    public ResponseEntity<BorrowRecord> borrow(@RequestBody BorrowRequestDTO req){
        int days = req.days() > 0 ? req.days() : 14;
        return ResponseEntity.ok(service.borrow(req.userId(), req.bookId(), days));
    }

    @PostMapping("/return/{recordId}")
    public ResponseEntity<BorrowRecord> returnBook(@RequestBody ReturnBookRequest req, @PathVariable String recordId){
        return ResponseEntity.ok(service.returnBook(req.userId(), recordId));
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<BorrowRecord>> active(@PathVariable String userId){
        return ResponseEntity.ok(service.activeForUser(userId));
    }

    @GetMapping("/user/{userId}/history")
    public ResponseEntity<List<BorrowRecord>> history(@PathVariable String userId){
        return ResponseEntity.ok(service.getBorrowingHistory(userId));
    }

    @GetMapping("/overdue")
    public ResponseEntity<List<BorrowRecord>> overdue(){
        return ResponseEntity.ok(service.getOverdueRecords());
    }

    @GetMapping("/{recordId}")
    public ResponseEntity<BorrowRecord> getById(@PathVariable String recordId){
        return ResponseEntity.ok(service.getById(recordId));
    }

    @GetMapping("/active/all")
    public ResponseEntity<List<BorrowRecord>> getAllActive() {
        return ResponseEntity.ok(service.getActiveBorrows());
    }

    @GetMapping("/due-in-days/{days}")
    public ResponseEntity<List<BorrowRecord>> getDueInDays(@PathVariable int days) {
        return ResponseEntity.ok(service.getBorrowsDueInDays(days));
    }
    
    @PostMapping("/{recordId}/lost")
    public ResponseEntity<BorrowRecord> markAsLost(@RequestBody ReturnBookRequest req, @PathVariable String recordId) {
        return ResponseEntity.ok(service.markBookAsLost(req.userId(), recordId));
    }
    
    // Borrow Request endpoints
    record CreateBorrowRequestDTO(String bookId, int days, String reason) {}
    
    @PostMapping("/request")
    public ResponseEntity<BorrowRequest> createRequest(@RequestBody CreateBorrowRequestDTO req) {
        // Assuming userId is in request or should be extracted from JWT
        // For now, we'll need userId - this should come from security context in production
        String userId = "user-id-from-token"; // TODO: Extract from JWT
        return ResponseEntity.ok(service.createBorrowRequest(userId, req.bookId(), req.days(), req.reason()));
    }
    
    @PostMapping("/request/{requestId}/approve")
    @PreAuthorize("hasRole('LIBRARIAN')")
    public ResponseEntity<BorrowRecord> approveRequest(@PathVariable String requestId, @RequestBody ApproveRejectRequest request) {
        return ResponseEntity.ok(service.approveBorrowRequest(requestId, request.librarianId()));
    }
    
    @PostMapping("/request/{requestId}/reject")
    @PreAuthorize("hasRole('LIBRARIAN')")
    public ResponseEntity<BorrowRequest> rejectRequest(@PathVariable String requestId, @RequestBody ApproveRejectRequest request) {
        return ResponseEntity.ok(service.rejectBorrowRequest(requestId, request.librarianId()));
    }
    
    @GetMapping("/request/pending")
    @PreAuthorize("hasRole('LIBRARIAN')")
    public ResponseEntity<List<BorrowRequest>> getPendingRequests() {
        return ResponseEntity.ok(service.getPendingRequests());
    }
    
    @GetMapping("/request/user/{userId}")
    public ResponseEntity<List<BorrowRequest>> getUserRequests(@PathVariable String userId) {
        return ResponseEntity.ok(service.getUserRequests(userId));
    }
}

