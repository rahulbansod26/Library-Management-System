package com.hashedin.library.borrow.client;

import com.hashedin.library.common.dto.BookDTO;
import com.hashedin.library.common.dto.UpdateStatusRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class CatalogServiceClient {
    private static final Logger log = LoggerFactory.getLogger(CatalogServiceClient.class);
    private final RestTemplate restTemplate;
    private static final String CATALOG_SERVICE_NAME = "catalog-service";

    public CatalogServiceClient(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public BookDTO getBook(String bookId) {
        try {
            ResponseEntity<BookDTO> response = restTemplate.exchange(
                    "http://" + CATALOG_SERVICE_NAME + "/api/books/" + bookId,
                    HttpMethod.GET,
                    null,
                    new ParameterizedTypeReference<BookDTO>() {}
            );
            return response.getBody();
        } catch (Exception e) {
            log.error("Error fetching book {}: {}", bookId, e.getMessage(), e);
            return null;
        }
    }

    public void updateBookStatus(String bookId, String status) {
        try {
            HttpEntity<UpdateStatusRequest> request = 
                new HttpEntity<>(new UpdateStatusRequest(status));
            restTemplate.exchange(
                    "http://" + CATALOG_SERVICE_NAME + "/api/books/" + bookId + "/status",
                    HttpMethod.PATCH,
                    request,
                    new ParameterizedTypeReference<BookDTO>() {}
            );
        } catch (Exception e) {
            log.error("Error updating book status for {} to {}: {}", bookId, status, e.getMessage(), e);
        }
    }
}

