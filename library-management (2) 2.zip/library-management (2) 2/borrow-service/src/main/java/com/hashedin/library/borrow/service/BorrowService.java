
package com.hashedin.library.borrow.service;

import com.hashedin.library.borrow.domain.BorrowRecord;
import com.hashedin.library.borrow.repo.BorrowRepo;
import com.hashedin.library.common.events.RoutingKeys;
import com.hashedin.library.common.events.BorrowRequestedEvent;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class BorrowService {
    private final BorrowRepo repo;
    private final RabbitTemplate rabbit;
    private final TopicExchange exchange;
    private final int MAX_BOOKS = 5;

    public BorrowService(BorrowRepo repo, RabbitTemplate rabbit, TopicExchange exchange){
        this.repo=repo; this.rabbit=rabbit; this.exchange=exchange;
    }

    @CacheEvict(cacheNames="active_loans", key="#userId")
    public BorrowRecord borrow(String userId, String bookId, int days){
        long active = repo.countByUserIdAndStatus(userId, BorrowRecord.Status.ACTIVE);
        if(active >= MAX_BOOKS) throw new RuntimeException("Borrow limit exceeded");
        BorrowRecord r = new BorrowRecord();
        r.setUserId(userId); r.setBookId(bookId);
        r.setStartDate(LocalDate.now());
        r.setEndDate(LocalDate.now().plusDays(days));
        r = repo.save(r);
        rabbit.convertAndSend(exchange.getName(), RoutingKeys.BORROW_REQUESTED, new BorrowRequestedEvent(userId, bookId));
        return r;
    }

    @CacheEvict(cacheNames="active_loans", key="#userId")
    public BorrowRecord returnBook(String userId, String recordId){
        BorrowRecord r = repo.findById(recordId).orElseThrow();
        r.setStatus(BorrowRecord.Status.RETURNED);
        return repo.save(r);
    }

    @Cacheable(cacheNames="active_loans", key="#userId")
    public List<BorrowRecord> activeForUser(String userId){
        return repo.findByUserId(userId);
    }

    @Scheduled(cron = "0 0 * * * *")
    public void markOverdue(){
        List<BorrowRecord> due = repo.findByStatusAndEndDateBefore(BorrowRecord.Status.ACTIVE, LocalDate.now());
        for(BorrowRecord r: due){
            r.setStatus(BorrowRecord.Status.OVERDUE);
            repo.save(r);
            rabbit.convertAndSend(exchange.getName(), RoutingKeys.BOOK_OVERDUE, r);
        }
    }
}
