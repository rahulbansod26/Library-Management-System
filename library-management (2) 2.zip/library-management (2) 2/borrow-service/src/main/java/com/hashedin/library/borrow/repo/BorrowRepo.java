
package com.hashedin.library.borrow.repo;

import com.hashedin.library.borrow.domain.BorrowRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.LocalDate;
import java.util.List;

public interface BorrowRepo extends JpaRepository<BorrowRecord, String> {
    long countByUserIdAndStatus(String userId, BorrowRecord.Status status);
    List<BorrowRecord> findByUserId(String userId);
    List<BorrowRecord> findByStatusAndEndDateBefore(BorrowRecord.Status status, LocalDate date);
}
