
package com.hashedin.library.borrow.domain;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
public class BorrowRecord {
    public enum Status { ACTIVE, RETURNED, OVERDUE }
    @Id @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    private String userId;
    private String bookId;
    private LocalDate startDate;
    private LocalDate endDate;
    @Enumerated(EnumType.STRING)
    private Status status = Status.ACTIVE;

    public String getId(){return id;}
    public String getUserId(){return userId;} public void setUserId(String userId){this.userId=userId;}
    public String getBookId(){return bookId;} public void setBookId(String bookId){this.bookId=bookId;}
    public LocalDate getStartDate(){return startDate;} public void setStartDate(LocalDate startDate){this.startDate=startDate;}
    public LocalDate getEndDate(){return endDate;} public void setEndDate(LocalDate endDate){this.endDate=endDate;}
    public Status getStatus(){return status;} public void setStatus(Status status){this.status=status;}
}
