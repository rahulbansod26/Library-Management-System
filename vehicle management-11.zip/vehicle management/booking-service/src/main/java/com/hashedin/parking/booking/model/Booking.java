package com.hashedin.parking.booking.model;

import com.hashedin.parking.common.model.BookingStatus;
import jakarta.persistence.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@EntityListeners(AuditingEntityListener.class)
public class Booking {
    @Id @GeneratedValue
    private UUID id;
    private UUID userId;
    private Long lotId;
    private Long spotId;

    //private String status; // CREATED, CONFIRMED, CANCELLED, EXPIRED

    @Enumerated(EnumType.STRING)
    private BookingStatus status = BookingStatus.CREATED; // default CREATED

    private LocalDateTime startTime;
    private LocalDateTime endTime;
    
    @CreatedDate
    @Column(updatable = false)
    private LocalDateTime createdAt;
    
    @LastModifiedDate
    private LocalDateTime updatedAt;

    public UUID getId() { return id; }
    public void setId(UUID id) { this.id = id; }
    public UUID getUserId() { return userId; }
    public void setUserId(UUID userId) { this.userId = userId; }
    public Long getLotId() { return lotId; }
    public void setLotId(Long lotId) { this.lotId = lotId; }
    public Long getSpotId() { return spotId; }
    public void setSpotId(Long spotId) { this.spotId = spotId; }

    public BookingStatus getStatus() {
        return status;
    }

    public void setStatus(BookingStatus status) {
        this.status = status;
    }

//    public boolean isCreated() { return BookingStatus.CREATED.equals(this.status); }
//    public boolean isConfirmed() { return BookingStatus.CONFIRMED.equals(this.status); }
//    public boolean isCancelled() { return BookingStatus.CANCELLED.equals(this.status); }

    public LocalDateTime getStartTime() { return startTime; }
    public void setStartTime(LocalDateTime startTime) { this.startTime = startTime; }
    public LocalDateTime getEndTime() { return endTime; }
    public void setEndTime(LocalDateTime endTime) { this.endTime = endTime; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
}
