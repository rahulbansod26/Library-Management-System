package com.hashedin.parking.booking.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

@Component
public class AvailabilityCache {
    private static final Logger log = LoggerFactory.getLogger(AvailabilityCache.class);
    private final RedisTemplate<String, String> redis;

    public AvailabilityCache(RedisTemplate<String, String> redis) {
        this.redis = redis;
    }

    public void setUnavailable(Long spotId, String windowKey, long ttlSeconds) {
        try {
            String key = "spot:" + spotId + ":" + windowKey;
            redis.opsForValue().set(key, "unavailable", java.time.Duration.ofSeconds(ttlSeconds));
            log.debug("Marked spot {} unavailable in cache for window: {} (TTL: {}s)", spotId, windowKey, ttlSeconds);
        } catch (Exception e) {
            log.warn("Failed to mark spot {} unavailable in cache for window {}: {}", spotId, windowKey, e.getMessage());
        }
    }

    public boolean isUnavailable(Long spotId, String windowKey) {
        try {
            String key = "spot:" + spotId + ":" + windowKey;
            boolean unavailable = Boolean.TRUE.equals(redis.hasKey(key));
            if (unavailable) {
                log.debug("Cache HIT - Spot {} unavailable for window: {}", spotId, windowKey);
            } else {
                log.debug("Cache MISS - Spot {} availability check for window: {}", spotId, windowKey);
            }
            return unavailable;
        } catch (Exception e) {
            log.warn("Failed to check spot availability in cache for spot {} and window {}: {}", spotId, windowKey, e.getMessage());
            // Return false on error to allow database check
            return false;
        }
    }
    
    public void evict(Long spotId, String windowKey) {
        try {
            String key = "spot:" + spotId + ":" + windowKey;
            redis.delete(key);
            log.debug("Evicted availability cache for spot {} and window: {}", spotId, windowKey);
        } catch (Exception e) {
            log.warn("Failed to evict availability cache for spot {} and window {}: {}", spotId, windowKey, e.getMessage());
        }
    }
}
