@echo off
echo Starting Vehicle Parking Management System...
echo.

echo Starting Eureka Service Discovery on port 8761...
start "Discovery Service" cmd /k "cd discovery-service && mvn spring-boot:run"

timeout /t 10 /nobreak >nul

echo Starting API Gateway on port 8080...
start "API Gateway" cmd /k "cd api-gateway && mvn spring-boot:run"

timeout /t 5 /nobreak >nul

echo Starting User Service on port 8081...
start "User Service" cmd /k "cd user-service && mvn spring-boot:run"

timeout /t 5 /nobreak >nul

echo Starting Admin Service on port 8082...
start "Admin Service" cmd /k "cd admin-service && mvn spring-boot:run"

timeout /t 5 /nobreak >nul

echo Starting Booking Service on port 8083...
start "Booking Service" cmd /k "cd booking-service && mvn spring-boot:run"

timeout /t 5 /nobreak >nul

echo Starting Payment Service on port 8084...
start "Payment Service" cmd /k "cd payment-service && mvn spring-boot:run"

timeout /t 5 /nobreak >nul

echo Starting Notification Service on port 8085...
start "Notification Service" cmd /k "cd notification-service && mvn spring-boot:run"

echo.
echo All services are starting up...
echo.
echo Service URLs:
echo - Discovery Service: http://localhost:8761
echo - API Gateway: http://localhost:8080
echo - User Service: http://localhost:8081
echo - Admin Service: http://localhost:8082
echo - Booking Service: http://localhost:8083
echo - Payment Service: http://localhost:8084
echo - Notification Service: http://localhost:8085
echo.
echo Swagger Documentation:
echo - User Service: http://localhost:8081/swagger-ui.html
echo - Admin Service: http://localhost:8082/swagger-ui.html
echo - Booking Service: http://localhost:8083/swagger-ui.html
echo - Payment Service: http://localhost:8084/swagger-ui.html
echo - Notification Service: http://localhost:8085/swagger-ui.html
echo.
echo Press any key to exit...
pause >nul
