//package com.hashedin.parking.user.config;
//
//import com.hashedin.parking.common.security.JwtUtils;
//import com.hashedin.parking.common.web.SecurityConstants;
//import com.hashedin.parking.user.security.TokenBlacklistService;
//import io.jsonwebtoken.Claims;
//import io.jsonwebtoken.Jws;
//import jakarta.servlet.FilterChain;
//import jakarta.servlet.ServletException;
//import jakarta.servlet.http.HttpServletRequest;
//import jakarta.servlet.http.HttpServletResponse;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
//import org.springframework.security.config.Customizer;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.config.http.SessionCreationPolicy;
//import org.springframework.security.core.authority.SimpleGrantedAuthority;
//import org.springframework.security.core.context.SecurityContextHolder;
//import org.springframework.security.web.SecurityFilterChain;
//import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
//import org.springframework.web.filter.OncePerRequestFilter;
//
//import java.io.IOException;
//import java.util.List;
//
//@Configuration
//public class SecurityConfig {
//
//    //@Autowired
//    private final TokenBlacklistService blacklistService;
//
//    @Value("${app.jwt.secret:demo-secret-demo-secret-demo-secret-123456}")
//    private String jwtSecret;
//
//    public SecurityConfig(TokenBlacklistService blacklistService) {
//        this.blacklistService = blacklistService;
//    }
//
//    private class JwtFilter extends OncePerRequestFilter {
//        @Override
//        protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
//            String header = request.getHeader(SecurityConstants.AUTH_HEADER);
//            if (header != null && header.startsWith(SecurityConstants.BEARER_PREFIX)) {
//
//
//                String token = header.substring(SecurityConstants.BEARER_PREFIX.length());
//                if (blacklistService.isBlacklisted(token)) {
//                    response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
//                    return;
//                }
//
//
//                try {
//           //         String token = header.substring(SecurityConstants.BEARER_PREFIX.length());
//                    JwtUtils jwt = new JwtUtils(jwtSecret, 3600);
//                    Jws<Claims> jws = jwt.parse(token);
//                    String sub = jws.getBody().getSubject();
//                    Object role = jws.getBody().get("role");
//                    if (sub != null && role != null) {
//                        UsernamePasswordAuthenticationToken auth =
//                                new UsernamePasswordAuthenticationToken(sub, null, List.of(new SimpleGrantedAuthority("ROLE_" + role)));
//                        SecurityContextHolder.getContext().setAuthentication(auth);
//                    }
//                } catch (Exception ignored) { }
//            }
//            filterChain.doFilter(request, response);
//        }
//    }
//
//    @Bean
//    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
//        http.csrf(csrf -> csrf.disable())
//                .sessionManagement(sm -> sm.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
//                .authorizeHttpRequests(reg -> reg
//                        .requestMatchers("/actuator/**","/v3/api-docs/**","/swagger-ui/**","/swagger-ui.html","/api/auth/**").permitAll()
//                        .anyRequest().authenticated()
//                )
//                .addFilterBefore(new JwtFilter(), UsernamePasswordAuthenticationFilter.class)
//                .httpBasic(Customizer.withDefaults());
//        return http.build();
//    }
//}


package com.hashedin.parking.user.config;

import com.hashedin.parking.common.security.JwtUtils;
import com.hashedin.parking.common.web.SecurityConstants;
import com.hashedin.parking.user.security.TokenBlacklistService;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.List;

@Configuration
@EnableMethodSecurity(prePostEnabled = true)
public class SecurityConfig {

    private final TokenBlacklistService blacklistService;

    @Value("${app.jwt.secret:demo-secret-demo-secret-demo-secret-123456}")
    private String jwtSecret;

    public SecurityConfig(TokenBlacklistService blacklistService) {
        this.blacklistService = blacklistService;
    }

    private class JwtFilter extends OncePerRequestFilter {
        @Override
        protected void doFilterInternal(HttpServletRequest request,
                                        HttpServletResponse response,
                                        FilterChain filterChain) throws ServletException, IOException {
            String path = request.getRequestURI();

            // ✅ Skip all /api/auth/** endpoints (register, login, logout, etc.)
            if (path.equals("/api/auth/register") ||
                    path.equals("/api/auth/login") ||
                    path.equals("/api/auth/forgot-password") ||
                    path.equals("/api/auth/reset-password")) {
                filterChain.doFilter(request, response);
                return;
            }

            String header = request.getHeader(SecurityConstants.AUTH_HEADER);
            if (header == null || !header.startsWith(SecurityConstants.BEARER_PREFIX)) {
                // ✅ No token → just continue without setting auth
                filterChain.doFilter(request, response);
                return;
            }

            String token = header.substring(SecurityConstants.BEARER_PREFIX.length());
            if (blacklistService.isBlacklisted(token)) {
                response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                return;
            }

            try {
                JwtUtils jwt = new JwtUtils(jwtSecret, 3600);
                Jws<Claims> jws = jwt.parse(token);
                String sub = jws.getBody().getSubject();
                Object role = jws.getBody().get("role");
                if (sub != null && role != null) {
                    UsernamePasswordAuthenticationToken auth =
                            new UsernamePasswordAuthenticationToken(
                                    sub, null, List.of(new SimpleGrantedAuthority("ROLE_" + role))
                            );
                    SecurityContextHolder.getContext().setAuthentication(auth);
                }
            } catch (Exception ignored) { }

            filterChain.doFilter(request, response);
        }
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http.csrf(csrf -> csrf.disable())
                .sessionManagement(sm -> sm.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .authorizeHttpRequests(reg -> reg
                        // ✅ Auth endpoints are open
                        .requestMatchers("/actuator/**",
                                "/v3/api-docs/**",
                                "/swagger-ui/**",
                                "/swagger-ui.html",
                                "/api/auth/register",
                                "/api/auth/login",
                                "/api/auth/forgot-password",
                                "/api/auth/reset-password").permitAll()
                        // everything else requires auth
                        .anyRequest().authenticated()
                )
                .addFilterBefore(new JwtFilter(), UsernamePasswordAuthenticationFilter.class)
                .httpBasic(Customizer.withDefaults());
        return http.build();
    }
}
