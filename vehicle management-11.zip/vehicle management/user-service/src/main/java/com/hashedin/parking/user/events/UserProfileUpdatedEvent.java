package com.hashedin.parking.user.events;

import java.io.Serializable;
import java.util.UUID;

public class UserProfileUpdatedEvent implements Serializable {
    private UUID userId;
    private String email;
    private String fullName;

    public UserProfileUpdatedEvent() {}

    public UserProfileUpdatedEvent(UUID userId, String email, String fullName) {
        this.userId = userId;
        this.email = email;
        this.fullName = fullName;
    }

    public UUID getUserId() { return userId; }
    public void setUserId(UUID userId) { this.userId = userId; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }
}
