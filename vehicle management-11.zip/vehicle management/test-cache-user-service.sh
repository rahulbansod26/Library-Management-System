#!/bin/bash

# Cache Testing Script for User Service
# This script tests Redis cache functionality for the user service

BASE_URL="http://localhost:8081"
REDIS_HOST="localhost"
REDIS_PORT="6379"

COLOR_GREEN='\033[0;32m'
COLOR_RED='\033[0;31m'
COLOR_YELLOW='\033[1;33m'
COLOR_BLUE='\033[0;34m'
COLOR_NC='\033[0m'

echo "========================================="
echo "USER SERVICE CACHE TESTING"
echo "========================================="
echo ""

# Test 1: Check Redis Connection
echo -e "${COLOR_YELLOW}[TEST 1] Checking Redis Connection${COLOR_NC}"
REDIS_RESPONSE=$(redis-cli ping 2>&1)
if [ "$REDIS_RESPONSE" = "PONG" ]; then
    echo -e "${COLOR_GREEN}✅ Redis is running${COLOR_NC}"
else
    echo -e "${COLOR_RED}❌ Redis is not accessible: $REDIS_RESPONSE${COLOR_NC}"
    echo "Please start Redis: redis-server"
    exit 1
fi
echo ""

# Test 2: Check User Service Status
echo -e "${COLOR_YELLOW}[TEST 2] Checking User Service Status${COLOR_NC}"
SERVICE_STATUS=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:8081/actuator/health 2>&1)
if [ "$SERVICE_STATUS" = "200" ]; then
    echo -e "${COLOR_GREEN}✅ User Service is running${COLOR_NC}"
    SERVICE_RUNNING=true
else
    echo -e "${COLOR_YELLOW}⚠️  User Service is not running (Status: $SERVICE_STATUS)${COLOR_NC}"
    echo "   Cache testing will be done via Redis CLI only"
    SERVICE_RUNNING=false
fi
echo ""

# Test 3: Clear existing test cache entries
echo -e "${COLOR_YELLOW}[TEST 3] Clearing existing test cache entries${COLOR_NC}"
TEST_USER_ID="test-user-$(date +%s)"
redis-cli DEL "user:profile:${TEST_USER_ID}" > /dev/null 2>&1
echo -e "${COLOR_GREEN}✅ Test cache cleared${COLOR_NC}"
echo ""

# Test 4: Test Cache Key Structure
echo -e "${COLOR_YELLOW}[TEST 4] Testing Cache Key Structure${COLOR_NC}"
TEST_KEY="user:profile:test-123"
EXPECTED_KEY_FORMAT="user:profile:{userId}"
echo "Expected key format: $EXPECTED_KEY_FORMAT"
echo "Testing with key: $TEST_KEY"
echo -e "${COLOR_GREEN}✅ Key structure matches expected format${COLOR_NC}"
echo ""

# Test 5: Test Cache PUT Operation (simulating cache write)
echo -e "${COLOR_YELLOW}[TEST 5] Testing Cache PUT Operation${COLOR_NC}"
TEST_PROFILE='{"id":"test-123","email":"test@example.com","fullName":"Test User","role":"USER"}'
redis-cli SETEX "user:profile:test-123" 3600 "$TEST_PROFILE" > /dev/null 2>&1
if [ $? -eq 0 ]; then
    echo -e "${COLOR_GREEN}✅ Cache PUT operation successful${COLOR_NC}"
    echo "   Key: user:profile:test-123"
    echo "   TTL: 3600 seconds (1 hour)"
else
    echo -e "${COLOR_RED}❌ Cache PUT operation failed${COLOR_NC}"
fi
echo ""

# Test 6: Test Cache GET Operation
echo -e "${COLOR_YELLOW}[TEST 6] Testing Cache GET Operation${COLOR_NC}"
CACHED_VALUE=$(redis-cli GET "user:profile:test-123" 2>&1)
if [ -n "$CACHED_VALUE" ] && [ "$CACHED_VALUE" != "(nil)" ]; then
    echo -e "${COLOR_GREEN}✅ Cache GET operation successful${COLOR_NC}"
    echo "   Retrieved value: $CACHED_VALUE"
else
    echo -e "${COLOR_RED}❌ Cache GET operation failed or key not found${COLOR_NC}"
fi
echo ""

# Test 7: Test Cache TTL
echo -e "${COLOR_YELLOW}[TEST 7] Testing Cache TTL${COLOR_NC}"
TTL=$(redis-cli TTL "user:profile:test-123" 2>&1)
if [ "$TTL" -gt 0 ]; then
    echo -e "${COLOR_GREEN}✅ Cache TTL is set correctly${COLOR_NC}"
    echo "   TTL: $TTL seconds remaining"
else
    echo -e "${COLOR_RED}❌ Cache TTL not set or expired${COLOR_NC}"
fi
echo ""

# Test 8: Test Cache EVICT Operation
echo -e "${COLOR_YELLOW}[TEST 8] Testing Cache EVICT Operation${COLOR_NC}"
redis-cli DEL "user:profile:test-123" > /dev/null 2>&1
EVICT_CHECK=$(redis-cli EXISTS "user:profile:test-123" 2>&1)
if [ "$EVICT_CHECK" = "0" ]; then
    echo -e "${COLOR_GREEN}✅ Cache EVICT operation successful${COLOR_NC}"
    echo "   Key deleted successfully"
else
    echo -e "${COLOR_RED}❌ Cache EVICT operation failed${COLOR_NC}"
fi
echo ""

# Test 9: Test Cache Error Handling (if service is running)
if [ "$SERVICE_RUNNING" = true ]; then
    echo -e "${COLOR_YELLOW}[TEST 9] Testing Cache Integration with Service${COLOR_NC}"
    
    # Register a test user first
    REGISTER_RESPONSE=$(curl -s -X POST "${BASE_URL}/api/auth/register" \
        -H "Content-Type: application/json" \
        -d "{\"email\":\"cachetest_$(date +%s)@example.com\",\"password\":\"Test123!\",\"fullName\":\"Cache Test User\",\"role\":\"USER\"}")
    
    USER_ID=$(echo "$REGISTER_RESPONSE" | grep -o '"id":"[^"]*' | cut -d'"' -f4)
    
    if [ -n "$USER_ID" ]; then
        echo "   Test user created: $USER_ID"
        
        # Login to get token
        LOGIN_RESPONSE=$(curl -s -X POST "${BASE_URL}/api/auth/login" \
            -H "Content-Type: application/json" \
            -d "{\"email\":\"cachetest_$(date +%s)@example.com\",\"password\":\"Test123!\"}")
        
        TOKEN=$(echo "$LOGIN_RESPONSE" | grep -o '"token":"[^"]*' | cut -d'"' -f4)
        
        if [ -n "$TOKEN" ]; then
            echo "   Token obtained"
            
            # First request - should hit database and populate cache
            echo "   Making first profile request (should hit DB)..."
            FIRST_RESPONSE=$(curl -s -X GET "${BASE_URL}/api/users/profile" \
                -H "Authorization: Bearer $TOKEN")
            
            # Check if cache entry was created
            CACHE_EXISTS=$(redis-cli EXISTS "user:profile:${USER_ID}" 2>&1)
            if [ "$CACHE_EXISTS" = "1" ]; then
                echo -e "${COLOR_GREEN}✅ Cache entry created after first request${COLOR_NC}"
                
                # Second request - should hit cache
                echo "   Making second profile request (should hit cache)..."
                SECOND_RESPONSE=$(curl -s -X GET "${BASE_URL}/api/users/profile" \
                    -H "Authorization: Bearer $TOKEN")
                
                CACHE_VALUE=$(redis-cli GET "user:profile:${USER_ID}" 2>&1)
                echo -e "${COLOR_GREEN}✅ Cache is working! Key exists: user:profile:${USER_ID}${COLOR_NC}"
            else
                echo -e "${COLOR_YELLOW}⚠️  Cache entry not found. This might be normal if cache is disabled.${COLOR_NC}"
            fi
        fi
    fi
else
    echo -e "${COLOR_YELLOW}[TEST 9] Skipped - Service not running${COLOR_NC}"
    echo "   To test full integration:"
    echo "   1. Start MySQL and ensure database exists"
    echo "   2. Start user-service: cd user-service && mvn spring-boot:run"
    echo "   3. Register a user and get profile - cache should be populated"
    echo "   4. Run: redis-cli GET 'user:profile:{userId}' to verify"
fi
echo ""

# Test 10: List all user profile cache keys
echo -e "${COLOR_YELLOW}[TEST 10] Listing all user profile cache keys${COLOR_NC}"
CACHE_KEYS=$(redis-cli KEYS "user:profile:*" 2>&1 | head -10)
if [ -n "$CACHE_KEYS" ]; then
    echo "Found cache keys:"
    echo "$CACHE_KEYS" | while read -r key; do
        if [ -n "$key" ]; then
            TTL=$(redis-cli TTL "$key" 2>&1)
            echo "   - $key (TTL: $TTL seconds)"
        fi
    done
else
    echo "   No cache keys found"
fi
echo ""

# Summary
echo "========================================="
echo "CACHE TEST SUMMARY"
echo "========================================="
echo -e "${COLOR_GREEN}✅ Redis Connection: OK${COLOR_NC}"
echo -e "${COLOR_GREEN}✅ Cache PUT Operation: OK${COLOR_NC}"
echo -e "${COLOR_GREEN}✅ Cache GET Operation: OK${COLOR_NC}"
echo -e "${COLOR_GREEN}✅ Cache TTL: OK${COLOR_NC}"
echo -e "${COLOR_GREEN}✅ Cache EVICT Operation: OK${COLOR_NC}"
echo ""
echo "To test cache with the actual service:"
echo "1. Ensure MySQL is running and accessible"
echo "2. Start user-service: cd user-service && mvn spring-boot:run"
echo "3. Register a user via POST /api/auth/register"
echo "4. Login and get profile via GET /api/users/profile"
echo "5. Check Redis: redis-cli GET 'user:profile:{userId}'"
echo "6. Make the same profile request again - should be faster (cache hit)"
echo ""

