package com.hashedin.parking.payment.mq;

import com.hashedin.parking.common.events.Events;
import com.hashedin.parking.common.model.PaymentStatus;
import com.hashedin.parking.payment.model.Payment;
import com.hashedin.parking.payment.repo.PaymentRepo;
import com.hashedin.parking.payment.service.PaymentCache;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.Duration;
import java.util.List;

@Component
public class BookingListener {

    private static final Logger log = LoggerFactory.getLogger(BookingListener.class);
    private final PaymentRepo paymentRepo;
    private final PaymentCache cache;

    public BookingListener(PaymentRepo paymentRepo, PaymentCache cache) {
        this.paymentRepo = paymentRepo;
        this.cache = cache;
    }

    // NOTE: nested YAML key
    @RabbitListener(queues = "${app.queues.paymentService.bookingCreated}")
    @Transactional
    public void onBookingCreated(Events.BookingCreated ev) {
        log.info("Payment init for booking {}", ev.bookingId());

        // Check if payment already exists for this booking
        if (paymentRepo.existsByBookingIdAndStatus(ev.bookingId(), "PENDING")) {
            log.info("Payment already exists for booking {}, skipping creation", ev.bookingId());
            return;
        }

        Payment p = new Payment();
        p.setBookingId(ev.bookingId());
        p.setUserId(ev.userId());
        p.setAmount(new BigDecimal("100.00"));
        p.setStatus("PENDING");
        Payment saved = paymentRepo.save(p);

        log.info("Payment {} created for booking {}", saved.getId(), ev.bookingId());
        // Cache the payment
        cache.putPayment(saved, Duration.ofMinutes(30));

        // Evict related caches
        cache.evictUserPayments(saved.getUserId());
        cache.evictBookingPayments(saved.getBookingId());
        cache.evictPaymentsByStatus("PENDING");

        log.info("Created payment {} for booking {}", saved.getId(), ev.bookingId());
    }

    @RabbitListener(queues = "${app.queues.paymentService.bookingCancelled}")
    @Transactional
    public void onBookingCancelled(Events.BookingCancelled ev) {
        log.info("Processing booking cancellation for booking {}", ev.bookingId());
        
        List<Payment> payments = paymentRepo.findByBookingId(ev.bookingId());
        if (payments.isEmpty()) {
            log.info("No payment found for cancelled booking {}", ev.bookingId());
            return;
        }

        log.info("Found {} payment(s) for cancelled booking {}", payments.size(), ev.bookingId());
        
        // Process all payments for this booking
        for (Payment p : payments) {
            PaymentStatus status = PaymentStatus.valueOf(p.getStatus());
            log.info("Processing payment {} for cancelled booking {}, status: {}", p.getId(), ev.bookingId(), p.getStatus());
            
            // Cancel payment if it's in a cancellable state
            if (status == PaymentStatus.PENDING) {
                p.setStatus(PaymentStatus.CANCELLED.name());
                paymentRepo.save(p);
                
                log.info("Payment {} cancelled due to booking cancellation", p.getId());
            } else if (status == PaymentStatus.FAILED) {
                // If payment is already failed, mark as cancelled
                p.setStatus(PaymentStatus.CANCELLED.name());
                paymentRepo.save(p);
                
                log.info("Payment {} marked as cancelled (was already failed)", p.getId());
            } else if (status == PaymentStatus.COMPLETED) {
                // Can't silently flip completed -> cancelled. Initiate refund flow:
                p.setStatus(PaymentStatus.REFUND_REQUESTED.name());
                paymentRepo.save(p);
                
                log.info("Payment {} refund requested due to booking cancellation", p.getId());
                // Actual refund processing might be async / external, not in this service
            } else {
                log.info("Payment {} status {} requires no action for booking cancellation", p.getId(), p.getStatus());
            }
        }
        
        // Update cache after processing all payments
        if (!payments.isEmpty()) {
            Payment firstPayment = payments.get(0);
            cache.evictUserPayments(firstPayment.getUserId());
            cache.evictBookingPayments(ev.bookingId());
            cache.evictPaymentsByStatus("PENDING");
            cache.evictPaymentsByStatus("FAILED");
            cache.evictPaymentsByStatus("COMPLETED");
            cache.evictPaymentsByStatus("CANCELLED");
            cache.evictPaymentsByStatus("REFUND_REQUESTED");
        }
        
        log.info("Completed processing {} payment(s) for cancelled booking {}", payments.size(), ev.bookingId());
    }

}
