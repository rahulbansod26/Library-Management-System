package com.hashedin.parking.payment.service;

import java.time.Duration;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import com.hashedin.parking.payment.model.Payment;

@Component
public class PaymentCache {
    private static final Logger log = LoggerFactory.getLogger(PaymentCache.class);
    
    private final RedisTemplate<String, Object> redis;
    
    public PaymentCache(RedisTemplate<String, Object> redis) {
        this.redis = redis;
    }
    
    private String userPaymentsKey(UUID userId) {
        return "payments:user:" + userId;
    }
    
    private String bookingPaymentsKey(UUID bookingId) {
        return "payments:booking:" + bookingId;
    }
    
    private String paymentKey(UUID paymentId) {
        return "payment:" + paymentId;
    }
    
    private String statusPaymentsKey(String status) {
        return "payments:status:" + status;
    }
    
    public List<Payment> getUserPayments(UUID userId) {
        try {
            Object cached = redis.opsForValue().get(userPaymentsKey(userId));
            if (cached instanceof List<?> list) {
                @SuppressWarnings("unchecked")
                List<Payment> payments = (List<Payment>) list;
                log.debug("Cache HIT for user payments: {}", userId);
                return payments;
            }
            log.debug("Cache MISS for user payments: {}", userId);
        } catch (Exception e) {
            log.warn("Failed to get user payments from cache for user {}: {}", userId, e.getMessage());
        }
        return null;
    }
    
    public void putUserPayments(UUID userId, List<Payment> payments, Duration ttl) {
        try {
            redis.opsForValue().set(userPaymentsKey(userId), payments, ttl.toSeconds(), TimeUnit.SECONDS);
            log.debug("Cached user payments for user: {} ({} payments)", userId, payments.size());
        } catch (Exception e) {
            log.warn("Failed to put user payments in cache for user {}: {}", userId, e.getMessage());
        }
    }
    
    public List<Payment> getBookingPayments(UUID bookingId) {
        try {
            Object cached = redis.opsForValue().get(bookingPaymentsKey(bookingId));
            if (cached instanceof List<?> list) {
                @SuppressWarnings("unchecked")
                List<Payment> payments = (List<Payment>) list;
                log.debug("Cache HIT for booking payments: {}", bookingId);
                return payments;
            }
            log.debug("Cache MISS for booking payments: {}", bookingId);
        } catch (Exception e) {
            log.warn("Failed to get booking payments from cache for booking {}: {}", bookingId, e.getMessage());
        }
        return null;
    }
    
    public void putBookingPayments(UUID bookingId, List<Payment> payments, Duration ttl) {
        try {
            redis.opsForValue().set(bookingPaymentsKey(bookingId), payments, ttl.toSeconds(), TimeUnit.SECONDS);
            log.debug("Cached booking payments for booking: {} ({} payments)", bookingId, payments.size());
        } catch (Exception e) {
            log.warn("Failed to put booking payments in cache for booking {}: {}", bookingId, e.getMessage());
        }
    }
    
    public Payment getPayment(UUID paymentId) {
        try {
            Object cached = redis.opsForValue().get(paymentKey(paymentId));
            if (cached instanceof Payment payment) {
                log.debug("Cache HIT for payment: {}", paymentId);
                return payment;
            }
            log.debug("Cache MISS for payment: {}", paymentId);
        } catch (Exception e) {
            log.warn("Failed to get payment from cache for payment {}: {}", paymentId, e.getMessage());
        }
        return null;
    }
    
    public void putPayment(Payment payment, Duration ttl) {
        try {
            redis.opsForValue().set(paymentKey(payment.getId()), payment, ttl.toSeconds(), TimeUnit.SECONDS);
            log.debug("Cached payment: {}", payment.getId());
        } catch (Exception e) {
            log.warn("Failed to put payment in cache for payment {}: {}", payment.getId(), e.getMessage());
        }
    }
    
    public List<Payment> getPaymentsByStatus(String status) {
        try {
            Object cached = redis.opsForValue().get(statusPaymentsKey(status));
            if (cached instanceof List<?> list) {
                @SuppressWarnings("unchecked")
                List<Payment> payments = (List<Payment>) list;
                log.debug("Cache HIT for payments by status: {}", status);
                return payments;
            }
            log.debug("Cache MISS for payments by status: {}", status);
        } catch (Exception e) {
            log.warn("Failed to get payments by status from cache for status {}: {}", status, e.getMessage());
        }
        return null;
    }
    
    public void putPaymentsByStatus(String status, List<Payment> payments, Duration ttl) {
        try {
            redis.opsForValue().set(statusPaymentsKey(status), payments, ttl.toSeconds(), TimeUnit.SECONDS);
            log.debug("Cached payments by status: {} ({} payments)", status, payments.size());
        } catch (Exception e) {
            log.warn("Failed to put payments by status in cache for status {}: {}", status, e.getMessage());
        }
    }
    
    public void evictUserPayments(UUID userId) {
        try {
            redis.delete(userPaymentsKey(userId));
            log.debug("Evicted user payments cache for user: {}", userId);
        } catch (Exception e) {
            log.warn("Failed to evict user payments cache for user {}: {}", userId, e.getMessage());
        }
    }
    
    public void evictBookingPayments(UUID bookingId) {
        try {
            redis.delete(bookingPaymentsKey(bookingId));
            log.debug("Evicted booking payments cache for booking: {}", bookingId);
        } catch (Exception e) {
            log.warn("Failed to evict booking payments cache for booking {}: {}", bookingId, e.getMessage());
        }
    }
    
    public void evictPayment(UUID paymentId) {
        try {
            redis.delete(paymentKey(paymentId));
            log.debug("Evicted payment cache for payment: {}", paymentId);
        } catch (Exception e) {
            log.warn("Failed to evict payment cache for payment {}: {}", paymentId, e.getMessage());
        }
    }
    
    public void evictPaymentsByStatus(String status) {
        try {
            redis.delete(statusPaymentsKey(status));
            log.debug("Evicted payments by status cache for status: {}", status);
        } catch (Exception e) {
            log.warn("Failed to evict payments by status cache for status {}: {}", status, e.getMessage());
        }
    }
    
    public Object getPaymentsByDateRange(String cacheKey) {
        try {
            Object cached = redis.opsForValue().get("payments:dateRange:" + cacheKey);
            if (cached != null) {
                log.debug("Cache HIT for payments by date range: {}", cacheKey);
            } else {
                log.debug("Cache MISS for payments by date range: {}", cacheKey);
            }
            return cached;
        } catch (Exception e) {
            log.warn("Failed to get payments by date range from cache for key {}: {}", cacheKey, e.getMessage());
            return null;
        }
    }
    
    public void putPaymentsByDateRange(String cacheKey, List<Payment> payments, Duration ttl) {
        try {
            redis.opsForValue().set("payments:dateRange:" + cacheKey, payments, ttl.toSeconds(), TimeUnit.SECONDS);
            log.debug("Cached payments by date range: {} ({} payments)", cacheKey, payments.size());
        } catch (Exception e) {
            log.warn("Failed to put payments by date range in cache for key {}: {}", cacheKey, e.getMessage());
        }
    }
    
    public void evictPaymentsByDateRange(String cacheKey) {
        try {
            redis.delete("payments:dateRange:" + cacheKey);
            log.debug("Evicted payments by date range cache for key: {}", cacheKey);
        } catch (Exception e) {
            log.warn("Failed to evict payments by date range cache for key {}: {}", cacheKey, e.getMessage());
        }
    }

    public void evictAllPaymentCaches() {
        try {
            int deleted = 0;
            // Use SCAN instead of keys() to avoid blocking
            Set<String> keysToDelete = redis.keys("payments:*");
            if (keysToDelete != null && !keysToDelete.isEmpty()) {
                redis.delete(keysToDelete);
                deleted += keysToDelete.size();
            }
            
            Set<String> paymentKeys = redis.keys("payment:*");
            if (paymentKeys != null && !paymentKeys.isEmpty()) {
                redis.delete(paymentKeys);
                deleted += paymentKeys.size();
            }
            
            log.info("Evicted all payment caches: {} keys deleted", deleted);
        } catch (Exception e) {
            log.warn("Failed to evict all payment caches: {}", e.getMessage());
        }
    }
}
