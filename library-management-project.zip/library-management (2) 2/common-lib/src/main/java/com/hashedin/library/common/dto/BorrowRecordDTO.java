package com.hashedin.library.common.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.time.LocalDate;

public class BorrowRecordDTO {
    public enum Status { ACTIVE, RETURNED, OVERDUE, LOST }
    
    private String id;
    private String userId;
    private String bookId;
    
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate startDate;
    
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate endDate;
    
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate returnDate;
    
    private Status status;

    // Constructors
    public BorrowRecordDTO() {}

    public BorrowRecordDTO(String id, String userId, String bookId, LocalDate startDate, 
                          LocalDate endDate, LocalDate returnDate, Status status) {
        this.id = id;
        this.userId = userId;
        this.bookId = bookId;
        this.startDate = startDate;
        this.endDate = endDate;
        this.returnDate = returnDate;
        this.status = status;
    }

    // Getters
    public String getId() { return id; }
    public String getUserId() { return userId; }
    public String getBookId() { return bookId; }
    public LocalDate getStartDate() { return startDate; }
    public LocalDate getEndDate() { return endDate; }
    public LocalDate getReturnDate() { return returnDate; }
    public Status getStatus() { return status; }

    // Setters
    public void setId(String id) { this.id = id; }
    public void setUserId(String userId) { this.userId = userId; }
    public void setBookId(String bookId) { this.bookId = bookId; }
    public void setStartDate(LocalDate startDate) { this.startDate = startDate; }
    public void setEndDate(LocalDate endDate) { this.endDate = endDate; }
    public void setReturnDate(LocalDate returnDate) { this.returnDate = returnDate; }
    public void setStatus(Status status) { this.status = status; }
}

