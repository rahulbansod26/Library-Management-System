package com.hashedin.library.common.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;

import java.security.Key;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class JwtUtil {
    
    public static Claims parseToken(String token, String secret) {
        Key key = Keys.hmacShaKeyFor(secret.getBytes());
        return Jwts.parserBuilder()
                .setSigningKey(key)
                .build()
                .parseClaimsJws(token)
                .getBody();
    }
    
    public static String getSubject(String token, String secret) {
        return parseToken(token, secret).getSubject();
    }
    
    public static List<String> extractRoles(String token, String secret) {
        Claims claims = parseToken(token, secret);
        Object rolesObj = claims.get("roles");
        if (rolesObj == null) {
            return List.of();
        }
        
        // Roles are stored as a string representation like "[ROLE_USER, ROLE_LIBRARIAN]"
        // The toString() of List<GrantedAuthority> produces this format
        String rolesStr = rolesObj.toString();
        // Remove brackets and split by comma
        rolesStr = rolesStr.replaceAll("[\\[\\]]", "");
        return Arrays.stream(rolesStr.split(","))
                .map(String::trim)
                .filter(s -> !s.isEmpty() && s.startsWith("ROLE_"))
                .collect(Collectors.toList());
    }
    
    public static boolean hasRole(String token, String secret, String role) {
        String expectedRole = role.startsWith("ROLE_") ? role : "ROLE_" + role;
        return extractRoles(token, secret).contains(expectedRole);
    }
}

