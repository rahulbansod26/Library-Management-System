package com.hashedin.library.common.dto;

import lombok.NonNull;

public record UpdateStatusRequest(@NonNull String status) {
}

