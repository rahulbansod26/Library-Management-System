package com.hashedin.library.common.dto;

import jakarta.validation.constraints.NotBlank;

public record ApproveRejectRequest(@NotBlank String librarianId) {
}

