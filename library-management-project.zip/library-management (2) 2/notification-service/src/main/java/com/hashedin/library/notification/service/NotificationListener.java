package com.hashedin.library.notification.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hashedin.library.common.events.BookOverdueEvent;
import com.hashedin.library.common.events.BookReturnedEvent;
import com.hashedin.library.common.events.BorrowApprovedEvent;
import com.hashedin.library.common.events.FineUpdatedEvent;
import com.hashedin.library.common.events.PaymentCompletedEvent;
import com.hashedin.library.common.events.UserPasswordResetEvent;
import com.hashedin.library.common.events.UserProfileChangedEvent;
import com.hashedin.library.common.events.UserRegisteredEvent;
import com.hashedin.library.notification.client.UserServiceClient;
import com.hashedin.library.notification.domain.Notification;
import com.hashedin.library.notification.repo.NotificationRepo;

@Service
public class NotificationListener {
    private static final Logger log = LoggerFactory.getLogger(NotificationListener.class);

    private final EmailService emailService;
    private final NotificationRepo notificationRepo;
    private final UserServiceClient userServiceClient;

    @Autowired
    public NotificationListener(EmailService emailService, NotificationRepo notificationRepo, UserServiceClient userServiceClient) {
        this.emailService = emailService;
        this.notificationRepo = notificationRepo;
        this.userServiceClient = userServiceClient;
    }

    @Async
    @Transactional
    private void sendEmailAndStoreNotification(String userId, String email, String subject, String body, String type, String title) {
        try {
            // Fetch email if not provided
            String userEmail = email;
            if ((userEmail == null || userEmail.isEmpty()) && userId != null) {
                try {
                    userEmail = userServiceClient.getUserEmailByUserId(userId);
                    if (userEmail == null || userEmail.isEmpty()) {
                        log.warn("Could not fetch email for user {} - notification will be stored but not emailed", userId);
                    }
                } catch (Exception e) {
                    log.warn("Error fetching email for user {}: {}", userId, e.getMessage());
                }
            }

            // Send email if email address is available and email service is configured
            if (userEmail != null && !userEmail.isEmpty() && emailService.isConfigured()) {
                try {
                    emailService.send(userEmail, subject, body);
                } catch (Exception mailEx) {
                    log.error("[EMAIL ERROR] Failed to send email to {}: {}", userEmail, mailEx.getMessage());
                    // Continue to store notification even if email fails
                }
            } else if (userEmail != null && !userEmail.isEmpty() && !emailService.isConfigured()) {
                log.warn("Email service not configured - notification stored but not emailed to {}", userEmail);
            }
            
            // Always store notification
            Notification notification = new Notification();
            notification.setUserId(userId);
            notification.setType(type);
            notification.setTitle(title);
            notification.setMessage(body);
            notificationRepo.save(notification);
            
            log.info("[NOTIFICATION STORED] {} notification stored for user {}", type, userId);
        } catch (Exception ex) {
            log.error("[ERROR] Failed to process {} notification for user {}: {}", type, userId, ex.getMessage(), ex);
            // Still try to store notification even if email fails
            try {
                Notification notification = new Notification();
                notification.setUserId(userId);
                notification.setType(type);
                notification.setTitle(title);
                notification.setMessage(body);
                notificationRepo.save(notification);
            } catch (Exception storeEx) {
                log.error("[ERROR] Failed to store notification: {}", storeEx.getMessage(), storeEx);
            }
        }
    }

    // USER EVENTS
    @RabbitListener(queues = "user.events.q")
    public void onUserRegistered(UserRegisteredEvent e){
        log.info("[EVENT RECEIVED] UserRegisteredEvent: userId={}, email={}, name={}", e.getUserId(), e.getEmail(), e.getName());
        sendEmailAndStoreNotification(
            e.getUserId(),
            e.getEmail(),
            "Welcome to Library Management System!",
            "Dear " + e.getName() + ",\n\n" +
                    "Welcome to our Library Management System! Your account has been successfully created.\n\n" +
                    "You can now:\n" +
                    "- Browse and search books\n" +
                    "- Borrow books\n" +
                    "- Manage your profile\n\n" +
                    "Thank you for joining us!\n\n" +
                    "Best regards,\n" +
                    "Library Management Team",
            "USER_REGISTERED",
            "Welcome to Library Management System!"
        );
    }

    @RabbitListener(queues = "user.events.q")
    public void onPasswordReset(UserPasswordResetEvent e){
        sendEmailAndStoreNotification(
            e.getUserId(),
            e.getEmail(),
            "Password Reset Request",
            "Dear User,\n\n" +
                    "You have requested a password reset for your Library Management System account.\n\n" +
                    "Reset Token: " + e.getResetToken() + "\n\n" +
                    "Please use this token to reset your password. This token will expire in 30 minutes.\n\n" +
                    "If you did not request this reset, please ignore this email.\n\n" +
                    "Best regards,\n" +
                    "Library Management Team",
            "PASSWORD_RESET",
            "Password Reset Request"
        );
    }

    @RabbitListener(queues = "user.events.q")
    public void onProfileChanged(UserProfileChangedEvent e){
        sendEmailAndStoreNotification(
            e.getUserId(),
            e.getEmail(),
            "Profile Updated Successfully",
            "Dear User,\n\n" +
                    "Your profile has been successfully updated in the Library Management System.\n\n" +
                    "If you did not make this change, please contact our support team immediately.\n\n" +
                    "Best regards,\n" +
                    "Library Management Team",
            "PROFILE_CHANGED",
            "Profile Updated"
        );
    }

    // BORROW EVENTS
    @RabbitListener(queues = "borrow.events.q")
    public void onBorrowApproved(BorrowApprovedEvent e){
        sendEmailAndStoreNotification(
            e.getUserId(),
            null, // Email will need to be fetched if needed
            "Book Borrowing Confirmed",
            "Your book borrowing request has been approved.\n\n" +
                    "Book ID: " + e.getBookId() + "\n" +
                    "Due Date: " + e.getDueDate().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) + "\n\n" +
                    "Please return the book by the due date to avoid fines.\n\n" +
                    "Best regards,\n" +
                    "Library Management Team",
            "BORROW_APPROVED",
            "Book Borrowing Confirmed"
        );
    }

    @RabbitListener(queues = "borrow.events.q")
    public void onBookReturned(BookReturnedEvent e){
        sendEmailAndStoreNotification(
            e.getUserId(),
            null,
            "Book Return Confirmed",
            "Thank you for returning the book!\n\n" +
                    "Book ID: " + e.getBookId() + "\n" +
                    "Return Date: " + LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) + "\n\n" +
                    "We hope you enjoyed reading the book. Feel free to borrow more books!\n\n" +
                    "Best regards,\n" +
                    "Library Management Team",
            "BOOK_RETURNED",
            "Book Return Confirmed"
        );
    }

    @RabbitListener(queues = "borrow.events.q")
    public void onBookOverdue(BookOverdueEvent e){
        sendEmailAndStoreNotification(
            e.getUserId(),
            null,
            "Book Overdue Alert",
            "This is to inform you that the book you borrowed is now overdue.\n\n" +
                    "Book ID: " + e.getBookId() + "\n\n" +
                    "Please return the book as soon as possible to avoid additional fines.\n" +
                    "Fines will be calculated daily until the book is returned.\n\n" +
                    "Best regards,\n" +
                    "Library Management Team",
            "BOOK_OVERDUE",
            "Book Overdue Alert"
        );
    }

    // FINE EVENTS
    @RabbitListener(queues = "fine.events.q")
    public void onFineUpdated(FineUpdatedEvent e){
        sendEmailAndStoreNotification(
            e.getUserId(),
            null,
            "Fine Updated",
            "A fine has been applied to your account.\n\n" +
                    "Amount: $" + e.getAmount() + "\n" +
                    (e.getBorrowRecordId() != null ? "Borrow Record ID: " + e.getBorrowRecordId() + "\n" : "") +
                    "\nPlease pay the fine at your earliest convenience.\n\n" +
                    "Best regards,\n" +
                    "Library Management Team",
            "FINE_UPDATED",
            "Fine Updated"
        );
    }

    @RabbitListener(queues = "fine.events.q")
    public void onPaymentCompleted(PaymentCompletedEvent e){
        sendEmailAndStoreNotification(
            e.getUserId(),
            null,
            "Payment Confirmed",
            "Your payment has been successfully processed.\n\n" +
                    "Amount: $" + e.getAmount() + "\n" +
                    "Transaction ID: " + e.getPaymentId() + "\n" +
                    "Payment Date: " + LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) + "\n\n" +
                    "Thank you for your payment!\n\n" +
                    "Best regards,\n" +
                    "Library Management Team",
            "PAYMENT_COMPLETED",
            "Payment Confirmed"
        );
    }
}
