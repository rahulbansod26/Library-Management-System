package com.hashedin.library.notification.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;

/**
 * Configuration for async task execution.
 * Provides a dedicated thread pool for @Async methods used in scheduled tasks.
 * Note: @EnableAsync is already enabled in Application.java
 */
@Configuration
public class AsyncConfig {

    /**
     * Creates a thread pool executor for async scheduled tasks.
     * This executor is used by @Async methods in NotificationReminderService.
     * 
     * @return ThreadPoolTaskExecutor configured for async execution
     */
    @Bean(name = "taskExecutor")
    public Executor taskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(5);
        executor.setMaxPoolSize(10);
        executor.setQueueCapacity(100);
        executor.setThreadNamePrefix("notification-async-");
        executor.initialize();
        return executor;
    }
}

