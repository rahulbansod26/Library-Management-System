package com.hashedin.library.notification.client;

import com.hashedin.library.common.dto.BorrowRecordDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Component
public class BorrowServiceClient {
    private static final Logger log = LoggerFactory.getLogger(BorrowServiceClient.class);
    private final RestTemplate restTemplate;
    private static final String BORROW_SERVICE_NAME = "borrow-service";

    public BorrowServiceClient(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public List<BorrowRecordDTO> getActiveBorrows() {
        try {
            ResponseEntity<List<BorrowRecordDTO>> response = restTemplate.exchange(
                    "http://" + BORROW_SERVICE_NAME + "/api/borrow/active/all",
                    HttpMethod.GET,
                    null,
                    new ParameterizedTypeReference<List<BorrowRecordDTO>>() {}
            );
            return response.getBody() != null ? response.getBody() : List.of();
        } catch (Exception e) {
            log.error("Error fetching active borrows: {}", e.getMessage(), e);
            return List.of();
        }
    }

    public List<BorrowRecordDTO> getBorrowsDueInDays(int days) {
        try {
            ResponseEntity<List<BorrowRecordDTO>> response = restTemplate.exchange(
                    "http://" + BORROW_SERVICE_NAME + "/api/borrow/due-in-days/" + days,
                    HttpMethod.GET,
                    null,
                    new ParameterizedTypeReference<List<BorrowRecordDTO>>() {}
            );
            return response.getBody() != null ? response.getBody() : List.of();
        } catch (Exception e) {
            log.error("Error fetching borrows due in {} days: {}", days, e.getMessage(), e);
            return List.of();
        }
    }
}

