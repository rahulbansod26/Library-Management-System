package com.hashedin.library.notification.client;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

@Component
public class UserServiceClient {
    private static final Logger log = LoggerFactory.getLogger(UserServiceClient.class);
    private final RestTemplate restTemplate;
    private static final String USER_SERVICE_NAME = "user-service";

    public UserServiceClient(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public String getUserEmail(String userId) {
        try {
            // Try to get user by ID first
            ResponseEntity<Map<String, Object>> response = restTemplate.exchange(
                    "http://" + USER_SERVICE_NAME + "/api/profile/get",
                    HttpMethod.GET,
                    null,
                    new ParameterizedTypeReference<Map<String, Object>>() {}
            );
            
            Map<String, Object> body = response.getBody();
            if (body != null && body.containsKey("email")) {
                Object email = body.get("email");
                return email != null ? email.toString() : null;
            }
        } catch (Exception e) {
            log.warn("Could not fetch email for user {}: {}", userId, e.getMessage());
        }
        return null;
    }

    public Map<String, Object> getUserProfile(String email) {
        try {
            Map<String, String> requestBody = Map.of("email", email);
            org.springframework.http.HttpEntity<Map<String, String>> request = new org.springframework.http.HttpEntity<>(requestBody);
            ResponseEntity<Map<String, Object>> response = restTemplate.exchange(
                    "http://" + USER_SERVICE_NAME + "/api/profile/get",
                    HttpMethod.POST,
                    request,
                    new ParameterizedTypeReference<Map<String, Object>>() {}
            );
            return response.getBody();
        } catch (Exception e) {
            log.warn("Could not fetch profile for email {}: {}", email, e.getMessage());
            return null;
        }
    }

    public String getUserEmailByUserId(String userId) {
        try {
            ResponseEntity<Map<String, Object>> response = restTemplate.exchange(
                    "http://" + USER_SERVICE_NAME + "/api/profile/" + userId,
                    HttpMethod.GET,
                    null,
                    new ParameterizedTypeReference<Map<String, Object>>() {}
            );
            
            Map<String, Object> body = response.getBody();
            if (body != null && body.containsKey("email")) {
                Object email = body.get("email");
                return email != null ? email.toString() : null;
            }
        } catch (Exception e) {
            log.warn("Could not fetch email for user ID {}: {}", userId, e.getMessage());
        }
        return null;
    }
}

