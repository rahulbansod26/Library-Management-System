# Testing Instructions - Quick Start

## 🚀 Current Status

**Services are starting in the background!**

The `start-and-test.sh` script is currently:
1. ✅ Starting all 7 services (Eureka, User, Catalog, Borrow, Fine, Notification, Gateway)
2. ⏳ Waiting for services to initialize (~2-3 minutes)
3. ⏳ Will automatically run comprehensive API tests once ready

## 📊 Monitor Progress

### Check Service Status
```bash
./check-status.sh
```

### Check if Services are Ready
```bash
./check-services-ready.sh
```

### View Service Logs
```bash
# View all logs
tail -f logs/*.log

# View specific service log
tail -f logs/user-service.log
tail -f logs/catalog-service.log
# etc.
```

## ⏱️ Timeline

**Expected startup time:**
- Eureka: ~15 seconds
- User Service: ~20 seconds
- Catalog Service: ~20 seconds
- Borrow Service: ~20 seconds
- Fine Service: ~20 seconds
- Notification Service: ~20 seconds
- API Gateway: ~20 seconds
- **Total: ~2-3 minutes**

## 🧪 What Happens Next

Once services are ready, the script will automatically:
1. ✅ Verify all services are responding
2. ✅ Run comprehensive API tests (40+ endpoints)
3. ✅ Display test results and summary
4. ✅ Verify Eureka registration

## 📝 Manual Testing (Alternative)

If you want to test manually or the automated script didn't run tests:

```bash
# Wait for services to be ready (check with check-services-ready.sh)
# Then run:
./comprehensive-api-testing.sh
```

## 🔍 What to Check

### Eureka Dashboard
Open in browser: **http://localhost:8761**
- Should see all 6 services registered

### Service Health
All services should respond:
- User Service: http://localhost:8081
- Catalog Service: http://localhost:8082
- Borrow Service: http://localhost:8083
- Fine Service: http://localhost:8084
- Notification Service: http://localhost:8085
- API Gateway: http://localhost:7000

### Swagger Documentation
Once services are running, access Swagger UI:
- User Service: http://localhost:8081/swagger-ui.html
- Catalog Service: http://localhost:8082/swagger-ui.html
- Borrow Service: http://localhost:8083/swagger-ui.html
- Fine Service: http://localhost:8084/swagger-ui.html
- Notification Service: http://localhost:8085/swagger-ui.html

## 🛑 Stop Services

To stop all services:
```bash
./stop-all-services.sh
```

Or manually kill processes:
```bash
# If you have the PID file
kill $(cat logs/pids.txt | cut -d'=' -f2)
```

## 📋 Test Coverage

The comprehensive test script will test:

### Phase 1: User Service (7 tests)
- Registration (USER & LIBRARIAN)
- Login (both roles)
- Profile management
- Password reset

### Phase 2: Catalog Service (9 tests)
- CRUD operations
- Search functionality
- Book status updates

### Phase 3: Borrow Service (9 tests)
- Borrow/return operations
- Borrowing history
- Overdue detection

### Phase 4: Fine Service (7 tests)
- Fine retrieval
- Payment processing
- Fine calculation

### Phase 5: Notification Service (7 tests)
- Notification retrieval
- Email testing
- Mark as read

### Phase 6: Eureka Verification
- Service registration check

**Total: 40+ API endpoint tests**

## ⚠️ Troubleshooting

### Services not starting
- Check logs: `tail -f logs/*.log`
- Verify MySQL, RabbitMQ, Redis are running
- Check if ports are available: `lsof -i :8081`

### Tests failing
- Ensure services are fully started (wait 3-4 minutes)
- Check service logs for errors
- Verify database connections
- Check RabbitMQ queue status

### Email tests
- Email service is optional
- Check `application.yml` for SMTP config
- Notifications will still be stored even if email fails

## ✅ Success Indicators

You'll know everything is working when:
- ✅ All services show as "READY" in check-services-ready.sh
- ✅ Eureka dashboard shows all 6 services
- ✅ Comprehensive tests show mostly/all passing
- ✅ No errors in service logs
- ✅ RabbitMQ queues are created
- ✅ Notifications are stored in database

---

**Current Action:** Services are starting. Wait 2-3 minutes, then check status with `./check-status.sh`

