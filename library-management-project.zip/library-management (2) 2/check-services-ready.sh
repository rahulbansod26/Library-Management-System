#!/bin/bash

# Quick Service Readiness Check Script

COLOR_GREEN='\033[0;32m'
COLOR_RED='\033[0;31m'
COLOR_YELLOW='\033[1;33m'
COLOR_BLUE='\033[0;34m'
COLOR_NC='\033[0m'

echo -e "${COLOR_BLUE}Checking service readiness...${COLOR_NC}"
echo ""

# Function to check service
check_service() {
    local port=$1
    local name=$2
    local url=$3
    
    if curl -s -f "${url}" > /dev/null 2>&1 || \
       curl -s -f "${url}/actuator/health" > /dev/null 2>&1 || \
       curl -s -f "${url}/api" > /dev/null 2>&1; then
        echo -e "${COLOR_GREEN}✓ ${name} (port ${port})${COLOR_NC}"
        return 0
    else
        echo -e "${COLOR_RED}✗ ${name} (port ${port}) - NOT READY${COLOR_NC}"
        return 1
    fi
}

# Check all services
ALL_READY=true

check_service 8761 "Eureka Service Discovery" "http://localhost:8761" || ALL_READY=false
check_service 8081 "User Service" "http://localhost:8081" || ALL_READY=false
check_service 8082 "Catalog Service" "http://localhost:8082" || ALL_READY=false
check_service 8083 "Borrow Service" "http://localhost:8083" || ALL_READY=false
check_service 8084 "Fine Service" "http://localhost:8084" || ALL_READY=false
check_service 8085 "Notification Service" "http://localhost:8085" || ALL_READY=false
check_service 7000 "API Gateway" "http://localhost:7000" || ALL_READY=false

echo ""

if [ "$ALL_READY" = true ]; then
    echo -e "${COLOR_GREEN}All services are ready!${COLOR_NC}"
    echo -e "${COLOR_BLUE}You can now run: ./comprehensive-api-testing.sh${COLOR_NC}"
    exit 0
else
    echo -e "${COLOR_RED}Some services are not ready.${COLOR_NC}"
    echo -e "${COLOR_YELLOW}Please wait for all services to start before running tests.${COLOR_NC}"
    exit 1
fi

