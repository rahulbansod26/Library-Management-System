package com.hashedin.library.user.UserService;

import java.util.Optional;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.hashedin.library.common.events.RoutingKeys;
import com.hashedin.library.common.events.UserRegisteredEvent;
import com.hashedin.library.common.security.Role;
import com.hashedin.library.user.UserDto.User;
import com.hashedin.library.user.UserRepository.PasswordResetTokenRepo;
import com.hashedin.library.user.UserRepository.UserRepo;

@ExtendWith(MockitoExtension.class)
class UserServiceTest {

    @Mock
    private UserRepo repo;

    @Mock
    private PasswordResetTokenRepo tokenRepo;

    @Mock
    private PasswordEncoder encoder;

    @Mock
    private RabbitTemplate rabbit;

    @Mock
    private TopicExchange exchange;

    @InjectMocks
    private UserService userService;

    private User testUser;

    @BeforeEach
    void setUp() {
        testUser = new User();
        testUser.setId("user-123");
        testUser.setEmail("test@example.com");
        testUser.setName("Test User");
        testUser.setPasswordHash("encodedPassword");
        testUser.setRoles(Set.of(Role.USER));
    }

    @Test
    void testRegister_Success() {
        // Arrange
        String email = "newuser@example.com";
        String name = "New User";
        String password = "password123";
        Set<Role> roles = Set.of(Role.USER);
        String encodedPassword = "encodedPassword123";

        when(encoder.encode(password)).thenReturn(encodedPassword);
        when(repo.save(any(User.class))).thenAnswer(invocation -> {
            User user = invocation.getArgument(0);
            user.setId("new-user-id");
            return user;
        });
        when(exchange.getName()).thenReturn("library-exchange");

        // Act
        User result = userService.register(email, name, password, roles);

        // Assert
        assertNotNull(result);
        assertEquals(email, result.getEmail());
        assertEquals(name, result.getName());
        assertEquals(encodedPassword, result.getPasswordHash());
        assertEquals(roles, result.getRoles());

        // Verify event was published
        ArgumentCaptor<UserRegisteredEvent> eventCaptor = ArgumentCaptor.forClass(UserRegisteredEvent.class);
        verify(rabbit).convertAndSend(eq("library-exchange"), eq(RoutingKeys.USER_REGISTERED), eventCaptor.capture());
        
        UserRegisteredEvent event = eventCaptor.getValue();
        assertEquals(result.getId(), event.getUserId());
        assertEquals(email, event.getEmail());
        assertEquals(name, event.getName());
    }

    @Test
    void testRegister_DefaultRole() {
        // Arrange
        String email = "user@example.com";
        String name = "User";
        String password = "password123";
        String encodedPassword = "encodedPassword123";

        when(encoder.encode(password)).thenReturn(encodedPassword);
        when(repo.save(any(User.class))).thenAnswer(invocation -> {
            User user = invocation.getArgument(0);
            user.setId("user-id");
            return user;
        });
        when(exchange.getName()).thenReturn("library-exchange");

        // Act - register with null roles
        User result = userService.register(email, name, password, null);

        // Assert - should default to USER role
        assertNotNull(result);
        assertEquals(Set.of(Role.USER), result.getRoles());
    }

    @Test
    void testRegister_LibrarianRole() {
        // Arrange
        String email = "librarian@example.com";
        String name = "Librarian";
        String password = "password123";
        Set<Role> roles = Set.of(Role.LIBRARIAN);
        String encodedPassword = "encodedPassword123";

        when(encoder.encode(password)).thenReturn(encodedPassword);
        when(repo.save(any(User.class))).thenAnswer(invocation -> {
            User user = invocation.getArgument(0);
            user.setId("librarian-id");
            return user;
        });
        when(exchange.getName()).thenReturn("library-exchange");

        // Act
        User result = userService.register(email, name, password, roles);

        // Assert
        assertNotNull(result);
        assertEquals(roles, result.getRoles());
    }

    @Test
    void testFindByEmail_Success() {
        // Arrange
        String email = "test@example.com";
        when(repo.findByEmail(email)).thenReturn(Optional.of(testUser));

        // Act
        Optional<User> result = userService.findByEmail(email);

        // Assert
        assertTrue(result.isPresent());
        assertEquals(testUser.getEmail(), result.get().getEmail());
        verify(repo).findByEmail(email);
    }

    @Test
    void testFindByEmail_NotFound() {
        // Arrange
        String email = "nonexistent@example.com";
        when(repo.findByEmail(email)).thenReturn(Optional.empty());

        // Act
        Optional<User> result = userService.findByEmail(email);

        // Assert
        assertFalse(result.isPresent());
        verify(repo).findByEmail(email);
    }
}

