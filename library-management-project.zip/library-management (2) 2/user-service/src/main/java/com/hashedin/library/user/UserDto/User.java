package com.hashedin.library.user.UserDto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.hashedin.library.common.security.Role;
import jakarta.persistence.*;
import java.time.Instant;
import java.util.Set;

@Entity
@Table(name="users")
public class User {
    @Id 
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    
    @Column(unique = true, nullable = false)
    private String email;
    
    private String name;
    
    @JsonIgnore
    private String passwordHash;
    
    @ElementCollection(fetch = FetchType.EAGER)
    @Enumerated(EnumType.STRING)
    private Set<Role> roles;
    
    private Instant createdAt = Instant.now();

    // Getters
    public String getId() { return id; }
    public String getEmail() { return email; }
    public String getName() { return name; }
    public String getPasswordHash() { return passwordHash; }
    public Set<Role> getRoles() { return roles; }
    public Instant getCreatedAt() { return createdAt; }

    // Setters
    public void setId(String id) { this.id = id; }
    public void setEmail(String email) { this.email = email; }
    public void setName(String name) { this.name = name; }
    public void setPasswordHash(String passwordHash) { this.passwordHash = passwordHash; }
    public void setRoles(Set<Role> roles) { this.roles = roles; }
    public void setCreatedAt(Instant createdAt) { this.createdAt = createdAt; }
}
