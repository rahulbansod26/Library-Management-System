package com.hashedin.library.user.UserDto;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
public class PasswordResetToken {
    @Id 
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    
    @Column(nullable = false) 
    private String userId;
    
    @Column(nullable = false, unique = true) 
    private String token;
    
    @Column(nullable = false) 
    private Instant expiresAt;

    // Getters
    public String getId() { return id; }
    public String getUserId() { return userId; }
    public String getToken() { return token; }
    public Instant getExpiresAt() { return expiresAt; }

    // Setters
    public void setId(String id) { this.id = id; }
    public void setUserId(String userId) { this.userId = userId; }
    public void setToken(String token) { this.token = token; }
    public void setExpiresAt(Instant expiresAt) { this.expiresAt = expiresAt; }
}
