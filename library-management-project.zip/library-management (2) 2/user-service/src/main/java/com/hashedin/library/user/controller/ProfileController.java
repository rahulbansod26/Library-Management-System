
package com.hashedin.library.user.controller;

import com.hashedin.library.user.UserDto.User;
import com.hashedin.library.user.UserRepository.UserRepo;
import com.hashedin.library.user.UserService.UserService;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/profile")
public class ProfileController {
    private final UserService userService;
    private final UserRepo repo;

    public ProfileController(UserService userService, UserRepo repo){ this.userService=userService; this.repo=repo; }

    record GetProfileReq(@Email String email){}
    record UpdateProfileReq(@NotBlank String name){}

    /**
     * Gets user profile by email.
     * Users can only access their own profile.
     * Allows internal service-to-service calls (when no authentication is present).
     * 
     * @param req The request containing email
     * @return The user profile
     * @throws RuntimeException if user is authenticated but trying to access another user's profile
     */
    @PostMapping("/get")
    public ResponseEntity<User> getByEmail(@RequestBody GetProfileReq req){
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        
        // If authenticated with a real user (not anonymous), enforce authorization
        if (authentication != null && authentication.isAuthenticated() 
            && !authentication.getName().equals("anonymousUser") 
            && authentication.getName() != null) {
            String authenticatedEmail = authentication.getName();
            if (!authenticatedEmail.equals(req.email())) {
                throw new RuntimeException("Unauthorized: You can only access your own profile");
            }
        }
        // If not authenticated or anonymous (internal service call), allow access
        
        return repo.findByEmail(req.email()).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    /**
     * Gets user profile by user ID.
     * Users can only access their own profile.
     * Allows internal service-to-service calls (when no authentication is present).
     * 
     * @param userId The user ID
     * @return The user profile
     * @throws RuntimeException if user is authenticated but trying to access another user's profile
     */
    @GetMapping("/{userId}")
    public ResponseEntity<User> getById(@PathVariable String userId){
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        User user = repo.findById(userId).orElseThrow(() -> new RuntimeException("User not found"));
        
        // If authenticated with a real user (not anonymous), enforce authorization
        if (authentication != null && authentication.isAuthenticated() 
            && !authentication.getName().equals("anonymousUser") 
            && authentication.getName() != null) {
            String authenticatedEmail = authentication.getName();
            if (!authenticatedEmail.equals(user.getEmail())) {
                throw new RuntimeException("Unauthorized: You can only access your own profile");
            }
        }
        // If not authenticated or anonymous (internal service call), allow access
        
        return ResponseEntity.ok(user);
    }

    /**
     * Updates the authenticated user's profile.
     * Users can only update their own profile.
     * Requires authentication (not for internal service calls).
     * 
     * @param req The update request containing new name
     * @return The updated user profile
     * @throws RuntimeException if user is not authenticated
     */
    @PutMapping
    public ResponseEntity<User> update(@RequestBody UpdateProfileReq req){
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        
        // Update requires authentication - this is a user-initiated action
        if (authentication == null || !authentication.isAuthenticated() 
            || authentication.getName() == null 
            || authentication.getName().equals("anonymousUser")) {
            throw new RuntimeException("User not authenticated");
        }
        
        String authenticatedEmail = authentication.getName();
        User user = repo.findByEmail(authenticatedEmail).orElseThrow(() -> new RuntimeException("User not found"));
        
        return ResponseEntity.ok(userService.updateProfile(user.getId(), req.name()));
    }
}


