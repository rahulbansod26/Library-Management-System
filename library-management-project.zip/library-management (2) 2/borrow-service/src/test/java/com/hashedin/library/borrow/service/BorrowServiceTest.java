package com.hashedin.library.borrow.service;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.rabbit.core.RabbitTemplate;

import com.hashedin.library.borrow.client.CatalogServiceClient;
import com.hashedin.library.borrow.domain.BorrowRecord;
import com.hashedin.library.borrow.repo.BorrowRepo;
import com.hashedin.library.borrow.repo.BorrowRequestRepo;
import com.hashedin.library.common.dto.BookDTO;
import com.hashedin.library.common.events.BorrowApprovedEvent;
import com.hashedin.library.common.events.RoutingKeys;

@ExtendWith(MockitoExtension.class)
class BorrowServiceTest {

    @Mock
    private BorrowRepo repo;

    @Mock
    private BorrowRequestRepo requestRepo;

    @Mock
    private CatalogServiceClient catalogServiceClient;

    @Mock
    private RabbitTemplate rabbit;

    @Mock
    private TopicExchange exchange;

    @InjectMocks
    private BorrowService borrowService;

    private BookDTO testBook;
    private BorrowRecord testBorrowRecord;

    @BeforeEach
    void setUp() {
        testBook = new BookDTO();
        testBook.setId("book-123");
        testBook.setTitle("Test Book");
        testBook.setStatus(BookDTO.Status.AVAILABLE);
        testBook.setQuantity(5);

        testBorrowRecord = new BorrowRecord();
        testBorrowRecord.setId("borrow-123");
        testBorrowRecord.setUserId("user-123");
        testBorrowRecord.setBookId("book-123");
        testBorrowRecord.setStartDate(LocalDate.now());
        testBorrowRecord.setEndDate(LocalDate.now().plusDays(14));
        testBorrowRecord.setStatus(BorrowRecord.Status.ACTIVE);
    }

    @Test
    void testBorrow_Success() {
        // Arrange
        String userId = "user-123";
        String bookId = "book-123";
        int days = 14;

        when(catalogServiceClient.getBook(bookId)).thenReturn(testBook);
        when(repo.countByUserIdAndStatus(userId, BorrowRecord.Status.ACTIVE)).thenReturn(2L);
        when(repo.save(any(BorrowRecord.class))).thenAnswer(invocation -> {
            BorrowRecord record = invocation.getArgument(0);
            record.setId("new-borrow-id");
            return record;
        });
        when(exchange.getName()).thenReturn("library-exchange");

        // Act
        BorrowRecord result = borrowService.borrow(userId, bookId, days);

        // Assert
        assertNotNull(result);
        assertEquals(userId, result.getUserId());
        assertEquals(bookId, result.getBookId());
        assertEquals(BorrowRecord.Status.ACTIVE, result.getStatus());
        assertNotNull(result.getStartDate());
        assertNotNull(result.getEndDate());

        // Verify catalog service was called
        verify(catalogServiceClient).getBook(bookId);
        verify(catalogServiceClient).updateBookStatus(bookId, "BORROWED");

        // Verify event was published
        ArgumentCaptor<BorrowApprovedEvent> eventCaptor = ArgumentCaptor.forClass(BorrowApprovedEvent.class);
        verify(rabbit, atLeastOnce()).convertAndSend(eq("library-exchange"), eq(RoutingKeys.BORROW_APPROVED), eventCaptor.capture());
    }

    @Test
    void testBorrow_BookNotFound() {
        // Arrange
        String userId = "user-123";
        String bookId = "nonexistent";
        int days = 14;

        when(catalogServiceClient.getBook(bookId)).thenThrow(new RuntimeException("Book not found"));

        // Act & Assert
        assertThrows(Exception.class, () -> borrowService.borrow(userId, bookId, days));
        verify(catalogServiceClient).getBook(bookId);
        verify(repo, never()).save(any());
    }

    @Test
    void testGetActiveBorrows() {
        // Arrange
        List<BorrowRecord> records = Arrays.asList(testBorrowRecord);
        when(repo.findByStatus(BorrowRecord.Status.ACTIVE)).thenReturn(records);

        // Act
        List<BorrowRecord> result = borrowService.getActiveBorrows();

        // Assert
        assertEquals(1, result.size());
        assertEquals(testBorrowRecord.getId(), result.get(0).getId());
        verify(repo).findByStatus(BorrowRecord.Status.ACTIVE);
    }

    @Test
    void testGetBorrowingHistory() {
        // Arrange
        String userId = "user-123";
        List<BorrowRecord> records = Arrays.asList(testBorrowRecord);
        when(repo.findByUserIdOrderByStartDateDesc(userId)).thenReturn(records);

        // Act
        List<BorrowRecord> result = borrowService.getBorrowingHistory(userId);

        // Assert
        assertEquals(1, result.size());
        verify(repo).findByUserIdOrderByStartDateDesc(userId);
    }
}

