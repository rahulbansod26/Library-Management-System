package com.hashedin.library.borrow.client;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hashedin.library.common.dto.BookDTO;
import com.hashedin.library.common.dto.UpdateStatusRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

@Component
public class CatalogServiceClient {
    private static final Logger log = LoggerFactory.getLogger(CatalogServiceClient.class);
    private final RestTemplate restTemplate;
    private final ObjectMapper objectMapper;
    private static final String CATALOG_SERVICE_NAME = "catalog-service";

    public CatalogServiceClient(RestTemplate restTemplate, ObjectMapper objectMapper) {
        this.restTemplate = restTemplate;
        this.objectMapper = objectMapper != null ? objectMapper : new ObjectMapper();
    }

    public BookDTO getBook(String bookId) {
        try {
            String url = "http://" + CATALOG_SERVICE_NAME + "/api/books/" + bookId;
            log.info("Fetching book from catalog service: {}", url);
            // First fetch as Map to handle any deserialization issues
            ResponseEntity<Map<String, Object>> response = restTemplate.exchange(
                    url,
                    HttpMethod.GET,
                    null,
                    new ParameterizedTypeReference<Map<String, Object>>() {}
            );
            if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
                log.info("Successfully fetched book {} from catalog service", bookId);
                // Convert Map to BookDTO
                Map<String, Object> bookMap = response.getBody();
                BookDTO bookDTO = new BookDTO();
                bookDTO.setId((String) bookMap.get("id"));
                bookDTO.setTitle((String) bookMap.get("title"));
                bookDTO.setAuthor((String) bookMap.get("author"));
                bookDTO.setGenre((String) bookMap.get("genre"));
                bookDTO.setIsbn((String) bookMap.get("isbn"));
                bookDTO.setPublisher((String) bookMap.get("publisher"));
                bookDTO.setPublicationYear(bookMap.get("publicationYear") != null ? ((Number) bookMap.get("publicationYear")).intValue() : null);
                bookDTO.setDescription((String) bookMap.get("description"));
                if (bookMap.get("status") != null) {
                    try {
                        bookDTO.setStatus(BookDTO.Status.valueOf(bookMap.get("status").toString()));
                    } catch (IllegalArgumentException e) {
                        log.warn("Invalid status value: {}, defaulting to AVAILABLE", bookMap.get("status"));
                        bookDTO.setStatus(BookDTO.Status.AVAILABLE);
                    }
                }
                bookDTO.setQuantity(bookMap.get("quantity") != null ? ((Number) bookMap.get("quantity")).intValue() : 0);
                return bookDTO;
            } else {
                log.warn("Book {} not found in catalog service (status: {})", bookId, response.getStatusCode());
                return null;
            }
        } catch (org.springframework.web.client.HttpClientErrorException.NotFound e) {
            log.warn("Book {} not found in catalog service (404): {}", bookId, e.getResponseBodyAsString());
            return null;
        } catch (org.springframework.web.client.ResourceAccessException e) {
            log.error("Cannot access catalog service for book {}: {} - Service may be down or unreachable", bookId, e.getMessage());
            throw new RuntimeException("Catalog service unavailable: " + e.getMessage(), e);
        } catch (Exception e) {
            log.error("Error fetching book {} from catalog service: {} - Exception type: {}", 
                    bookId, e.getMessage(), e.getClass().getName(), e);
            throw new RuntimeException("Failed to fetch book from catalog service: " + e.getMessage(), e);
        }
    }

    public void updateBookStatus(String bookId, String status) {
        try {
            HttpEntity<UpdateStatusRequest> request = 
                new HttpEntity<>(new UpdateStatusRequest(status));
            restTemplate.exchange(
                    "http://" + CATALOG_SERVICE_NAME + "/api/books/" + bookId + "/status",
                    HttpMethod.PATCH,
                    request,
                    new ParameterizedTypeReference<BookDTO>() {}
            );
        } catch (Exception e) {
            log.error("Error updating book status for {} to {}: {}", bookId, status, e.getMessage(), e);
        }
    }
}

