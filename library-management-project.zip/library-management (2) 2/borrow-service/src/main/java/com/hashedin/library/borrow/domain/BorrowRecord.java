package com.hashedin.library.borrow.domain;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
public class BorrowRecord {
    public enum Status { ACTIVE, RETURNED, OVERDUE, LOST }
    
    @Id 
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    
    private String userId;
    private String bookId;
    private LocalDate startDate;
    private LocalDate endDate;
    private LocalDate returnDate;
    
    @Enumerated(EnumType.STRING)
    private Status status = Status.ACTIVE;

    // Getters
    public String getId() { return id; }
    public String getUserId() { return userId; }
    public String getBookId() { return bookId; }
    public LocalDate getStartDate() { return startDate; }
    public LocalDate getEndDate() { return endDate; }
    public LocalDate getReturnDate() { return returnDate; }
    public Status getStatus() { return status; }

    // Setters
    public void setId(String id) { this.id = id; }
    public void setUserId(String userId) { this.userId = userId; }
    public void setBookId(String bookId) { this.bookId = bookId; }
    public void setStartDate(LocalDate startDate) { this.startDate = startDate; }
    public void setEndDate(LocalDate endDate) { this.endDate = endDate; }
    public void setReturnDate(LocalDate returnDate) { this.returnDate = returnDate; }
    public void setStatus(Status status) { this.status = status; }
}
