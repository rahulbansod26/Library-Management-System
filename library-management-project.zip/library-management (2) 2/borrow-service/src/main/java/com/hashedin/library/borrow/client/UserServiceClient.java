package com.hashedin.library.borrow.client;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

@Component
public class UserServiceClient {
    private static final Logger log = LoggerFactory.getLogger(UserServiceClient.class);
    private final RestTemplate restTemplate;
    private static final String USER_SERVICE_NAME = "user-service";

    public UserServiceClient(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public String getUserIdByEmail(String email) {
        try {
            String url = "http://" + USER_SERVICE_NAME + "/api/profile/get";
            log.debug("Fetching user ID from user service for email: {}", email);
            
            Map<String, String> requestBody = Map.of("email", email);
            HttpEntity<Map<String, String>> request = new HttpEntity<>(requestBody);
            
            ResponseEntity<Map<String, Object>> response = restTemplate.exchange(
                    url,
                    HttpMethod.POST,
                    request,
                    new ParameterizedTypeReference<Map<String, Object>>() {}
            );
            
            if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
                Map<String, Object> userMap = response.getBody();
                if (userMap != null) {
                    Object id = userMap.get("id");
                    if (id != null) {
                        log.debug("Successfully fetched user ID: {} for email: {}", id, email);
                        return id.toString();
                    }
                }
            }
            log.warn("User not found for email: {}", email);
            return null;
        } catch (org.springframework.web.client.HttpClientErrorException.NotFound e) {
            log.warn("User not found for email {} (404): {}", email, e.getMessage());
            return null;
        } catch (org.springframework.web.client.ResourceAccessException e) {
            log.error("Cannot access user service for email {}: {} - Service may be down or unreachable", email, e.getMessage());
            throw new RuntimeException("User service unavailable: " + e.getMessage(), e);
        } catch (Exception e) {
            log.error("Error fetching user ID for email {} from user service: {} - Exception type: {}", 
                    email, e.getMessage(), e.getClass().getName(), e);
            throw new RuntimeException("Failed to fetch user ID from user service: " + e.getMessage(), e);
        }
    }
}

