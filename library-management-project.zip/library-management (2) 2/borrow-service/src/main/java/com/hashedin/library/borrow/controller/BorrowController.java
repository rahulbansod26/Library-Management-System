
package com.hashedin.library.borrow.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hashedin.library.borrow.client.UserServiceClient;
import com.hashedin.library.borrow.domain.BorrowRecord;
import com.hashedin.library.borrow.domain.BorrowRequest;
import com.hashedin.library.borrow.service.BorrowService;
import com.hashedin.library.common.dto.ApproveRejectRequest;

@RestController
@RequestMapping("/api/borrow")
public class BorrowController {
    private final BorrowService service;
    private final UserServiceClient userServiceClient;
    
    public BorrowController(BorrowService service, UserServiceClient userServiceClient) {
        this.service = service;
        this.userServiceClient = userServiceClient;
    }

    record BorrowRequestDTO(String userId, String bookId, int days) {}

    record ReturnBookRequest(String userId) {}

    /**
     * Borrows a book for a user with the specified duration.
     * Default borrow duration is 14 days if not specified.
     * 
     * @param req The borrow request containing userId, bookId, and days
     * @return The borrow record
     */
    @PostMapping
    public ResponseEntity<BorrowRecord> borrow(@RequestBody BorrowRequestDTO req){
        int days = req.days() > 0 ? req.days() : 14;
        return ResponseEntity.ok(service.borrow(req.userId(), req.bookId(), days));
    }

    /**
     * Returns a borrowed book by record ID.
     * 
     * @param req The return request containing userId
     * @param recordId The borrow record ID
     * @return The updated borrow record
     */
    @PostMapping("/return/{recordId}")
    public ResponseEntity<BorrowRecord> returnBook(@RequestBody ReturnBookRequest req, @PathVariable String recordId){
        return ResponseEntity.ok(service.returnBook(req.userId(), recordId));
    }

    /**
     * Gets all active borrow records for a specific user.
     * 
     * @param userId The user ID
     * @return List of active borrow records
     */
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<BorrowRecord>> active(@PathVariable String userId){
        return ResponseEntity.ok(service.activeForUser(userId));
    }

    /**
     * Gets the complete borrowing history for a specific user.
     * 
     * @param userId The user ID
     * @return List of all borrow records for the user
     */
    @GetMapping("/user/{userId}/history")
    public ResponseEntity<List<BorrowRecord>> history(@PathVariable String userId){
        return ResponseEntity.ok(service.getBorrowingHistory(userId));
    }

    /**
     * Gets all overdue borrow records across all users.
     * 
     * @return List of overdue borrow records
     */
    @GetMapping("/overdue")
    public ResponseEntity<List<BorrowRecord>> overdue(){
        return ResponseEntity.ok(service.getOverdueRecords());
    }

    /**
     * Gets a borrow record by its ID.
     * 
     * @param recordId The borrow record ID
     * @return The borrow record
     */
    @GetMapping("/{recordId}")
    public ResponseEntity<BorrowRecord> getById(@PathVariable String recordId){
        return ResponseEntity.ok(service.getById(recordId));
    }

    /**
     * Gets all active borrow records across all users.
     * 
     * @return List of all active borrow records
     */
    @GetMapping("/active/all")
    public ResponseEntity<List<BorrowRecord>> getAllActive() {
        return ResponseEntity.ok(service.getActiveBorrows());
    }

    /**
     * Gets all borrow records that are due within the specified number of days.
     * 
     * @param days The number of days
     * @return List of borrow records due within the specified days
     */
    @GetMapping("/due-in-days/{days}")
    public ResponseEntity<List<BorrowRecord>> getDueInDays(@PathVariable int days) {
        return ResponseEntity.ok(service.getBorrowsDueInDays(days));
    }
    
    /**
     * Marks a borrowed book as lost.
     * 
     * @param req The request containing userId
     * @param recordId The borrow record ID
     * @return The updated borrow record
     */
    @PostMapping("/{recordId}/lost")
    public ResponseEntity<BorrowRecord> markAsLost(@RequestBody ReturnBookRequest req, @PathVariable String recordId) {
        return ResponseEntity.ok(service.markBookAsLost(req.userId(), recordId));
    }
    
    // Borrow Request endpoints
    record CreateBorrowRequestDTO(String bookId, int days, String reason) {}
    
    /**
     * Creates a borrow request for the authenticated user.
     * Extracts userId from JWT token and creates a borrow request with the specified book and duration.
     * 
     * @param req The borrow request containing bookId, days, and reason
     * @return The created borrow request
     * @throws RuntimeException if user is not authenticated or user not found
     */
    @PostMapping("/request")
    public ResponseEntity<BorrowRequest> createRequest(@RequestBody CreateBorrowRequestDTO req) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || authentication.getName() == null) {
            throw new RuntimeException("User not authenticated");
        }
        String email = authentication.getName();
        
        String userId = userServiceClient.getUserIdByEmail(email);
        if (userId == null) {
            throw new RuntimeException("User not found for email: " + email);
        }
        
        return ResponseEntity.ok(service.createBorrowRequest(userId, req.bookId(), req.days(), req.reason()));
    }
    
    /**
     * Approves a borrow request and creates a borrow record.
     * Requires LIBRARIAN role.
     * 
     * @param requestId The borrow request ID
     * @param request The approval request containing librarianId
     * @return The created borrow record
     */
    @PostMapping("/request/{requestId}/approve")
    @PreAuthorize("hasRole('LIBRARIAN')")
    public ResponseEntity<BorrowRecord> approveRequest(@PathVariable String requestId, @RequestBody ApproveRejectRequest request) {
        return ResponseEntity.ok(service.approveBorrowRequest(requestId, request.librarianId()));
    }
    
    /**
     * Rejects a borrow request.
     * Requires LIBRARIAN role.
     * 
     * @param requestId The borrow request ID
     * @param request The rejection request containing librarianId
     * @return The updated borrow request with REJECTED status
     */
    @PostMapping("/request/{requestId}/reject")
    @PreAuthorize("hasRole('LIBRARIAN')")
    public ResponseEntity<BorrowRequest> rejectRequest(@PathVariable String requestId, @RequestBody ApproveRejectRequest request) {
        return ResponseEntity.ok(service.rejectBorrowRequest(requestId, request.librarianId()));
    }
    
    /**
     * Gets all pending borrow requests.
     * Requires LIBRARIAN role.
     * 
     * @return List of pending borrow requests
     */
    @GetMapping("/request/pending")
    @PreAuthorize("hasRole('LIBRARIAN')")
    public ResponseEntity<List<BorrowRequest>> getPendingRequests() {
        return ResponseEntity.ok(service.getPendingRequests());
    }
    
    /**
     * Gets all borrow requests for a specific user.
     * 
     * @param userId The user ID
     * @return List of borrow requests for the user
     */
    @GetMapping("/request/user/{userId}")
    public ResponseEntity<List<BorrowRequest>> getUserRequests(@PathVariable String userId) {
        return ResponseEntity.ok(service.getUserRequests(userId));
    }
}

