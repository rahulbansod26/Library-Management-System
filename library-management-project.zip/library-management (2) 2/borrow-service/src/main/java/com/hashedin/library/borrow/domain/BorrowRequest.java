package com.hashedin.library.borrow.domain;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
public class BorrowRequest {
    public enum Status { PENDING, APPROVED, REJECTED, CANCELLED }
    
    @Id 
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    
    private String userId;
    private String bookId;
    private int requestedDays;
    private String reason;
    
    @Enumerated(EnumType.STRING)
    private Status status = Status.PENDING;
    
    private Instant requestDate = Instant.now();
    private Instant processedDate;
    private String processedBy; // Librarian/Admin ID

    // Getters
    public String getId() { return id; }
    public String getUserId() { return userId; }
    public String getBookId() { return bookId; }
    public int getRequestedDays() { return requestedDays; }
    public String getReason() { return reason; }
    public Status getStatus() { return status; }
    public Instant getRequestDate() { return requestDate; }
    public Instant getProcessedDate() { return processedDate; }
    public String getProcessedBy() { return processedBy; }

    // Setters
    public void setId(String id) { this.id = id; }
    public void setUserId(String userId) { this.userId = userId; }
    public void setBookId(String bookId) { this.bookId = bookId; }
    public void setRequestedDays(int requestedDays) { this.requestedDays = requestedDays; }
    public void setReason(String reason) { this.reason = reason; }
    public void setStatus(Status status) { this.status = status; }
    public void setRequestDate(Instant requestDate) { this.requestDate = requestDate; }
    public void setProcessedDate(Instant processedDate) { this.processedDate = processedDate; }
    public void setProcessedBy(String processedBy) { this.processedBy = processedBy; }
}

