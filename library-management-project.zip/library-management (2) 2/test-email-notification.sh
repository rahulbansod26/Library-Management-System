#!/bin/bash

# Test Email Notification Script
# This script tests the email notification functionality

echo "========================================="
echo "Testing Email Notification Service"
echo "========================================="
echo ""

BASE_URL="${1:-http://localhost:7000}"
TEST_EMAIL="${2:-recipient@example.com}"

echo "Base URL: $BASE_URL"
echo "Test Email: $TEST_EMAIL"
echo ""

# Step 1: Check Email Service Status
echo "Step 1: Checking email service status..."
echo "----------------------------------------"
STATUS_RESPONSE=$(curl -s -X GET "$BASE_URL/api/notifications/test/email/status")
echo "$STATUS_RESPONSE" | python3 -m json.tool 2>/dev/null || echo "$STATUS_RESPONSE"
echo ""

# Check if service is configured
if echo "$STATUS_RESPONSE" | grep -q '"mailSenderConfigured":true'; then
    echo "✓ Email service is configured"
else
    echo "✗ Email service is NOT configured"
    echo "  Please check application.yml configuration"
    exit 1
fi
echo ""

# Step 2: Send Test Email
echo "Step 2: Sending test email..."
echo "----------------------------------------"
TEST_REQUEST=$(cat <<EOF
{
  "to": "$TEST_EMAIL",
  "subject": "Test Email from Library Management System",
  "message": "This is a test email to verify email notification functionality.\n\nIf you receive this email, the notification service is working correctly!"
}
EOF
)

RESPONSE=$(curl -s -X POST "$BASE_URL/api/notifications/test/email" \
  -H "Content-Type: application/json" \
  -d "$TEST_REQUEST")

echo "$RESPONSE" | python3 -m json.tool 2>/dev/null || echo "$RESPONSE"
echo ""

# Check response
if echo "$RESPONSE" | grep -q '"status":"success"'; then
    echo "✓ Test email sent successfully!"
    echo "  Please check the inbox for: $TEST_EMAIL"
elif echo "$RESPONSE" | grep -q '"status":"error"'; then
    echo "✗ Failed to send test email"
    ERROR_MSG=$(echo "$RESPONSE" | grep -o '"message":"[^"]*"' | cut -d'"' -f4)
    echo "  Error: $ERROR_MSG"
    exit 1
else
    echo "? Unexpected response"
    exit 1
fi

echo ""
echo "========================================="
echo "Email Notification Test Completed"
echo "========================================="

