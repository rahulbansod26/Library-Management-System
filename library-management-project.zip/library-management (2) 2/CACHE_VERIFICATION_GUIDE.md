# Cache Verification Guide

## Where Cache is Used

### 1. **Catalog Service** - Book Caching

#### Cache Names:
- `book_search` - TTL: 30 minutes
- `book_by_isbn` - TTL: 2 hours

#### Cached Methods:
```java
// BookService.java

// Caches book search results
@Cacheable(cacheNames = "book_search", key = "#query", unless = "#result == null || #result.isEmpty()")
public List<Book> search(String query)

// Caches book by ISBN lookup
@Cacheable(cacheNames = "book_by_isbn", key = "#isbn")
public Optional<Book> byIsbn(String isbn)

// Evicts cache on add/update/remove operations
@CacheEvict(cacheNames = {"book_search","book_by_isbn"}, allEntries = true)
public Book add(Book book)

@CacheEvict(cacheNames = {"book_search","book_by_isbn"}, allEntries = true)
public Book update(String id, Book book)

@CacheEvict(cacheNames = {"book_search","book_by_isbn"}, allEntries = true)
public void remove(String id)
```

**What's Stored:**
- Book search results by query string
- Individual books by ISBN

---

### 2. **Borrow Service** - Active Loans Caching

#### Cache Name:
- `active_loans` - TTL: 15 minutes

#### Cached Methods:
```java
// BorrowService.java

// Caches active loans for a user
@Cacheable(cacheNames="active_loans", key="#userId")
public List<BorrowRecord> activeForUser(String userId)

// Evicts cache on borrow/return operations
@CacheEvict(cacheNames="active_loans", key="#userId")
public BorrowRecord borrow(String userId, String bookId, int days)

@CacheEvict(cacheNames="active_loans", key="#userId")
public BorrowRecord returnBook(String userId, String recordId)

@CacheEvict(cacheNames="active_loans", key="#userId")
public BorrowRecord markBookAsLost(String userId, String recordId)
```

**What's Stored:**
- List of active borrow records per user ID

---

## How to Verify Cache is Working

### Method 1: Check Redis Keys via CLI

1. **Connect to Redis CLI:**
```bash
redis-cli
```

2. **List all cache keys:**
```bash
KEYS *
```

3. **Check specific cache entries:**
```bash
# Catalog service caches (prefixed with cache name)
KEYS book_search:*
KEYS book_by_isbn:*

# Borrow service caches
KEYS active_loans:*
```

4. **Get a cached value:**
```bash
GET "book_by_isbn::1234567890"
```

5. **Check TTL (Time To Live):**
```bash
TTL "book_by_isbn::1234567890"
# Returns remaining seconds, -1 means no expiry, -2 means key doesn't exist
```

### Method 2: Monitor Logs During API Calls

1. **First API Call (Cache Miss):**
   - Call `GET /api/books/search?q=Java`
   - Check logs - you'll see database query
   - Check Redis - new key will be created

2. **Second API Call (Cache Hit):**
   - Call same endpoint again immediately
   - Check logs - NO database query (data comes from cache)
   - Response will be faster

3. **After Cache Eviction:**
   - Update a book: `PUT /api/books/{id}`
   - Check logs - cache is evicted
   - Next search will query database again

### Method 3: Enable Cache Debug Logging

Add to `application.yml` of the service you want to monitor:

```yaml
logging:
  level:
    org.springframework.cache: DEBUG
    org.springframework.data.redis: DEBUG
```

This will show:
- When cache is accessed
- When cache hits/misses occur
- When cache is evicted

### Method 4: Use Spring Boot Actuator (if available)

If actuator is enabled, check:
```
GET /actuator/metrics/cache.gets?tag=result:hit
GET /actuator/metrics/cache.gets?tag=result:miss
```

### Method 5: Performance Comparison

1. **Without Cache (first call):**
   - Time the API call
   - Note: Slower response (DB query)

2. **With Cache (subsequent calls):**
   - Time the same API call immediately
   - Note: Much faster response (cache hit)

---

## Test Script for Cache Verification

```bash
#!/bin/bash

echo "=== Testing Cache ===\n"

# 1. First call - should query database (cache miss)
echo "1. First search call (cache miss)..."
TIME1=$(curl -w "@curl-format.txt" -o /dev/null -s "http://localhost:7000/api/books/search" \
  -H "Content-Type: application/json" \
  -d '{"q":"Java"}' \
  -H "Authorization: Bearer YOUR_TOKEN")

echo "Response time: ${TIME1}ms"

# Wait a bit
sleep 1

# 2. Second call - should use cache (cache hit)
echo "\n2. Second search call (cache hit)..."
TIME2=$(curl -w "@curl-format.txt" -o /dev/null -s "http://localhost:7000/api/books/search" \
  -H "Content-Type: application/json" \
  -d '{"q":"Java"}' \
  -H "Authorization: Bearer YOUR_TOKEN")

echo "Response time: ${TIME2}ms"

echo "\n=== Results ==="
echo "First call (DB): ${TIME1}ms"
echo "Second call (Cache): ${TIME2}ms"
echo "Cache improvement: $((TIME1 - TIME2))ms faster"

# 3. Check Redis
echo "\n=== Redis Keys ==="
redis-cli KEYS "book_search:*"
```

---

## Cache Statistics

### What Gets Cached:

1. **Book Search** (`book_search`):
   - Key Format: `book_search::<query>`
   - Example: `book_search::Java`
   - TTL: 30 minutes
   - Value: List of Book objects

2. **Book by ISBN** (`book_by_isbn`):
   - Key Format: `book_by_isbn::<isbn>`
   - Example: `book_by_isbn::1234567890`
   - TTL: 2 hours
   - Value: Book object

3. **Active Loans** (`active_loans`):
   - Key Format: `active_loans::<userId>`
   - Example: `active_loans::user-123`
   - TTL: 15 minutes
   - Value: List of BorrowRecord objects

---

## Cache Eviction Strategy

Cache is automatically evicted when:

1. **Book Search & ISBN Cache:**
   - When a new book is added
   - When a book is updated
   - When a book is removed
   - All entries in both caches are cleared

2. **Active Loans Cache:**
   - When a user borrows a book
   - When a user returns a book
   - When a book is marked as lost
   - Only that user's cache entry is cleared

---

## Monitoring Cache Health

### Redis Commands for Monitoring:

```bash
# Check if Redis is running
redis-cli ping
# Should return: PONG

# Get total number of keys
redis-cli DBSIZE

# Get memory usage
redis-cli INFO memory

# Monitor all commands in real-time
redis-cli MONITOR

# Get info about a specific key
redis-cli OBJECT ENCODING "book_by_isbn::1234567890"
```

---

## Troubleshooting

### Cache Not Working?

1. **Check Redis is running:**
   ```bash
   redis-cli ping
   ```

2. **Check application logs for errors:**
   ```bash
   tail -f logs/catalog-service.log | grep -i cache
   ```

3. **Verify cache configuration:**
   - Check `application.yml` has `spring.cache.type: redis`
   - Check `@EnableCaching` is in Application.java
   - Check Redis connection in `application.yml`

4. **Check if methods are being called:**
   - Verify the API endpoints are actually calling the cached methods
   - Check logs for cache hit/miss messages (if DEBUG logging enabled)

---

## Expected Behavior

### Cache Miss (First Call):
- Database query executes
- Result is stored in Redis
- Response includes data from database

### Cache Hit (Subsequent Calls):
- No database query
- Data retrieved from Redis
- Faster response time
- Same data as first call

### Cache Eviction:
- Cache is cleared when data changes
- Next call will be a cache miss
- Fresh data is fetched from database
- New entry is created in cache

