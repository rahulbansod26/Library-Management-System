#!/bin/bash

# Start Services and Run Comprehensive Tests

COLOR_GREEN='\033[0;32m'
COLOR_RED='\033[0;31m'
COLOR_YELLOW='\033[1;33m'
COLOR_BLUE='\033[0;34m'
COLOR_CYAN='\033[0;36m'
COLOR_NC='\033[0m'

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

echo -e "${COLOR_CYAN}╔════════════════════════════════════════════════════════╗${COLOR_NC}"
echo -e "${COLOR_CYAN}║   LIBRARY MANAGEMENT SYSTEM - START & TEST             ║${COLOR_NC}"
echo -e "${COLOR_CYAN}╚════════════════════════════════════════════════════════╝${COLOR_NC}"
echo ""

# Check prerequisites
echo -e "${COLOR_YELLOW}Checking prerequisites...${COLOR_NC}"

# Check MySQL
if ! command -v mysql &> /dev/null; then
    echo -e "${COLOR_RED}✗ MySQL not found. Please install MySQL.${COLOR_NC}"
    exit 1
else
    echo -e "${COLOR_GREEN}✓ MySQL found${COLOR_NC}"
fi

# Check RabbitMQ
if rabbitmqctl status &> /dev/null; then
    echo -e "${COLOR_GREEN}✓ RabbitMQ is running${COLOR_NC}"
else
    echo -e "${COLOR_YELLOW}⚠ RabbitMQ may not be running. Attempting to continue...${COLOR_NC}"
fi

# Check Redis (optional)
if redis-cli ping &> /dev/null 2>&1; then
    echo -e "${COLOR_GREEN}✓ Redis is running${COLOR_NC}"
else
    echo -e "${COLOR_YELLOW}⚠ Redis is not running (optional, caching will be disabled)${COLOR_NC}"
fi

echo ""

# Create logs directory
LOGS_DIR="$SCRIPT_DIR/logs"
mkdir -p "$LOGS_DIR"

# Start services
echo -e "${COLOR_BLUE}Starting services...${COLOR_NC}"
echo ""

# Start Eureka
echo -e "${COLOR_YELLOW}[1/7] Starting Eureka Service Discovery...${COLOR_NC}"
cd eureka-service
mvn spring-boot:run > "$LOGS_DIR/eureka.log" 2>&1 &
EUREKA_PID=$!
echo "  Eureka PID: $EUREKA_PID"
sleep 20
cd ..

# Start User Service
echo -e "${COLOR_YELLOW}[2/7] Starting User Service...${COLOR_NC}"
cd user-service
mvn spring-boot:run > "$LOGS_DIR/user-service.log" 2>&1 &
USER_SERVICE_PID=$!
echo "  User Service PID: $USER_SERVICE_PID"
sleep 25
cd ..

# Start Catalog Service
echo -e "${COLOR_YELLOW}[3/7] Starting Catalog Service...${COLOR_NC}"
cd catalog-service
mvn spring-boot:run > "$LOGS_DIR/catalog-service.log" 2>&1 &
CATALOG_SERVICE_PID=$!
echo "  Catalog Service PID: $CATALOG_SERVICE_PID"
sleep 25
cd ..

# Start Borrow Service
echo -e "${COLOR_YELLOW}[4/7] Starting Borrow Service...${COLOR_NC}"
cd borrow-service
mvn spring-boot:run > "$LOGS_DIR/borrow-service.log" 2>&1 &
BORROW_SERVICE_PID=$!
echo "  Borrow Service PID: $BORROW_SERVICE_PID"
sleep 25
cd ..

# Start Fine Service
echo -e "${COLOR_YELLOW}[5/7] Starting Fine Service...${COLOR_NC}"
cd fine-service
mvn spring-boot:run > "$LOGS_DIR/fine-service.log" 2>&1 &
FINE_SERVICE_PID=$!
echo "  Fine Service PID: $FINE_SERVICE_PID"
sleep 25
cd ..

# Start Notification Service
echo -e "${COLOR_YELLOW}[6/7] Starting Notification Service...${COLOR_NC}"
cd notification-service
mvn spring-boot:run > "$LOGS_DIR/notification-service.log" 2>&1 &
NOTIFICATION_SERVICE_PID=$!
echo "  Notification Service PID: $NOTIFICATION_SERVICE_PID"
sleep 25
cd ..

# Start API Gateway
echo -e "${COLOR_YELLOW}[7/7] Starting API Gateway...${COLOR_NC}"
cd api-gateway
mvn spring-boot:run > "$LOGS_DIR/api-gateway.log" 2>&1 &
GATEWAY_PID=$!
echo "  API Gateway PID: $GATEWAY_PID"
sleep 25
cd ..

# Save PIDs
echo "EUREKA_PID=$EUREKA_PID" > "$LOGS_DIR/pids.txt"
echo "USER_SERVICE_PID=$USER_SERVICE_PID" >> "$LOGS_DIR/pids.txt"
echo "CATALOG_SERVICE_PID=$CATALOG_SERVICE_PID" >> "$LOGS_DIR/pids.txt"
echo "BORROW_SERVICE_PID=$BORROW_SERVICE_PID" >> "$LOGS_DIR/pids.txt"
echo "FINE_SERVICE_PID=$FINE_SERVICE_PID" >> "$LOGS_DIR/pids.txt"
echo "NOTIFICATION_SERVICE_PID=$NOTIFICATION_SERVICE_PID" >> "$LOGS_DIR/pids.txt"
echo "GATEWAY_PID=$GATEWAY_PID" >> "$LOGS_DIR/pids.txt"

echo ""
echo -e "${COLOR_GREEN}All services started!${COLOR_NC}"
echo -e "${COLOR_YELLOW}Waiting for services to be ready...${COLOR_NC}"
echo ""

# Wait a bit more for services to fully initialize
sleep 30

# Check if services are ready
echo -e "${COLOR_BLUE}Checking service readiness...${COLOR_NC}"
./check-services-ready.sh

if [ $? -eq 0 ]; then
    echo ""
    echo -e "${COLOR_GREEN}All services are ready!${COLOR_NC}"
    echo ""
    echo -e "${COLOR_CYAN}Starting comprehensive API tests...${COLOR_NC}"
    echo ""
    sleep 5
    
    # Run comprehensive tests
    ./comprehensive-api-testing.sh
    
    TEST_RESULT=$?
    
    echo ""
    echo -e "${COLOR_CYAN}═══════════════════════════════════════════════════════${COLOR_NC}"
    echo -e "${COLOR_CYAN}Service PIDs saved in: $LOGS_DIR/pids.txt${COLOR_NC}"
    echo -e "${COLOR_CYAN}Service logs in: $LOGS_DIR/ directory${COLOR_NC}"
    echo -e "${COLOR_CYAN}═══════════════════════════════════════════════════════${COLOR_NC}"
    echo ""
    echo -e "${COLOR_YELLOW}To stop all services, run: ./stop-all-services.sh${COLOR_NC}"
    
    exit $TEST_RESULT
else
    echo ""
    echo -e "${COLOR_RED}Some services are not ready. Please check logs and try again.${COLOR_NC}"
    echo -e "${COLOR_YELLOW}You can check logs in: $LOGS_DIR/ directory${COLOR_NC}"
    exit 1
fi

