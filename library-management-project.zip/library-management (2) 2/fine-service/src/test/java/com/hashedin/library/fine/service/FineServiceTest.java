package com.hashedin.library.fine.service;

import com.hashedin.library.fine.domain.Fine;
import com.hashedin.library.fine.repo.FineRepo;
import com.hashedin.library.fine.repo.PaymentHistoryRepo;
import com.hashedin.library.fine.client.BorrowServiceClient;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class FineServiceTest {

    @Mock
    private FineRepo repo;

    @Mock
    private PaymentHistoryRepo paymentHistoryRepo;

    @Mock
    private BorrowServiceClient borrowServiceClient;

    @Mock
    private RabbitTemplate rabbit;

    @Mock
    private TopicExchange exchange;

    @InjectMocks
    private FineService fineService;

    private Fine testFine;

    @BeforeEach
    void setUp() {
        testFine = new Fine();
        testFine.setId("fine-123");
        testFine.setUserId("user-123");
        testFine.setAmount(new BigDecimal("25.00"));
        testFine.setPaidAmount(BigDecimal.ZERO);
        testFine.setStatus(Fine.Status.PENDING);
    }

    @Test
    void testGetOrCreate_ExistingFine() {
        // Arrange
        String userId = "user-123";
        List<Fine> fines = Arrays.asList(testFine);
        when(repo.findByUserId(userId)).thenReturn(fines);

        // Act
        Fine result = fineService.getOrCreate(userId);

        // Assert
        assertNotNull(result);
        assertEquals(testFine.getId(), result.getId());
        assertEquals(testFine.getUserId(), result.getUserId());
        verify(repo).findByUserId(userId);
        verify(repo, never()).save(any());
    }

    @Test
    void testGetOrCreate_NewFine() {
        // Arrange
        String userId = "user-123";
        when(repo.findByUserId(userId)).thenReturn(Arrays.asList());
        when(repo.save(any(Fine.class))).thenAnswer(invocation -> {
            Fine fine = invocation.getArgument(0);
            fine.setId("new-fine-id");
            return fine;
        });

        // Act
        Fine result = fineService.getOrCreate(userId);

        // Assert
        assertNotNull(result);
        assertEquals(userId, result.getUserId());
        verify(repo).findByUserId(userId);
        verify(repo).save(any(Fine.class));
    }

    @Test
    void testGetFinesByUserId() {
        // Arrange
        String userId = "user-123";
        List<Fine> fines = Arrays.asList(testFine);
        when(repo.findByUserIdOrderByCreatedAtDesc(userId)).thenReturn(fines);

        // Act
        List<Fine> result = fineService.getFinesByUserId(userId);

        // Assert
        assertEquals(1, result.size());
        assertEquals(testFine.getId(), result.get(0).getId());
        verify(repo).findByUserIdOrderByCreatedAtDesc(userId);
    }

    @Test
    void testGetOutstandingFines() {
        // Arrange
        String userId = "user-123";
        testFine.setAmount(new BigDecimal("50.00"));
        testFine.setPaidAmount(new BigDecimal("25.00"));
        List<Fine> fines = Arrays.asList(testFine);
        when(repo.findByUserId(userId)).thenReturn(fines);

        // Act
        BigDecimal result = fineService.getOutstandingFines(userId);

        // Assert
        assertNotNull(result);
        // Outstanding amount = amount - paidAmount = 50.00 - 25.00 = 25.00
        assertEquals(new BigDecimal("25.00"), result);
        verify(repo).findByUserId(userId);
    }

    @Test
    void testAddFine_Success() {
        // Arrange
        String userId = "user-123";
        BigDecimal amount = new BigDecimal("25.00");
        // Mock getOrCreate to return existing fine (so it doesn't create a new one)
        List<Fine> existingFines = Arrays.asList(testFine);
        when(repo.findByUserId(userId)).thenReturn(existingFines);
        when(repo.save(any(Fine.class))).thenAnswer(invocation -> {
            Fine fine = invocation.getArgument(0);
            if (fine.getId() == null) {
                fine.setId("new-fine-id");
            }
            return fine;
        });
        when(exchange.getName()).thenReturn("library-exchange");

        // Act
        fineService.addFine(userId, amount);

        // Assert - verify that save was called with correct fine (amount should be added)
        ArgumentCaptor<Fine> fineCaptor = ArgumentCaptor.forClass(Fine.class);
        verify(repo).save(fineCaptor.capture());
        
        Fine savedFine = fineCaptor.getValue();
        assertNotNull(savedFine);
        assertEquals(userId, savedFine.getUserId());
        // Original amount (25.00) + new amount (25.00) = 50.00
        assertEquals(new BigDecimal("50.00"), savedFine.getAmount());
    }
}

