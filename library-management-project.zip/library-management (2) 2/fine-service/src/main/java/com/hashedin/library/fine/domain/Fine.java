
package com.hashedin.library.fine.domain;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;

@Entity
public class Fine {
    public enum Status { PENDING, PAID, PARTIALLY_PAID, CANCELLED }
    
    @Id 
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    
    private String userId;
    private String borrowRecordId;
    private BigDecimal amount = BigDecimal.ZERO;
    private BigDecimal paidAmount = BigDecimal.ZERO;
    private LocalDate dueDate;
    private LocalDate paidDate;
    
    @Enumerated(EnumType.STRING)
    private Status status = Status.PENDING;
    
    private Instant createdAt = Instant.now();
    private Instant updatedAt = Instant.now();

    @PreUpdate
    protected void onUpdate() {
        updatedAt = Instant.now();
    }
    
    public boolean isPaid() {
        return status == Status.PAID || (amount.compareTo(BigDecimal.ZERO) > 0 && paidAmount.compareTo(amount) >= 0);
    }
    
    public BigDecimal getOutstandingAmount() {
        return amount.subtract(paidAmount);
    }

    // Getters
    public String getId() { return id; }
    public String getUserId() { return userId; }
    public String getBorrowRecordId() { return borrowRecordId; }
    public BigDecimal getAmount() { return amount; }
    public BigDecimal getPaidAmount() { return paidAmount; }
    public LocalDate getDueDate() { return dueDate; }
    public LocalDate getPaidDate() { return paidDate; }
    public Status getStatus() { return status; }
    public Instant getCreatedAt() { return createdAt; }
    public Instant getUpdatedAt() { return updatedAt; }

    // Setters
    public void setId(String id) { this.id = id; }
    public void setUserId(String userId) { this.userId = userId; }
    public void setBorrowRecordId(String borrowRecordId) { this.borrowRecordId = borrowRecordId; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }
    public void setPaidAmount(BigDecimal paidAmount) { this.paidAmount = paidAmount; }
    public void setDueDate(LocalDate dueDate) { this.dueDate = dueDate; }
    public void setPaidDate(LocalDate paidDate) { this.paidDate = paidDate; }
    public void setStatus(Status status) { this.status = status; }
    public void setCreatedAt(Instant createdAt) { this.createdAt = createdAt; }
    public void setUpdatedAt(Instant updatedAt) { this.updatedAt = updatedAt; }
}
