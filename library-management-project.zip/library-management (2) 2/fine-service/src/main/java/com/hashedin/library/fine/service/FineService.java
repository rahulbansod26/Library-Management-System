
package com.hashedin.library.fine.service;

import com.hashedin.library.common.events.RoutingKeys;
import com.hashedin.library.common.events.FineUpdatedEvent;
import com.hashedin.library.fine.client.BorrowServiceClient;
import com.hashedin.library.fine.domain.Fine;
import com.hashedin.library.fine.domain.PaymentHistory;
import com.hashedin.library.fine.repo.FineRepo;
import com.hashedin.library.fine.repo.PaymentHistoryRepo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.UUID;

@Service
public class FineService {
    private static final Logger log = LoggerFactory.getLogger(FineService.class);
    private static final BigDecimal DAILY_FINE_RATE = new BigDecimal("5.00"); // $5 per day
    private static final BigDecimal MAX_FINE_PER_BOOK = new BigDecimal("100.00"); // Max $100 per book
    
    private final FineRepo fineRepo;
    private final PaymentHistoryRepo paymentHistoryRepo;
    private final BorrowServiceClient borrowServiceClient;
    private final RabbitTemplate rabbit;
    private final TopicExchange exchange;

    public FineService(FineRepo fineRepo, PaymentHistoryRepo paymentHistoryRepo,
                      BorrowServiceClient borrowServiceClient, RabbitTemplate rabbit, TopicExchange exchange){
        this.fineRepo = fineRepo;
        this.paymentHistoryRepo = paymentHistoryRepo;
        this.borrowServiceClient = borrowServiceClient;
        this.rabbit = rabbit;
        this.exchange = exchange;
    }

    public Fine getOrCreate(String userId){
        List<Fine> fines = fineRepo.findByUserId(userId);
        // Return first fine if exists, otherwise create a new one
        if (!fines.isEmpty()) {
            return fines.get(0);
        }
        Fine f = new Fine(); 
        f.setUserId(userId); 
        return fineRepo.save(f);
    }

    public Fine getOrCreateForBorrowRecord(String userId, String borrowRecordId){
        return fineRepo.findByBorrowRecordId(borrowRecordId).orElseGet(()->{
            Fine f = new Fine(); 
            f.setUserId(userId); 
            f.setBorrowRecordId(borrowRecordId);
            return fineRepo.save(f);
        });
    }

    @Transactional
    public void addFine(String userId, BigDecimal amount){
        Fine f = getOrCreate(userId);
        f.setAmount(f.getAmount().add(amount));
        if (f.getStatus() == Fine.Status.PAID) {
            f.setStatus(Fine.Status.PENDING);
        }
        fineRepo.save(f);
        publishFineUpdatedEvent(f);
    }

    @Scheduled(cron = "0 15 * * * *") // Runs at 15 minutes past every hour
    public void scheduledFineCalc(){
        try {
            // Fetch overdue records from borrow service
            List<com.hashedin.library.common.dto.BorrowRecordDTO> overdueRecords = borrowServiceClient.getOverdueRecords();
            
            for (com.hashedin.library.common.dto.BorrowRecordDTO record : overdueRecords) {
                if (record.getUserId() != null && record.getId() != null && record.getEndDate() != null) {
                    calculateAndApplyFine(record.getUserId(), record.getId(), record.getEndDate().toString());
                }
            }
        } catch (Exception e) {
            log.error("Error in scheduled fine calculation: {}", e.getMessage(), e);
        }
    }

    @Transactional
    public void calculateAndApplyFine(String userId, String borrowRecordId, String endDateStr) {
        try {
            // Get borrow record to check if it's lost
            com.hashedin.library.common.dto.BorrowRecordDTO borrowRecord = borrowServiceClient.getBorrowRecord(borrowRecordId);
            if (borrowRecord == null) {
                return;
            }
            
            // Handle lost book scenario
            if (borrowRecord.getStatus() == com.hashedin.library.common.dto.BorrowRecordDTO.Status.LOST) {
                calculateLostBookFine(userId, borrowRecordId);
                return;
            }
            
            // Handle overdue scenario
            LocalDate endDate = borrowRecord.getEndDate() != null ? borrowRecord.getEndDate() : LocalDate.parse(endDateStr);
            LocalDate today = LocalDate.now();
            
            if (today.isAfter(endDate)) {
                long daysOverdue = ChronoUnit.DAYS.between(endDate, today);
                
                // Calculate fine: $5 per day, max $100
                BigDecimal calculatedFine = DAILY_FINE_RATE.multiply(new BigDecimal(daysOverdue));
                if (calculatedFine.compareTo(MAX_FINE_PER_BOOK) > 0) {
                    calculatedFine = MAX_FINE_PER_BOOK;
                }
                
                Fine fine = getOrCreateForBorrowRecord(userId, borrowRecordId);
                
                // Only update if fine amount needs to increase
                if (calculatedFine.compareTo(fine.getAmount()) > 0) {
                    fine.setAmount(calculatedFine);
                    fine.setDueDate(today.plusDays(30)); // Fine due 30 days from calculation
                    fine.setStatus(Fine.Status.PENDING);
                    fineRepo.save(fine);
                    publishFineUpdatedEvent(fine);
                }
            }
        } catch (Exception e) {
            log.error("Error calculating fine for borrow record {}: {}", borrowRecordId, e.getMessage(), e);
        }
    }
    
    @Transactional
    public void calculateLostBookFine(String userId, String borrowRecordId) {
        // Lost book fine: typically the replacement cost or a fixed high amount
        BigDecimal LOST_BOOK_FINE = new BigDecimal("200.00"); // $200 for lost book
        
        Fine fine = getOrCreateForBorrowRecord(userId, borrowRecordId);
        
        // Only set lost book fine if not already set
        if (fine.getAmount().compareTo(BigDecimal.ZERO) == 0 || 
            fine.getAmount().compareTo(LOST_BOOK_FINE) < 0) {
            fine.setAmount(LOST_BOOK_FINE);
            fine.setDueDate(LocalDate.now().plusDays(30)); // Fine due 30 days
            fine.setStatus(Fine.Status.PENDING);
            fineRepo.save(fine);
            publishFineUpdatedEvent(fine);
        }
    }

    @Async
    @Transactional
    public void processPaymentAsync(String userId, String fineId, BigDecimal amount, 
                                   PaymentHistory.PaymentMethod paymentMethod) {
        try {
            Fine fine = fineRepo.findById(fineId)
                    .orElseThrow(() -> new RuntimeException("Fine not found: " + fineId));
            
            if (!fine.getUserId().equals(userId)) {
                throw new RuntimeException("Fine does not belong to user");
            }
            
            BigDecimal outstandingAmount = fine.getOutstandingAmount();
            if (amount.compareTo(outstandingAmount) > 0) {
                amount = outstandingAmount; // Don't accept overpayment
            }
            
            // Create payment history record
            PaymentHistory payment = new PaymentHistory();
            payment.setFineId(fineId);
            payment.setAmount(amount);
            payment.setPaymentMethod(paymentMethod);
            payment.setTransactionId(UUID.randomUUID().toString());
            payment.setStatus(PaymentHistory.PaymentStatus.COMPLETED);
            paymentHistoryRepo.save(payment);
            
            // Update fine
            fine.setPaidAmount(fine.getPaidAmount().add(amount));
            if (fine.getOutstandingAmount().compareTo(BigDecimal.ZERO) <= 0) {
                fine.setStatus(Fine.Status.PAID);
                fine.setPaidDate(LocalDate.now());
            } else {
                fine.setStatus(Fine.Status.PARTIALLY_PAID);
            }
            fineRepo.save(fine);
            
            // Publish payment completed event
            com.hashedin.library.common.events.PaymentCompletedEvent event = 
                    new com.hashedin.library.common.events.PaymentCompletedEvent(
                            userId, amount, payment.getTransactionId());
            rabbit.convertAndSend(exchange.getName(), RoutingKeys.PAYMENT_COMPLETED, event);
            
        } catch (Exception e) {
            log.error("Error processing payment for fine {}: {}", fineId, e.getMessage(), e);
            throw new RuntimeException("Payment processing failed: " + e.getMessage(), e);
        }
    }

    public List<Fine> getFinesByUserId(String userId) {
        return fineRepo.findByUserIdOrderByCreatedAtDesc(userId);
    }

    public BigDecimal getOutstandingFines(String userId) {
        return fineRepo.findByUserId(userId)
                .stream()
                .map(Fine::getOutstandingAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    public List<PaymentHistory> getPaymentHistory(String fineId) {
        return paymentHistoryRepo.findByFineIdOrderByPaymentDateDesc(fineId);
    }

    private void publishFineUpdatedEvent(Fine fine) {
        FineUpdatedEvent event = new FineUpdatedEvent();
        event.setUserId(fine.getUserId());
        event.setAmount(fine.getAmount());
        event.setBorrowRecordId(fine.getBorrowRecordId());
        rabbit.convertAndSend(exchange.getName(), RoutingKeys.FINE_UPDATED, event);
    }
}
