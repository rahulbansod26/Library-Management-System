package com.hashedin.library.fine.client;

import com.hashedin.library.common.dto.BorrowRecordDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Component
public class BorrowServiceClient {
    private static final Logger log = LoggerFactory.getLogger(BorrowServiceClient.class);
    private final RestTemplate restTemplate;
    private static final String BORROW_SERVICE_NAME = "borrow-service";

    public BorrowServiceClient(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public List<BorrowRecordDTO> getOverdueRecords() {
        try {
            ResponseEntity<List<BorrowRecordDTO>> response = restTemplate.exchange(
                    "http://" + BORROW_SERVICE_NAME + "/api/borrow/overdue",
                    HttpMethod.GET,
                    null,
                    new ParameterizedTypeReference<List<BorrowRecordDTO>>() {}
            );
            return response.getBody() != null ? response.getBody() : List.of();
        } catch (Exception e) {
            log.error("Error fetching overdue records: {}", e.getMessage(), e);
            return List.of();
        }
    }

    public BorrowRecordDTO getBorrowRecord(String recordId) {
        try {
            ResponseEntity<BorrowRecordDTO> response = restTemplate.exchange(
                    "http://" + BORROW_SERVICE_NAME + "/api/borrow/" + recordId,
                    HttpMethod.GET,
                    null,
                    new ParameterizedTypeReference<BorrowRecordDTO>() {}
            );
            return response.getBody();
        } catch (Exception e) {
            log.error("Error fetching borrow record {}: {}", recordId, e.getMessage(), e);
            return null;
        }
    }
}

