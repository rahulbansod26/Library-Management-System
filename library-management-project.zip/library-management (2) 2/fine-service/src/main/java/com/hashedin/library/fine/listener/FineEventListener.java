package com.hashedin.library.fine.listener;

import com.hashedin.library.common.dto.BorrowRecordDTO;
import com.hashedin.library.common.events.BookOverdueEvent;
import com.hashedin.library.fine.client.BorrowServiceClient;
import com.hashedin.library.fine.service.FineService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

@Component
public class FineEventListener {
    private static final Logger log = LoggerFactory.getLogger(FineEventListener.class);
    private final FineService fineService;
    private final BorrowServiceClient borrowServiceClient;

    public FineEventListener(FineService fineService, BorrowServiceClient borrowServiceClient) {
        this.fineService = fineService;
        this.borrowServiceClient = borrowServiceClient;
    }

    @RabbitListener(queues = "borrow.events.q")
    public void handleBookOverdue(BookOverdueEvent event) {
        // When a book becomes overdue, trigger fine calculation via scheduled task
        // The scheduled task will fetch all overdue records and calculate fines
        log.info("Book overdue event received for user: {}, book: {}", event.getUserId(), event.getBookId());
    }

    @RabbitListener(queues = "borrow.events.q")
    public void handleBookOverdueRecord(BorrowRecordDTO record) {
        // Handle when BorrowRecord is sent as DTO in overdue event
        try {
            if (record != null && record.getStatus() == BorrowRecordDTO.Status.OVERDUE) {
                if (record.getUserId() != null && record.getId() != null && record.getEndDate() != null) {
                    fineService.calculateAndApplyFine(record.getUserId(), record.getId(), record.getEndDate().toString());
                }
            }
        } catch (Exception e) {
            log.error("Error handling overdue record: {}", e.getMessage(), e);
        }
    }
}

