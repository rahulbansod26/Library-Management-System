# Library Management System - Complete Flow Explanation

## Overview
This document explains the complete flow from user registration to fine calculation and how all services communicate.

---

## 🔄 Complete System Flow

### **Phase 1: User Registration** 👤

```
USER → User-Service API → Database → RabbitMQ Event → Notification-Service
```

1. **User Registration API Call**
   - Endpoint: `POST /api/users/register`
   - User provides: email, name, password, roles (optional)
   
2. **User-Service Processing**
   - Encrypts password using BCrypt
   - Sets default role to USER if not provided
   - Saves user to database
   - **Publishes Event**: `UserRegisteredEvent` → RabbitMQ
   
3. **Notification-Service (Async)**
   - Listens to `UserRegisteredEvent`
   - Sends welcome email
   - Stores notification in database

**Key Code:**
```java
// UserService.register()
User u = new User();
u.setPasswordHash(encoder.encode(rawPassword));
repo.save(u);
rabbit.convertAndSend(exchange.getName(), RoutingKeys.USER_REGISTERED, 
    new UserRegisteredEvent(u.getId(), u.getEmail(), u.getName()));
```

---

### **Phase 2: Book Borrowing** 📚

```
USER → Borrow-Service API → Catalog-Service (REST) → Borrow-Service → RabbitMQ Events
```

1. **Borrow Request API Call**
   - Endpoint: `POST /api/borrow`
   - User provides: userId, bookId, days (default 14, max 30)
   
2. **Borrow-Service Validation (Synchronous REST Call)**
   ```
   Borrow-Service → Catalog-Service: GET /api/books/{bookId}
   ```
   - Checks if book exists
   - Validates book status = AVAILABLE
   - Validates quantity > 0
   
3. **Borrow-Service Business Rules**
   - Checks user hasn't exceeded max 5 active books
   - Validates borrow duration (1-30 days)
   
4. **Create Borrow Record**
   - Creates `BorrowRecord` with:
     - status = ACTIVE
     - startDate = today
     - endDate = today + days
   - Saves to database
   - **Updates Cache**: Evicts active_loans cache
   
5. **Update Book Status (Synchronous REST Call)**
   ```
   Borrow-Service → Catalog-Service: PATCH /api/books/{bookId}/status
   ```
   - Sets book status = BORROWED
   
6. **Publish Events (Async via RabbitMQ)**
   - `BorrowRequestedEvent` → Notification Service
   - `BorrowApprovedEvent` → Notification Service
   
7. **Notification-Service (Async)**
   - Listens to `BorrowApprovedEvent`
   - Sends borrow confirmation email
   - Stores notification

**Key Code:**
```java
// BorrowService.borrow()
BookDTO book = catalogServiceClient.getBook(bookId);  // REST call
// Validation...
catalogServiceClient.updateBookStatus(bookId, "BORROWED");  // REST call
rabbit.convertAndSend(..., RoutingKeys.BORROW_APPROVED, ...);  // Event
```

---

### **Phase 3: Overdue Detection** ⏰

```
Scheduler → Borrow-Service → RabbitMQ Event → Fine-Service + Notification-Service
```

1. **Scheduled Task Runs Every Hour**
   - Cron: `@Scheduled(cron = "0 0 * * * *")`
   - Executes in Borrow-Service
   
2. **Query Overdue Records**
   ```sql
   SELECT * FROM borrow_record 
   WHERE status = 'ACTIVE' 
   AND end_date < CURRENT_DATE
   ```

3. **Mark as Overdue**
   - Updates status = OVERDUE
   - **Publishes Event**: `BookOverdueEvent` → RabbitMQ (sends full BorrowRecordDTO)

4. **Event Listeners (Both Async)**
   
   **Fine-Service Listener:**
   - Receives `BookOverdueEvent` or `BorrowRecordDTO`
   - Triggers fine calculation
   
   **Notification-Service Listener:**
   - Receives `BookOverdueEvent`
   - Sends overdue alert email
   - Stores notification

**Key Code:**
```java
// BorrowService.markOverdue() - Runs every hour
@Scheduled(cron = "0 0 * * * *")
public void markOverdue(){
    List<BorrowRecord> due = repo.findByStatusAndEndDateBefore(
        BorrowRecord.Status.ACTIVE, LocalDate.now());
    for(BorrowRecord r: due){
        r.setStatus(BorrowRecord.Status.OVERDUE);
        repo.save(r);
        rabbit.convertAndSend(..., RoutingKeys.BOOK_OVERDUE, r);  // Event
    }
}
```

---

### **Phase 4: Fine Calculation** 💰

```
Scheduler → Fine-Service → Borrow-Service (REST) → Fine-Service → RabbitMQ Event
```

1. **Scheduled Task Runs Every Hour (at 15 minutes)**
   - Cron: `@Scheduled(cron = "0 15 * * * *")`
   - Executes in Fine-Service
   
2. **Fetch Overdue Records (Synchronous REST Call)**
   ```
   Fine-Service → Borrow-Service: GET /api/borrow/overdue
   ```
   - Gets all records with status = OVERDUE
   
3. **Calculate Fine for Each Record**
   - For each overdue record:
     ```
     Fine-Service → Borrow-Service: GET /api/borrow/{recordId}
     ```
     - Gets full borrow record details
   
4. **Fine Calculation Logic**
   - **Overdue Fine**: $5/day, max $100
     ```
     daysOverdue = today - endDate
     fine = min(daysOverdue × $5, $100)
     ```
   - **Lost Book Fine**: Fixed $200
   
5. **Create/Update Fine**
   - Creates or updates `Fine` record
   - Sets status = PENDING
   - Sets dueDate = today + 30 days
   
6. **Publish Event (Async via RabbitMQ)**
   - `FineUpdatedEvent` → Notification Service
   
7. **Notification-Service (Async)**
   - Listens to `FineUpdatedEvent`
   - Sends fine notification email
   - Stores notification

**Key Code:**
```java
// FineService.scheduledFineCalc() - Runs every hour at :15
@Scheduled(cron = "0 15 * * * *")
public void scheduledFineCalc(){
    List<BorrowRecordDTO> overdueRecords = 
        borrowServiceClient.getOverdueRecords();  // REST call
    
    for (BorrowRecordDTO record : overdueRecords) {
        calculateAndApplyFine(...);
    }
}

// FineService.calculateAndApplyFine()
BorrowRecordDTO borrowRecord = 
    borrowServiceClient.getBorrowRecord(borrowRecordId);  // REST call
long daysOverdue = ChronoUnit.DAYS.between(endDate, today);
BigDecimal calculatedFine = DAILY_FINE_RATE.multiply(
    new BigDecimal(daysOverdue));
// Max $100 logic...
fineRepo.save(fine);
rabbit.convertAndSend(..., RoutingKeys.FINE_UPDATED, ...);  // Event
```

---

### **Phase 5: Payment Processing** 💳

```
USER → Fine-Service API → Payment History → RabbitMQ Event → Notification-Service
```

1. **Payment API Call**
   - Endpoint: `POST /api/fines/{userId}/pay/{fineId}`
   - User provides: userId, fineId, amount, paymentMethod
   
2. **Fine-Service Processing (Async)**
   - Validates fine exists and belongs to user
   - Creates `PaymentHistory` record
   - Updates fine:
     - paidAmount += amount
     - If fully paid: status = PAID
     - If partially paid: status = PARTIALLY_PAID
   
3. **Publish Event (Async via RabbitMQ)**
   - `PaymentCompletedEvent` → Notification Service
   
4. **Notification-Service (Async)**
   - Listens to `PaymentCompletedEvent`
   - Sends payment confirmation email
   - Stores notification

**Key Code:**
```java
// FineService.processPaymentAsync()
@Async
public void processPaymentAsync(...){
    PaymentHistory payment = new PaymentHistory();
    paymentHistoryRepo.save(payment);
    
    fine.setPaidAmount(fine.getPaidAmount().add(amount));
    if (fine.getOutstandingAmount() <= 0) {
        fine.setStatus(Fine.Status.PAID);
    }
    
    rabbit.convertAndSend(..., RoutingKeys.PAYMENT_COMPLETED, ...);  // Event
}
```

---

### **Phase 6: Due Date Reminders** 📧

```
Scheduler → Notification-Service → Borrow-Service (REST) → Notification-Service
```

1. **Scheduled Tasks (Daily)**
   - **3-Day Reminder**: Runs daily at 9:00 AM
   - **1-Day Reminder**: Runs daily at 9:00 AM
   - **Batch Reminder**: Runs daily at 10:00 AM
   
2. **Fetch Borrow Records (Synchronous REST Call)**
   ```
   Notification-Service → Borrow-Service: GET /api/borrow/due-in-days/{days}
   ```
   - Gets books due in specified days
   
3. **Send Notifications**
   - For each record, sends reminder email
   - Stores notification in database

**Key Code:**
```java
// NotificationReminderService.sendDueDateReminders()
@Scheduled(cron = "0 0 9 * * *")  // Daily at 9 AM
public void sendDueDateReminders() {
    List<BorrowRecordDTO> borrowsDueIn3Days = 
        borrowServiceClient.getBorrowsDueInDays(3);  // REST call
    
    for (BorrowRecordDTO borrow : borrowsDueIn3Days) {
        sendDueDateReminder(...);  // Email + Store notification
    }
}
```

---

## 🔗 Service Communication Patterns

### **1. Synchronous Communication (REST)**
Used for immediate data needs:
- **Borrow-Service ↔ Catalog-Service**
  - GET book details
  - PATCH book status
  
- **Fine-Service → Borrow-Service**
  - GET overdue records
  - GET specific borrow record
  
- **Notification-Service → Borrow-Service**
  - GET active borrows
  - GET borrows due in X days

### **2. Asynchronous Communication (RabbitMQ Events)**
Used for decoupled notifications and triggers:

**Topic Exchange**: `lib.events`

**Event Types:**
- `user.registered` → Notification Service
- `user.password.reset` → Notification Service
- `user.profile.changed` → Notification Service
- `borrow.requested` → Notification Service
- `borrow.approved` → Notification Service
- `book.returned` → Notification Service
- `book.overdue` → Fine Service + Notification Service
- `fine.updated` → Notification Service
- `payment.completed` → Notification Service
- `book.added` → Notification Service (optional)
- `book.updated` → Notification Service (optional)
- `book.removed` → Notification Service (optional)

---

## ⚙️ Scheduled Tasks

| Service | Task | Schedule | Purpose |
|---------|------|----------|---------|
| **Borrow-Service** | `markOverdue()` | Every hour (`0 0 * * * *`) | Mark ACTIVE books past due date as OVERDUE |
| **Fine-Service** | `scheduledFineCalc()` | Every hour at :15 (`0 15 * * * *`) | Calculate fines for all overdue records |
| **Notification-Service** | `sendDueDateReminders()` | Daily at 9 AM (`0 0 9 * * *`) | Send 3-day advance reminders |
| **Notification-Service** | `sendFinalDueDateReminders()` | Daily at 9 AM (`0 0 9 * * *`) | Send 1-day advance reminders |
| **Notification-Service** | `sendBatchDueDateReminders()` | Daily at 10 AM (`0 0 10 * * *`) | Batch reminders for books due in 7 days |

---

## 📊 Complete Example Flow: User to Fine

### Scenario: User borrows book, forgets to return, gets fined

1. **Day 0 - User Registration**
   ```
   POST /api/users/register
   → User-Service saves user
   → Event: USER_REGISTERED
   → Notification-Service sends welcome email
   ```

2. **Day 0 - User Borrows Book**
   ```
   POST /api/borrow {userId, bookId, days: 14}
   → Borrow-Service checks book availability (REST call to Catalog-Service)
   → Borrow-Service creates record: startDate=Day0, endDate=Day14, status=ACTIVE
   → Borrow-Service updates book status to BORROWED (REST call)
   → Event: BORROW_APPROVED
   → Notification-Service sends borrow confirmation
   ```

3. **Day 11 - Reminder Sent**
   ```
   Scheduler runs at 9 AM (Notification-Service)
   → Fetches books due in 3 days (REST call to Borrow-Service)
   → Finds user's book (due Day 14)
   → Sends 3-day reminder email
   ```

4. **Day 13 - Final Reminder**
   ```
   Scheduler runs at 9 AM (Notification-Service)
   → Fetches books due in 1 day (REST call)
   → Sends 1-day reminder email
   ```

5. **Day 15 - Book Becomes Overdue**
   ```
   Scheduler runs at :00 (Borrow-Service)
   → Finds book with endDate=Day14, status=ACTIVE
   → Updates status=OVERDUE
   → Event: BOOK_OVERDUE (sends BorrowRecordDTO)
   → Notification-Service receives event, sends overdue alert
   → Fine-Service receives event, triggers fine calculation
   ```

6. **Day 15 - Fine Calculated**
   ```
   Scheduler runs at :15 (Fine-Service)
   → Fetches all overdue records (REST call to Borrow-Service)
   → For each record, calculates fine: (Day15 - Day14) × $5 = $5
   → Creates/updates Fine record: amount=$5, status=PENDING
   → Event: FINE_UPDATED
   → Notification-Service sends fine notification
   ```

7. **Day 16 - Additional Fine**
   ```
   Scheduler runs at :15 (Fine-Service)
   → Recalculates: (Day16 - Day14) × $5 = $10
   → Updates Fine record: amount=$10
   → Event: FINE_UPDATED
   → Notification-Service sends updated fine notification
   ```

8. **Day 20 - User Pays Fine**
   ```
   POST /api/fines/{userId}/pay/{fineId} {amount: $25, paymentMethod: CREDIT_CARD}
   → Fine-Service processes payment (async)
   → Creates PaymentHistory record
   → Updates Fine: paidAmount=$25, status=PAID (since $25 > $30 total fine)
   → Event: PAYMENT_COMPLETED
   → Notification-Service sends payment confirmation
   ```

---

## 🗄️ Data Flow Diagram

```
┌─────────────┐
│   User      │
└──────┬──────┘
       │
       │ HTTP/REST
       ▼
┌─────────────────────────────────────────────────────────────┐
│                    API Gateway                              │
│              (Eureka Service Discovery)                     │
└─────────────────────────────────────────────────────────────┘
       │
       ├──────────────────────────────────────────────────┐
       │                                                  │
       ▼                                                  ▼
┌──────────────┐                                  ┌──────────────┐
│ User-Service │                                  │Catalog-Service│
└──────┬───────┘                                  └──────┬───────┘
       │                                                  │
       │ REST (Check Book)                               │
       ▼                                                  │
┌──────────────┐                                         │
│Borrow-Service│◄────────────────────────────────────────┘
└──────┬───────┘      REST (Update Status)
       │
       │ REST (Get Overdue)
       ▼
┌──────────────┐
│Fine-Service  │
└──────────────┘

All Services ──RabbitMQ Events──► Notification-Service
```

---

## 🔐 Security Flow

1. **User Login**
   ```
   POST /api/users/login
   → User-Service validates credentials
   → Generates JWT token with roles
   → Returns token
   ```

2. **Authenticated Request**
   ```
   GET /api/books (with JWT token)
   → API Gateway validates JWT
   → Catalog-Service receives authenticated request
   → Returns book list
   ```

3. **Librarian-Only Endpoints**
   ```
   POST /api/books (with JWT token, role=LIBRARIAN)
   → API Gateway validates JWT
   → Catalog-Service checks @PreAuthorize("hasRole('LIBRARIAN')")
   → Only proceeds if role matches
   ```

---

## 💾 Caching Strategy

- **Book Search**: Cached in Redis (30 min TTL)
- **Book by ISBN**: Cached in Redis (2 hours TTL)
- **Active Loans**: Cached in Redis (15 min TTL)
- **Cache Eviction**: Automatic on updates (using @CacheEvict)

---

## 📝 Key Takeaways

1. **Synchronous (REST)**: Used when immediate data is needed (book status, borrow records)
2. **Asynchronous (RabbitMQ)**: Used for decoupled notifications and triggers
3. **Schedulers**: Handle time-based tasks (overdue detection, fine calculation, reminders)
4. **Event-Driven**: Services communicate via events, not direct coupling
5. **Service Discovery**: Eureka enables service-to-service REST calls
6. **Caching**: Redis improves performance for frequent queries
7. **Security**: JWT tokens and role-based authorization protect endpoints

