# Email Notification Testing Guide

This guide explains how to test the email notification functionality in the Library Management System.

## Prerequisites

1. **Notification Service Running**: Ensure the notification service is running on port 8085 (or configured port)
2. **Gmail App Password**: The configured Gmail account must have an app password generated
3. **Network Access**: The service must be able to connect to Gmail SMTP servers

## Email Configuration

The email configuration is in `notification-service/src/main/resources/application.yml`:

```yaml
spring:
  mail:
    host: smtp.gmail.com
    port: 587
    username: hrushikeshpathrabe23@gmail.com
    password: mmnk ilpo bsxj wvbg
    properties:
      mail:
        smtp:
          auth: true
          starttls:
            enable: true
            required: true
```

**Note**: 
- The password in the config is a Gmail App Password (not the regular Gmail password)
- If you need to use a different Gmail account, you must:
  1. Enable 2-Factor Authentication on your Gmail account
  2. Generate an App Password: https://myaccount.google.com/apppasswords
  3. Update the `username` and `password` in `application.yml`

## Testing Methods

### Method 1: Using Postman Collection

1. **Check Email Service Status**
   - Endpoint: `GET /api/notifications/test/email/status`
   - This verifies if the email service is configured correctly

2. **Send Test Email**
   - Endpoint: `POST /api/notifications/test/email`
   - Body:
     ```json
     {
       "to": "recipient@example.com",
       "subject": "Test Email from Library Management System",
       "message": "This is a test email to verify email notification functionality."
     }
     ```
   - Replace `recipient@example.com` with your actual email address

### Method 2: Using cURL

**Check Status:**
```bash
curl -X GET http://localhost:7000/api/notifications/test/email/status
```

**Send Test Email:**
```bash
curl -X POST http://localhost:7000/api/notifications/test/email \
  -H "Content-Type: application/json" \
  -d '{
    "to": "recipient@example.com",
    "subject": "Test Email from Library Management System",
    "message": "This is a test email to verify email notification functionality."
  }'
```

### Method 3: Using Test Script

Run the provided test script:
```bash
./test-email-notification.sh [BASE_URL] [TEST_EMAIL]

# Example:
./test-email-notification.sh http://localhost:7000 your-email@example.com
```

## Testing Real Notification Scenarios

### 1. User Registration Email

Trigger by registering a new user:
```bash
curl -X POST http://localhost:7000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "email": "newuser@example.com",
    "name": "Test User",
    "password": "password123",
    "roles": ["USER"]
  }'
```

**Expected**: An email should be sent to `newuser@example.com` with a welcome message.

### 2. Password Reset Email

Trigger by requesting a password reset:
```bash
curl -X POST http://localhost:7000/api/auth/password/forgot \
  -H "Content-Type: application/json" \
  -d '{
    "email": "user@example.com"
  }'
```

**Expected**: An email should be sent with a password reset token.

### 3. Book Borrowing Approval

When a librarian approves a borrow request, an email should be sent to the user.

### 4. Due Date Reminders

The system sends automatic reminders when books are due. These are triggered by the scheduled task in `NotificationReminderService`.

### 5. Overdue Notifications

When a book becomes overdue, an email notification is sent.

### 6. Fine Notifications

When a fine is calculated or updated, an email notification is sent.

## Troubleshooting

### Issue: Email service not configured

**Error**: `"mailSenderConfigured": false`

**Solution**: 
1. Check that `spring-boot-starter-mail` dependency is in `pom.xml`
2. Verify email configuration in `application.yml`
3. Restart the notification service

### Issue: Authentication failed

**Error**: `535-5.7.8 Username and Password not accepted`

**Solution**:
1. Ensure you're using a Gmail App Password, not the regular password
2. Verify the username is correct
3. Make sure 2-Factor Authentication is enabled on the Gmail account
4. Regenerate the App Password if needed

### Issue: Connection timeout

**Error**: `Could not connect to SMTP host`

**Solution**:
1. Check network connectivity
2. Verify firewall isn't blocking port 587
3. Ensure `smtp.gmail.com` is accessible

### Issue: Emails not received

**Check**:
1. Check spam/junk folder
2. Verify the recipient email address is correct
3. Check notification service logs: `logs/notification-service.log`
4. Look for `[EMAIL SENT]` or `[EMAIL ERROR]` log entries

## Logs

Check notification service logs for email-related messages:

```bash
tail -f logs/notification-service.log | grep EMAIL
```

Expected log entries:
- `[EMAIL SENT]` - Email sent successfully
- `[EMAIL ERROR]` - Email sending failed
- `[TEST EMAIL SENT]` - Test email sent successfully
- `[TEST EMAIL ERROR]` - Test email failed

## Success Indicators

✅ **Email service configured**: Status endpoint returns `"mailSenderConfigured": true`
✅ **Test email sent**: Test endpoint returns `"status": "success"`
✅ **Email received**: Check your inbox for the test email
✅ **Notifications stored**: Check database for notification records

## Testing Checklist

- [ ] Email service status check returns configured
- [ ] Test email endpoint sends successfully
- [ ] Test email received in inbox
- [ ] User registration triggers welcome email
- [ ] Password reset triggers reset email
- [ ] Borrow approval triggers confirmation email
- [ ] Overdue notifications are sent
- [ ] Fine notifications are sent
- [ ] All notifications are stored in database

## Notes

- Email sending is **asynchronous** - emails are sent in the background
- Notifications are **always stored** in the database, even if email fails
- The system gracefully handles email failures without breaking functionality
- If email service is not configured, notifications will still be stored but no emails will be sent

