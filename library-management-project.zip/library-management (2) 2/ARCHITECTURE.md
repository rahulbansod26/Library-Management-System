# Library Management System - Architecture Documentation

## System Architecture Overview

This document describes the high-level architecture of the Library Management System, including service flow, communication patterns, and infrastructure components.

---

## High-Level Architecture Flow

### Request Flow

```
Client Application
    ↓
API Gateway (Port: 7000)
    ↓ (uses Eureka for service discovery)
Microservices (Ports: 8081-8085)
    ↓
Databases (MySQL)
```

### Detailed Service Flow

1. **Eureka Service Discovery (Port: 8761)** - Starts first
   - Service registry and discovery
   - All services register with Eureka on startup

2. **API Gateway (Port: 7000)** - Starts second
   - Connects to Eureka to discover services
   - Routes client requests to appropriate microservices
   - Single entry point for all API calls

3. **Microservices** - Start after Eureka and Gateway
   - Register with Eureka on startup
   - Receive requests routed from API Gateway
   - Connect to their respective databases

4. **Databases (MySQL)**
   - Each service has its own database
   - Isolated data storage per service

---

## High-Level Design Diagram

```mermaid
graph TB
    subgraph "Client Layer"
        Client[Client Applications]
    end
    
    subgraph "Service Discovery"
        Eureka[Eureka Service Discovery<br/>Port: 8761]
    end
    
    subgraph "Gateway Layer"
        Gateway[API Gateway<br/>Port: 7000]
    end
    
    subgraph "Microservices Layer"
        UserService[User Service<br/>Port: 8081]
        CatalogService[Catalog Service<br/>Port: 8082]
        BorrowService[Borrow Service<br/>Port: 8083]
        FineService[Fine Service<br/>Port: 8084]
        NotificationService[Notification Service<br/>Port: 8085]
    end
    
    subgraph "Data Layer"
        UserDB[(User Database<br/>userdb - MySQL)]
        CatalogDB[(Catalog Database<br/>catalogdb - MySQL)]
        BorrowDB[(Borrow Database<br/>borrowdb - MySQL)]
        FineDB[(Fine Database<br/>finedb - MySQL)]
        NotifDB[(Notification Database<br/>notifdb - MySQL)]
        Redis[(Redis Cache<br/>Port: 6379)]
    end
    
    subgraph "Message Broker"
        RabbitMQ[RabbitMQ<br/>Message Broker<br/>Port: 5672]
    end
    
    subgraph "External Services"
        SMTP[SMTP Server<br/>Gmail - Port: 587]
    end
    
    %% Client to Gateway
    Client --> Gateway
    
    %% Eureka Service Discovery (Registration)
    Eureka -.->|Registers| Gateway
    Eureka -.->|Registers| UserService
    Eureka -.->|Registers| CatalogService
    Eureka -.->|Registers| BorrowService
    Eureka -.->|Registers| FineService
    Eureka -.->|Registers| NotificationService
    
    %% API Gateway Routing (Clean vertical flow)
    Gateway -->|/api/auth/**<br/>/api/profile/**| UserService
    Gateway -->|/api/books/**| CatalogService
    Gateway -->|/api/borrow/**| BorrowService
    Gateway -->|/api/fines/**| FineService
    Gateway -->|/api/notifications/**| NotificationService
    
    %% Service to Database (Vertical, aligned)
    UserService --> UserDB
    CatalogService --> CatalogDB
    BorrowService --> BorrowDB
    FineService --> FineDB
    NotificationService --> NotifDB
    
    %% Cache connection
    UserService --> Redis
    
    %% Service-to-Service REST calls (grouped to avoid crossing)
    BorrowService -.->|REST: Book Lookup| CatalogService
    FineService -.->|REST: Overdue Records| BorrowService
    NotificationService -.->|REST: User Email| UserService
    NotificationService -.->|REST: Borrow Records| BorrowService
    
    %% Message Broker connections (grouped at bottom)
    UserService --> RabbitMQ
    CatalogService --> RabbitMQ
    BorrowService --> RabbitMQ
    FineService --> RabbitMQ
    NotificationService --> RabbitMQ
    
    %% External service
    NotificationService --> SMTP
    
    %% Styling
    style Eureka fill:#e1f5ff,stroke:#01579b,stroke-width:2px
    style Gateway fill:#fff4e1,stroke:#e65100,stroke-width:2px
    style UserService fill:#e8f5e9,stroke:#2e7d32,stroke-width:2px
    style CatalogService fill:#e8f5e9,stroke:#2e7d32,stroke-width:2px
    style BorrowService fill:#e8f5e9,stroke:#2e7d32,stroke-width:2px
    style FineService fill:#e8f5e9,stroke:#2e7d32,stroke-width:2px
    style NotificationService fill:#e8f5e9,stroke:#2e7d32,stroke-width:2px
    style RabbitMQ fill:#f3e5f5,stroke:#6a1b9a,stroke-width:2px
    style Redis fill:#ffebee,stroke:#c62828,stroke-width:2px
    style SMTP fill:#fff3e0,stroke:#ef6c00,stroke-width:2px
```

---

## Service Registration and Discovery

### Eureka Service Discovery

**Port**: 8761  
**URL**: http://localhost:8761

All services register with Eureka on startup:

1. **Eureka Service** - Service registry (starts first)
2. **API Gateway** - Registers with Eureka, uses it for service discovery
3. **User Service** - Registers as `USER-SERVICE`
4. **Catalog Service** - Registers as `CATALOG-SERVICE`
5. **Borrow Service** - Registers as `BORROW-SERVICE`
6. **Fine Service** - Registers as `FINE-SERVICE`
7. **Notification Service** - Registers as `NOTIFICATION-SERVICE`

### API Gateway Routing

The API Gateway uses Eureka to discover services and routes requests based on path:

| Path Pattern | Routes To | Service Name |
|--------------|-----------|--------------|
| `/api/auth/**` | User Service | USER-SERVICE |
| `/api/profile/**` | User Service | USER-SERVICE |
| `/api/books/**` | Catalog Service | CATALOG-SERVICE |
| `/api/borrow/**` | Borrow Service | BORROW-SERVICE |
| `/api/fines/**` | Fine Service | FINE-SERVICE |
| `/api/notifications/**` | Notification Service | NOTIFICATION-SERVICE |

---

## Database Architecture

### Database per Service Pattern

Each microservice has its own isolated database:

| Service | Database Name | Port | Purpose |
|---------|--------------|------|---------|
| User Service | `userdb` | 3306 | User accounts, authentication, profiles |
| Catalog Service | `catalogdb` | 3306 | Book catalog, metadata |
| Borrow Service | `borrowdb` | 3306 | Borrowing records, requests |
| Fine Service | `finedb` | 3306 | Fine records, payment history |
| Notification Service | `notifdb` | 3306 | Notifications, email tracking |

### Database Connection

All services connect to MySQL on `localhost:3306` with:
- **Username**: `root`
- **Password**: (empty/default)
- **Auto-create**: Databases are created automatically if they don't exist

---

## Communication Patterns

### Synchronous Communication (REST)

1. **Client → API Gateway → Microservice**
   - All client requests go through API Gateway
   - Gateway uses Eureka to locate services
   - Load balancing handled by Spring Cloud LoadBalancer

2. **Service-to-Service (Direct REST)**
   - Borrow Service → Catalog Service (book lookup)
   - Fine Service → Borrow Service (overdue records)
   - Notification Service → User Service (fetch user email)
   - Notification Service → Borrow Service (fetch borrow records)

### Asynchronous Communication (RabbitMQ)

**RabbitMQ Port**: 5672  
**Management UI**: http://localhost:15672 (if enabled)

#### Event-Driven Architecture

All services publish events to RabbitMQ:

| Event Type | Publisher | Consumer | Queue |
|------------|-----------|----------|-------|
| User Registered | User Service | Notification Service | `user.events.q` |
| Password Reset | User Service | Notification Service | `user.events.q` |
| Profile Changed | User Service | Notification Service | `user.events.q` |
| Book Added | Catalog Service | - | `catalog.events.q` |
| Book Updated | Catalog Service | - | `catalog.events.q` |
| Borrow Approved | Borrow Service | Notification Service | `borrow.events.q` |
| Book Returned | Borrow Service | Notification Service | `borrow.events.q` |
| Book Overdue | Borrow Service | Fine Service, Notification Service | `borrow.events.q` |
| Fine Updated | Fine Service | Notification Service | `fine.events.q` |
| Payment Completed | Fine Service | Notification Service | `fine.events.q` |

#### Event Flow Example

```
User Service (publishes)
    ↓ UserRegisteredEvent
RabbitMQ (message broker)
    ↓ event delivery
Notification Service (consumes)
    ↓ processes event
Sends welcome email
Stores notification in database
```

---

## Infrastructure Components

### Redis Cache (Port: 6379)

**Used by**: User Service

- Caches user authentication data
- Improves login performance
- Session management (optional)

### SMTP Server (Gmail - Port: 587)

**Used by**: Notification Service

- Email notifications via JavaMailSender
- Gmail SMTP with App Password authentication
- Sends welcome emails, reminders, alerts

---

## Service-to-Service Communication Details

### Borrow Service → Catalog Service

**Purpose**: Validate book availability before borrowing

```
Borrow Service
    ↓ GET /api/books/{bookId}
Catalog Service
    ↓ Returns BookDTO
Borrow Service
    ↓ Validates availability
Creates borrow record
```

### Fine Service → Borrow Service

**Purpose**: Fetch overdue borrow records for fine calculation

```
Fine Service
    ↓ GET /api/borrow/overdue
Borrow Service
    ↓ Returns List<BorrowRecordDTO>
Fine Service
    ↓ Calculates fines
Creates fine records
```

### Notification Service → User Service

**Purpose**: Fetch user email for sending notifications

```
Notification Service
    ↓ GET /api/users/{userId}/email
User Service
    ↓ Returns email
Notification Service
    ↓ Sends email
```

### Notification Service → Borrow Service

**Purpose**: Fetch borrow records for scheduled reminders

```
Notification Service
    ↓ GET /api/borrow/due-in-days/{days}
Borrow Service
    ↓ Returns List<BorrowRecordDTO>
Notification Service
    ↓ Sends reminder emails
```

---

## Request Flow Example

### Example: User Borrows a Book

```
1. Client Request
   POST http://localhost:7000/api/borrow
   ↓
2. API Gateway
   Discovers BORROW-SERVICE via Eureka
   Routes to: http://borrow-service:8083/api/borrow
   ↓
3. Borrow Service
   Validates request
   ↓ REST call
4. Catalog Service (via Eureka)
   GET /api/books/{bookId}
   Returns book details
   ↓
5. Borrow Service
   Creates borrow record in borrowdb
   Updates book status via Catalog Service
   ↓ Publishes event
6. RabbitMQ
   Receives BorrowApprovedEvent
   ↓ Delivers to queue
7. Notification Service
   Consumes BorrowApprovedEvent
   Fetches user email from User Service
   Sends confirmation email via SMTP
   Stores notification in notifdb
   ↓
8. Response
   Returns borrow record to client
```

---

## Service Ports Summary

| Component | Port | Protocol | Description |
|-----------|------|----------|-------------|
| Eureka | 8761 | HTTP | Service discovery dashboard |
| API Gateway | 7000 | HTTP | Main entry point |
| User Service | 8081 | HTTP | User management |
| Catalog Service | 8082 | HTTP | Book catalog |
| Borrow Service | 8083 | HTTP | Book borrowing |
| Fine Service | 8084 | HTTP | Fine management |
| Notification Service | 8085 | HTTP | Notifications |
| MySQL | 3306 | TCP | Database |
| RabbitMQ | 5672 | AMQP | Message broker |
| Redis | 6379 | TCP | Cache |

---

## Security Architecture

### Authentication Flow

```
Client
    ↓ POST /api/auth/login
API Gateway
    ↓ Routes to User Service
User Service
    ↓ Validates credentials
    ↓ Generates JWT token
Returns token
    ↓
Client
    ↓ Stores token
Subsequent requests
    ↓ Include: Authorization: Bearer <token>
API Gateway / Microservices
    ↓ Validate JWT
Process request
```

### JWT Token Structure

- **Issuer**: User Service
- **Subject**: User email
- **Claims**: User ID, Roles (USER, LIBRARIAN)
- **Expiration**: 120 minutes
- **Secret**: Configured in each service

### Role-Based Access Control

| Role | Permissions |
|------|-------------|
| USER | Borrow books, view profile, view notifications |
| LIBRARIAN | All USER permissions + Add/Update/Delete books |
| ADMIN | All permissions |

---

## Deployment Architecture

### Startup Order

1. **Eureka Service** (Port: 8761)
   - Must start first
   - Other services depend on it

2. **API Gateway** (Port: 7000)
   - Starts second
   - Connects to Eureka

3. **User Service** (Port: 8081)
   - Can start in parallel with other services
   - Registers with Eureka

4. **Catalog Service** (Port: 8082)
   - Can start in parallel with other services

5. **Borrow Service** (Port: 8083)
   - Depends on Catalog Service (for book validation)
   - Registers with Eureka

6. **Fine Service** (Port: 8084)
   - Depends on Borrow Service (for overdue records)
   - Registers with Eureka

7. **Notification Service** (Port: 8085)
   - Depends on User Service and Borrow Service
   - Registers with Eureka

### Service Dependencies

```
Eureka (no dependencies)
    ↓
API Gateway (depends on Eureka)
    ↓
User Service (depends on Eureka)
Catalog Service (depends on Eureka)
    ↓
Borrow Service (depends on Eureka + Catalog Service)
    ↓
Fine Service (depends on Eureka + Borrow Service)
Notification Service (depends on Eureka + User Service + Borrow Service)
```

---

## Scalability Considerations

### Horizontal Scaling

- All microservices are stateless (except database connections)
- Can run multiple instances of each service
- Eureka handles service discovery and load balancing
- API Gateway distributes load across service instances

### Database Scaling

- Each service has its own database
- Can scale databases independently
- Consider read replicas for read-heavy services
- Sharding possible per service domain

### Caching Strategy

- Redis caching in User Service
- Consider adding caching to Catalog Service (book lookups)
- Consider adding caching to Borrow Service (active borrows)

---

## Monitoring and Observability

### Service Health

- Each service exposes `/actuator/health` endpoint
- Eureka dashboard shows service status
- Health checks integrated with Eureka registration

### Logging

- Structured logging with SLF4J and Logback
- Logs written to `logs/` directory per service
- Log format: Timestamp, Level, Service, Message

### Distributed Tracing

- Consider implementing Spring Cloud Sleuth
- Track requests across services
- Monitor service-to-service calls

---

## Error Handling

### Global Exception Handling

- Each service has `GlobalExceptionHandler`
- Consistent error response format
- Error codes and messages standardized

### Circuit Breaker Pattern

- Consider implementing Spring Cloud Circuit Breaker
- Handle service failures gracefully
- Fallback mechanisms for critical paths

---

## Future Enhancements

1. **API Gateway Enhancements**
   - Rate limiting
   - Request/response transformation
   - API versioning

2. **Security Enhancements**
   - OAuth2 integration
   - API key management
   - Request signing

3. **Observability**
   - Distributed tracing (Zipkin/Jaeger)
   - Metrics collection (Prometheus)
   - Log aggregation (ELK stack)

4. **Performance**
   - API Gateway caching
   - Database connection pooling optimization
   - Async processing improvements

