package com.hashedin.library.catalog.service;

import com.hashedin.library.catalog.domain.Book;
import com.hashedin.library.catalog.repo.BookRepo;
import com.hashedin.library.common.events.BookAddedEvent;
import com.hashedin.library.common.events.BookRemovedEvent;
import com.hashedin.library.common.events.BookUpdatedEvent;
import com.hashedin.library.common.events.RoutingKeys;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.rabbit.core.RabbitTemplate;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class BookServiceTest {

    @Mock
    private BookRepo repo;

    @Mock
    private RabbitTemplate rabbit;

    @Mock
    private TopicExchange exchange;

    @InjectMocks
    private BookService bookService;

    private Book testBook;

    @BeforeEach
    void setUp() {
        testBook = new Book();
        testBook.setId("book-123");
        testBook.setTitle("Test Book");
        testBook.setAuthor("Test Author");
        testBook.setIsbn("123-456-789");
        testBook.setStatus(Book.Status.AVAILABLE);
        testBook.setQuantity(5);
    }

    @Test
    void testAdd_Success() {
        // Arrange
        Book newBook = new Book();
        newBook.setTitle("New Book");
        newBook.setAuthor("New Author");
        newBook.setIsbn("978-1234567890");

        when(repo.save(any(Book.class))).thenAnswer(invocation -> {
            Book book = invocation.getArgument(0);
            book.setId("new-book-id");
            return book;
        });
        when(exchange.getName()).thenReturn("library-exchange");

        // Act
        Book result = bookService.add(newBook);

        // Assert
        assertNotNull(result);
        assertNotNull(result.getId());
        verify(repo).save(newBook);

        // Verify event was published
        ArgumentCaptor<BookAddedEvent> eventCaptor = ArgumentCaptor.forClass(BookAddedEvent.class);
        verify(rabbit).convertAndSend(eq("library-exchange"), eq(RoutingKeys.BOOK_ADDED), eventCaptor.capture());
        
        BookAddedEvent event = eventCaptor.getValue();
        assertEquals(result.getId(), event.getBookId());
        assertEquals(result.getTitle(), event.getTitle());
    }

    @Test
    void testFindById_Success() {
        // Arrange
        String bookId = "book-123";
        when(repo.findById(bookId)).thenReturn(Optional.of(testBook));

        // Act
        Optional<Book> result = bookService.findById(bookId);

        // Assert
        assertTrue(result.isPresent());
        assertEquals(testBook.getId(), result.get().getId());
        verify(repo).findById(bookId);
    }

    @Test
    void testFindById_NotFound() {
        // Arrange
        String bookId = "nonexistent";
        when(repo.findById(bookId)).thenReturn(Optional.empty());

        // Act
        Optional<Book> result = bookService.findById(bookId);

        // Assert
        assertFalse(result.isPresent());
        verify(repo).findById(bookId);
    }

    @Test
    void testFindAll() {
        // Arrange
        List<Book> books = Arrays.asList(testBook);
        when(repo.findAll()).thenReturn(books);

        // Act
        List<Book> result = bookService.findAll();

        // Assert
        assertEquals(1, result.size());
        assertEquals(testBook.getId(), result.get(0).getId());
        verify(repo).findAll();
    }

    @Test
    void testByIsbn_Success() {
        // Arrange
        String isbn = "123-456-789";
        when(repo.findByIsbn(isbn)).thenReturn(Optional.of(testBook));

        // Act
        Optional<Book> result = bookService.byIsbn(isbn);

        // Assert
        assertTrue(result.isPresent());
        assertEquals(testBook.getIsbn(), result.get().getIsbn());
        verify(repo).findByIsbn(isbn);
    }

    @Test
    void testSearch() {
        // Arrange
        String query = "Test";
        List<Book> books = Arrays.asList(testBook);
        when(repo.findByTitleContainingIgnoreCase(query)).thenReturn(books);

        // Act
        List<Book> result = bookService.search(query);

        // Assert
        assertEquals(1, result.size());
        verify(repo).findByTitleContainingIgnoreCase(query);
    }

    @Test
    void testFindByAuthor() {
        // Arrange
        String author = "Test Author";
        List<Book> books = Arrays.asList(testBook);
        when(repo.findByAuthorContainingIgnoreCase(author)).thenReturn(books);

        // Act
        List<Book> result = bookService.findByAuthor(author);

        // Assert
        assertEquals(1, result.size());
        assertEquals(testBook.getAuthor(), result.get(0).getAuthor());
        verify(repo).findByAuthorContainingIgnoreCase(author);
    }

    @Test
    void testFindByGenre() {
        // Arrange
        String genre = "Fiction";
        testBook.setGenre(genre);
        List<Book> books = Arrays.asList(testBook);
        when(repo.findByGenreIgnoreCase(genre)).thenReturn(books);

        // Act
        List<Book> result = bookService.findByGenre(genre);

        // Assert
        assertEquals(1, result.size());
        verify(repo).findByGenreIgnoreCase(genre);
    }

    @Test
    void testUpdate_Success() {
        // Arrange
        when(repo.save(any(Book.class))).thenReturn(testBook);
        when(exchange.getName()).thenReturn("library-exchange");

        // Act
        Book result = bookService.update(testBook);

        // Assert
        assertNotNull(result);
        verify(repo).save(testBook);
        verify(rabbit).convertAndSend(eq("library-exchange"), eq(RoutingKeys.BOOK_UPDATED), any(BookUpdatedEvent.class));
    }

    @Test
    void testRemove_Success() {
        // Arrange
        String bookId = "book-123";
        when(repo.findById(bookId)).thenReturn(Optional.of(testBook));
        when(exchange.getName()).thenReturn("library-exchange");

        // Act
        bookService.remove(bookId);

        // Assert
        verify(repo).findById(bookId);
        verify(repo).deleteById(bookId);
        verify(rabbit).convertAndSend(eq("library-exchange"), eq(RoutingKeys.BOOK_REMOVED), any(BookRemovedEvent.class));
    }

    @Test
    void testRemove_NotFound() {
        // Arrange
        String bookId = "nonexistent";
        when(repo.findById(bookId)).thenReturn(Optional.empty());

        // Act
        bookService.remove(bookId);

        // Assert
        verify(repo).findById(bookId);
        verify(repo, never()).deleteById(any());
        verify(rabbit, never()).convertAndSend(anyString(), anyString(), any(BookRemovedEvent.class));
    }

    @Test
    void testUpdateBookStatus_Success() {
        // Arrange
        String bookId = "book-123";
        Book.Status newStatus = Book.Status.BORROWED;
        when(repo.findById(bookId)).thenReturn(Optional.of(testBook));
        when(repo.save(any(Book.class))).thenReturn(testBook);
        when(exchange.getName()).thenReturn("library-exchange");

        // Act
        bookService.updateBookStatus(bookId, newStatus);

        // Assert
        assertEquals(newStatus, testBook.getStatus());
        verify(repo).findById(bookId);
        verify(repo).save(testBook);
        verify(rabbit).convertAndSend(eq("library-exchange"), eq(RoutingKeys.BOOK_UPDATED), any(BookUpdatedEvent.class));
    }

    @Test
    void testUpdateBookStatus_BookNotFound() {
        // Arrange
        String bookId = "nonexistent";
        Book.Status newStatus = Book.Status.BORROWED;
        when(repo.findById(bookId)).thenReturn(Optional.empty());

        // Act
        bookService.updateBookStatus(bookId, newStatus);

        // Assert
        verify(repo).findById(bookId);
        verify(repo, never()).save(any());
        verify(rabbit, never()).convertAndSend(anyString(), anyString(), any(BookUpdatedEvent.class));
    }
}

