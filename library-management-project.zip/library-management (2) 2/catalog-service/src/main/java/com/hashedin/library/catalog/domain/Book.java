
package com.hashedin.library.catalog.domain;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
public class Book {
    public enum Status { AVAILABLE, BORROWED, RESERVED, REMOVED }
    
    @Id 
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    
    @Column(nullable=false) 
    private String title;
    
    private String author;
    private String genre;
    
    @Column(unique = true) 
    private String isbn;
    
    private String publisher;
    private Integer publicationYear;
    private String description;
    
    @Enumerated(EnumType.STRING) 
    private Status status = Status.AVAILABLE;
    
    private int quantity = 1;
    private Instant createdAt = Instant.now();
    private Instant updatedAt = Instant.now();

    @PreUpdate
    protected void onUpdate() {
        updatedAt = Instant.now();
    }

    // Getters
    public String getId() { return id; }
    public String getTitle() { return title; }
    public String getAuthor() { return author; }
    public String getGenre() { return genre; }
    public String getIsbn() { return isbn; }
    public String getPublisher() { return publisher; }
    public Integer getPublicationYear() { return publicationYear; }
    public String getDescription() { return description; }
    public Status getStatus() { return status; }
    public int getQuantity() { return quantity; }
    public Instant getCreatedAt() { return createdAt; }
    public Instant getUpdatedAt() { return updatedAt; }

    // Setters
    public void setId(String id) { this.id = id; }
    public void setTitle(String title) { this.title = title; }
    public void setAuthor(String author) { this.author = author; }
    public void setGenre(String genre) { this.genre = genre; }
    public void setIsbn(String isbn) { this.isbn = isbn; }
    public void setPublisher(String publisher) { this.publisher = publisher; }
    public void setPublicationYear(Integer publicationYear) { this.publicationYear = publicationYear; }
    public void setDescription(String description) { this.description = description; }
    public void setStatus(Status status) { this.status = status; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
    public void setCreatedAt(Instant createdAt) { this.createdAt = createdAt; }
    public void setUpdatedAt(Instant updatedAt) { this.updatedAt = updatedAt; }
}
