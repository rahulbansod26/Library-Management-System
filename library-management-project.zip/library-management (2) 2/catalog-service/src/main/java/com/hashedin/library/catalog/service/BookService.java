
package com.hashedin.library.catalog.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hashedin.library.catalog.domain.Book;
import com.hashedin.library.catalog.repo.BookRepo;
import com.hashedin.library.common.events.BookAddedEvent;
import com.hashedin.library.common.events.BookRemovedEvent;
import com.hashedin.library.common.events.BookUpdatedEvent;
import com.hashedin.library.common.events.RoutingKeys;

@Service
public class BookService {
    private static final Logger log = LoggerFactory.getLogger(BookService.class);
    private final BookRepo repo;
    private final RabbitTemplate rabbit;
    private final TopicExchange exchange;

    public BookService(BookRepo repo, RabbitTemplate rabbit, TopicExchange exchange){
        this.repo=repo; this.rabbit=rabbit; this.exchange=exchange;
    }

    @CacheEvict(cacheNames = {"book_search","book_by_isbn"}, allEntries = true)
    @Transactional
    public Book add(Book b){
        Book saved = repo.save(b);
        rabbit.convertAndSend(exchange.getName(), RoutingKeys.BOOK_ADDED, 
                new BookAddedEvent(saved.getId(), saved.getTitle()));
        log.info("Book added: id={}, title={}, isbn={}", saved.getId(), saved.getTitle(), saved.getIsbn());
        return saved;
    }

    @CacheEvict(cacheNames = {"book_search","book_by_isbn"}, allEntries = true)
    @Transactional
    public Book update(Book b){ 
        Book updated = repo.save(b);
        rabbit.convertAndSend(exchange.getName(), RoutingKeys.BOOK_UPDATED, 
                new BookUpdatedEvent(updated.getId(), updated.getTitle()));
        log.info("Book updated: id={}, title={}", updated.getId(), updated.getTitle());
        return updated;
    }

    @CacheEvict(cacheNames = {"book_search","book_by_isbn"}, allEntries = true)
    @Transactional
    public void remove(String id){ 
        Optional<Book> bookOpt = repo.findById(id);
        if (bookOpt.isPresent()) {
            Book book = bookOpt.get();
            repo.deleteById(id);
            rabbit.convertAndSend(exchange.getName(), RoutingKeys.BOOK_REMOVED, 
                    new BookRemovedEvent(book.getId(), book.getTitle()));
            log.info("Book removed: id={}, title={}", book.getId(), book.getTitle());
        }
    }

    public Optional<Book> findById(String id) {
        return repo.findById(id);
    }

    public List<Book> findAll() {
        return repo.findAll();
    }

    @Cacheable(cacheNames = "book_by_isbn", key = "#isbn")
    public Optional<Book> byIsbn(String isbn){ 
        return repo.findByIsbn(isbn); 
    }

    @Cacheable(cacheNames = "book_search", key = "#query", unless = "#result == null || #result.isEmpty()")
    public List<Book> search(String query){ 
        return repo.findByTitleContainingIgnoreCase(query); 
    }

    public List<Book> findByAuthor(String author) {
        return repo.findByAuthorContainingIgnoreCase(author);
    }

    public List<Book> findByGenre(String genre) {
        return repo.findByGenreIgnoreCase(genre);
    }

    @Transactional
    public void updateBookStatus(String bookId, Book.Status status) {
        repo.findById(bookId).ifPresent(book -> {
            book.setStatus(status);
            repo.save(book);
            rabbit.convertAndSend(exchange.getName(), RoutingKeys.BOOK_UPDATED, 
                    new BookUpdatedEvent(book.getId(), book.getTitle()));
        });
    }
}
