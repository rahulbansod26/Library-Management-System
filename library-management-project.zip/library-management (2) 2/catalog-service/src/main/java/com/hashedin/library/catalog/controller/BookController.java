package com.hashedin.library.catalog.controller;

import com.hashedin.library.catalog.domain.Book;
import com.hashedin.library.catalog.repo.BookRepo;
import com.hashedin.library.catalog.service.BookService;
import com.hashedin.library.common.exception.BadRequestException;
import com.hashedin.library.common.exception.ResourceNotFoundException;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/books")
public class BookController {
    private final BookService service;
    private final BookRepo repo;

    public BookController(BookService service, BookRepo repo) {
        this.service = service;
        this.repo = repo;
    }

    record SearchRequest(String q) {}

    @GetMapping
    public ResponseEntity<List<Book>> getAll() {
        return ResponseEntity.ok(service.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Book> getById(@PathVariable String id) {
        return service.findById(id)
                .map(ResponseEntity::ok)
                .orElseThrow(() -> new ResourceNotFoundException("Book", id));
    }

    @PostMapping
    @PreAuthorize("hasRole('LIBRARIAN')")
    public ResponseEntity<Book> add(@RequestBody Book req) {
        return ResponseEntity.ok(service.add(req));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('LIBRARIAN')")
    public ResponseEntity<Book> update(@PathVariable String id, @RequestBody Book req) {
        Book updated = repo.findById(id).map(existing -> {
            existing.setTitle(req.getTitle());
            existing.setAuthor(req.getAuthor());
            existing.setGenre(req.getGenre());
            existing.setDescription(req.getDescription());
            existing.setIsbn(req.getIsbn());
            existing.setPublisher(req.getPublisher());
            existing.setPublicationYear(req.getPublicationYear());
            existing.setQuantity(req.getQuantity());
            existing.setStatus(req.getStatus());
            return service.update(existing);
        }).orElseThrow(() -> new ResourceNotFoundException("Book", id));
        return ResponseEntity.ok(updated);
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('LIBRARIAN')")
    public ResponseEntity<Void> remove(@PathVariable String id) {
        if (!repo.existsById(id)) {
            throw new ResourceNotFoundException("Book", id);
        }
        service.remove(id);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/search")
    public ResponseEntity<List<Book>> search(@RequestBody SearchRequest req) {
        return ResponseEntity.ok(service.search(req.q()));
    }

    @GetMapping("/isbn/{isbn}")
    public ResponseEntity<Book> byIsbn(@PathVariable String isbn) {
        return service.byIsbn(isbn)
                .map(ResponseEntity::ok)
                .orElseThrow(() -> new ResourceNotFoundException("Book with ISBN", isbn));
    }

    @GetMapping("/author/{author}")
    public ResponseEntity<List<Book>> byAuthor(@PathVariable String author) {
        return ResponseEntity.ok(service.findByAuthor(author));
    }

    @GetMapping("/genre/{genre}")
    public ResponseEntity<List<Book>> byGenre(@PathVariable String genre) {
        return ResponseEntity.ok(service.findByGenre(genre));
    }

    @PatchMapping("/{id}/status")
    @PreAuthorize("hasRole('LIBRARIAN')")
    public ResponseEntity<Book> updateStatus(@PathVariable String id, @RequestBody com.hashedin.library.common.dto.UpdateStatusRequest request) {
        Book.Status status;
        try {
            status = Book.Status.valueOf(request.status());
        } catch (IllegalArgumentException e) {
            throw new BadRequestException("Invalid status: " + request.status());
        }
        service.updateBookStatus(id, status);
        return service.findById(id)
                .map(ResponseEntity::ok)
                .orElseThrow(() -> new ResourceNotFoundException("Book", id));
    }
}

