# Quick Test Guide - Library Management System

## 🚀 Fastest Way to Test All Services

### Method 1: Automated Comprehensive Testing (Recommended)

```bash
# Step 1: Start all services (in one command)
./start-all-services.sh

# Step 2: Wait 2-3 minutes for all services to start

# Step 3: Check if services are ready
./check-services-ready.sh

# Step 4: Run comprehensive tests
./comprehensive-api-testing.sh
```

This will:
- ✅ Test all services automatically
- ✅ Show pass/fail for each test
- ✅ Display summary statistics
- ✅ Verify Eureka registration
- ✅ Test all API endpoints

---

### Method 2: Test Services One by One

```bash
# Start services first (see Method 1, Step 1)

# Then test each service individually:
./test-user-service.sh        # User Service tests
./test-catalog-service.sh     # Catalog Service tests
./test-borrow-service.sh      # Borrow Service tests
./test-fine-service.sh        # Fine Service tests
./test-notification-service.sh # Notification Service tests
```

---

## 📋 What Gets Tested

### User Service
- ✅ User registration (USER and LIBRARIAN roles)
- ✅ User login and JWT token generation
- ✅ Profile management (get, update)
- ✅ Password reset functionality

### Catalog Service
- ✅ Get all books
- ✅ Add new book (librarian only)
- ✅ Get book by ID and ISBN
- ✅ Update book (librarian only)
- ✅ Search books
- ✅ Get books by author/genre
- ✅ Update book status
- ✅ Delete book (librarian only)

### Borrow Service
- ✅ Borrow book
- ✅ Get active borrows
- ✅ Get borrowing history
- ✅ Get borrow record by ID
- ✅ Get all active borrows
- ✅ Get overdue records
- ✅ Get borrows due in N days
- ✅ Return book
- ✅ Mark book as lost

### Fine Service
- ✅ Get user's fines
- ✅ Get outstanding fine amount
- ✅ Manually add fine
- ✅ Process payment (async)
- ✅ Get payment history
- ✅ Trigger fine calculation

### Notification Service
- ✅ Get all notifications
- ✅ Get unread notifications
- ✅ Get unread count
- ✅ Mark notification as read
- ✅ Mark all as read
- ✅ Test email notification
- ✅ Check email service status

---

## 🔍 Verification Steps

### 1. Check Eureka Dashboard
Open: http://localhost:8761
- Should see all 6 services registered

### 2. Check Service Health
```bash
./check-services-ready.sh
```

### 3. View Test Results
After running `./comprehensive-api-testing.sh`, you'll see:
- Total tests executed
- Pass/fail count
- Detailed results for each test

---

## ⚠️ Common Issues

### Services not starting
```bash
# Check if ports are in use
lsof -i :8081  # Check each port

# Check service logs
tail -f logs/user-service.log
```

### Tests failing
- Ensure all prerequisites are running (MySQL, RabbitMQ, Redis)
- Wait longer for services to fully start
- Check service logs for errors
- Verify Eureka is running first

### Email tests failing
- Email service is optional - notifications will still be stored
- Check `application.yml` for SMTP configuration
- Test email endpoint will show configuration status

---

## 📊 Expected Test Results

**Minimum Expected:**
- 30+ tests executed
- All critical functionality tests passing
- Services registered in Eureka

**Success Criteria:**
- ✅ All service endpoints responding
- ✅ JWT authentication working
- ✅ Event-driven notifications working
- ✅ Fine calculation working
- ✅ All CRUD operations working

---

## 🎯 Next Steps After Testing

1. ✅ Review test results
2. ✅ Check service logs for warnings
3. ✅ Verify RabbitMQ queues are populated
4. ✅ Check Redis cache is working
5. ✅ Test end-to-end user flows manually

