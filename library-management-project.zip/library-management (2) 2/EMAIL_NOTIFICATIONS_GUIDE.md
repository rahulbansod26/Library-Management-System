# Email Notifications - Library Management System

## Overview
The notification service automatically sends email notifications to users based on events from other services. All emails are sent using the configured Gmail account: **anujbhalekar908@gmail.com**.

---

## 📧 Email Notifications by Category

### 1. User Account Events

#### ✅ **User Registration** (`UserRegisteredEvent`)
- **Trigger**: When a new user registers in the system
- **Email Subject**: "Welcome to Library Management System!"
- **Email Content**: 
  - Welcome message
  - Account creation confirmation
  - Information about available features (browse books, borrow, manage profile)
- **When**: Automatically triggered on user registration

#### ✅ **Password Reset** (`UserPasswordResetEvent`)
- **Trigger**: When a user requests a password reset
- **Email Subject**: "Password Reset Request"
- **Email Content**:
  - Reset token
  - Instructions to use the token
  - Token expiration time (30 minutes)
  - Security notice
- **When**: Automatically triggered on password reset request

#### ✅ **Profile Update** (`UserProfileChangedEvent`)
- **Trigger**: When a user updates their profile
- **Email Subject**: "Profile Updated Successfully"
- **Email Content**:
  - Confirmation of profile update
  - Security notice if change was unauthorized
- **When**: Automatically triggered on profile update

---

### 2. Book Borrowing Events

#### ✅ **Borrow Confirmation** (`BorrowApprovedEvent`)
- **Trigger**: When a book borrowing request is approved
- **Email Subject**: "Book Borrowing Confirmed"
- **Email Content**:
  - Book ID
  - Due date
  - Reminder to return by due date
- **When**: Automatically triggered when a book is successfully borrowed

#### ✅ **Book Return Confirmation** (`BookReturnedEvent`)
- **Trigger**: When a user returns a borrowed book
- **Email Subject**: "Book Return Confirmed"
- **Email Content**:
  - Thank you message
  - Book ID
  - Return date
  - Encouragement to borrow more books
- **When**: Automatically triggered when a book is returned

#### ✅ **Book Overdue Alert** (`BookOverdueEvent`)
- **Trigger**: When a borrowed book becomes overdue
- **Email Subject**: "Book Overdue Alert"
- **Email Content**:
  - Warning about overdue book
  - Book ID
  - Notice about daily fine calculation
- **When**: Automatically triggered when a book becomes overdue (scheduled check runs hourly)

---

### 3. Fine and Payment Events

#### ✅ **Fine Update** (`FineUpdatedEvent`)
- **Trigger**: When a fine is applied or updated for a user
- **Email Subject**: "Fine Updated"
- **Email Content**:
  - Fine amount
  - Borrow Record ID (if applicable)
  - Request to pay the fine
- **When**: Automatically triggered when fines are calculated or updated

#### ✅ **Payment Confirmation** (`PaymentCompletedEvent`)
- **Trigger**: When a payment is successfully processed
- **Email Subject**: "Payment Confirmed"
- **Email Content**:
  - Payment amount
  - Transaction ID
  - Payment date
  - Confirmation message
- **When**: Automatically triggered after successful payment processing (async)

---

### 4. Scheduled Reminders

#### ✅ **3-Day Advance Reminder**
- **Trigger**: Scheduled task runs daily at 9:00 AM
- **Email Subject**: "Reminder: Book Due in 3 Days"
- **Email Content**:
  - Friendly reminder
  - Book ID
  - Due date
  - Days remaining (3)
  - Reminder to return by due date
- **When**: Runs daily at 9 AM for books due in exactly 3 days

#### ✅ **1-Day Advance Reminder (Final Reminder)**
- **Trigger**: Scheduled task runs daily at 9:00 AM
- **Email Subject**: "Final Reminder: Book Due Tomorrow"
- **Email Content**:
  - Urgent reminder
  - Book ID
  - Due date (tomorrow)
  - Warning about fines
- **When**: Runs daily at 9 AM for books due in exactly 1 day

#### ✅ **Batch Reminders (7-Day Window)**
- **Trigger**: Scheduled task runs daily at 10:00 AM
- **Email Subject**: "Reminder: Book Due in X Days" (where X = 0-7 days)
- **Email Content**:
  - Reminder based on days until due date
  - Book ID
  - Due date
  - Days remaining
  - Different urgency levels:
    - **Due Today**: "URGENT: Your borrowed book is due TODAY!"
    - **Due Tomorrow**: "REMINDER: Your borrowed book is due TOMORROW!"
    - **Due in 2-7 days**: Friendly reminder with days remaining
- **When**: Runs daily at 10 AM for all active borrows due within 7 days

---

## 🔄 How It Works

### Event-Driven Architecture
1. **Event Publishing**: Services publish events to RabbitMQ when actions occur
   - User Service → User events (registration, password reset, profile update)
   - Borrow Service → Borrow events (approved, returned, overdue)
   - Fine Service → Fine events (updated, payment completed)

2. **Event Consumption**: Notification Service listens to RabbitMQ queues
   - `user.events.q` - User-related events
   - `borrow.events.q` - Borrowing-related events
   - `fine.events.q` - Fine and payment events

3. **Email Sending**: 
   - Notification Service receives events
   - Fetches user email from User Service if needed
   - Sends email via JavaMailSender (Gmail SMTP)
   - Stores notification in database for history

4. **Scheduled Reminders**:
   - Runs daily at scheduled times
   - Fetches active borrows from Borrow Service
   - Calculates days until due date
   - Sends appropriate reminder emails

---

## 📋 Email Configuration

- **SMTP Host**: smtp.gmail.com
- **Port**: 587 (TLS)
- **From Email**: anujbhalekar908@gmail.com
- **Authentication**: Gmail App Password

---

## ✅ Notification Storage

All email notifications are also stored in the database with:
- User ID
- Notification type
- Title
- Message content
- Timestamp
- Read status

Users can view all their notifications via the API:
- `GET /api/notifications/user/{userId}` - Get all notifications
- `GET /api/notifications/user/{userId}/unread` - Get unread notifications
- `PUT /api/notifications/{id}/read` - Mark as read
- `PUT /api/notifications/user/{userId}/read-all` - Mark all as read

---

## 🔍 Notification Tracking

All email sending attempts are logged with:
- Notification ID (UUID)
- Recipient email
- Subject
- Status (ATTEMPTING, DELIVERED, FAILED, SKIPPED)
- Timestamp

Check logs for email delivery status:
```
NOTIFICATION_TRACKING: ID={uuid}, TO={email}, SUBJECT={subject}, STATUS={status}, TIMESTAMP={timestamp}
```

---

## ⚠️ Important Notes

1. **Email Service Availability**: If email service is not configured or unavailable, notifications are still stored in the database but not emailed.

2. **User Email Fetching**: If user email is not available in the event, the service automatically fetches it from User Service.

3. **Error Handling**: Email failures don't block event processing. Notifications are always stored even if email fails.

4. **Scheduled Reminders**: Reminders run at fixed times (9 AM and 10 AM) and process all relevant borrows at that time.

---

## 📊 Summary of Email Notifications

| Event Type | Trigger | Frequency | Email Subject |
|------------|---------|-----------|---------------|
| User Registration | User registers | On-demand | Welcome to Library Management System! |
| Password Reset | User requests reset | On-demand | Password Reset Request |
| Profile Update | User updates profile | On-demand | Profile Updated Successfully |
| Borrow Confirmed | Book borrowed | On-demand | Book Borrowing Confirmed |
| Book Returned | Book returned | On-demand | Book Return Confirmed |
| Book Overdue | Book becomes overdue | Hourly check | Book Overdue Alert |
| Fine Updated | Fine applied/updated | On-demand | Fine Updated |
| Payment Completed | Payment processed | On-demand | Payment Confirmed |
| 3-Day Reminder | Scheduled task | Daily at 9 AM | Reminder: Book Due in 3 Days |
| 1-Day Reminder | Scheduled task | Daily at 9 AM | Final Reminder: Book Due Tomorrow |
| Batch Reminders | Scheduled task | Daily at 10 AM | Reminder: Book Due in X Days |

---

**Total Email Notification Types: 11**
**Automatic Email Triggers: 11**
**Manual/Test Endpoints: 0** (Removed - using real event-driven logic only)

