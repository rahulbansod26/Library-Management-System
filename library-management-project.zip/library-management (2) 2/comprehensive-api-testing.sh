#!/bin/bash

# Comprehensive API Testing Script - Library Management System
# Tests all services one by one with detailed verification

COLOR_GREEN='\033[0;32m'
COLOR_RED='\033[0;31m'
COLOR_YELLOW='\033[1;33m'
COLOR_BLUE='\033[0;34m'
COLOR_CYAN='\033[0;36m'
COLOR_NC='\033[0m'

BASE_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$BASE_DIR"

# Service URLs
EUREKA_URL="http://localhost:8761"
USER_SERVICE="http://localhost:8081"
CATALOG_SERVICE="http://localhost:8082"
BORROW_SERVICE="http://localhost:8083"
FINE_SERVICE="http://localhost:8084"
NOTIFICATION_SERVICE="http://localhost:8085"
GATEWAY_URL="http://localhost:7000"

# Test data storage
USER_TOKEN=""
LIBRARIAN_TOKEN=""
USER_ID=""
LIBRARIAN_ID=""
BOOK_ID=""
BORROW_RECORD_ID=""
FINE_ID=""

TIMESTAMP=$(date +%s)
TEST_USER_EMAIL="testuser_${TIMESTAMP}@example.com"
TEST_LIBRARIAN_EMAIL="librarian_${TIMESTAMP}@example.com"
TEST_ISBN="978-0743273565-${TIMESTAMP}"

# Counters
TOTAL_TESTS=0
PASSED_TESTS=0
FAILED_TESTS=0

echo -e "${COLOR_CYAN}╔════════════════════════════════════════════════════════╗${COLOR_NC}"
echo -e "${COLOR_CYAN}║  COMPREHENSIVE API TESTING - LIBRARY MANAGEMENT SYSTEM ║${COLOR_NC}"
echo -e "${COLOR_CYAN}╚════════════════════════════════════════════════════════╝${COLOR_NC}"
echo ""

# Function to test endpoint
test_api() {
    local method=$1
    local url=$2
    local data=$3
    local description=$4
    local token=$5
    local expected_code=${6:-200}
    
    TOTAL_TESTS=$((TOTAL_TESTS + 1))
    
    echo -e "${COLOR_YELLOW}[TEST ${TOTAL_TESTS}] ${description}${COLOR_NC}"
    echo -e "  ${COLOR_BLUE}${method} ${url}${COLOR_NC}"
    
    local headers=("Content-Type: application/json")
    if [ ! -z "$token" ]; then
        headers+=("Authorization: Bearer ${token}")
    fi
    
    local curl_cmd="curl -s -w \"\n%{http_code}\" -X ${method} \"${url}\""
    for header in "${headers[@]}"; do
        curl_cmd="${curl_cmd} -H \"${header}\""
    done
    
    if [ ! -z "$data" ]; then
        curl_cmd="${curl_cmd} -d '${data}'"
    fi
    
    response=$(eval $curl_cmd 2>/dev/null || echo -e "\n500")
    http_code=$(echo "$response" | tail -n1)
    body=$(echo "$response" | sed '$d')
    
    # Debug: Log if token is being sent (only for failed auth requests)
    if [ "$http_code" = "403" ] || [ "$http_code" = "401" ]; then
        if [ ! -z "$token" ]; then
            echo "  DEBUG: Token being sent: ${token:0:30}..." >&2
        else
            echo "  DEBUG: No token provided!" >&2
        fi
    fi
    
    if [ "$http_code" -eq "$expected_code" ]; then
        echo -e "  ${COLOR_GREEN}✓ PASS (HTTP ${http_code})${COLOR_NC}"
        if [ ! -z "$body" ]; then
            echo "$body" | head -c 200 | sed 's/^/    /'
            [ ${#body} -gt 200 ] && echo -e "\n    ... (truncated)"
        fi
        echo "$body" > /tmp/last_response.json 2>/dev/null
        PASSED_TESTS=$((PASSED_TESTS + 1))
        echo ""
        return 0
    else
        echo -e "  ${COLOR_RED}✗ FAIL (Expected HTTP ${expected_code}, Got HTTP ${http_code})${COLOR_NC}"
        echo -e "  ${COLOR_RED}Response: ${body}${COLOR_NC}"
        FAILED_TESTS=$((FAILED_TESTS + 1))
        echo ""
        return 1
    fi
}

# Function to check service health
check_service() {
    local url=$1
    local name=$2
    
    echo -e "${COLOR_BLUE}Checking ${name}...${COLOR_NC}"
    local http_code="000"
    
    # Try different endpoints based on service type
    if [[ "$name" == *"User"* ]] || [[ "$name" == *"Eureka"* ]]; then
        # Try registration endpoint (will return error but that means service is up)
        http_code=$(curl -s -o /dev/null -w "%{http_code}" "${url}/api/auth/register" 2>/dev/null || echo "000")
    elif [[ "$name" == *"Catalog"* ]]; then
        # Try books endpoint
        http_code=$(curl -s -o /dev/null -w "%{http_code}" "${url}/api/books" 2>/dev/null || echo "000")
    elif [[ "$name" == *"Borrow"* ]]; then
        # Try borrow endpoint
        http_code=$(curl -s -o /dev/null -w "%{http_code}" "${url}/api/borrow" 2>/dev/null || echo "000")
    elif [[ "$name" == *"Fine"* ]]; then
        # Try fine endpoint
        http_code=$(curl -s -o /dev/null -w "%{http_code}" "${url}/api/fines" 2>/dev/null || echo "000")
    elif [[ "$name" == *"Notification"* ]]; then
        # Try notification endpoint
        http_code=$(curl -s -o /dev/null -w "%{http_code}" "${url}/api/notifications" 2>/dev/null || echo "000")
    fi
    
    # If still no response, try root endpoint
    if [ "$http_code" = "000" ] || [ -z "$http_code" ]; then
        http_code=$(curl -s -o /dev/null -w "%{http_code}" "${url}" 2>/dev/null || echo "000")
    fi
    
    # If we get any HTTP response (not 000), service is running
    if [ "$http_code" != "000" ] && [ "$http_code" != "" ]; then
        echo -e "${COLOR_GREEN}✓ ${name} is running (HTTP ${http_code})${COLOR_NC}"
        return 0
    else
        echo -e "${COLOR_RED}✗ ${name} is not responding${COLOR_NC}"
        return 1
    fi
}

# Function to wait for service
wait_for_service() {
    local url=$1
    local name=$2
    local max_wait=60
    local waited=0
    
    echo -e "${COLOR_YELLOW}Waiting for ${name}...${COLOR_NC}"
    while [ $waited -lt $max_wait ]; do
        if check_service "$url" "$name" > /dev/null 2>&1; then
            return 0
        fi
        sleep 2
        waited=$((waited + 2))
        echo -n "."
    done
    echo ""
    return 1
}

# Function to check Eureka registration
check_eureka() {
    local service_name=$1
    echo -e "${COLOR_BLUE}Checking Eureka registration for ${service_name}...${COLOR_NC}"
    if curl -s "${EUREKA_URL}/eureka/apps/${service_name}" 2>/dev/null | grep -q "UP"; then
        echo -e "${COLOR_GREEN}✓ ${service_name} registered in Eureka${COLOR_NC}"
        return 0
    else
        echo -e "${COLOR_RED}✗ ${service_name} not found in Eureka${COLOR_NC}"
        return 1
    fi
}

# ========================================
# PHASE 0: Pre-flight Checks
# ========================================
echo -e "${COLOR_CYAN}═══════════════════════════════════════════════════════${COLOR_NC}"
echo -e "${COLOR_CYAN}PHASE 0: PRE-FLIGHT CHECKS${COLOR_NC}"
echo -e "${COLOR_CYAN}═══════════════════════════════════════════════════════${COLOR_NC}"
echo ""

check_service "${EUREKA_URL}" "Eureka Service Discovery" || {
    echo -e "${COLOR_RED}ERROR: Eureka must be running!${COLOR_NC}"
    echo -e "${COLOR_YELLOW}Please start Eureka first: cd eureka-service && mvn spring-boot:run${COLOR_NC}"
    exit 1
}

check_service "${USER_SERVICE}" "User Service" || wait_for_service "${USER_SERVICE}" "User Service"
check_service "${CATALOG_SERVICE}" "Catalog Service" || wait_for_service "${CATALOG_SERVICE}" "Catalog Service"
check_service "${BORROW_SERVICE}" "Borrow Service" || wait_for_service "${BORROW_SERVICE}" "Borrow Service"
check_service "${FINE_SERVICE}" "Fine Service" || wait_for_service "${FINE_SERVICE}" "Fine Service"
check_service "${NOTIFICATION_SERVICE}" "Notification Service" || wait_for_service "${NOTIFICATION_SERVICE}" "Notification Service"

echo ""
sleep 2

# ========================================
# PHASE 1: USER SERVICE TESTING
# ========================================
echo -e "${COLOR_CYAN}═══════════════════════════════════════════════════════${COLOR_NC}"
echo -e "${COLOR_CYAN}PHASE 1: USER SERVICE TESTING${COLOR_NC}"
echo -e "${COLOR_CYAN}═══════════════════════════════════════════════════════${COLOR_NC}"
echo ""

# 1.1 Register Regular User
REGISTER_USER_DATA="{\"name\":\"Test User\",\"email\":\"${TEST_USER_EMAIL}\",\"password\":\"password123\",\"roles\":[\"USER\"]}"
test_api "POST" "${USER_SERVICE}/api/auth/register" "$REGISTER_USER_DATA" "1.1 Register Regular User"
USER_ID=$(cat /tmp/last_response.json 2>/dev/null | grep -o '"id":"[^"]*' | head -1 | cut -d'"' -f4)

# 1.2 Register Librarian
REGISTER_LIBRARIAN_DATA="{\"name\":\"Test Librarian\",\"email\":\"${TEST_LIBRARIAN_EMAIL}\",\"password\":\"password123\",\"roles\":[\"LIBRARIAN\"]}"
test_api "POST" "${USER_SERVICE}/api/auth/register" "$REGISTER_LIBRARIAN_DATA" "1.2 Register Librarian"
LIBRARIAN_ID=$(cat /tmp/last_response.json 2>/dev/null | grep -o '"id":"[^"]*' | head -1 | cut -d'"' -f4)

# 1.3 User Login
LOGIN_DATA="{\"email\":\"${TEST_USER_EMAIL}\",\"password\":\"password123\"}"
test_api "POST" "${USER_SERVICE}/api/auth/login" "$LOGIN_DATA" "1.3 User Login"
USER_TOKEN=$(cat /tmp/last_response.json 2>/dev/null | jq -r '.token' 2>/dev/null)
if [ -z "$USER_TOKEN" ] || [ "$USER_TOKEN" = "null" ]; then
    # Fallback to grep method
    USER_TOKEN=$(cat /tmp/last_response.json 2>/dev/null | grep -o '"token":"[^"]*' | cut -d'"' -f4)
fi

# 1.4 Librarian Login
LIBRARIAN_LOGIN_DATA="{\"email\":\"${TEST_LIBRARIAN_EMAIL}\",\"password\":\"password123\"}"
test_api "POST" "${USER_SERVICE}/api/auth/login" "$LIBRARIAN_LOGIN_DATA" "1.4 Librarian Login"
LIBRARIAN_TOKEN=$(cat /tmp/last_response.json 2>/dev/null | jq -r '.token' 2>/dev/null)
if [ -z "$LIBRARIAN_TOKEN" ] || [ "$LIBRARIAN_TOKEN" = "null" ]; then
    # Fallback to grep method
    LIBRARIAN_TOKEN=$(cat /tmp/last_response.json 2>/dev/null | grep -o '"token":"[^"]*' | cut -d'"' -f4)
fi

# 1.5 Get User Profile
if [ ! -z "$USER_ID" ]; then
    test_api "GET" "${USER_SERVICE}/api/profile/${USER_ID}" "" "1.5 Get User Profile by ID"
fi

# 1.6 Update User Profile
if [ ! -z "$USER_ID" ]; then
    UPDATE_PROFILE_DATA="{\"email\":\"${TEST_USER_EMAIL}\",\"name\":\"Updated Test User\"}"
    test_api "PUT" "${USER_SERVICE}/api/profile" "$UPDATE_PROFILE_DATA" "1.6 Update User Profile"
fi

# 1.7 Forgot Password
FORGOT_PWD_DATA="{\"email\":\"${TEST_USER_EMAIL}\"}"
test_api "POST" "${USER_SERVICE}/api/auth/password/forgot" "$FORGOT_PWD_DATA" "1.7 Forgot Password"

echo ""

# ========================================
# PHASE 2: CATALOG SERVICE TESTING
# ========================================
echo -e "${COLOR_CYAN}═══════════════════════════════════════════════════════${COLOR_NC}"
echo -e "${COLOR_CYAN}PHASE 2: CATALOG SERVICE TESTING${COLOR_NC}"
echo -e "${COLOR_CYAN}═══════════════════════════════════════════════════════${COLOR_NC}"
echo ""

# 2.1 Get All Books (requires auth)
if [ ! -z "$USER_TOKEN" ]; then
    test_api "GET" "${CATALOG_SERVICE}/api/books" "" "2.1 Get All Books" "$USER_TOKEN"
fi

# 2.2 Add New Book (as Librarian)
if [ ! -z "$LIBRARIAN_TOKEN" ]; then
    BOOK_DATA="{\"title\":\"The Great Gatsby\",\"author\":\"F. Scott Fitzgerald\",\"genre\":\"Fiction\",\"isbn\":\"${TEST_ISBN}\",\"publisher\":\"Scribner\",\"publicationYear\":2004,\"description\":\"A classic American novel\",\"quantity\":5,\"status\":\"AVAILABLE\"}"
    test_api "POST" "${CATALOG_SERVICE}/api/books" "$BOOK_DATA" "2.2 Add New Book (Librarian)" "$LIBRARIAN_TOKEN"
    BOOK_ID=$(cat /tmp/last_response.json 2>/dev/null | grep -o '"id":"[^"]*' | head -1 | cut -d'"' -f4)
fi

# 2.3 Get Book by ID (requires auth)
if [ ! -z "$BOOK_ID" ] && [ ! -z "$USER_TOKEN" ]; then
    test_api "GET" "${CATALOG_SERVICE}/api/books/${BOOK_ID}" "" "2.3 Get Book by ID" "$USER_TOKEN"
fi

# 2.4 Get Book by ISBN (requires auth)
if [ ! -z "$USER_TOKEN" ] && [ ! -z "$TEST_ISBN" ]; then
    test_api "GET" "${CATALOG_SERVICE}/api/books/isbn/${TEST_ISBN}" "" "2.4 Get Book by ISBN" "$USER_TOKEN"
fi

# 2.5 Update Book (as Librarian)
if [ ! -z "$BOOK_ID" ] && [ ! -z "$LIBRARIAN_TOKEN" ]; then
    UPDATE_BOOK_DATA="{\"title\":\"The Great Gatsby (Updated)\",\"author\":\"F. Scott Fitzgerald\",\"genre\":\"Fiction\",\"isbn\":\"${TEST_ISBN}\",\"publisher\":\"Scribner\",\"publicationYear\":2004,\"description\":\"Updated description\",\"quantity\":10,\"status\":\"AVAILABLE\"}"
    test_api "PUT" "${CATALOG_SERVICE}/api/books/${BOOK_ID}" "$UPDATE_BOOK_DATA" "2.5 Update Book (Librarian)" "$LIBRARIAN_TOKEN"
fi

# 2.6 Search Books (requires auth)
if [ ! -z "$USER_TOKEN" ]; then
    test_api "POST" "${CATALOG_SERVICE}/api/books/search" "{\"q\":\"Gatsby\"}" "2.6 Search Books" "$USER_TOKEN"
fi

# 2.7 Get Books by Author (requires auth) - URL encode the author name
if [ ! -z "$USER_TOKEN" ]; then
    AUTHOR_ENCODED="F.%20Scott%20Fitzgerald"
    test_api "GET" "${CATALOG_SERVICE}/api/books/author/${AUTHOR_ENCODED}" "" "2.7 Get Books by Author" "$USER_TOKEN"
fi

# 2.8 Get Books by Genre (requires auth)
if [ ! -z "$USER_TOKEN" ]; then
    test_api "GET" "${CATALOG_SERVICE}/api/books/genre/Fiction" "" "2.8 Get Books by Genre" "$USER_TOKEN"
fi

# 2.9 Update Book Status (as Librarian)
if [ ! -z "$BOOK_ID" ] && [ ! -z "$LIBRARIAN_TOKEN" ]; then
    UPDATE_STATUS_DATA="{\"status\":\"BORROWED\"}"
    test_api "PATCH" "${CATALOG_SERVICE}/api/books/${BOOK_ID}/status" "$UPDATE_STATUS_DATA" "2.9 Update Book Status" "$LIBRARIAN_TOKEN"
fi

# Note: We skip deleting the book so it can be used in borrow testing

echo ""

# ========================================
# PHASE 3: BORROW SERVICE TESTING
# ========================================
echo -e "${COLOR_CYAN}═══════════════════════════════════════════════════════${COLOR_NC}"
echo -e "${COLOR_CYAN}PHASE 3: BORROW SERVICE TESTING${COLOR_NC}"
echo -e "${COLOR_CYAN}═══════════════════════════════════════════════════════${COLOR_NC}"
echo ""

# Reset book status to AVAILABLE for borrowing
if [ ! -z "$BOOK_ID" ] && [ ! -z "$LIBRARIAN_TOKEN" ]; then
    RESET_STATUS_DATA="{\"status\":\"AVAILABLE\"}"
    curl -s -X PATCH "${CATALOG_SERVICE}/api/books/${BOOK_ID}/status" \
        -H "Content-Type: application/json" \
        -H "Authorization: Bearer ${LIBRARIAN_TOKEN}" \
        -d "$RESET_STATUS_DATA" > /dev/null
fi

# 3.1 Borrow Book (requires auth)
BORROW_SUCCESS=false
if [ ! -z "$USER_ID" ] && [ ! -z "$BOOK_ID" ] && [ ! -z "$USER_TOKEN" ]; then
    BORROW_DATA="{\"userId\":\"${USER_ID}\",\"bookId\":\"${BOOK_ID}\",\"days\":14}"
    test_api "POST" "${BORROW_SERVICE}/api/borrow" "$BORROW_DATA" "3.1 Borrow Book" "$USER_TOKEN"
    BORROW_RECORD_ID=$(cat /tmp/last_response.json 2>/dev/null | grep -o '"id":"[^"]*' | head -1 | cut -d'"' -f4)
    # Check if borrow was successful (got a valid ID)
    if [ ! -z "$BORROW_RECORD_ID" ] && [ "$BORROW_RECORD_ID" != "null" ]; then
        BORROW_SUCCESS=true
    fi
fi

# 3.2 Get Active Borrows for User (requires auth)
if [ ! -z "$USER_ID" ] && [ ! -z "$USER_TOKEN" ]; then
    test_api "GET" "${BORROW_SERVICE}/api/borrow/user/${USER_ID}" "" "3.2 Get Active Borrows for User" "$USER_TOKEN"
fi

# 3.3 Get Borrowing History (requires auth)
if [ ! -z "$USER_ID" ] && [ ! -z "$USER_TOKEN" ]; then
    test_api "GET" "${BORROW_SERVICE}/api/borrow/user/${USER_ID}/history" "" "3.3 Get Borrowing History" "$USER_TOKEN"
fi

# 3.4 Get Borrow Record by ID (requires auth) - only if borrow was successful
if [ "$BORROW_SUCCESS" = true ] && [ ! -z "$BORROW_RECORD_ID" ] && [ ! -z "$USER_TOKEN" ]; then
    test_api "GET" "${BORROW_SERVICE}/api/borrow/${BORROW_RECORD_ID}" "" "3.4 Get Borrow Record by ID" "$USER_TOKEN"
fi

# 3.5 Get All Active Borrows (requires auth)
if [ ! -z "$USER_TOKEN" ]; then
    test_api "GET" "${BORROW_SERVICE}/api/borrow/active/all" "" "3.5 Get All Active Borrows" "$USER_TOKEN"
fi

# 3.6 Get Overdue Records (requires auth)
if [ ! -z "$USER_TOKEN" ]; then
    test_api "GET" "${BORROW_SERVICE}/api/borrow/overdue" "" "3.6 Get Overdue Records" "$USER_TOKEN"
fi

# 3.7 Get Borrows Due in Days (requires auth)
if [ ! -z "$USER_TOKEN" ]; then
    test_api "GET" "${BORROW_SERVICE}/api/borrow/due-in-days/7" "" "3.7 Get Borrows Due in 7 Days" "$USER_TOKEN"
fi

# 3.8 Return Book (requires auth) - only if borrow was successful
if [ "$BORROW_SUCCESS" = true ] && [ ! -z "$USER_ID" ] && [ ! -z "$BORROW_RECORD_ID" ] && [ ! -z "$USER_TOKEN" ]; then
    RETURN_DATA="{\"userId\":\"${USER_ID}\"}"
    test_api "POST" "${BORROW_SERVICE}/api/borrow/return/${BORROW_RECORD_ID}" "$RETURN_DATA" "3.8 Return Book" "$USER_TOKEN"
fi

echo ""

# ========================================
# PHASE 4: FINE SERVICE TESTING
# ========================================
echo -e "${COLOR_CYAN}═══════════════════════════════════════════════════════${COLOR_NC}"
echo -e "${COLOR_CYAN}PHASE 4: FINE SERVICE TESTING${COLOR_NC}"
echo -e "${COLOR_CYAN}═══════════════════════════════════════════════════════${COLOR_NC}"
echo ""

# 4.1 Get User's Fine (requires auth)
if [ ! -z "$USER_ID" ] && [ ! -z "$USER_TOKEN" ]; then
    test_api "GET" "${FINE_SERVICE}/api/fines/${USER_ID}" "" "4.1 Get User's Fine" "$USER_TOKEN"
fi

# 4.2 Get All Fines for User (requires auth)
if [ ! -z "$USER_ID" ] && [ ! -z "$USER_TOKEN" ]; then
    test_api "GET" "${FINE_SERVICE}/api/fines/${USER_ID}/all" "" "4.2 Get All Fines for User" "$USER_TOKEN"
fi

# 4.3 Get Outstanding Fine Amount (requires auth)
if [ ! -z "$USER_ID" ] && [ ! -z "$USER_TOKEN" ]; then
    test_api "GET" "${FINE_SERVICE}/api/fines/${USER_ID}/outstanding" "" "4.3 Get Outstanding Fine Amount" "$USER_TOKEN"
fi

# 4.4 Manually Add Fine (requires auth)
if [ ! -z "$USER_ID" ] && [ ! -z "$USER_TOKEN" ]; then
    ADD_FINE_DATA="{\"amount\":25.00}"
    test_api "POST" "${FINE_SERVICE}/api/fines/${USER_ID}/add" "$ADD_FINE_DATA" "4.4 Manually Add Fine" "$USER_TOKEN"
    FINE_ID=$(cat /tmp/last_response.json 2>/dev/null | grep -o '"id":"[^"]*' | head -1 | cut -d'"' -f4)
fi

# 4.5 Process Payment (Async) (requires auth)
if [ ! -z "$USER_ID" ] && [ ! -z "$FINE_ID" ] && [ ! -z "$USER_TOKEN" ]; then
    PAYMENT_DATA="{\"amount\":25.00,\"paymentMethod\":\"CREDIT_CARD\"}"
    test_api "POST" "${FINE_SERVICE}/api/fines/${USER_ID}/pay/${FINE_ID}" "$PAYMENT_DATA" "4.5 Process Payment (Async)" "$USER_TOKEN"
    sleep 2  # Wait for async processing
fi

# 4.6 Get Payment History (requires auth)
if [ ! -z "$FINE_ID" ] && [ ! -z "$USER_TOKEN" ]; then
    test_api "GET" "${FINE_SERVICE}/api/fines/${FINE_ID}/payments" "" "4.6 Get Payment History" "$USER_TOKEN"
fi

# 4.7 Manually Trigger Fine Calculation (requires auth)
if [ ! -z "$USER_TOKEN" ]; then
    test_api "POST" "${FINE_SERVICE}/api/fines/calculate" "" "4.7 Trigger Fine Calculation" "$USER_TOKEN"
fi

echo ""

# ========================================
# PHASE 5: NOTIFICATION SERVICE TESTING
# ========================================
echo -e "${COLOR_CYAN}═══════════════════════════════════════════════════════${COLOR_NC}"
echo -e "${COLOR_CYAN}PHASE 5: NOTIFICATION SERVICE TESTING${COLOR_NC}"
echo -e "${COLOR_CYAN}═══════════════════════════════════════════════════════${COLOR_NC}"
echo ""

# 5.1 Get All Notifications for User
if [ ! -z "$USER_ID" ]; then
    test_api "GET" "${NOTIFICATION_SERVICE}/api/notifications/user/${USER_ID}" "" "5.1 Get All Notifications"
fi

# 5.2 Get Unread Notifications
if [ ! -z "$USER_ID" ]; then
    test_api "GET" "${NOTIFICATION_SERVICE}/api/notifications/user/${USER_ID}/unread" "" "5.2 Get Unread Notifications"
fi

# 5.3 Get Unread Notification Count
if [ ! -z "$USER_ID" ]; then
    test_api "GET" "${NOTIFICATION_SERVICE}/api/notifications/user/${USER_ID}/unread/count" "" "5.3 Get Unread Notification Count"
fi

# 5.4 Mark Notification as Read
if [ ! -z "$USER_ID" ]; then
    NOTIFICATION_ID=$(curl -s "${NOTIFICATION_SERVICE}/api/notifications/user/${USER_ID}" | grep -o '"id":"[^"]*' | head -1 | cut -d'"' -f4)
    if [ ! -z "$NOTIFICATION_ID" ]; then
        test_api "PUT" "${NOTIFICATION_SERVICE}/api/notifications/${NOTIFICATION_ID}/read" "" "5.4 Mark Notification as Read"
    fi
fi

# 5.5 Mark All Notifications as Read
if [ ! -z "$USER_ID" ]; then
    test_api "PUT" "${NOTIFICATION_SERVICE}/api/notifications/user/${USER_ID}/read-all" "" "5.5 Mark All Notifications as Read"
fi

# Note: Test email endpoints removed - using real notification logic via events

echo ""

# ========================================
# PHASE 6: EUREKA REGISTRATION VERIFICATION
# ========================================
echo -e "${COLOR_CYAN}═══════════════════════════════════════════════════════${COLOR_NC}"
echo -e "${COLOR_CYAN}PHASE 6: EUREKA REGISTRATION VERIFICATION${COLOR_NC}"
echo -e "${COLOR_CYAN}═══════════════════════════════════════════════════════${COLOR_NC}"
echo ""

check_eureka "USER-SERVICE"
check_eureka "CATALOG-SERVICE"
check_eureka "BORROW-SERVICE"
check_eureka "FINE-SERVICE"
check_eureka "NOTIFICATION-SERVICE"

echo ""

# ========================================
# PHASE 7: TEST SUMMARY
# ========================================
echo -e "${COLOR_CYAN}═══════════════════════════════════════════════════════${COLOR_NC}"
echo -e "${COLOR_CYAN}TEST SUMMARY${COLOR_NC}"
echo -e "${COLOR_CYAN}═══════════════════════════════════════════════════════${COLOR_NC}"
echo ""
echo -e "Total Tests: ${TOTAL_TESTS}"
echo -e "${COLOR_GREEN}Passed: ${PASSED_TESTS}${COLOR_NC}"
echo -e "${COLOR_RED}Failed: ${FAILED_TESTS}${COLOR_NC}"

if [ $FAILED_TESTS -eq 0 ]; then
    echo ""
    echo -e "${COLOR_GREEN}╔═══════════════════════════════════════════════════════╗${COLOR_NC}"
    echo -e "${COLOR_GREEN}║           ALL TESTS PASSED SUCCESSFULLY! ✓            ║${COLOR_NC}"
    echo -e "${COLOR_GREEN}╚═══════════════════════════════════════════════════════╝${COLOR_NC}"
    exit 0
else
    echo ""
    echo -e "${COLOR_RED}╔═══════════════════════════════════════════════════════╗${COLOR_NC}"
    echo -e "${COLOR_RED}║            SOME TESTS FAILED - CHECK LOGS             ║${COLOR_NC}"
    echo -e "${COLOR_RED}╚═══════════════════════════════════════════════════════╝${COLOR_NC}"
    exit 1
fi

