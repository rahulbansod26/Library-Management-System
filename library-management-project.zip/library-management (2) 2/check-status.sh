#!/bin/bash

# Quick Status Check Script

COLOR_GREEN='\033[0;32m'
COLOR_RED='\033[0;31m'
COLOR_YELLOW='\033[1;33m'
COLOR_BLUE='\033[0;34m'
COLOR_CYAN='\033[0;36m'
COLOR_NC='\033[0m'

echo -e "${COLOR_CYAN}═══════════════════════════════════════════════════════${COLOR_NC}"
echo -e "${COLOR_CYAN}LIBRARY MANAGEMENT SYSTEM - STATUS CHECK${COLOR_NC}"
echo -e "${COLOR_CYAN}═══════════════════════════════════════════════════════${COLOR_NC}"
echo ""

# Check processes
echo -e "${COLOR_BLUE}Running Processes:${COLOR_NC}"
if [ -f logs/pids.txt ]; then
    while IFS='=' read -r key value; do
        if [ ! -z "$value" ]; then
            if ps -p "$value" > /dev/null 2>&1; then
                echo -e "  ${COLOR_GREEN}✓ ${key}: Running (PID: $value)${COLOR_NC}"
            else
                echo -e "  ${COLOR_RED}✗ ${key}: Not running${COLOR_NC}"
            fi
        fi
    done < logs/pids.txt
else
    echo -e "  ${COLOR_YELLOW}No PID file found. Services may not be started yet.${COLOR_NC}"
fi

echo ""

# Check service endpoints
echo -e "${COLOR_BLUE}Service Health:${COLOR_NC}"
./check-services-ready.sh

echo ""

# Check Eureka
echo -e "${COLOR_BLUE}Eureka Dashboard:${COLOR_NC}"
if curl -s http://localhost:8761 > /dev/null 2>&1; then
    echo -e "  ${COLOR_GREEN}✓ Eureka Dashboard: http://localhost:8761${COLOR_NC}"
    REGISTERED=$(curl -s http://localhost:8761/eureka/apps 2>/dev/null | grep -o '<name>[^<]*</name>' | sed 's/<name>//;s/<\/name>//' | sort -u | wc -l | tr -d ' ')
    echo -e "  ${COLOR_BLUE}  Registered Services: $REGISTERED${COLOR_NC}"
else
    echo -e "  ${COLOR_RED}✗ Eureka not accessible${COLOR_NC}"
fi

echo ""

# Check logs
if [ -d logs ]; then
    echo -e "${COLOR_BLUE}Recent Log Files:${COLOR_NC}"
    ls -lh logs/*.log 2>/dev/null | tail -7 | awk '{print "  " $9 " (" $5 ")"}'
fi

echo ""

