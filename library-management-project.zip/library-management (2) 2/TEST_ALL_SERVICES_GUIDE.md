# Comprehensive Service Testing Guide

This guide provides step-by-step instructions to test all services one by one.

## Prerequisites

Before testing, ensure these services are running:
- ✅ MySQL (port 3306)
- ✅ RabbitMQ (port 5672)
- ✅ Redis (port 6379) - Optional but recommended

## Quick Start - Automated Testing

### Option 1: Test All Services Automatically (Recommended)

```bash
# 1. Start all services first
./start-all-services.sh

# Wait 2-3 minutes for all services to start

# 2. Run comprehensive tests
./comprehensive-api-testing.sh
```

### Option 2: Test Services One by One

```bash
# After starting all services, test each service individually:

./test-user-service.sh        # Test User Service
./test-catalog-service.sh     # Test Catalog Service  
./test-borrow-service.sh      # Test Borrow Service
./test-fine-service.sh        # Test Fine Service
./test-notification-service.sh # Test Notification Service
```

## Manual Step-by-Step Testing

### Step 1: Start Services

```bash
# Terminal 1: Start Eureka
cd eureka-service && mvn spring-boot:run

# Terminal 2: Start User Service (wait 15 seconds after Eureka)
cd user-service && mvn spring-boot:run

# Terminal 3: Start Catalog Service (wait 30 seconds after User Service)
cd catalog-service && mvn spring-boot:run

# Terminal 4: Start Borrow Service (wait 30 seconds after Catalog Service)
cd borrow-service && mvn spring-boot:run

# Terminal 5: Start Fine Service (wait 30 seconds after Borrow Service)
cd fine-service && mvn spring-boot:run

# Terminal 6: Start Notification Service (wait 30 seconds after Fine Service)
cd notification-service && mvn spring-boot:run

# Terminal 7: Start API Gateway (wait 30 seconds after Notification Service)
cd api-gateway && mvn spring-boot:run
```

**Verify Services are Running:**
- Eureka Dashboard: http://localhost:8761
- All 6 services should appear in Eureka dashboard

### Step 2: Test User Service (Port 8081)

```bash
# 1. Register a regular user
curl -X POST http://localhost:8081/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Test User",
    "email": "user@test.com",
    "password": "password123",
    "roles": ["USER"]
  }'

# Save the user ID from response

# 2. Register a librarian
curl -X POST http://localhost:8081/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Test Librarian",
    "email": "librarian@test.com",
    "password": "password123",
    "roles": ["LIBRARIAN"]
  }'

# Save the librarian ID from response

# 3. Login as user
curl -X POST http://localhost:8081/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "user@test.com",
    "password": "password123"
  }'

# Save the JWT token from response (USER_TOKEN)

# 4. Login as librarian
curl -X POST http://localhost:8081/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "librarian@test.com",
    "password": "password123"
  }'

# Save the JWT token from response (LIBRARIAN_TOKEN)

# 5. Get user profile
curl http://localhost:8081/api/profile/{USER_ID}

# 6. Update profile
curl -X PUT http://localhost:8081/api/profile \
  -H "Content-Type: application/json" \
  -d '{
    "email": "user@test.com",
    "name": "Updated Name"
  }'

# 7. Forgot password
curl -X POST http://localhost:8081/api/auth/password/forgot \
  -H "Content-Type: application/json" \
  -d '{
    "email": "user@test.com"
  }'
```

### Step 3: Test Catalog Service (Port 8082)

```bash
# Replace LIBRARIAN_TOKEN with the token from Step 2

# 1. Get all books
curl http://localhost:8082/api/books

# 2. Add a new book (requires LIBRARIAN token)
curl -X POST http://localhost:8082/api/books \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer LIBRARIAN_TOKEN" \
  -d '{
    "title": "The Great Gatsby",
    "author": "F. Scott Fitzgerald",
    "genre": "Fiction",
    "isbn": "978-0743273565",
    "publisher": "Scribner",
    "publicationYear": 2004,
    "description": "A classic American novel",
    "quantity": 5,
    "status": "AVAILABLE"
  }'

# Save the book ID from response

# 3. Get book by ID
curl http://localhost:8082/api/books/{BOOK_ID}

# 4. Get book by ISBN
curl http://localhost:8082/api/books/isbn/978-0743273565

# 5. Update book (requires LIBRARIAN token)
curl -X PUT http://localhost:8082/api/books/{BOOK_ID} \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer LIBRARIAN_TOKEN" \
  -d '{
    "title": "The Great Gatsby (Updated)",
    "author": "F. Scott Fitzgerald",
    "genre": "Fiction",
    "isbn": "978-0743273565",
    "publisher": "Scribner",
    "publicationYear": 2004,
    "description": "Updated description",
    "quantity": 10,
    "status": "AVAILABLE"
  }'

# 6. Search books
curl -X POST http://localhost:8082/api/books/search \
  -H "Content-Type: application/json" \
  -d '{"q": "Gatsby"}'

# 7. Get books by author
curl http://localhost:8082/api/books/author/F. Scott Fitzgerald

# 8. Get books by genre
curl http://localhost:8082/api/books/genre/Fiction

# 9. Update book status (requires LIBRARIAN token)
curl -X PATCH http://localhost:8082/api/books/{BOOK_ID}/status \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer LIBRARIAN_TOKEN" \
  -d '{"status": "BORROWED"}'

# 10. Delete book (requires LIBRARIAN token)
curl -X DELETE http://localhost:8082/api/books/{BOOK_ID} \
  -H "Authorization: Bearer LIBRARIAN_TOKEN"
```

### Step 4: Test Borrow Service (Port 8083)

```bash
# Replace USER_ID and BOOK_ID with actual IDs from previous steps

# 1. Borrow a book
curl -X POST http://localhost:8083/api/borrow \
  -H "Content-Type: application/json" \
  -d '{
    "userId": "USER_ID",
    "bookId": "BOOK_ID",
    "days": 14
  }'

# Save the borrow record ID from response

# 2. Get active borrows for user
curl http://localhost:8083/api/borrow/user/{USER_ID}

# 3. Get borrowing history
curl http://localhost:8083/api/borrow/user/{USER_ID}/history

# 4. Get borrow record by ID
curl http://localhost:8083/api/borrow/{BORROW_RECORD_ID}

# 5. Get all active borrows
curl http://localhost:8083/api/borrow/active/all

# 6. Get overdue records
curl http://localhost:8083/api/borrow/overdue

# 7. Get borrows due in N days
curl http://localhost:8083/api/borrow/due-in-days/7

# 8. Return book
curl -X POST http://localhost:8083/api/borrow/return/{BORROW_RECORD_ID} \
  -H "Content-Type: application/json" \
  -d '{
    "userId": "USER_ID"
  }'

# 9. Mark book as lost
curl -X POST http://localhost:8083/api/borrow/{BORROW_RECORD_ID}/lost \
  -H "Content-Type: application/json" \
  -d '{
    "userId": "USER_ID"
  }'
```

### Step 5: Test Fine Service (Port 8084)

```bash
# Replace USER_ID with actual user ID

# 1. Get user's fine
curl http://localhost:8084/api/fines/{USER_ID}

# 2. Get all fines for user
curl http://localhost:8084/api/fines/{USER_ID}/all

# 3. Get outstanding fine amount
curl http://localhost:8084/api/fines/{USER_ID}/outstanding

# 4. Manually add fine
curl -X POST http://localhost:8084/api/fines/{USER_ID}/add \
  -H "Content-Type: application/json" \
  -d '{
    "amount": 25.00
  }'

# Save the fine ID from response

# 5. Process payment (async)
curl -X POST http://localhost:8084/api/fines/{USER_ID}/pay/{FINE_ID} \
  -H "Content-Type: application/json" \
  -d '{
    "amount": 25.00,
    "paymentMethod": "CREDIT_CARD"
  }'

# Wait 2-3 seconds for async processing

# 6. Get payment history
curl http://localhost:8084/api/fines/{FINE_ID}/payments

# 7. Manually trigger fine calculation
curl -X POST http://localhost:8084/api/fines/calculate
```

### Step 6: Test Notification Service (Port 8085)

```bash
# Replace USER_ID with actual user ID

# 1. Get all notifications for user
curl http://localhost:8085/api/notifications/user/{USER_ID}

# 2. Get unread notifications
curl http://localhost:8085/api/notifications/user/{USER_ID}/unread

# 3. Get unread notification count
curl http://localhost:8085/api/notifications/user/{USER_ID}/unread/count

# 4. Mark notification as read
curl -X PUT http://localhost:8085/api/notifications/{NOTIFICATION_ID}/read

# 5. Mark all notifications as read
curl -X PUT http://localhost:8085/api/notifications/user/{USER_ID}/read-all

# 6. Test email notification
curl -X POST http://localhost:8085/api/notifications/test/email \
  -H "Content-Type: application/json" \
  -d '{
    "to": "user@test.com",
    "subject": "Test Email",
    "message": "This is a test email"
  }'

# 7. Check email service status
curl http://localhost:8085/api/notifications/test/email/status
```

### Step 7: Test API Gateway (Port 7000)

```bash
# Test routing through gateway (all previous endpoints should work via gateway)

# 1. User service via gateway
curl http://localhost:7000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "user@test.com",
    "password": "password123"
  }'

# 2. Catalog service via gateway
curl http://localhost:7000/api/books

# 3. Borrow service via gateway
curl http://localhost:7000/api/borrow/user/{USER_ID}

# 4. Fine service via gateway
curl http://localhost:7000/api/fines/{USER_ID}

# 5. Notification service via gateway
curl http://localhost:7000/api/notifications/user/{USER_ID}
```

## End-to-End Flow Testing

### Complete Flow: Register → Borrow → Fine → Payment → Notification

```bash
# 1. Register user
USER_RESPONSE=$(curl -s -X POST http://localhost:8081/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "End-to-End User",
    "email": "e2e@test.com",
    "password": "password123",
    "roles": ["USER"]
  }')
USER_ID=$(echo $USER_RESPONSE | grep -o '"id":"[^"]*' | cut -d'"' -f4)

# 2. Login
LOGIN_RESPONSE=$(curl -s -X POST http://localhost:8081/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "e2e@test.com",
    "password": "password123"
  }')
TOKEN=$(echo $LOGIN_RESPONSE | grep -o '"token":"[^"]*' | cut -d'"' -f4)

# 3. Add book (as librarian - use librarian token from Step 2)
# ... (add book)

# 4. Borrow book
# ... (borrow book, save BORROW_RECORD_ID)

# 5. Check notifications (should see borrow confirmation)
curl http://localhost:8085/api/notifications/user/${USER_ID}

# 6. Trigger fine calculation (or wait for scheduled task)
curl -X POST http://localhost:8084/api/fines/calculate

# 7. Check fines
curl http://localhost:8084/api/fines/${USER_ID}/outstanding

# 8. Pay fine
# ... (pay fine, save FINE_ID)

# 9. Check payment confirmation notification
curl http://localhost:8085/api/notifications/user/${USER_ID}

# 10. Return book
curl -X POST http://localhost:8083/api/borrow/return/{BORROW_RECORD_ID} \
  -H "Content-Type: application/json" \
  -d '{"userId": "'${USER_ID}'"}'

# 11. Check return confirmation notification
curl http://localhost:8085/api/notifications/user/${USER_ID}
```

## Verification Checklist

After running all tests, verify:

### ✅ Service Health
- [ ] All services respond to health checks
- [ ] All services registered in Eureka (http://localhost:8761)
- [ ] No error logs in service consoles

### ✅ API Functionality
- [ ] User registration and login works
- [ ] Books can be added/updated/deleted (by librarian)
- [ ] Books can be borrowed and returned
- [ ] Fines are calculated and can be paid
- [ ] Notifications are sent and stored

### ✅ Event-Driven Architecture
- [ ] RabbitMQ queues are created
- [ ] Events are published when actions occur
- [ ] Notification service receives events
- [ ] Fine service receives overdue events

### ✅ Caching
- [ ] Redis cache stores book search results
- [ ] Cache eviction works on updates
- [ ] Active loans are cached

### ✅ Scheduled Tasks
- [ ] Overdue detection runs (hourly)
- [ ] Fine calculation runs (hourly at :15)
- [ ] Due date reminders run (daily at 9 AM and 10 AM)

## Troubleshooting

### Service Not Responding
```bash
# Check if service is running
lsof -i :8081  # Change port for each service

# Check service logs
tail -f logs/user-service.log
```

### Eureka Registration Failed
- Wait 30-60 seconds after service startup
- Check Eureka URL in application.yml
- Verify Eureka service is running

### RabbitMQ Errors
```bash
# Check RabbitMQ status
rabbitmqctl status

# Check queues
rabbitmqctl list_queues
```

### Redis Errors
```bash
# Check Redis connection
redis-cli ping

# Check cache keys
redis-cli keys "*"
```

## Test Results

After running `./comprehensive-api-testing.sh`, you'll see:
- Total number of tests executed
- Number of passed tests
- Number of failed tests
- Detailed output for each test

All test results are logged for review.

