package com.retailx.inventory.controller;

import com.retailx.inventory.domain.Inventory;
import com.retailx.inventory.repository.InventoryRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Dev-only seed endpoints to quickly populate demo inventory data via API.
 *
 * Enabled by default for local/dev: retailx.seed.api.enabled=true
 */
@Slf4j
@RestController
@RequestMapping("/api/inventory/dev")
@RequiredArgsConstructor
public class DevSeedController {

    private final InventoryRepository inventoryRepository;

    @Value("${retailx.seed.api.enabled:true}")
    private boolean seedApiEnabled;

    @PostMapping("/seed")
    public ResponseEntity<Map<String, Object>> seed(
            @RequestParam(defaultValue = "WH-001") String warehouseId,
            @RequestParam(defaultValue = "100") int onHand,
            @RequestParam(defaultValue = "true") boolean alsoSeedDefaultWarehouse
    ) {
        if (!seedApiEnabled) {
            return ResponseEntity.status(403).body(Map.of(
                    "message", "Seed API disabled (retailx.seed.api.enabled=false)"
            ));
        }

        List<String> skus = List.of(
                "RX-TSHIRT-001",
                "RX-JEANS-001",
                "RX-SNEAKER-001",
                "RX-PHONE-001",
                "RX-HEADPHONES-001",
                "RX-LAPTOP-001",
                "RX-COFFEE-001",
                "RX-OLIVE-001",
                "RX-BOOK-001",
                "RX-MUG-001"
        );

        int created = 0;
        int skipped = 0;
        List<Inventory> toCreate = new ArrayList<>();

        List<String> warehouses = alsoSeedDefaultWarehouse
                ? List.of(warehouseId, "default-warehouse")
                : List.of(warehouseId);

        for (String wh : warehouses) {
            for (String sku : skus) {
                if (inventoryRepository.findBySkuAndWarehouseId(sku, wh).isPresent()) {
                    skipped++;
                    continue;
                }
                toCreate.add(Inventory.builder()
                        .sku(sku)
                        .warehouseId(wh)
                        .onHand(BigInteger.valueOf(onHand))
                        .reserved(BigInteger.ZERO)
                        .build());
                created++;
            }
        }

        if (!toCreate.isEmpty()) {
            inventoryRepository.saveAll(toCreate);
        }

        return ResponseEntity.ok(Map.of(
                "message", "Seed completed",
                "warehouseId", warehouseId,
                "seededDefaultWarehouse", alsoSeedDefaultWarehouse,
                "created", created,
                "skipped", skipped,
                "totalRequested", skus.size() * (alsoSeedDefaultWarehouse ? 2 : 1)
        ));
    }
}


