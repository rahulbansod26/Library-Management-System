package com.retailx.inventory.bootstrap;

import com.retailx.inventory.domain.Inventory;
import com.retailx.inventory.repository.InventoryRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

/**
 * Seeds sample inventory for local/demo usage.
 *
 * Runs only when inventory table is empty, and can be disabled via:
 * retailx.seed.enabled=false
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class SampleDataSeeder implements ApplicationRunner {

    private final InventoryRepository inventoryRepository;

    @Value("${retailx.seed.enabled:true}")
    private boolean seedEnabled;

    @Override
    public void run(ApplicationArguments args) {
        if (!seedEnabled) {
            log.info("SampleDataSeeder disabled (retailx.seed.enabled=false)");
            return;
        }

        long existing = inventoryRepository.count();
        if (existing > 0) {
            log.info("Skipping sample inventory seeding (inventory rows already exist: {})", existing);
            return;
        }

        log.info("Seeding sample inventory (empty DB detected)...");

        // Must match Order Service warehouse strategy (tries WH-001 then falls back to default-warehouse)
        List<String> warehouses = List.of("WH-001", "default-warehouse");
        List<String> skus = List.of(
                "RX-TSHIRT-001",
                "RX-JEANS-001",
                "RX-SNEAKER-001",
                "RX-PHONE-001",
                "RX-HEADPHONES-001",
                "RX-LAPTOP-001",
                "RX-COFFEE-001",
                "RX-OLIVE-001",
                "RX-BOOK-001",
                "RX-MUG-001"
        );

        List<Inventory> rows = new ArrayList<>();
        for (String warehouseId : warehouses) {
            for (String sku : skus) {
                rows.add(Inventory.builder()
                        .sku(sku)
                        .warehouseId(warehouseId)
                        .onHand(BigInteger.valueOf(100))
                        .reserved(BigInteger.ZERO)
                        .build());
            }
        }

        inventoryRepository.saveAll(rows);
        log.info("Sample inventory seeding complete: {} rows across {}", rows.size(), warehouses);
    }
}


