package com.retailx.frontend.config;

import feign.Logger;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Feign client configuration.
 */
@Configuration
@EnableFeignClients(basePackages = "com.retailx.frontend.client")
public class FeignConfig {
    
    /**
     * Enable full logging for Feign clients to debug issues.
     */
    @Bean
    public Logger.Level feignLoggerLevel() {
        return Logger.Level.FULL;
    }
}

