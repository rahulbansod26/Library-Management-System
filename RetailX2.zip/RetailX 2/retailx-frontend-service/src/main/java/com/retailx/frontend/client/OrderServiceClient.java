package com.retailx.frontend.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * Feign client for Order Service.
 */
@FeignClient(name = "retailx-api-gateway", path = "/api")
public interface OrderServiceClient {
    
    @GetMapping("/carts")
    Map<String, Object> getCart(@RequestHeader("Authorization") String token);
    
    @PostMapping("/carts/items")
    Map<String, Object> addToCart(
            @RequestHeader("Authorization") String token,
            @RequestBody Map<String, Object> request);
    
    @DeleteMapping("/carts/items/{id}")
    void removeFromCart(
            @RequestHeader("Authorization") String token,
            @PathVariable Long id);
    
    @PostMapping("/checkout")
    Map<String, Object> checkout(
            @RequestHeader("Authorization") String token,
            @RequestHeader("Idempotency-Key") String idempotencyKey,
            @RequestBody Map<String, Object> request);
    
    @GetMapping("/orders/customer")
    Map<String, Object> getCustomerOrders(
            @RequestHeader("Authorization") String token,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size);
    
    @GetMapping("/orders/merchant")
    Map<String, Object> getMerchantOrders(
            @RequestHeader("Authorization") String token,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size);
    
    @GetMapping("/reports/order-status")
    Map<String, Long> getOrderStatusCounts(@RequestHeader("Authorization") String token);
    
    @PutMapping("/orders/{id}/status")
    Map<String, Object> updateOrderStatus(
            @RequestHeader("Authorization") String token,
            @PathVariable Long id,
            @RequestParam String status,
            @RequestParam(required = false) String reason);
}

