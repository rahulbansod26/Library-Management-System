package com.retailx.frontend.controller;

import com.retailx.frontend.client.AuthServiceClient;
import com.retailx.frontend.client.OrderServiceClient;
import com.retailx.frontend.client.ProductServiceClient;
import feign.FeignException;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Frontend controller for Thymeleaf pages.
 */
@Slf4j
@Controller
@RequiredArgsConstructor
public class FrontendController {
    
    private final ProductServiceClient productServiceClient;
    private final OrderServiceClient orderServiceClient;
    private final AuthServiceClient authServiceClient;
    
    @GetMapping("/")
    public String index() {
        return "redirect:/catalog";
    }
    
    @GetMapping("/catalog")
    public String catalog(
            @RequestParam(required = false) String categoryPath,
            @RequestParam(required = false) Double minPrice,
            @RequestParam(required = false) Double maxPrice,
            @RequestParam(required = false) String search,
            @RequestParam(defaultValue = "0") int page,
            HttpSession session,
            Model model) {
        try {
            Map<String, Object> response = productServiceClient.getProducts(
                    categoryPath, minPrice, maxPrice, search, page, 20);
            model.addAttribute("products", response);
            model.addAttribute("currentPage", page);
            model.addAttribute("isLoggedIn", session.getAttribute("token") != null);
        } catch (Exception e) {
            log.error("Error fetching products", e);
            model.addAttribute("error", "Failed to load products");
        }
        return "catalog";
    }
    
    @GetMapping("/products/{id}")
    public String productDetail(@PathVariable Long id, HttpSession session, Model model) {
        try {
            Map<String, Object> product = productServiceClient.getProductById(id);
            model.addAttribute("product", product);
            model.addAttribute("isLoggedIn", session.getAttribute("token") != null);
        } catch (Exception e) {
            log.error("Error fetching product", e);
            model.addAttribute("error", "Product not found");
        }
        return "product-detail";
    }
    
    @GetMapping("/cart")
    public String cart(HttpSession session, Model model) {
        String token = (String) session.getAttribute("token");
        if (token == null) {
            return "redirect:/login";
        }
        
        try {
            Map<String, Object> cart = orderServiceClient.getCart("Bearer " + token);
            model.addAttribute("cart", cart);
        } catch (Exception e) {
            log.error("Error fetching cart", e);
            model.addAttribute("error", "Failed to load cart");
        }
        return "cart";
    }
    
    @PostMapping("/cart/add")
    public String addToCart(
            @RequestParam String sku,
            @RequestParam Integer quantity,
            HttpSession session) {
        String token = (String) session.getAttribute("token");
        if (token == null) {
            return "redirect:/login";
        }
        
        try {
            Map<String, Object> request = new HashMap<>();
            request.put("sku", sku);
            request.put("quantity", quantity);
            orderServiceClient.addToCart("Bearer " + token, request);
        } catch (Exception e) {
            log.error("Error adding to cart", e);
        }
        return "redirect:/cart";
    }
    
    @PostMapping("/cart/remove/{id}")
    public String removeFromCart(@PathVariable Long id, HttpSession session) {
        String token = (String) session.getAttribute("token");
        if (token == null) {
            return "redirect:/login";
        }
        
        try {
            orderServiceClient.removeFromCart("Bearer " + token, id);
        } catch (Exception e) {
            log.error("Error removing from cart", e);
        }
        return "redirect:/cart";
    }
    
    @GetMapping("/checkout")
    public String checkout(HttpSession session, Model model) {
        String token = (String) session.getAttribute("token");
        if (token == null) {
            return "redirect:/login";
        }
        
        try {
            Map<String, Object> cart = orderServiceClient.getCart("Bearer " + token);
            model.addAttribute("cart", cart);
            // Generate idempotency key
            model.addAttribute("idempotencyKey", UUID.randomUUID().toString());
        } catch (Exception e) {
            log.error("Error loading checkout", e);
            model.addAttribute("error", "Failed to load checkout");
        }
        return "checkout";
    }
    
    @PostMapping("/checkout")
    public String processCheckout(
            @RequestParam String shippingAddress,
            @RequestParam String shippingMethod,
            @RequestParam String idempotencyKey,
            HttpSession session,
            Model model) {
        String token = (String) session.getAttribute("token");
        if (token == null) {
            return "redirect:/login";
        }
        
        try {
            Map<String, Object> request = new HashMap<>();
            request.put("shippingAddress", shippingAddress);
            request.put("shippingMethod", shippingMethod);
            
            Map<String, Object> response = orderServiceClient.checkout(
                    "Bearer " + token, idempotencyKey, request);
            model.addAttribute("order", response);
            log.info("Checkout successful: order={}", response);
            return "order-confirmation";
        } catch (Exception e) {
            log.error("Error processing checkout", e);
            String errorMsg = "Checkout failed: " + (e.getMessage() != null ? e.getMessage() : "Unknown error");
            model.addAttribute("error", errorMsg);
            // Reload cart for retry
            try {
                Map<String, Object> cart = orderServiceClient.getCart("Bearer " + token);
                model.addAttribute("cart", cart);
                model.addAttribute("idempotencyKey", UUID.randomUUID().toString());
            } catch (Exception cartError) {
                log.error("Error reloading cart", cartError);
            }
            return "checkout";
        }
    }
    
    @GetMapping("/orders")
    public String orders(
            @RequestParam(defaultValue = "0") int page,
            HttpSession session,
            Model model) {
        String token = (String) session.getAttribute("token");
        if (token == null) {
            return "redirect:/login";
        }
        
        try {
            // Check if user is a merchant - if so, show merchant orders
            Object rolesObj = session.getAttribute("roles");
            boolean isMerchant = false;
            if (rolesObj != null) {
                String rolesStr = rolesObj.toString();
                isMerchant = rolesStr.contains("MERCHANT") || rolesStr.contains("ADMIN");
            }
            
            Map<String, Object> orders;
            if (isMerchant) {
                orders = orderServiceClient.getMerchantOrders("Bearer " + token, page, 20);
                model.addAttribute("isMerchant", true);
            } else {
                orders = orderServiceClient.getCustomerOrders("Bearer " + token, page, 20);
                model.addAttribute("isMerchant", false);
            }
            
            model.addAttribute("orders", orders);
            model.addAttribute("currentPage", page);
        } catch (Exception e) {
            log.error("Error fetching orders", e);
            model.addAttribute("error", "Failed to load orders");
        }
        return "orders";
    }
    
    @PostMapping("/orders/{id}/status")
    public String updateOrderStatus(
            @PathVariable Long id,
            @RequestParam String status,
            @RequestParam(required = false) String reason,
            HttpSession session,
            Model model) {
        String token = (String) session.getAttribute("token");
        if (token == null) {
            return "redirect:/login";
        }
        
        try {
            orderServiceClient.updateOrderStatus("Bearer " + token, id, status, reason);
            model.addAttribute("success", "Order status updated successfully");
        } catch (Exception e) {
            log.error("Error updating order status", e);
            model.addAttribute("error", "Failed to update order status: " + e.getMessage());
        }
        
        return "redirect:/orders";
    }
    
    @GetMapping("/merchant/dashboard")
    public String merchantDashboard(HttpSession session, Model model) {
        String token = (String) session.getAttribute("token");
        if (token == null) {
            return "redirect:/login";
        }
        
        try {
            // Get order status counts
            Map<String, Long> statusCounts = orderServiceClient.getOrderStatusCounts("Bearer " + token);
            
            // Get merchant orders to calculate total revenue
            Map<String, Object> ordersResponse = orderServiceClient.getMerchantOrders("Bearer " + token, 0, 1000);
            
            // Calculate totals
            long totalOrders = statusCounts.values().stream().mapToLong(Long::longValue).sum();
            long pendingOrders = statusCounts.getOrDefault("PENDING", 0L);
            
            // Calculate total revenue from all paid/fulfilled orders
            double totalRevenue = 0.0;
            if (ordersResponse != null && ordersResponse.containsKey("content")) {
                @SuppressWarnings("unchecked")
                List<Map<String, Object>> orders = (List<Map<String, Object>>) ordersResponse.get("content");
                totalRevenue = orders.stream()
                    .filter(o -> {
                        String status = (String) o.get("status");
                        return status != null && (status.equals("PAID") || status.equals("FULFILLING") 
                            || status.equals("SHIPPED") || status.equals("DELIVERED"));
                    })
                    .mapToDouble(o -> {
                        Object total = o.get("total");
                        if (total instanceof Number) {
                            return ((Number) total).doubleValue();
                        }
                        return 0.0;
                    })
                    .sum();
            }
            
            model.addAttribute("totalOrders", totalOrders);
            model.addAttribute("pendingOrders", pendingOrders);
            model.addAttribute("totalRevenue", String.format("%.2f", totalRevenue));
        } catch (Exception e) {
            log.error("Error fetching merchant dashboard data", e);
            model.addAttribute("totalOrders", 0);
            model.addAttribute("pendingOrders", 0);
            model.addAttribute("totalRevenue", "0.00");
        }
        
        return "merchant-dashboard";
    }
    
    @GetMapping("/login")
    public String loginPage(@RequestParam(required = false) String error, Model model) {
        // Don't add error from query param if we already have one in model
        // This prevents duplicate error messages
        return "login";
    }
    
    @PostMapping("/login")
    public String login(
            @RequestParam String email,
            @RequestParam String password,
            HttpSession session,
            Model model) {
        try {
            // Trim email and password to handle any whitespace issues
            String trimmedEmail = email != null ? email.trim() : "";
            String trimmedPassword = password != null ? password.trim() : "";
            
            log.info("Login attempt - email: '{}', password length: {}", trimmedEmail, trimmedPassword.length());
            
            Map<String, String> request = new HashMap<>();
            request.put("email", trimmedEmail);
            request.put("password", trimmedPassword);
            
            Map<String, Object> response = authServiceClient.login(request);
            
            log.info("Login response received: {}", response);
            log.info("Login response keys: {}", response != null ? response.keySet() : "null");
            
            // Extract values from response map (Feign deserializes JSON to Map)
            String token = extractStringValue(response, "token");
            Object userId = response != null ? response.get("userId") : null;
            Object emailObj = response != null ? response.get("email") : null;
            Object roles = response != null ? response.get("roles") : null;
            
            log.info("Extracted - token: {}, userId: {}, email: {}, roles: {}", 
                    token != null ? token.substring(0, Math.min(20, token.length())) + "..." : "null",
                    userId, emailObj, roles);
            
            if (token == null || token.isEmpty() || "null".equals(token)) {
                log.error("Login response missing token. Full response: {}", response);
                model.addAttribute("error", "Login failed: Invalid response from server. Response was: " + 
                        (response != null ? response.toString() : "null"));
                return "login";
            }
            
            // Store session data
            session.setAttribute("token", token);
            session.setAttribute("userId", userId);
            session.setAttribute("email", emailObj);
            session.setAttribute("roles", roles);
            
            log.info("Login successful for: {}, userId: {}", email, userId);
            return "redirect:/catalog";
        } catch (FeignException e) {
            log.error("Login failed (FeignException) for: {}", email);
            log.error("FeignException status: {}, message: {}", e.status(), e.getMessage());
            
            String errorMessage = "Login failed";
            String responseBody = null;
            
            try {
                // Try to extract error message from response body
                if (e.responseBody() != null && e.responseBody().isPresent()) {
                    byte[] bodyBytes = e.responseBody().get().array();
                    responseBody = new String(bodyBytes, StandardCharsets.UTF_8);
                    log.error("Feign error response body (raw): {}", responseBody);
                    
                    // Try to parse JSON response for error message
                    // Response format: {"status":400,"error":"Bad Request","message":"Invalid credentials",...}
                    if (responseBody.contains("\"message\"")) {
                        // Find message field value
                        int messageIndex = responseBody.indexOf("\"message\"");
                        if (messageIndex >= 0) {
                            // Find the colon after "message"
                            int colonIndex = responseBody.indexOf(":", messageIndex);
                            if (colonIndex >= 0) {
                                // Find the opening quote of the value
                                int valueStart = responseBody.indexOf("\"", colonIndex) + 1;
                                if (valueStart > 0) {
                                    // Find the closing quote
                                    int valueEnd = responseBody.indexOf("\"", valueStart);
                                    if (valueEnd > valueStart) {
                                        String message = responseBody.substring(valueStart, valueEnd);
                                        log.info("Extracted error message: {}", message);
                                        if (message.contains("Invalid credentials") || message.contains("Invalid email") || message.contains("Invalid password")) {
                                            errorMessage = "Invalid email or password";
                                        } else {
                                            errorMessage = message;
                                        }
                                    }
                                }
                            }
                        }
                    } else if (responseBody.contains("Invalid credentials")) {
                        errorMessage = "Invalid email or password";
                    }
                } else {
                    log.warn("No response body in FeignException");
                }
            } catch (Exception parseError) {
                log.error("Error parsing Feign exception response: {}", parseError.getMessage(), parseError);
            }
            
            // Fallback to status code based messages
            if (errorMessage.equals("Login failed")) {
                int status = e.status();
                if (status == 400 || status == 401) {
                    errorMessage = "Invalid email or password";
                } else if (status == 500) {
                    errorMessage = "Server error. Please try again later.";
                } else if (status == 404) {
                    errorMessage = "Service not found. Please check if auth service is running.";
                } else {
                    errorMessage = String.format("Login failed. HTTP Status: %d. %s", status, 
                            responseBody != null ? "Response: " + responseBody.substring(0, Math.min(200, responseBody.length())) : "");
                }
            }
            
            log.error("Final error message for user: {}", errorMessage);
            model.addAttribute("error", errorMessage);
            return "login";
        } catch (Exception e) {
            log.error("Login failed (Exception) for: {}", email, e);
            log.error("Exception type: {}, message: {}", e.getClass().getName(), e.getMessage());
            
            String errorMessage = "Login failed";
            if (e.getMessage() != null) {
                if (e.getMessage().contains("Invalid credentials") || e.getMessage().contains("401")) {
                    errorMessage = "Invalid email or password";
                } else if (e.getMessage().contains("500")) {
                    errorMessage = "Server error. Please try again later.";
                } else {
                    errorMessage = "Login failed: " + e.getMessage();
                }
            } else {
                errorMessage = "Login failed. Please check your credentials and try again.";
            }
            
            log.error("Adding error to model: {}", errorMessage);
            model.addAttribute("error", errorMessage);
            log.error("Model attributes after adding error: {}", model.asMap().keySet());
            return "login";
        }
    }
    
    @PostMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/catalog";
    }
    
    /**
     * Helper method to extract string value from map, handling different response formats.
     */
    private String extractStringValue(Map<String, Object> map, String key) {
        if (map == null || key == null) {
            return null;
        }
        
        Object value = map.get(key);
        if (value == null) {
            return null;
        }
        
        return String.valueOf(value);
    }
    
    @GetMapping("/register")
    public String registerPage() {
        return "register";
    }
    
    @PostMapping("/register")
    public String register(
            @RequestParam String name,
            @RequestParam String email,
            @RequestParam String password,
            @RequestParam(defaultValue = "CUSTOMER") String role,
            Model model) {
        try {
            // Trim all inputs to handle any whitespace issues
            String trimmedName = name != null ? name.trim() : "";
            String trimmedEmail = email != null ? email.trim() : "";
            String trimmedPassword = password != null ? password.trim() : "";
            String trimmedRole = role != null ? role.trim() : "";
            
            log.info("Registration attempt - email: '{}', password length: {}", trimmedEmail, trimmedPassword.length());
            
            Map<String, String> request = new HashMap<>();
            request.put("name", trimmedName);
            request.put("email", trimmedEmail);
            request.put("password", trimmedPassword);
            request.put("role", trimmedRole);
            
            authServiceClient.register(request);
            log.info("Registration successful for: {}", email);
            return "redirect:/login?registered=true";
        } catch (FeignException e) {
            log.error("Registration failed (FeignException) for: {}", email);
            log.error("FeignException status: {}, message: {}", e.status(), e.getMessage());

            String errorMessage = "Registration failed";
            String responseBody = null;

            try {
                if (e.responseBody() != null && e.responseBody().isPresent()) {
                    byte[] bodyBytes = e.responseBody().get().array();
                    responseBody = new String(bodyBytes, StandardCharsets.UTF_8);
                    log.error("Feign error response body (raw): {}", responseBody);

                    // Expected format (example):
                    // {"error":"Validation Failed","message":"Request validation failed","errors":{"password":"..."},"status":400,...}
                    if (responseBody.contains("\"errors\"") && responseBody.contains("\"password\"")) {
                        int passwordIndex = responseBody.indexOf("\"password\"");
                        int colonIndex = responseBody.indexOf(":", passwordIndex);
                        if (colonIndex >= 0) {
                            int valueStart = responseBody.indexOf("\"", colonIndex) + 1;
                            if (valueStart > 0) {
                                int valueEnd = responseBody.indexOf("\"", valueStart);
                                if (valueEnd > valueStart) {
                                    String pwdMessage = responseBody.substring(valueStart, valueEnd);
                                    errorMessage = pwdMessage;
                                }
                            }
                        }
                    } else if (responseBody.contains("\"message\"")) {
                        int messageIndex = responseBody.indexOf("\"message\"");
                        int colonIndex = responseBody.indexOf(":", messageIndex);
                        if (colonIndex >= 0) {
                            int valueStart = responseBody.indexOf("\"", colonIndex) + 1;
                            if (valueStart > 0) {
                                int valueEnd = responseBody.indexOf("\"", valueStart);
                                if (valueEnd > valueStart) {
                                    errorMessage = responseBody.substring(valueStart, valueEnd);
                                }
                            }
                        }
                    }
                }
            } catch (Exception parseError) {
                log.error("Error parsing Feign exception response: {}", parseError.getMessage(), parseError);
            }

            // Fallback to status-based messages
            if ("Registration failed".equals(errorMessage)) {
                int status = e.status();
                if (status == 400) {
                    errorMessage = "Registration failed: Please check your input (password must be strong).";
                } else if (status == 409) {
                    errorMessage = "Registration failed: Email already exists.";
                } else if (status == 500) {
                    errorMessage = "Registration failed: Server error. Please try again later.";
                } else {
                    errorMessage = String.format("Registration failed. HTTP Status: %d. %s", status,
                            responseBody != null ? "Response: " + responseBody.substring(0, Math.min(200, responseBody.length())) : "");
                }
            }

            model.addAttribute("error", errorMessage);
            return "register";
        } catch (Exception e) {
            log.error("Registration failed for: {}", email, e);
            String errorMessage = "Registration failed: " + (e.getMessage() != null ? e.getMessage() : "Please check your input");
            model.addAttribute("error", errorMessage);
            return "register";
        }
    }
}

