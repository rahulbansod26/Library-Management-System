package com.retailx.repository;

import com.retailx.domain.AuditEvent;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;

/**
 * Repository for AuditEvent entity.
 */
@Repository
public interface AuditEventRepository extends JpaRepository<AuditEvent, Long> {
    
    @Query("SELECT a FROM AuditEvent a WHERE " +
           "(:actorId IS NULL OR a.actorId = :actorId) " +
           "AND (:entityType IS NULL OR a.entityType = :entityType) " +
           "AND (:entityId IS NULL OR a.entityId = :entityId) " +
           "AND (:startDate IS NULL OR a.timestamp >= :startDate) " +
           "AND (:endDate IS NULL OR a.timestamp <= :endDate)")
    Page<AuditEvent> searchAuditEvents(
        @Param("actorId") String actorId,
        @Param("entityType") String entityType,
        @Param("entityId") String entityId,
        @Param("startDate") LocalDateTime startDate,
        @Param("endDate") LocalDateTime endDate,
        Pageable pageable
    );
}

