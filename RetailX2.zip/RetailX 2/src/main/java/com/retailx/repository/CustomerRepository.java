package com.retailx.repository;

import com.retailx.domain.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * Repository for Customer entity.
 */
@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long> {
    
    Optional<Customer> findByUserId(Long userId);
    
    @Query("SELECT c FROM Customer c WHERE c.user.id = :userId AND c.deleted = false")
    Optional<Customer> findActiveByUserId(@Param("userId") Long userId);
}

