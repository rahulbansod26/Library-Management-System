package com.retailx.auth.repository;

import com.retailx.auth.domain.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * Repository for User entity.
 */
@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    
    Optional<User> findByEmailAndDeletedFalse(String email);
    
    boolean existsByEmailAndDeletedFalse(String email);
    
    @Query("SELECT u FROM User u WHERE LOWER(u.email) = LOWER(:email) AND u.deleted = false")
    Optional<User> findByEmailIgnoreCase(@Param("email") String email);
    
    @Query("SELECT u FROM User u WHERE LOWER(u.email) = LOWER(:email) AND u.deleted = false")
    Optional<User> findActiveByEmail(@Param("email") String email);
}

