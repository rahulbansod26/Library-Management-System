package com.retailx.auth.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.Contact;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Swagger/OpenAPI configuration.
 */
@Configuration
public class SwaggerConfig {
    
    @Bean
    public OpenAPI authServiceOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("RetailX Auth Service API")
                        .description("API documentation for Auth Service")
                        .version("1.0.0")
                        .contact(new Contact()
                                .name("RetailX Team")
                                .email("support@retailx.com")));
    }
}

