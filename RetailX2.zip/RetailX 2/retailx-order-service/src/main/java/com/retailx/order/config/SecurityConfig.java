package com.retailx.order.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

/**
 * Security configuration for Order Service with role-based access control.
 */
@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {
    
    @Autowired
    private JwtAuthenticationFilter jwtAuthenticationFilter;
    
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable())
            .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class)
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/actuator/**")
                    .permitAll() // Allow actuator endpoints for health checks
                .requestMatchers("/api/carts/**", "/api/checkout", "/api/orders/customer/**", "/api/returns/orders/**")
                    .hasAnyRole("CUSTOMER", "ADMIN")
                .requestMatchers(HttpMethod.GET, "/api/shipments/orders/**")
                    .hasAnyRole("CUSTOMER", "MERCHANT", "ADMIN", "OPS") // Allow CUSTOMER to view shipments
                .requestMatchers("/api/orders/merchant/**", "/api/reports/**", "/api/shipments/**", "/api/returns/**")
                    .hasAnyRole("MERCHANT", "ADMIN", "OPS")
                .requestMatchers("/api/orders/**")
                    .authenticated()
                .anyRequest().permitAll()
            );
        
        return http.build();
    }
}

