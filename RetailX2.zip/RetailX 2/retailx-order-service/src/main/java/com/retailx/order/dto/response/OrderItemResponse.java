package com.retailx.order.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.math.BigInteger;

/**
 * Order item response DTO.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OrderItemResponse {
    
    private Long id;
    private String sku;
    private String productName;
    private BigInteger quantity;
    private BigDecimal unitPrice;
    private BigDecimal lineTotal;
}

