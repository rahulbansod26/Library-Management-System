package com.retailx.order.scheduler;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * Scheduler for Spring Batch jobs.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class BatchScheduler {
    
    private final JobLauncher jobLauncher;
    @Qualifier("inventoryReconciliationJob")
    private final Job inventoryReconciliationJob;
    @Qualifier("monthlySalesStatementJob")
    private final Job monthlySalesStatementJob;
    
    /**
     * Run inventory reconciliation nightly at 2 AM.
     */
    @Scheduled(cron = "0 0 2 * * ?")
    public void runInventoryReconciliation() {
        log.info("Starting scheduled inventory reconciliation job");
        try {
            JobParameters parameters = new JobParametersBuilder()
                    .addLong("timestamp", System.currentTimeMillis())
                    .toJobParameters();
            jobLauncher.run(inventoryReconciliationJob, parameters);
        } catch (Exception e) {
            log.error("Error running inventory reconciliation job", e);
        }
    }
    
    /**
     * Run monthly sales statement on 1st of each month at 3 AM.
     */
    @Scheduled(cron = "0 0 3 1 * ?")
    public void runMonthlySalesStatement() {
        log.info("Starting scheduled monthly sales statement job");
        try {
            JobParameters parameters = new JobParametersBuilder()
                    .addLong("timestamp", System.currentTimeMillis())
                    .toJobParameters();
            jobLauncher.run(monthlySalesStatementJob, parameters);
        } catch (Exception e) {
            log.error("Error running monthly sales statement job", e);
        }
    }
}

