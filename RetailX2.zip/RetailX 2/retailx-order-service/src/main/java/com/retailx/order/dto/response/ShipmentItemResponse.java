package com.retailx.order.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigInteger;

/**
 * Shipment item response DTO.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ShipmentItemResponse {
    
    private Long id;
    private String sku;
    private BigInteger quantity;
}

