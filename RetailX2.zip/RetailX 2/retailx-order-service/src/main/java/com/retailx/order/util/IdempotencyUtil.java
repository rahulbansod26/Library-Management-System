package com.retailx.order.util;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Utility for idempotency key operations.
 */
public class IdempotencyUtil {
    
    private static final int MAX_KEY_LENGTH = 64;
    
    /**
     * Validates idempotency key format.
     */
    public static boolean isValidKey(String key) {
        return key != null 
            && !key.trim().isEmpty() 
            && key.length() <= MAX_KEY_LENGTH;
    }
    
    /**
     * Generates hash of request payload for idempotency checking.
     */
    public static String hashRequest(String payload) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(payload.getBytes(StandardCharsets.UTF_8));
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 algorithm not found", e);
        }
    }
}

