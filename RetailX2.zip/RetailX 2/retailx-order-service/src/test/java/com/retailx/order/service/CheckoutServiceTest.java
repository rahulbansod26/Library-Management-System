package com.retailx.order.service;

import com.retailx.order.domain.Cart;
import com.retailx.order.domain.CartItem;
import com.retailx.order.domain.IdempotencyKey;
import com.retailx.order.dto.request.CheckoutRequest;
import com.retailx.order.repository.CartRepository;
import com.retailx.order.repository.IdempotencyKeyRepository;
import com.retailx.order.repository.OrderRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * Unit tests for CheckoutService.
 */
@ExtendWith(MockitoExtension.class)
class CheckoutServiceTest {
    
    @Mock
    private CartRepository cartRepository;
    
    @Mock
    private OrderRepository orderRepository;
    
    @Mock
    private IdempotencyKeyRepository idempotencyKeyRepository;
    
    @Mock
    private InventoryServiceClient inventoryServiceClient;
    
    @Mock
    private ProductServiceClient productServiceClient;
    
    @Mock
    private KafkaTemplate<String, String> kafkaTemplate;
    
    @InjectMocks
    private CheckoutService checkoutService;
    
    private Cart testCart;
    private CheckoutRequest checkoutRequest;
    private String idempotencyKey;
    
    @BeforeEach
    void setUp() {
        idempotencyKey = "test-key-123";
        testCart = Cart.builder()
                .customerId(1L)
                .items(new ArrayList<>())
                .subtotal(new BigDecimal("100"))
                .tax(new BigDecimal("10"))
                .shipping(new BigDecimal("5"))
                .total(new BigDecimal("115"))
                .build();
        
        CartItem item = CartItem.builder()
                .cart(testCart)
                .sku("PROD-001")
                .quantity(BigInteger.valueOf(2))
                .unitPrice(new BigDecimal("50"))
                .lineTotal(new BigDecimal("100"))
                .build();
        testCart.getItems().add(item);
        
        checkoutRequest = new CheckoutRequest();
        checkoutRequest.setShippingAddress("123 Main St");
        checkoutRequest.setShippingMethod("STANDARD");
        
        // Set @Value fields using reflection since we're using MockitoExtension
        try {
            java.lang.reflect.Field maxItemsField = CheckoutService.class.getDeclaredField("maxItems");
            maxItemsField.setAccessible(true);
            maxItemsField.setInt(checkoutService, 50);
            
            java.lang.reflect.Field maxTotalValueField = CheckoutService.class.getDeclaredField("maxTotalValue");
            maxTotalValueField.setAccessible(true);
            maxTotalValueField.set(checkoutService, new BigDecimal("10000"));
            
            java.lang.reflect.Field maxQuantityPerItemField = CheckoutService.class.getDeclaredField("maxQuantityPerItem");
            maxQuantityPerItemField.setAccessible(true);
            maxQuantityPerItemField.setInt(checkoutService, 100);
        } catch (Exception e) {
            // Ignore reflection errors
        }
    }
    
    @Test
    void testCheckout_Success() {
        when(cartRepository.findByCustomerIdAndDeletedFalse(1L))
                .thenReturn(Optional.of(testCart));
        when(idempotencyKeyRepository.findByKeyValue(idempotencyKey))
                .thenReturn(Optional.empty());
        when(productServiceClient.getProductBySku(anyString()))
                .thenReturn(java.util.Map.of("status", "ACTIVE", "basePrice", 50.0));
        when(inventoryServiceClient.reserveInventory(anyString(), any(), anyString()))
                .thenReturn(true);
        when(orderRepository.save(any())).thenAnswer(invocation -> invocation.getArgument(0));
        when(idempotencyKeyRepository.save(any())).thenAnswer(invocation -> invocation.getArgument(0));
        
        var response = checkoutService.checkout(1L, checkoutRequest, idempotencyKey);
        
        assertNotNull(response);
        assertNotNull(response.getOrderNumber());
        verify(orderRepository, times(1)).save(any());
        verify(kafkaTemplate, times(1)).send(anyString(), anyString(), anyString());
    }
    
    @Test
    void testCheckout_InvalidIdempotencyKey() {
        assertThrows(ResponseStatusException.class, () -> {
            checkoutService.checkout(1L, checkoutRequest, null);
        });
    }
    
    @Test
    void testCheckout_EmptyCart() {
        testCart.getItems().clear();
        when(cartRepository.findByCustomerIdAndDeletedFalse(1L))
                .thenReturn(Optional.of(testCart));
        
        assertThrows(RuntimeException.class, () -> {
            checkoutService.checkout(1L, checkoutRequest, idempotencyKey);
        });
    }
    
    @Test
    void testCheckout_IdempotentRequest() {
        // Calculate the correct request hash that matches what the service will calculate
        String requestHash = com.retailx.order.util.IdempotencyUtil.hashRequest(checkoutRequest.toString());
        
        IdempotencyKey existingKey = IdempotencyKey.builder()
                .keyValue(idempotencyKey)
                .requestHash(requestHash)
                .responseSummary("{\"orderNumber\":\"ORD-001\",\"orderId\":\"1\"}")
                .used(true)
                .build();
        
        when(idempotencyKeyRepository.findByKeyValue(idempotencyKey))
                .thenReturn(Optional.of(existingKey));
        
        var response = checkoutService.checkout(1L, checkoutRequest, idempotencyKey);
        
        assertNotNull(response);
        verify(orderRepository, never()).save(any());
    }
}

