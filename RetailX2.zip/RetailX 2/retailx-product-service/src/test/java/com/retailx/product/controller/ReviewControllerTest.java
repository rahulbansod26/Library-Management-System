package com.retailx.product.controller;

import com.retailx.product.dto.request.ReviewRequest;
import com.retailx.product.dto.response.ReviewResponse;
import com.retailx.product.service.ReviewService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for ReviewController.
 */
@ExtendWith(MockitoExtension.class)
class ReviewControllerTest {
    
    @Mock
    private ReviewService reviewService;
    
    @InjectMocks
    private ReviewController reviewController;
    
    private ReviewRequest reviewRequest;
    private ReviewResponse reviewResponse;
    
    @BeforeEach
    void setUp() {
        reviewRequest = new ReviewRequest();
        reviewRequest.setRating(5);
        reviewRequest.setText("Great product!");
        
        reviewResponse = ReviewResponse.builder()
                .id(1L)
                .productId(1L)
                .customerId(1L)
                .rating(5)
                .text("Great product!")
                .status("APPROVED")
                .build();
    }
    
    @Test
    void testCreateReview_Success() {
        when(reviewService.createReview(anyLong(), anyLong(), anyLong(), any(ReviewRequest.class)))
                .thenReturn(reviewResponse);
        
        ResponseEntity<ReviewResponse> response = 
                reviewController.createReview(1L, 1L, 1L, reviewRequest);
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(5, response.getBody().getRating());
        verify(reviewService, times(1)).createReview(1L, 1L, 1L, reviewRequest);
    }
    
    @Test
    void testGetReviewsByProduct_Success() {
        Page<ReviewResponse> page = new PageImpl<>(Arrays.asList(reviewResponse));
        when(reviewService.getReviewsByProduct(anyLong(), anyString(), any()))
                .thenReturn(page);
        
        ResponseEntity<Page<ReviewResponse>> response = 
                reviewController.getReviewsByProduct(1L, "APPROVED", 0, 20);
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(1, response.getBody().getTotalElements());
        verify(reviewService, times(1)).getReviewsByProduct(eq(1L), eq("APPROVED"), any());
    }
    
    @Test
    void testModerateReview_Success() {
        reviewResponse.setStatus("APPROVED");
        when(reviewService.moderateReview(anyLong(), anyString(), anyString()))
                .thenReturn(reviewResponse);
        
        ResponseEntity<ReviewResponse> response = 
                reviewController.moderateReview(1L, "APPROVE", "1");
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("APPROVED", response.getBody().getStatus());
        verify(reviewService, times(1)).moderateReview(1L, "APPROVE", "1");
    }
    
    @Test
    void testGetPendingReviews_Success() {
        reviewResponse.setStatus("PENDING");
        List<ReviewResponse> pendingReviews = Arrays.asList(reviewResponse);
        when(reviewService.getPendingReviews()).thenReturn(pendingReviews);
        
        ResponseEntity<List<ReviewResponse>> response = reviewController.getPendingReviews();
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(1, response.getBody().size());
        verify(reviewService, times(1)).getPendingReviews();
    }
}

