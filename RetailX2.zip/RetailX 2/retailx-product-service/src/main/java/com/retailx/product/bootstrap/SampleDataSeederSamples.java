package com.retailx.product.bootstrap;

import com.retailx.product.domain.enums.ProductStatus;
import com.retailx.product.dto.request.ProductRequest;

import java.math.BigDecimal;
import java.util.List;

/**
 * Shared sample catalog data used by both startup seeder and dev seed API.
 */
public final class SampleDataSeederSamples {
    private SampleDataSeederSamples() {}

    public static List<ProductRequest> samples() {
        return List.of(
                sample("RX-TSHIRT-001", "RetailX Cotton T‑Shirt", "Soft, breathable cotton tee for everyday wear.",
                        "fashion/men/tops", new BigDecimal("19.99"), "{\"color\":\"black\",\"material\":\"cotton\"}", 1L),
                sample("RX-JEANS-001", "Slim Fit Jeans", "Classic slim fit jeans with stretch denim.",
                        "fashion/men/bottoms", new BigDecimal("49.99"), "{\"fit\":\"slim\",\"material\":\"denim\"}", 1L),
                sample("RX-SNEAKER-001", "Everyday Sneakers", "Lightweight sneakers with cushioned sole.",
                        "fashion/unisex/shoes", new BigDecimal("59.99"), "{\"sizeRange\":\"7-12\",\"color\":\"white\"}", 1L),

                sample("RX-PHONE-001", "Smartphone X Lite", "6.1\" display, dual camera, all‑day battery.",
                        "electronics/phones", new BigDecimal("399.00"), "{\"storage\":\"128GB\",\"color\":\"blue\"}", 1L),
                sample("RX-HEADPHONES-001", "Noise Cancelling Headphones", "Over‑ear ANC headphones with deep bass.",
                        "electronics/audio", new BigDecimal("129.00"), "{\"type\":\"over-ear\",\"anc\":true}", 1L),
                sample("RX-LAPTOP-001", "Ultrabook Pro 14", "Portable 14\" laptop for work and study.",
                        "electronics/computers", new BigDecimal("899.00"), "{\"ram\":\"16GB\",\"storage\":\"512GB\"}", 1L),

                sample("RX-COFFEE-001", "Arabica Coffee Beans 1kg", "Fresh roast, smooth and balanced.",
                        "grocery/beverages/coffee", new BigDecimal("24.50"), "{\"roast\":\"medium\",\"origin\":\"blend\"}", 1L),
                sample("RX-OLIVE-001", "Extra Virgin Olive Oil 1L", "Cold‑pressed EVOO for cooking and salads.",
                        "grocery/pantry/oils", new BigDecimal("14.25"), "{\"type\":\"extra virgin\",\"size\":\"1L\"}", 1L),

                sample("RX-BOOK-001", "Clean Architecture (Paperback)", "A practical guide to software architecture principles.",
                        "books/technology", new BigDecimal("32.00"), "{\"format\":\"paperback\"}", 1L),
                sample("RX-MUG-001", "RetailX Coffee Mug", "Ceramic mug, 350ml.",
                        "home/kitchen", new BigDecimal("9.99"), "{\"capacity\":\"350ml\",\"material\":\"ceramic\"}", 1L)
        );
    }

    private static ProductRequest sample(
            String sku,
            String name,
            String description,
            String categoryPath,
            BigDecimal price,
            String attributesJson,
            Long merchantId
    ) {
        ProductRequest req = new ProductRequest();
        req.setSku(sku);
        req.setName(name);
        req.setDescription(description);
        req.setCategoryPath(categoryPath);
        req.setBasePrice(price);
        req.setCurrency("USD");
        req.setStatus(ProductStatus.ACTIVE);
        req.setAttributes(attributesJson);
        req.setMerchantId(merchantId);
        req.setMedia(List.of(
                "https://example.com/images/" + sku.toLowerCase() + ".jpg"
        ));
        return req;
    }
}


