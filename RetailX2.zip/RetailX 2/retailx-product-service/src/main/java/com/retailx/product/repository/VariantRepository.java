package com.retailx.product.repository;

import com.retailx.product.domain.Variant;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * Repository for Variant entity.
 */
@Repository
public interface VariantRepository extends JpaRepository<Variant, Long> {
    
    Optional<Variant> findByVariantSkuAndDeletedFalse(String variantSku);
}

