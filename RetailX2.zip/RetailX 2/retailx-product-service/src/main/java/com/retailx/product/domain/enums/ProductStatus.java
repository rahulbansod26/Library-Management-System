package com.retailx.product.domain.enums;

/**
 * Product status values.
 */
public enum ProductStatus {
    DRAFT,
    ACTIVE,
    DISCONTINUED
}

