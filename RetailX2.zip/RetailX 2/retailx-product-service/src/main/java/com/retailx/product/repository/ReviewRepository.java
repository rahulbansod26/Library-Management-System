package com.retailx.product.repository;

import com.retailx.product.domain.Review;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Repository for Review entity.
 */
@Repository
public interface ReviewRepository extends JpaRepository<Review, Long> {
    
    Optional<Review> findByProductIdAndCustomerIdAndOrderItemId(Long productId, Long customerId, Long orderItemId);
    
    Page<Review> findByProductIdAndStatusAndDeletedFalse(Long productId, String status, Pageable pageable);
    
    List<Review> findByStatusAndDeletedFalse(String status);
}

