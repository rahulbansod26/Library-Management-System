package com.retailx.product.bootstrap;

import com.retailx.product.dto.request.ProductRequest;
import com.retailx.product.repository.ProductRepository;
import com.retailx.product.service.ProductService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Seeds sample catalog data for local/demo usage.
 *
 * Runs only when the products table is empty, and can be disabled via:
 * retailx.seed.enabled=false
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class SampleDataSeeder implements ApplicationRunner {

    private final ProductRepository productRepository;
    private final ProductService productService;

    @Value("${retailx.seed.enabled:true}")
    private boolean seedEnabled;

    @Override
    public void run(ApplicationArguments args) {
        if (!seedEnabled) {
            log.info("SampleDataSeeder disabled (retailx.seed.enabled=false)");
            return;
        }

        long existing = productRepository.count();
        if (existing > 0) {
            log.info("Skipping sample product seeding (products already exist: {})", existing);
            return;
        }

        log.info("Seeding sample products (empty DB detected)...");

        // Use ProductService so SKU/category normalization + catalogPath are consistent.
        List<ProductRequest> samples = SampleDataSeederSamples.samples();

        for (ProductRequest req : samples) {
            try {
                productService.createProduct(req);
            } catch (Exception e) {
                // Don't fail startup if one sample fails; log and continue.
                log.warn("Failed seeding sample product sku={}: {}", req.getSku(), e.getMessage());
            }
        }

        log.info("Sample product seeding complete.");
    }

    // SampleDataSeederSamples holds the sample list.
}


