package com.retailx.product.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Review response DTO.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ReviewResponse {
    
    private Long id;
    private Long productId;
    private Long customerId;
    private Long orderItemId;
    private Integer rating;
    private String text;
    private String status;
    private Boolean moderated;
    private LocalDateTime createdOn;
}

