package com.retailx.product.controller;

import com.retailx.product.dto.request.ReviewRequest;
import com.retailx.product.dto.response.ReviewResponse;
import com.retailx.product.service.ReviewService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST controller for review endpoints.
 */
@Slf4j
@RestController
@RequestMapping("/api/reviews")
@RequiredArgsConstructor
public class ReviewController {
    
    private final ReviewService reviewService;
    
    @PostMapping("/products/{productId}")
    @PreAuthorize("hasAnyRole('CUSTOMER', 'ADMIN')")
    public ResponseEntity<ReviewResponse> createReview(
            @PathVariable Long productId,
            @RequestHeader("X-User-Id") Long customerId,
            @RequestParam Long orderItemId,
            @RequestBody ReviewRequest request) {
        log.info("Creating review: productId={}, customerId={}, orderItemId={}", 
                productId, customerId, orderItemId);
        
        ReviewResponse response = reviewService.createReview(productId, customerId, orderItemId, request);
        return ResponseEntity.ok(response);
    }
    
    @GetMapping("/products/{productId}")
    public ResponseEntity<Page<ReviewResponse>> getReviewsByProduct(
            @PathVariable Long productId,
            @RequestParam(required = false) String status,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        Pageable pageable = PageRequest.of(page, size);
        Page<ReviewResponse> response = reviewService.getReviewsByProduct(productId, status, pageable);
        return ResponseEntity.ok(response);
    }
    
    @PutMapping("/{reviewId}/moderate")
    @PreAuthorize("hasAnyRole('ADMIN', 'OPS')")
    public ResponseEntity<ReviewResponse> moderateReview(
            @PathVariable Long reviewId,
            @RequestParam String action,
            @RequestHeader("X-User-Id") String actorId) {
        log.info("Moderating review: reviewId={}, action={}, actor={}", reviewId, action, actorId);
        
        ReviewResponse response = reviewService.moderateReview(reviewId, action, actorId);
        return ResponseEntity.ok(response);
    }
    
    @GetMapping("/pending")
    @PreAuthorize("hasAnyRole('ADMIN', 'OPS')")
    public ResponseEntity<List<ReviewResponse>> getPendingReviews() {
        List<ReviewResponse> response = reviewService.getPendingReviews();
        return ResponseEntity.ok(response);
    }
}

