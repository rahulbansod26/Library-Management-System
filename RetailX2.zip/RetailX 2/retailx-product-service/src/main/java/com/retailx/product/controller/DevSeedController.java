package com.retailx.product.controller;

import com.retailx.product.bootstrap.SampleDataSeederSamples;
import com.retailx.product.dto.request.ProductRequest;
import com.retailx.product.repository.ProductRepository;
import com.retailx.product.service.ProductService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

/**
 * Dev-only seed endpoints to quickly populate demo catalog data via API.
 *
 * Enabled by default for local/dev: retailx.seed.api.enabled=true
 */
@Slf4j
@RestController
@RequestMapping("/api/products/dev")
@RequiredArgsConstructor
public class DevSeedController {

    private final ProductRepository productRepository;
    private final ProductService productService;

    @Value("${retailx.seed.api.enabled:true}")
    private boolean seedApiEnabled;

    @PostMapping("/seed")
    public ResponseEntity<Map<String, Object>> seed(@RequestParam(defaultValue = "false") boolean force) {
        if (!seedApiEnabled) {
            return ResponseEntity.status(403).body(Map.of(
                    "message", "Seed API disabled (retailx.seed.api.enabled=false)"
            ));
        }

        // Same SKU set used by SampleDataSeeder, but seed via API will insert missing SKUs even if DB isn't empty.
        List<ProductRequest> samples = SampleDataSeederSamples.samples();

        int created = 0;
        int skipped = 0;
        for (ProductRequest req : samples) {
            try {
                if (productRepository.findBySkuAndDeletedFalse(req.getSku()).isPresent()) {
                    if (force) {
                        // For safety, don't overwrite existing data via API; just mark as skipped.
                        skipped++;
                    } else {
                        skipped++;
                    }
                    continue;
                }
                productService.createProduct(req);
                created++;
            } catch (Exception e) {
                log.warn("Seed create failed sku={}: {}", req.getSku(), e.getMessage());
            }
        }

        return ResponseEntity.ok(Map.of(
                "message", "Seed completed",
                "created", created,
                "skipped", skipped,
                "totalRequested", samples.size()
        ));
    }
}


