package com.retailx.notification.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.Contact;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Swagger/OpenAPI configuration for Notification Service.
 */
@Configuration
public class SwaggerConfig {
    
    @Bean
    public OpenAPI notificationServiceOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("RetailX Notification Service API")
                        .description("API documentation for Notification Service - Handles event-driven notifications via Kafka")
                        .version("1.0.0")
                        .contact(new Contact()
                                .name("RetailX Team")
                                .email("support@retailx.com")));
    }
}

