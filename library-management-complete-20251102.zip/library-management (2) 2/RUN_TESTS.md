# How to Run Tests - Quick Reference

## Prerequisites
1. ✅ Eureka Service Discovery running (port 8761)
2. ✅ All services started
3. ✅ MySQL, RabbitMQ, Redis running

## Quick Commands

### Test All Services
```bash
./test-all-services.sh
```

### Test Individual Services
```bash
./test-user-service.sh
./test-catalog-service.sh
./test-borrow-service.sh
./test-fine-service.sh
./test-notification-service.sh
```

## Step-by-Step Testing

### 1. Start Eureka
```bash
cd eureka-service
mvn spring-boot:run
# Wait for startup, then open http://localhost:8761
```

### 2. Start and Test User Service
```bash
# Terminal 2
cd user-service
mvn spring-boot:run

# Terminal 3 (after service starts)
cd /path/to/library-management
./test-user-service.sh
```

### 3. Start and Test Catalog Service
```bash
# Terminal 2
cd catalog-service
mvn spring-boot:run

# Terminal 3
./test-catalog-service.sh
```

### 4. Start and Test Borrow Service
```bash
# Terminal 2
cd borrow-service
mvn spring-boot:run

# Terminal 3
./test-borrow-service.sh
```

### 5. Start and Test Fine Service
```bash
# Terminal 2
cd fine-service
mvn spring-boot:run

# Terminal 3
./test-fine-service.sh
```

### 6. Start and Test Notification Service
```bash
# Terminal 2
cd notification-service
mvn spring-boot:run

# Terminal 3
./test-notification-service.sh
```

### 7. Start API Gateway and Run All Tests
```bash
# Terminal 2
cd api-gateway
mvn spring-boot:run

# Terminal 3
./test-all-services.sh
```

## Verify Eureka Registration

After each service starts, check:
- Open http://localhost:8761
- Look for service name in "Instances currently registered with Eureka"
- Status should be "UP"

Expected services:
- USER-SERVICE
- CATALOG-SERVICE
- BORROW-SERVICE
- FINE-SERVICE
- NOTIFICATION-SERVICE
- API-GATEWAY

## Test Results

All test scripts output:
- ✅ Green checkmarks for passed tests
- ❌ Red X for failed tests
- 🔵 Blue info for RabbitMQ/Redis monitoring

Check each service's output for detailed test results.

