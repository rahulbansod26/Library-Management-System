#!/bin/bash

# Complete Notification Service API Testing

BASE_URL="http://localhost:8085"
GATEWAY_URL="http://localhost:7000"
COLOR_GREEN='\033[0;32m'
COLOR_RED='\033[0;31m'
COLOR_YELLOW='\033[1;33m'
COLOR_BLUE='\033[0;34m'
COLOR_NC='\033[0m'

USER_ID="test-user-$(date +%s)"

echo "========================================="
echo "COMPREHENSIVE NOTIFICATION SERVICE API TESTING"
echo "========================================="
echo ""

# Function to test endpoint
test_api() {
    local method=$1
    local endpoint=$2
    local data=$3
    local description=$4
    local expected_code=${5:-200}
    
    echo -e "${COLOR_YELLOW}[TEST] ${description}${COLOR_NC}"
    echo "  ${method} ${endpoint}"
    
    if [ "$method" = "PUT" ]; then
        response=$(curl -s -w "\n%{http_code}" -X PUT "${BASE_URL}${endpoint}" \
            -H "Content-Type: application/json" \
            -d "${data}")
    else
        response=$(curl -s -w "\n%{http_code}" -X GET "${BASE_URL}${endpoint}")
    fi
    
    http_code=$(echo "$response" | tail -n1)
    body=$(echo "$response" | sed '$d')
    
    if [ "$http_code" -eq "$expected_code" ]; then
        echo -e "${COLOR_GREEN}✓ PASS (${http_code})${COLOR_NC}"
        echo "  Response: $body" | head -c 300
        echo ""
        echo "$body" > /tmp/last_response.json
        return 0
    else
        echo -e "${COLOR_RED}✗ FAIL (Expected ${expected_code}, Got ${http_code})${COLOR_NC}"
        echo "  Response: $body"
        return 1
    fi
}

# Check RabbitMQ queue
check_rabbitmq() {
    echo -e "${COLOR_BLUE}[RABBITMQ] Checking queue: $1${COLOR_NC}"
    curl -s -u guest:guest http://localhost:15672/api/queues 2>/dev/null | python3 -m json.tool 2>/dev/null | grep -A 5 "$1" || echo "  Queue info not available"
}

echo "========================================="
echo "PHASE 1: Notification Retrieval APIs"
echo "========================================="

# 1. Get all notifications for user
test_api "GET" "/api/notifications/user/${USER_ID}" "" "1.1 Get all notifications for user"

# 2. Get unread notifications
test_api "GET" "/api/notifications/user/${USER_ID}/unread" "" "1.2 Get unread notifications for user"

# 3. Get unread notification count
test_api "GET" "/api/notifications/user/${USER_ID}/unread/count" "" "1.3 Get unread notification count"

echo ""
echo -e "${COLOR_YELLOW}[NOTE] Notifications are created when events are published${COLOR_NC}"
echo -e "${COLOR_YELLOW}Trigger events from other services to see notifications appear${COLOR_NC}"
echo ""

# Wait for notifications to be created from other service events
sleep 5

# Check again after events
echo -e "${COLOR_YELLOW}[TEST] 1.4 Re-check notifications after events${COLOR_NC}"
NOTIFICATIONS=$(curl -s "${BASE_URL}/api/notifications/user/${USER_ID}")
NOTIFICATION_COUNT=$(echo "$NOTIFICATIONS" | grep -o '"id":"[^"]*' | wc -l)
echo "  Found $NOTIFICATION_COUNT notifications"

if [ ! -z "$NOTIFICATIONS" ] && [ "$NOTIFICATIONS" != "[]" ]; then
    NOTIFICATION_ID=$(echo "$NOTIFICATIONS" | grep -o '"id":"[^"]*' | head -1 | cut -d'"' -f4)
    
    # 4. Mark notification as read
    MARK_READ_DATA="{}"
    echo -e "${COLOR_YELLOW}[TEST] 1.5 Mark notification as read${COLOR_NC}"
    MARK_RESPONSE=$(curl -s -w "\n%{http_code}" -X PUT "${BASE_URL}/api/notifications/${NOTIFICATION_ID}/read" \
        -H "Content-Type: application/json" \
        -d "$MARK_READ_DATA")
    MARK_CODE=$(echo "$MARK_RESPONSE" | tail -n1)
    if [ "$MARK_CODE" -eq 200 ]; then
        echo -e "${COLOR_GREEN}✓ PASS - Notification marked as read${COLOR_NC}"
    else
        echo -e "${COLOR_RED}✗ FAIL - Could not mark as read (${MARK_CODE})${COLOR_NC}"
    fi
    echo ""
    
    # 5. Mark all notifications as read
    MARK_ALL_DATA="{}"
    echo -e "${COLOR_YELLOW}[TEST] 1.6 Mark all user notifications as read${COLOR_NC}"
    MARK_ALL_RESPONSE=$(curl -s -w "\n%{http_code}" -X PUT "${BASE_URL}/api/notifications/user/${USER_ID}/read-all" \
        -H "Content-Type: application/json" \
        -d "$MARK_ALL_DATA")
    MARK_ALL_CODE=$(echo "$MARK_ALL_RESPONSE" | tail -n1)
    if [ "$MARK_ALL_CODE" -eq 200 ]; then
        echo -e "${COLOR_GREEN}✓ PASS - All notifications marked as read${COLOR_NC}"
    else
        echo -e "${COLOR_RED}✗ FAIL - Could not mark all as read (${MARK_ALL_CODE})${COLOR_NC}"
    fi
    echo ""
fi

# Check RabbitMQ queues
echo ""
echo "========================================="
echo "PHASE 2: RabbitMQ Event Monitoring"
echo "========================================="

check_rabbitmq "user.events.q"
check_rabbitmq "borrow.events.q"
check_rabbitmq "fine.events.q"
check_rabbitmq "catalog.events.q"

echo ""
echo "========================================="
echo "PHASE 3: Gateway Routing Test"
echo "========================================="

# Test via Gateway
echo -e "${COLOR_YELLOW}[TEST] 3.1 Test get notifications via API Gateway${COLOR_NC}"
GATEWAY_RESPONSE=$(curl -s -w "\n%{http_code}" -X GET "${GATEWAY_URL}/api/notifications/user/${USER_ID}")
GATEWAY_CODE=$(echo "$GATEWAY_RESPONSE" | tail -n1)
if [ "$GATEWAY_CODE" -eq 200 ]; then
    echo -e "${COLOR_GREEN}✓ PASS - Gateway routing working${COLOR_NC}"
else
    echo -e "${COLOR_RED}✗ FAIL - Gateway routing failed (${GATEWAY_CODE})${COLOR_NC}"
fi
echo ""

echo ""
echo "========================================="
echo "NOTIFICATION SERVICE TESTING COMPLETE"
echo "========================================="
echo ""
echo -e "${COLOR_YELLOW}Note:${COLOR_NC} Notifications are created automatically when:"
echo "  - User registers"
echo "  - Book is borrowed/returned"
echo "  - Fine is updated"
echo "  - Payment is completed"
echo "  - Due date reminders are sent"

