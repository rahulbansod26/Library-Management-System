package com.hashedin.library.common.events;

public class BorrowRequestedEvent extends BaseEvent {
    private String userId;
    private String bookId;

    public BorrowRequestedEvent(){}
    public BorrowRequestedEvent(String userId, String bookId){
        this.userId = userId; this.bookId = bookId;
    }
    public String getUserId(){ return userId; }
    public String getBookId(){ return bookId; }
}
