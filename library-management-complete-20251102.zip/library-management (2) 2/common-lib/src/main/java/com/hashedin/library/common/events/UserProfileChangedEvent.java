
package com.hashedin.library.common.events;

public class UserProfileChangedEvent extends BaseEvent {
    private String userId;
    private String email;

    public UserProfileChangedEvent() {}
    public UserProfileChangedEvent(String userId, String email) {
        this.userId = userId; this.email = email;
    }
    public String getUserId() { return userId; }
    public String getEmail() { return email; }
}
