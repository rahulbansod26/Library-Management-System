package com.hashedin.library.common.events;

import java.math.BigDecimal;

public class FineUpdatedEvent extends BaseEvent {
    private String userId;
    private BigDecimal amount;
    private String borrowRecordId;

    public FineUpdatedEvent(){}
    public FineUpdatedEvent(String userId, BigDecimal amount){
        this.userId = userId; this.amount = amount;
    }
    public FineUpdatedEvent(String userId, BigDecimal amount, String borrowRecordId){
        this.userId = userId; this.amount = amount; this.borrowRecordId = borrowRecordId;
    }
    public String getUserId(){ return userId; }
    public void setUserId(String userId){ this.userId = userId; }
    public BigDecimal getAmount(){ return amount; }
    public void setAmount(BigDecimal amount){ this.amount = amount; }
    public String getBorrowRecordId(){ return borrowRecordId; }
    public void setBorrowRecordId(String borrowRecordId){ this.borrowRecordId = borrowRecordId; }
}
