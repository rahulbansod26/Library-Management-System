# Quick Start Guide

## Prerequisites Check

Before starting, ensure these are running:
```bash
# Check MySQL
mysql --version

# Check RabbitMQ
rabbitmqctl status

# Check Redis (optional)
redis-cli ping
```

## Option 1: Automated Startup (Recommended)

```bash
# Make scripts executable (if not already)
chmod +x start-all-services.sh stop-all-services.sh test-services.sh

# Start all services
./start-all-services.sh

# Wait for all services to start (takes ~2-3 minutes)

# Test all services
./test-services.sh

# Check Eureka dashboard
open http://localhost:8761

# Stop all services when done
./stop-all-services.sh
```

## Option 2: Manual Startup (Step by Step)

### Terminal 1: Eureka
```bash
cd eureka-service && mvn spring-boot:run
```
✅ Check: http://localhost:8761

### Terminal 2: User Service
```bash
cd user-service && mvn spring-boot:run
```
✅ Check Eureka: Look for USER-SERVICE
✅ Test: `curl http://localhost:8081/api/auth/login`

### Terminal 3: Catalog Service
```bash
cd catalog-service && mvn spring-boot:run
```
✅ Check Eureka: Look for CATALOG-SERVICE
✅ Test: `curl http://localhost:8082/api/books`

### Terminal 4: Borrow Service
```bash
cd borrow-service && mvn spring-boot:run
```
✅ Check Eureka: Look for BORROW-SERVICE
✅ Test: `curl http://localhost:8083/api/borrow/overdue`

### Terminal 5: Fine Service
```bash
cd fine-service && mvn spring-boot:run
```
✅ Check Eureka: Look for FINE-SERVICE
✅ Test: `curl -X POST http://localhost:8084/api/fines/calculate`

### Terminal 6: Notification Service
```bash
cd notification-service && mvn spring-boot:run
```
✅ Check Eureka: Look for NOTIFICATION-SERVICE
✅ Test: `curl http://localhost:8085/api/notifications/user/test`

### Terminal 7: API Gateway
```bash
cd api-gateway && mvn spring-boot:run
```
✅ Check Eureka: Look for API-GATEWAY
✅ Test: `curl http://localhost:7000/api/books`

## Verification Checklist

After starting all services, verify:

- [ ] Eureka Dashboard shows all 6 services registered
- [ ] Each service responds to direct port access
- [ ] API Gateway routes work correctly
- [ ] RabbitMQ queues are created
- [ ] Databases are created (auto-created by services)

## Common Issues

**Port already in use:**
```bash
lsof -i :PORT_NUMBER
kill -9 <PID>
```

**Service not registering with Eureka:**
- Wait 30-60 seconds
- Check service logs for errors
- Verify Eureka URL in application.yml

**Database connection error:**
- Verify MySQL is running
- Check username/password in application.yml
- Ensure database exists or auto-create is enabled

## Testing Flow

See `START_SERVICES.md` for complete testing scenarios including:
- User registration and login
- Book catalog management
- Book borrowing flow
- Fine calculation
- Payment processing
- Notification system

