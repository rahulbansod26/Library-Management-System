
package com.hashedin.library.fine.controller;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hashedin.library.fine.domain.Fine;
import com.hashedin.library.fine.domain.PaymentHistory;
import com.hashedin.library.fine.service.FineService;

@RestController
@RequestMapping("/api/fines")
public class FineController {
    private final FineService service;
    public FineController(FineService service){ this.service=service; }

    record AddFineRequest(BigDecimal amount) {}
    record PaymentRequest(BigDecimal amount, PaymentHistory.PaymentMethod paymentMethod) {}

    @PostMapping("/{userId}/add")
    public ResponseEntity<Fine> add(@PathVariable String userId, @RequestBody AddFineRequest req){
        service.addFine(userId, req.amount());
        return ResponseEntity.ok(service.getOrCreate(userId));
    }

    @GetMapping("/{userId}")
    public ResponseEntity<Fine> get(@PathVariable String userId){
        return ResponseEntity.ok(service.getOrCreate(userId));
    }

    @GetMapping("/{userId}/all")
    public ResponseEntity<List<Fine>> getAllFines(@PathVariable String userId){
        return ResponseEntity.ok(service.getFinesByUserId(userId));
    }

    @GetMapping("/{userId}/outstanding")
    public ResponseEntity<Map<String, BigDecimal>> getOutstanding(@PathVariable String userId){
        BigDecimal outstanding = service.getOutstandingFines(userId);
        return ResponseEntity.ok(Map.of("outstandingAmount", outstanding));
    }

    @PostMapping("/{userId}/pay/{fineId}")
    public ResponseEntity<Map<String,String>> pay(
            @PathVariable String userId, 
            @PathVariable String fineId,
            @RequestBody PaymentRequest req){
        service.processPaymentAsync(userId, fineId, req.amount(), req.paymentMethod());
        return ResponseEntity.ok(Map.of(
                "status","PROCESSING",
                "message","Payment is being processed asynchronously"
        ));
    }

    @GetMapping("/{fineId}/payments")
    public ResponseEntity<List<PaymentHistory>> getPaymentHistory(@PathVariable String fineId){
        return ResponseEntity.ok(service.getPaymentHistory(fineId));
    }

    @PostMapping("/calculate")
    public ResponseEntity<Map<String,String>> calculateFines(){
        service.scheduledFineCalc();
        return ResponseEntity.ok(Map.of("message","Fine calculation triggered"));
    }
}

