package com.hashedin.library.fine.domain;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.Instant;

@Entity
public class PaymentHistory {
    public enum PaymentMethod { CREDIT_CARD, DEBIT_CARD, PAYPAL, BANK_TRANSFER, CASH }
    public enum PaymentStatus { PENDING, COMPLETED, FAILED, REFUNDED }
    
    @Id @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    private String fineId;
    private BigDecimal amount;
    @Enumerated(EnumType.STRING)
    private PaymentMethod paymentMethod;
    private String transactionId;
    private Instant paymentDate = Instant.now();
    @Enumerated(EnumType.STRING)
    private PaymentStatus status = PaymentStatus.PENDING;
    private Instant createdAt = Instant.now();
    private String remarks;

    public String getId(){return id;}
    public String getFineId(){return fineId;} 
    public void setFineId(String fineId){this.fineId=fineId;}
    public BigDecimal getAmount(){return amount;} 
    public void setAmount(BigDecimal amount){this.amount=amount;}
    public PaymentMethod getPaymentMethod(){return paymentMethod;} 
    public void setPaymentMethod(PaymentMethod paymentMethod){this.paymentMethod=paymentMethod;}
    public String getTransactionId(){return transactionId;} 
    public void setTransactionId(String transactionId){this.transactionId=transactionId;}
    public Instant getPaymentDate(){return paymentDate;} 
    public void setPaymentDate(Instant paymentDate){this.paymentDate=paymentDate;}
    public PaymentStatus getStatus(){return status;} 
    public void setStatus(PaymentStatus status){this.status=status;}
    public Instant getCreatedAt(){return createdAt;}
    public String getRemarks(){return remarks;} 
    public void setRemarks(String remarks){this.remarks=remarks;}
}

