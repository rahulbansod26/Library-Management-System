
package com.hashedin.library.fine.repo;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hashedin.library.fine.domain.Fine;
public interface FineRepo extends JpaRepository<Fine, String> {
    Optional<Fine> findByBorrowRecordId(String borrowRecordId);
    List<Fine> findByUserId(String userId);
    List<Fine> findByUserIdOrderByCreatedAtDesc(String userId);
}
