package com.hashedin.library.fine.repo;

import com.hashedin.library.fine.domain.PaymentHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface PaymentHistoryRepo extends JpaRepository<PaymentHistory, String> {
    List<PaymentHistory> findByFineId(String fineId);
    Optional<PaymentHistory> findByTransactionId(String transactionId);
    List<PaymentHistory> findByFineIdOrderByPaymentDateDesc(String fineId);
}

