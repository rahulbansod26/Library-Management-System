package com.hashedin.library.fine.config;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.QueueBuilder;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.hashedin.library.common.events.RoutingKeys;

/**
 * Creates and binds the borrow.events.q queue for fine service to listen to borrow events
 */
@Configuration
public class BindingsConfig {

    @Bean
    public Queue borrowEventsQueue() {
        return QueueBuilder.nonDurable("borrow.events.q").autoDelete().build();
    }

    @Bean
    public Binding bindBookOverdue(@Qualifier("borrowEventsQueue") Queue q, TopicExchange libraryExchange) {
        return BindingBuilder.bind(q).to(libraryExchange).with(RoutingKeys.BOOK_OVERDUE);
    }
}

