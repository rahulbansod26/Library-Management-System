package com.hashedin.library.fine.listener;

import com.hashedin.library.common.events.BookOverdueEvent;
import com.hashedin.library.fine.client.BorrowServiceClient;
import com.hashedin.library.fine.service.FineService;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class FineEventListener {
    private final FineService fineService;
    private final BorrowServiceClient borrowServiceClient;

    public FineEventListener(FineService fineService, BorrowServiceClient borrowServiceClient) {
        this.fineService = fineService;
        this.borrowServiceClient = borrowServiceClient;
    }

    @RabbitListener(queues = "borrow.events.q")
    public void handleBookOverdue(BookOverdueEvent event) {
        // When a book becomes overdue, trigger fine calculation via scheduled task
        // The scheduled task will fetch all overdue records and calculate fines
        System.out.println("Book overdue event received for user: " + event.getUserId() + ", book: " + event.getBookId());
    }

    @RabbitListener(queues = "borrow.events.q")
    public void handleBookOverdueRecord(Map<String, Object> record) {
        // Handle when BorrowRecord is sent as Map in overdue event
        try {
            if (record != null && "OVERDUE".equals(record.get("status"))) {
                String userId = (String) record.get("userId");
                String borrowRecordId = (String) record.get("id");
                Object endDateObj = record.get("endDate");
                String endDateStr = endDateObj != null ? endDateObj.toString() : null;
                
                if (userId != null && borrowRecordId != null && endDateStr != null) {
                    fineService.calculateAndApplyFine(userId, borrowRecordId, endDateStr);
                }
            }
        } catch (Exception e) {
            System.err.println("Error handling overdue record: " + e.getMessage());
        }
    }
}

