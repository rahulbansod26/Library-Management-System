package com.hashedin.library.fine.client;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Map;

@Component
public class BorrowServiceClient {
    private final RestTemplate restTemplate;
    private static final String BORROW_SERVICE_NAME = "borrow-service";

    public BorrowServiceClient(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public List<Map<String, Object>> getOverdueRecords() {
        try {
            ResponseEntity<List<Map<String, Object>>> response = restTemplate.exchange(
                    "http://" + BORROW_SERVICE_NAME + "/api/borrow/overdue",
                    HttpMethod.GET,
                    null,
                    new ParameterizedTypeReference<List<Map<String, Object>>>() {}
            );
            List<Map<String, Object>> records = response.getBody();
            if (records != null) {
                // Convert LocalDate objects to strings for easier handling
                for (Map<String, Object> record : records) {
                    if (record.get("endDate") != null && !(record.get("endDate") instanceof String)) {
                        record.put("endDate", record.get("endDate").toString());
                    }
                    if (record.get("startDate") != null && !(record.get("startDate") instanceof String)) {
                        record.put("startDate", record.get("startDate").toString());
                    }
                }
            }
            return records != null ? records : List.of();
        } catch (Exception e) {
            // Log error and return empty list
            System.err.println("Error fetching overdue records: " + e.getMessage());
            return List.of();
        }
    }

    public Map<String, Object> getBorrowRecord(String recordId) {
        try {
            ResponseEntity<Map<String, Object>> response = restTemplate.exchange(
                    "http://" + BORROW_SERVICE_NAME + "/api/borrow/" + recordId,
                    HttpMethod.GET,
                    null,
                    new ParameterizedTypeReference<Map<String, Object>>() {}
            );
            return response.getBody();
        } catch (Exception e) {
            System.err.println("Error fetching borrow record: " + e.getMessage());
            return null;
        }
    }
}

