#!/bin/bash

# Complete Borrow Service API Testing

BASE_URL="http://localhost:8083"
GATEWAY_URL="http://localhost:7000"
CATALOG_URL="http://localhost:8082"
USER_URL="http://localhost:8081"
COLOR_GREEN='\033[0;32m'
COLOR_RED='\033[0;31m'
COLOR_YELLOW='\033[1;33m'
COLOR_BLUE='\033[0;34m'
COLOR_NC='\033[0m'

USER_ID=""
BOOK_ID=""
BORROW_RECORD_ID=""
BORROW_REQUEST_ID=""
TEST_USER_EMAIL="borrow_test_$(date +%s)@example.com"
USER_TOKEN=""

echo "========================================="
echo "COMPREHENSIVE BORROW SERVICE API TESTING"
echo "========================================="
echo ""

# Function to test endpoint
test_api() {
    local method=$1
    local endpoint=$2
    local data=$3
    local description=$4
    local expected_code=${5:-200}
    
    echo -e "${COLOR_YELLOW}[TEST] ${description}${COLOR_NC}"
    echo "  ${method} ${endpoint}"
    
    if [ "$method" = "POST" ]; then
        if [ -n "$data" ] && [ "$data" != "null" ]; then
            response=$(curl -s -w "\n%{http_code}" -X POST "${BASE_URL}${endpoint}" \
                -H "Content-Type: application/json" \
                -d "${data}")
        else
            response=$(curl -s -w "\n%{http_code}" -X POST "${BASE_URL}${endpoint}" \
                -H "Content-Type: application/json")
        fi
    elif [ "$method" = "PUT" ]; then
        response=$(curl -s -w "\n%{http_code}" -X PUT "${BASE_URL}${endpoint}" \
            -H "Content-Type: application/json" \
            -d "${data}")
    else
        response=$(curl -s -w "\n%{http_code}" -X GET "${BASE_URL}${endpoint}")
    fi
    
    http_code=$(echo "$response" | tail -n1)
    body=$(echo "$response" | sed '$d')
    
    if [ "$http_code" -eq "$expected_code" ]; then
        echo -e "${COLOR_GREEN}✓ PASS (${http_code})${COLOR_NC}"
        echo "  Response: $body" | head -c 300
        echo ""
        echo "$body" > /tmp/last_response.json
        return 0
    else
        echo -e "${COLOR_RED}✗ FAIL (Expected ${expected_code}, Got ${http_code})${COLOR_NC}"
        echo "  Response: $body"
        return 1
    fi
}

# Check RabbitMQ queue
check_rabbitmq() {
    echo -e "${COLOR_BLUE}[RABBITMQ] Checking queue: $1${COLOR_NC}"
    curl -s -u guest:guest http://localhost:15672/api/queues 2>/dev/null | python3 -m json.tool 2>/dev/null | grep -A 5 "$1" || echo "  Queue info not available"
}

# Check Redis cache
check_redis() {
    echo -e "${COLOR_BLUE}[REDIS] Checking key: $1${COLOR_NC}"
    redis-cli GET "$1" 2>/dev/null || echo "  Key not found or Redis not accessible"
}

echo "========================================="
echo "SETUP: Create User and Book"
echo "========================================="

# Create test user
echo -e "${COLOR_YELLOW}[SETUP] Creating test user${COLOR_NC}"
REGISTER_DATA="{\"name\":\"Borrow Test User\",\"email\":\"${TEST_USER_EMAIL}\",\"password\":\"password123\",\"role\":\"USER\"}"
USER_RESPONSE=$(curl -s -X POST "${USER_URL}/api/auth/register" \
    -H "Content-Type: application/json" \
    -d "$REGISTER_DATA")
USER_ID=$(echo "$USER_RESPONSE" | grep -o '"id":"[^"]*' | head -1 | cut -d'"' -f4)
echo "User ID: $USER_ID"

# Login to get token
LOGIN_DATA="{\"email\":\"${TEST_USER_EMAIL}\",\"password\":\"password123\"}"
LOGIN_RESPONSE=$(curl -s -X POST "${USER_URL}/api/auth/login" \
    -H "Content-Type: application/json" \
    -d "$LOGIN_DATA")
USER_TOKEN=$(echo "$LOGIN_RESPONSE" | grep -o '"token":"[^"]*' | cut -d'"' -f4)

# Create test book
echo -e "${COLOR_YELLOW}[SETUP] Creating test book${COLOR_NC}"
BOOK_ISBN="978-$(date +%s)"
ADD_BOOK_DATA="{\"title\":\"Test Book for Borrowing\",\"author\":\"Test Author\",\"genre\":\"Test\",\"isbn\":\"${BOOK_ISBN}\",\"quantity\":5,\"status\":\"AVAILABLE\"}"
BOOK_RESPONSE=$(curl -s -X POST "${CATALOG_URL}/api/books" \
    -H "Content-Type: application/json" \
    -d "$ADD_BOOK_DATA")
BOOK_ID=$(echo "$BOOK_RESPONSE" | grep -o '"id":"[^"]*' | head -1 | cut -d'"' -f4)
echo "Book ID: $BOOK_ID"
echo ""

echo "========================================="
echo "PHASE 1: Borrow Request Management"
echo "========================================="

# 1. Create borrow request
CREATE_REQUEST_DATA="{\"bookId\":\"${BOOK_ID}\",\"days\":14,\"reason\":\"For reading\"}"
test_api "POST" "/api/borrow/request" "$CREATE_REQUEST_DATA" "1.1 Create borrow request"
BORROW_REQUEST_ID=$(cat /tmp/last_response.json 2>/dev/null | grep -o '"id":"[^"]*' | head -1 | cut -d'"' -f4)
echo "Borrow Request ID: $BORROW_REQUEST_ID"

# 2. Get pending requests
test_api "GET" "/api/borrow/request/pending" "" "1.2 Get pending borrow requests"

# 3. Get user requests
test_api "GET" "/api/borrow/request/user/${USER_ID}" "" "1.3 Get user borrow requests"

# 4. Approve borrow request
APPROVE_DATA="{\"librarianId\":\"librarian-123\"}"
APPROVE_RESPONSE=$(curl -s -w "\n%{http_code}" -X POST "${BASE_URL}/api/borrow/request/${BORROW_REQUEST_ID}/approve" \
    -H "Content-Type: application/json" \
    -d "$APPROVE_DATA")
APPROVE_HTTP=$(echo "$APPROVE_RESPONSE" | tail -n1)
APPROVE_BODY=$(echo "$APPROVE_RESPONSE" | sed '$d')

if [ "$APPROVE_HTTP" -eq 200 ]; then
    echo -e "${COLOR_GREEN}✓ PASS (${APPROVE_HTTP}) - Approve borrow request${COLOR_NC}"
    BORROW_RECORD_ID=$(echo "$APPROVE_BODY" | grep -o '"id":"[^"]*' | head -1 | cut -d'"' -f4)
    echo "Borrow Record ID: $BORROW_RECORD_ID"
    echo "$APPROVE_BODY" > /tmp/last_response.json
else
    echo -e "${COLOR_YELLOW}⚠ WARN (${APPROVE_HTTP}) - Could not approve borrow request${COLOR_NC}"
    echo "  Response: $APPROVE_BODY"
    BORROW_RECORD_ID=""
fi

# Check RabbitMQ for borrow events
sleep 2
check_rabbitmq "borrow.events.q"

echo ""
echo "========================================="
echo "PHASE 2: Borrow Management APIs"
echo "========================================="

# 5. Get active borrows for user
test_api "GET" "/api/borrow/user/${USER_ID}" "" "2.1 Get active borrows for user"

# Check Redis cache
check_redis "active_loans:${USER_ID}"

# 6. Get borrowing history
test_api "GET" "/api/borrow/user/${USER_ID}/history" "" "2.2 Get borrowing history"

# 7. Get borrow record by ID
if [ -n "$BORROW_RECORD_ID" ]; then
    test_api "GET" "/api/borrow/${BORROW_RECORD_ID}" "" "2.3 Get borrow record by ID"
else
    echo -e "${COLOR_YELLOW}[TEST] 2.3 Get borrow record by ID${COLOR_NC}"
    echo -e "${COLOR_YELLOW}⚠ SKIP - No borrow record ID available${COLOR_NC}"
fi

# 8. Get all active borrows
test_api "GET" "/api/borrow/active/all" "" "2.4 Get all active borrows"

# 9. Get overdue records
test_api "GET" "/api/borrow/overdue" "" "2.5 Get overdue records"

# 10. Get borrows due in N days
test_api "GET" "/api/borrow/due-in-days/7" "" "2.6 Get borrows due in 7 days"

# 11. Return book (use user-id-from-token since that's what the controller sets)
if [ -n "$BORROW_RECORD_ID" ]; then
    RETURN_DATA="{\"userId\":\"user-id-from-token\"}"
    test_api "POST" "/api/borrow/return/${BORROW_RECORD_ID}" "$RETURN_DATA" "2.7 Return book"
else
    echo -e "${COLOR_YELLOW}[TEST] 2.7 Return book${COLOR_NC}"
    echo -e "${COLOR_YELLOW}⚠ SKIP - No borrow record ID available${COLOR_NC}"
fi

# Check RabbitMQ for return event
sleep 2
check_rabbitmq "borrow.events.q"

# 12. Mark book as lost (create a new book for this test to avoid conflicts)
echo -e "${COLOR_YELLOW}[SETUP] Creating another book for lost book test${COLOR_NC}"
LOST_BOOK_ISBN="978-lost-$(date +%s)"
LOST_BOOK_DATA="{\"title\":\"Lost Book Test\",\"author\":\"Test Author\",\"genre\":\"Test\",\"isbn\":\"${LOST_BOOK_ISBN}\",\"quantity\":5,\"status\":\"AVAILABLE\"}"
LOST_BOOK_RESPONSE=$(curl -s -X POST "${CATALOG_URL}/api/books" \
    -H "Content-Type: application/json" \
    -d "$LOST_BOOK_DATA")
LOST_BOOK_ID=$(echo "$LOST_BOOK_RESPONSE" | grep -o '"id":"[^"]*' | head -1 | cut -d'"' -f4)

if [ -n "$LOST_BOOK_ID" ]; then
    ANOTHER_REQUEST_DATA="{\"bookId\":\"${LOST_BOOK_ID}\",\"days\":14,\"reason\":\"For lost test\"}"
    ANOTHER_REQUEST_RESPONSE=$(curl -s -w "\n%{http_code}" -X POST "${BASE_URL}/api/borrow/request" \
        -H "Content-Type: application/json" \
        -d "$ANOTHER_REQUEST_DATA")
    ANOTHER_REQUEST_HTTP=$(echo "$ANOTHER_REQUEST_RESPONSE" | tail -n1)
    ANOTHER_REQUEST_BODY=$(echo "$ANOTHER_REQUEST_RESPONSE" | sed '$d')
    ANOTHER_REQUEST_ID=$(echo "$ANOTHER_REQUEST_BODY" | grep -o '"id":"[^"]*' | head -1 | cut -d'"' -f4)
    
    if [ -n "$ANOTHER_REQUEST_ID" ] && [ "$ANOTHER_REQUEST_HTTP" -eq 200 ]; then
        APPROVE_ANOTHER_DATA="{\"librarianId\":\"librarian-123\"}"
        ANOTHER_BORROW_RESPONSE=$(curl -s -w "\n%{http_code}" -X POST "${BASE_URL}/api/borrow/request/${ANOTHER_REQUEST_ID}/approve" \
            -H "Content-Type: application/json" \
            -d "$APPROVE_ANOTHER_DATA")
        ANOTHER_BORROW_HTTP=$(echo "$ANOTHER_BORROW_RESPONSE" | tail -n1)
        ANOTHER_BORROW_BODY=$(echo "$ANOTHER_BORROW_RESPONSE" | sed '$d')
        ANOTHER_BORROW_ID=$(echo "$ANOTHER_BORROW_BODY" | grep -o '"id":"[^"]*' | head -1 | cut -d'"' -f4)
        
        if [ -n "$ANOTHER_BORROW_ID" ] && [ "$ANOTHER_BORROW_HTTP" -eq 200 ]; then
            # Mark as lost (use user-id-from-token since that's what the controller sets)
            LOST_DATA="{\"userId\":\"user-id-from-token\"}"
            test_api "POST" "/api/borrow/${ANOTHER_BORROW_ID}/lost" "$LOST_DATA" "2.8 Mark book as lost"
        else
            echo -e "${COLOR_YELLOW}[TEST] 2.8 Mark book as lost${COLOR_NC}"
            echo -e "${COLOR_YELLOW}⚠ SKIP - Could not approve borrow request (may have hit borrow limit)${COLOR_NC}"
        fi
    else
        echo -e "${COLOR_YELLOW}[TEST] 2.8 Mark book as lost${COLOR_NC}"
        echo -e "${COLOR_YELLOW}⚠ SKIP - Could not create borrow request${COLOR_NC}"
    fi
else
    echo -e "${COLOR_YELLOW}[TEST] 2.8 Mark book as lost${COLOR_NC}"
    echo -e "${COLOR_YELLOW}⚠ SKIP - Could not create test book${COLOR_NC}"
fi

# Check RabbitMQ for lost book event
sleep 2
check_rabbitmq "borrow.events.q"

echo ""
echo "========================================="
echo "PHASE 3: Gateway Routing Test"
echo "========================================="

# Test via Gateway
echo -e "${COLOR_YELLOW}[TEST] 3.1 Test get overdue via API Gateway${COLOR_NC}"
GATEWAY_RESPONSE=$(curl -s -w "\n%{http_code}" -X GET "${GATEWAY_URL}/api/borrow/overdue")
GATEWAY_CODE=$(echo "$GATEWAY_RESPONSE" | tail -n1)
if [ "$GATEWAY_CODE" -eq 200 ]; then
    echo -e "${COLOR_GREEN}✓ PASS - Gateway routing working${COLOR_NC}"
else
    echo -e "${COLOR_RED}✗ FAIL - Gateway routing failed (${GATEWAY_CODE})${COLOR_NC}"
fi
echo ""

echo ""
echo "========================================="
echo "BORROW SERVICE TESTING COMPLETE"
echo "========================================="

