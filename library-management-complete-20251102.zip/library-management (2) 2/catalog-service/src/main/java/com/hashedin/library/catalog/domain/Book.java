
package com.hashedin.library.catalog.domain;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
public class Book {
    public enum Status { AVAILABLE, BORROWED, RESERVED, REMOVED }
    @Id @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    @Column(nullable=false) private String title;
    private String author;
    private String genre;
    @Column(unique = true) private String isbn;
    private String publisher;
    private Integer publicationYear;
    private String description;
    @Enumerated(EnumType.STRING) private Status status = Status.AVAILABLE;
    private int quantity = 1;
    private Instant createdAt = Instant.now();
    private Instant updatedAt = Instant.now();

    @PreUpdate
    protected void onUpdate() {
        updatedAt = Instant.now();
    }

    public String getId(){return id;}
    public String getTitle(){return title;} public void setTitle(String t){this.title=t;}
    public String getAuthor(){return author;} public void setAuthor(String a){this.author=a;}
    public String getGenre(){return genre;} public void setGenre(String g){this.genre=g;}
    public String getIsbn(){return isbn;} public void setIsbn(String i){this.isbn=i;}
    public String getPublisher(){return publisher;} public void setPublisher(String p){this.publisher=p;}
    public Integer getPublicationYear(){return publicationYear;} public void setPublicationYear(Integer y){this.publicationYear=y;}
    public String getDescription(){return description;} public void setDescription(String d){this.description=d;}
    public Status getStatus(){return status;} public void setStatus(Status s){this.status=s;}
    public int getQuantity(){return quantity;} public void setQuantity(int q){this.quantity=q;}
    public Instant getCreatedAt(){return createdAt;}
    public Instant getUpdatedAt(){return updatedAt;}
}
