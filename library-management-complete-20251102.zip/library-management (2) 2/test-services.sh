#!/bin/bash

# Library Management System - Service Testing Script

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}Library Management System - Testing${NC}"
echo -e "${GREEN}========================================${NC}"

# Test Eureka
echo -e "\n${YELLOW}[1] Testing Eureka Service Discovery...${NC}"
if curl -s http://localhost:8761 > /dev/null; then
    echo -e "${GREEN}✓ Eureka is running${NC}"
    echo "Registered services:"
    curl -s http://localhost:8761/eureka/apps | grep -o '<name>[^<]*</name>' | sed 's/<name>//;s/<\/name>//' | sort -u
else
    echo -e "${RED}✗ Eureka is not responding${NC}"
fi

# Test User Service
echo -e "\n${YELLOW}[2] Testing User Service...${NC}"
if curl -s http://localhost:8081/actuator/health > /dev/null 2>&1; then
    echo -e "${GREEN}✓ User Service is running${NC}"
else
    echo -e "${YELLOW}⚠ User Service health endpoint not available, trying direct endpoint...${NC}"
    if curl -s http://localhost:8081/api/auth/login > /dev/null 2>&1; then
        echo -e "${GREEN}✓ User Service is responding${NC}"
    else
        echo -e "${RED}✗ User Service is not responding${NC}"
    fi
fi

# Test Catalog Service
echo -e "\n${YELLOW}[3] Testing Catalog Service...${NC}"
if curl -s http://localhost:8082/api/books > /dev/null 2>&1; then
    echo -e "${GREEN}✓ Catalog Service is running${NC}"
    BOOK_COUNT=$(curl -s http://localhost:8082/api/books | jq '. | length' 2>/dev/null || echo "0")
    echo "  Books in catalog: $BOOK_COUNT"
else
    echo -e "${RED}✗ Catalog Service is not responding${NC}"
fi

# Test Borrow Service
echo -e "\n${YELLOW}[4] Testing Borrow Service...${NC}"
if curl -s http://localhost:8083/api/borrow/overdue > /dev/null 2>&1; then
    echo -e "${GREEN}✓ Borrow Service is running${NC}"
    OVERDUE_COUNT=$(curl -s http://localhost:8083/api/borrow/overdue | jq '. | length' 2>/dev/null || echo "0")
    echo "  Overdue records: $OVERDUE_COUNT"
else
    echo -e "${RED}✗ Borrow Service is not responding${NC}"
fi

# Test Fine Service
echo -e "\n${YELLOW}[5] Testing Fine Service...${NC}"
if curl -s -X POST http://localhost:8084/api/fines/calculate > /dev/null 2>&1; then
    echo -e "${GREEN}✓ Fine Service is running${NC}"
else
    echo -e "${RED}✗ Fine Service is not responding${NC}"
fi

# Test Notification Service
echo -e "\n${YELLOW}[6] Testing Notification Service...${NC}"
if curl -s http://localhost:8085/api/notifications/user/test-user-id > /dev/null 2>&1; then
    echo -e "${GREEN}✓ Notification Service is running${NC}"
else
    echo -e "${RED}✗ Notification Service is not responding${NC}"
fi

# Test API Gateway
echo -e "\n${YELLOW}[7] Testing API Gateway...${NC}"
if curl -s http://localhost:7000 > /dev/null 2>&1; then
    echo -e "${GREEN}✓ API Gateway is running${NC}"
    echo "  Testing routes:"
    
    # Test User Service route
    if curl -s http://localhost:7000/api/auth/login > /dev/null 2>&1; then
        echo -e "  ${GREEN}✓ /api/auth/** route working${NC}"
    else
        echo -e "  ${RED}✗ /api/auth/** route not working${NC}"
    fi
    
    # Test Catalog Service route
    if curl -s http://localhost:7000/api/books > /dev/null 2>&1; then
        echo -e "  ${GREEN}✓ /api/books/** route working${NC}"
    else
        echo -e "  ${RED}✗ /api/books/** route not working${NC}"
    fi
else
    echo -e "${RED}✗ API Gateway is not responding${NC}"
fi

echo -e "\n${GREEN}========================================${NC}"
echo -e "${GREEN}Testing Complete${NC}"
echo -e "${GREEN}========================================${NC}"

