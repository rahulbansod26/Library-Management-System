package com.hashedin.library.notification.domain;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
public class Notification {
    @Id @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    private String userId;
    private String type;
    private String title;
    @Column(length = 2000)
    private String message;
    private boolean isRead = false;
    private Instant sentAt = Instant.now();
    private Instant createdAt = Instant.now();

    public String getId(){return id;}
    public String getUserId(){return userId;} 
    public void setUserId(String userId){this.userId=userId;}
    public String getType(){return type;} 
    public void setType(String type){this.type=type;}
    public String getTitle(){return title;} 
    public void setTitle(String title){this.title=title;}
    public String getMessage(){return message;} 
    public void setMessage(String message){this.message=message;}
    public boolean isRead(){return isRead;} 
    public void setRead(boolean read){this.isRead=read;}
    public Instant getSentAt(){return sentAt;} 
    public void setSentAt(Instant sentAt){this.sentAt=sentAt;}
    public Instant getCreatedAt(){return createdAt;}
}

