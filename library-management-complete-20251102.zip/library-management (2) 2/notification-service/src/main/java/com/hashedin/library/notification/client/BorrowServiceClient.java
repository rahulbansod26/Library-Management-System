package com.hashedin.library.notification.client;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Map;

@Component
public class BorrowServiceClient {
    private final RestTemplate restTemplate;
    private static final String BORROW_SERVICE_NAME = "borrow-service";

    public BorrowServiceClient(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public List<Map<String, Object>> getActiveBorrows() {
        try {
            ResponseEntity<List<Map<String, Object>>> response = restTemplate.exchange(
                    "http://" + BORROW_SERVICE_NAME + "/api/borrow/active/all",
                    HttpMethod.GET,
                    null,
                    new ParameterizedTypeReference<List<Map<String, Object>>>() {}
            );
            List<Map<String, Object>> records = response.getBody();
            if (records != null) {
                // Convert LocalDate objects to strings for easier handling
                for (Map<String, Object> record : records) {
                    if (record.get("endDate") != null && !(record.get("endDate") instanceof String)) {
                        record.put("endDate", record.get("endDate").toString());
                    }
                    if (record.get("startDate") != null && !(record.get("startDate") instanceof String)) {
                        record.put("startDate", record.get("startDate").toString());
                    }
                }
            }
            return records != null ? records : List.of();
        } catch (Exception e) {
            System.err.println("Error fetching active borrows: " + e.getMessage());
            return List.of();
        }
    }

    public List<Map<String, Object>> getBorrowsDueInDays(int days) {
        try {
            ResponseEntity<List<Map<String, Object>>> response = restTemplate.exchange(
                    "http://" + BORROW_SERVICE_NAME + "/api/borrow/due-in-days/" + days,
                    HttpMethod.GET,
                    null,
                    new ParameterizedTypeReference<List<Map<String, Object>>>() {}
            );
            List<Map<String, Object>> records = response.getBody();
            if (records != null) {
                for (Map<String, Object> record : records) {
                    if (record.get("endDate") != null && !(record.get("endDate") instanceof String)) {
                        record.put("endDate", record.get("endDate").toString());
                    }
                    if (record.get("startDate") != null && !(record.get("startDate") instanceof String)) {
                        record.put("startDate", record.get("startDate").toString());
                    }
                }
            }
            return records != null ? records : List.of();
        } catch (Exception e) {
            System.err.println("Error fetching borrows due in " + days + " days: " + e.getMessage());
            return List.of();
        }
    }
}

