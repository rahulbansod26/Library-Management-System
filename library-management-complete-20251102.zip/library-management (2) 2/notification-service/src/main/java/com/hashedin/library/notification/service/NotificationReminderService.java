package com.hashedin.library.notification.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hashedin.library.notification.client.BorrowServiceClient;
import com.hashedin.library.notification.domain.Notification;
import com.hashedin.library.notification.repo.NotificationRepo;

@Service
public class NotificationReminderService {

    @Autowired
    private BorrowServiceClient borrowServiceClient;

    @Autowired
    private NotificationRepo notificationRepo;

    // Send reminders 3 days before due date - runs daily at 9 AM
    @Scheduled(cron = "0 0 9 * * *")
    @Async
    public void sendDueDateReminders() {
        try {
            System.out.println("[SCHEDULED] Checking for books due in 3 days...");
            List<Map<String, Object>> borrowsDueIn3Days = borrowServiceClient.getBorrowsDueInDays(3);
            
            for (Map<String, Object> borrow : borrowsDueIn3Days) {
                String userId = (String) borrow.get("userId");
                String bookId = (String) borrow.get("bookId");
                String endDateStr = borrow.get("endDate") != null ? borrow.get("endDate").toString() : null;
                
                if (userId != null && bookId != null && endDateStr != null) {
                    sendDueDateReminder(userId, bookId, endDateStr, 3);
                }
            }
            
            System.out.println("[SCHEDULED] Sent " + borrowsDueIn3Days.size() + " due date reminders (3 days)");
        } catch (Exception e) {
            System.err.println("[ERROR] Failed to send due date reminders: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Send reminders 1 day before due date - runs daily at 9 AM
    @Scheduled(cron = "0 0 9 * * *")
    @Async
    public void sendFinalDueDateReminders() {
        try {
            System.out.println("[SCHEDULED] Checking for books due tomorrow...");
            List<Map<String, Object>> borrowsDueTomorrow = borrowServiceClient.getBorrowsDueInDays(1);
            
            for (Map<String, Object> borrow : borrowsDueTomorrow) {
                String userId = (String) borrow.get("userId");
                String bookId = (String) borrow.get("bookId");
                String endDateStr = borrow.get("endDate") != null ? borrow.get("endDate").toString() : null;
                
                if (userId != null && bookId != null && endDateStr != null) {
                    sendDueDateReminder(userId, bookId, endDateStr, 1);
                }
            }
            
            System.out.println("[SCHEDULED] Sent " + borrowsDueTomorrow.size() + " final due date reminders (1 day)");
        } catch (Exception e) {
            System.err.println("[ERROR] Failed to send final due date reminders: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Send batch reminders for all active borrows - runs daily at 10 AM
    @Scheduled(cron = "0 0 10 * * *")
    @Async
    public void sendBatchDueDateReminders() {
        try {
            System.out.println("[SCHEDULED] Sending batch due date reminders...");
            List<Map<String, Object>> activeBorrows = borrowServiceClient.getActiveBorrows();
            
            int reminderCount = 0;
            LocalDate today = LocalDate.now();
            
            for (Map<String, Object> borrow : activeBorrows) {
                String userId = (String) borrow.get("userId");
                String bookId = (String) borrow.get("bookId");
                String endDateStr = borrow.get("endDate") != null ? borrow.get("endDate").toString() : null;
                
                if (userId != null && bookId != null && endDateStr != null) {
                    try {
                        LocalDate endDate = LocalDate.parse(endDateStr);
                        long daysUntilDue = java.time.temporal.ChronoUnit.DAYS.between(today, endDate);
                        
                        // Send reminder if due in 7 days or less (but not overdue)
                        if (daysUntilDue >= 0 && daysUntilDue <= 7) {
                            sendDueDateReminder(userId, bookId, endDateStr, (int) daysUntilDue);
                            reminderCount++;
                        }
                    } catch (Exception e) {
                        System.err.println("Error processing borrow record: " + e.getMessage());
                    }
                }
            }
            
            System.out.println("[SCHEDULED] Sent " + reminderCount + " batch due date reminders");
        } catch (Exception e) {
            System.err.println("[ERROR] Failed to send batch due date reminders: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Transactional
    private void sendDueDateReminder(String userId, String bookId, String endDateStr, int daysUntilDue) {
        try {
            String subject;
            String message;
            String title;
            
            if (daysUntilDue == 1) {
                subject = "Final Reminder: Book Due Tomorrow";
                title = "Book Due Tomorrow";
                message = "REMINDER: Your borrowed book is due TOMORROW!\n\n" +
                        "Book ID: " + bookId + "\n" +
                        "Due Date: " + endDateStr + "\n\n" +
                        "Please return the book on or before the due date to avoid fines.\n\n" +
                        "Best regards,\n" +
                        "Library Management Team";
            } else if (daysUntilDue == 0) {
                subject = "Urgent: Book Due Today";
                title = "Book Due Today";
                message = "URGENT: Your borrowed book is due TODAY!\n\n" +
                        "Book ID: " + bookId + "\n" +
                        "Due Date: " + endDateStr + "\n\n" +
                        "Please return the book today to avoid fines.\n\n" +
                        "Best regards,\n" +
                        "Library Management Team";
            } else {
                subject = "Reminder: Book Due in " + daysUntilDue + " Days";
                title = "Book Due in " + daysUntilDue + " Days";
                message = "This is a friendly reminder that your borrowed book will be due soon.\n\n" +
                        "Book ID: " + bookId + "\n" +
                        "Due Date: " + endDateStr + "\n" +
                        "Days Remaining: " + daysUntilDue + "\n\n" +
                        "Please return the book by the due date to avoid fines.\n\n" +
                        "Best regards,\n" +
                        "Library Management Team";
            }
            
            // Store notification
            Notification notification = new Notification();
            notification.setUserId(userId);
            notification.setType("DUE_DATE_REMINDER");
            notification.setTitle(title);
            notification.setMessage(message);
            notificationRepo.save(notification);
            
            System.out.println("[REMINDER SENT] " + title + " for user " + userId + ", book " + bookId);
        } catch (Exception e) {
            System.err.println("[ERROR] Failed to send reminder for user " + userId + ", book " + bookId + ": " + e.getMessage());
        }
    }
}

