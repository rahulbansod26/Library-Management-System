#!/bin/bash

# Complete Fine Service API Testing

BASE_URL="http://localhost:8084"
GATEWAY_URL="http://localhost:7000"
BORROW_URL="http://localhost:8083"
COLOR_GREEN='\033[0;32m'
COLOR_RED='\033[0;31m'
COLOR_YELLOW='\033[1;33m'
COLOR_BLUE='\033[0;34m'
COLOR_NC='\033[0m'

USER_ID=""
FINE_ID=""

echo "========================================="
echo "COMPREHENSIVE FINE SERVICE API TESTING"
echo "========================================="
echo ""

# Function to test endpoint
test_api() {
    local method=$1
    local endpoint=$2
    local data=$3
    local description=$4
    local expected_code=${5:-200}
    
    echo -e "${COLOR_YELLOW}[TEST] ${description}${COLOR_NC}"
    echo "  ${method} ${endpoint}"
    
    if [ "$method" = "POST" ]; then
        response=$(curl -s -w "\n%{http_code}" -X POST "${BASE_URL}${endpoint}" \
            -H "Content-Type: application/json" \
            -d "${data}")
    else
        response=$(curl -s -w "\n%{http_code}" -X GET "${BASE_URL}${endpoint}")
    fi
    
    http_code=$(echo "$response" | tail -n1)
    body=$(echo "$response" | sed '$d')
    
    if [ "$http_code" -eq "$expected_code" ]; then
        echo -e "${COLOR_GREEN}✓ PASS (${http_code})${COLOR_NC}"
        echo "  Response: $body" | head -c 300
        echo ""
        echo "$body" > /tmp/last_response.json
        return 0
    else
        echo -e "${COLOR_RED}✗ FAIL (Expected ${expected_code}, Got ${http_code})${COLOR_NC}"
        echo "  Response: $body"
        return 1
    fi
}

# Check RabbitMQ queue
check_rabbitmq() {
    echo -e "${COLOR_BLUE}[RABBITMQ] Checking queue: $1${COLOR_NC}"
    curl -s -u guest:guest http://localhost:15672/api/queues 2>/dev/null | python3 -m json.tool 2>/dev/null | grep -A 5 "$1" || echo "  Queue info not available"
}

echo "========================================="
echo "SETUP: Get User ID from Borrow Service"
echo "========================================="

# Get a user ID from borrow service (use first active borrow if exists)
ACTIVE_BORROWS=$(curl -s "${BORROW_URL}/api/borrow/active/all")
USER_ID=$(echo "$ACTIVE_BORROWS" | grep -o '"userId":"[^"]*' | head -1 | cut -d'"' -f4)

if [ -z "$USER_ID" ]; then
    echo -e "${COLOR_YELLOW}No active borrows found. Creating test scenario...${COLOR_NC}"
    USER_ID="test-user-id-$(date +%s)"
fi

echo "Using User ID: $USER_ID"
echo ""

echo "========================================="
echo "PHASE 1: Fine Management APIs"
echo "========================================="

# 1. Get user's fine
test_api "GET" "/api/fines/${USER_ID}" "" "1.1 Get user's fine"

# 2. Get all fines for user
test_api "GET" "/api/fines/${USER_ID}/all" "" "1.2 Get all fines for user"

# 3. Get outstanding fines
test_api "GET" "/api/fines/${USER_ID}/outstanding" "" "1.3 Get outstanding fine amount"

# 4. Manually add fine
ADD_FINE_DATA="{\"amount\":50.00}"
test_api "POST" "/api/fines/${USER_ID}/add" "$ADD_FINE_DATA" "1.4 Manually add fine"
FINE_ID=$(cat /tmp/last_response.json 2>/dev/null | grep -o '"id":"[^"]*' | head -1 | cut -d'"' -f4)
echo "Fine ID: $FINE_ID"

# Check RabbitMQ for fine updated event
sleep 2
check_rabbitmq "fine.events.q"

# 5. Process payment
PAYMENT_DATA="{\"amount\":25.00,\"paymentMethod\":\"CREDIT_CARD\"}"
test_api "POST" "/api/fines/${USER_ID}/pay/${FINE_ID}" "$PAYMENT_DATA" "1.5 Process payment (async)"

# Wait for async processing
sleep 3

# Check RabbitMQ for payment completed event
check_rabbitmq "fine.events.q"

# 6. Get payment history
test_api "GET" "/api/fines/${FINE_ID}/payments" "" "1.6 Get payment history for fine"

# 7. Get updated outstanding fines
test_api "GET" "/api/fines/${USER_ID}/outstanding" "" "1.7 Get updated outstanding fine amount"

# 8. Manually trigger fine calculation
test_api "POST" "/api/fines/calculate" "" "1.8 Manually trigger fine calculation"

# Check RabbitMQ after calculation
sleep 2
check_rabbitmq "fine.events.q"

echo ""
echo "========================================="
echo "PHASE 2: Gateway Routing Test"
echo "========================================="

# Test via Gateway
echo -e "${COLOR_YELLOW}[TEST] 2.1 Test get outstanding fines via API Gateway${COLOR_NC}"
GATEWAY_RESPONSE=$(curl -s -w "\n%{http_code}" -X GET "${GATEWAY_URL}/api/fines/${USER_ID}/outstanding")
GATEWAY_CODE=$(echo "$GATEWAY_RESPONSE" | tail -n1)
if [ "$GATEWAY_CODE" -eq 200 ]; then
    echo -e "${COLOR_GREEN}✓ PASS - Gateway routing working${COLOR_NC}"
else
    echo -e "${COLOR_RED}✗ FAIL - Gateway routing failed (${GATEWAY_CODE})${COLOR_NC}"
fi
echo ""

echo ""
echo "========================================="
echo "FINE SERVICE TESTING COMPLETE"
echo "========================================="

