# Library Management System - API Collection

This directory contains a comprehensive Postman collection for all API endpoints in the Library Management System.

## Files

- **Library-Management-API.postman_collection.json** - Complete Postman collection with all API endpoints

## Import Instructions

### Option 1: Import into Postman
1. Open Postman application
2. Click **Import** button (top left)
3. Select **File** tab
4. Choose `Library-Management-API.postman_collection.json`
5. Click **Import**

### Option 2: Import into Postman Web
1. Go to [Postman Web](https://web.postman.co/)
2. Click **Import** button
3. Upload the `Library-Management-API.postman_collection.json` file

## Environment Setup

The collection uses a variable `base_url` which is set to:
- **Default**: `http://localhost:7000` (API Gateway)

You can modify this variable:
- **API Gateway**: `http://localhost:7000`
- **Direct Service Access**: 
  - User Service: `http://localhost:8081`
  - Catalog Service: `http://localhost:8082`
  - Borrow Service: `http://localhost:8083`
  - Fine Service: `http://localhost:8084`
  - Notification Service: `http://localhost:8085`

## Collection Structure

The collection is organized by service:

### 1. User Service
- **Authentication**
  - Register User
  - Login (JWT)
  - Simple Login
  - Forgot Password
  - Reset Password
- **Profile**
  - Get Profile by Email
  - Update Profile

### 2. Catalog Service
- Get All Books
- Get Book by ID
- Get Book by ISBN
- Get Books by Author
- Get Books by Genre
- Search Books
- Add Book
- Update Book
- Update Book Status
- Delete Book

### 3. Borrow Service
- **Borrow Requests**
  - Create Borrow Request
  - Get Pending Requests
  - Get User Requests
  - Approve Borrow Request
  - Reject Borrow Request
- **Borrow Management**
  - Borrow Book (Direct)
  - Get Active Borrows for User
  - Get Borrowing History
  - Get Borrow Record by ID
  - Get All Active Borrows
  - Get Overdue Records
  - Get Borrows Due in N Days
  - Return Book
  - Mark Book as Lost

### 4. Fine Service
- Get User Fine
- Get All Fines for User
- Get Outstanding Fine Amount
- Manually Add Fine
- Process Payment
- Get Payment History
- Trigger Fine Calculation

### 5. Notification Service
- Get All Notifications for User
- Get Unread Notifications
- Get Unread Notification Count
- Mark Notification as Read
- Mark All Notifications as Read

## Using the Collection

1. **Update Variables**: Replace placeholder values like `:userId`, `:bookId`, `:id` with actual IDs from your system
2. **Authentication**: For endpoints that require JWT tokens:
   - First call the Login endpoint to get a token
   - Copy the token from the response
   - Add it as a Bearer token in the Authorization header for subsequent requests
3. **Test Workflows**: The collection supports end-to-end workflows:
   - Register → Login → Borrow Book → Return Book
   - Create Book → Borrow Request → Approve → Return
   - Borrow → Overdue → Fine Calculation → Payment

## Example Workflow

### Complete Book Borrowing Flow

1. **Register User**
   ```
   POST /api/auth/register
   {
     "email": "test@example.com",
     "name": "Test User",
     "password": "password123",
     "roles": ["USER"]
   }
   ```

2. **Login**
   ```
   POST /api/auth/login
   {
     "email": "test@example.com",
     "password": "password123"
   }
   ```
   Save the token from response

3. **Add Book** (as Librarian)
   ```
   POST /api/books
   {
     "title": "Test Book",
     "author": "Test Author",
     "isbn": "978-1234567890",
     "quantity": 5,
     "status": "AVAILABLE"
   }
   ```
   Save the book ID from response

4. **Create Borrow Request**
   ```
   POST /api/borrow/request
   {
     "bookId": "<book-id-from-step-3>",
     "days": 14,
     "reason": "For reading"
   }
   ```
   Save the request ID

5. **Approve Request** (as Librarian)
   ```
   POST /api/borrow/request/<request-id>/approve
   {
     "librarianId": "librarian-123"
   }
   ```

6. **Return Book**
   ```
   POST /api/borrow/return/<record-id>
   {
     "userId": "<user-id-from-step-1>"
   }
   ```

## Notes

- All endpoints are accessible through the API Gateway at `http://localhost:7000`
- Replace all placeholder values (like `:userId`, `:bookId`) with actual values
- Payment methods: `CREDIT_CARD`, `DEBIT_CARD`, `PAYPAL`, `CASH`
- Book status: `AVAILABLE`, `BORROWED`, `REMOVED`
- Fine payment status: `PROCESSING`, `COMPLETED`, `FAILED`

## Testing

After importing the collection, you can:
- Run individual requests
- Create test scripts for validation
- Set up automated test suites
- Share with your team for API documentation

