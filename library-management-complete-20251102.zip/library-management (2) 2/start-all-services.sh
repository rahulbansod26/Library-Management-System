#!/bin/bash

# Library Management System - Service Startup Script
# This script starts all services in order and verifies Eureka registration

set -e

# Colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}Library Management System Startup${NC}"
echo -e "${GREEN}========================================${NC}"

# Check prerequisites
echo -e "\n${YELLOW}Checking prerequisites...${NC}"

# Check MySQL
if ! command -v mysql &> /dev/null; then
    echo -e "${RED}MySQL not found. Please install MySQL.${NC}"
    exit 1
fi

# Check RabbitMQ
if ! rabbitmqctl status &> /dev/null; then
    echo -e "${YELLOW}RabbitMQ may not be running. Starting...${NC}"
    # Try to start RabbitMQ (adjust based on your system)
    # rabbitmq-server -detached
fi

# Function to check if port is available
check_port() {
    if lsof -Pi :$1 -sTCP:LISTEN -t >/dev/null 2>&1 ; then
        echo -e "${RED}Port $1 is already in use!${NC}"
        return 1
    fi
    return 0
}

# Function to wait for service to register with Eureka
wait_for_eureka_registration() {
    local service_name=$1
    local max_attempts=30
    local attempt=0
    
    echo -e "${YELLOW}Waiting for $service_name to register with Eureka...${NC}"
    
    while [ $attempt -lt $max_attempts ]; do
        if curl -s http://localhost:8761/eureka/apps/$service_name | grep -q "UP"; then
            echo -e "${GREEN}✓ $service_name registered with Eureka!${NC}"
            return 0
        fi
        attempt=$((attempt + 1))
        sleep 2
    done
    
    echo -e "${RED}✗ $service_name failed to register with Eureka${NC}"
    return 1
}

# Step 1: Start Eureka
echo -e "\n${GREEN}[1/7] Starting Eureka Service Discovery...${NC}"
check_port 8761
cd eureka-service
mvn spring-boot:run > ../logs/eureka.log 2>&1 &
EUREKA_PID=$!
echo "Eureka PID: $EUREKA_PID"
sleep 15
echo -e "${GREEN}✓ Eureka started (PID: $EUREKA_PID)${NC}"
cd ..

# Step 2: Start User Service
echo -e "\n${GREEN}[2/7] Starting User Service...${NC}"
check_port 8081
cd user-service
mvn spring-boot:run > ../logs/user-service.log 2>&1 &
USER_SERVICE_PID=$!
echo "User Service PID: $USER_SERVICE_PID"
sleep 20
wait_for_eureka_registration "USER-SERVICE"
cd ..

# Step 3: Start Catalog Service
echo -e "\n${GREEN}[3/7] Starting Catalog Service...${NC}"
check_port 8082
cd catalog-service
mvn spring-boot:run > ../logs/catalog-service.log 2>&1 &
CATALOG_SERVICE_PID=$!
echo "Catalog Service PID: $CATALOG_SERVICE_PID"
sleep 20
wait_for_eureka_registration "CATALOG-SERVICE"
cd ..

# Step 4: Start Borrow Service
echo -e "\n${GREEN}[4/7] Starting Borrow Service...${NC}"
check_port 8083
cd borrow-service
mvn spring-boot:run > ../logs/borrow-service.log 2>&1 &
BORROW_SERVICE_PID=$!
echo "Borrow Service PID: $BORROW_SERVICE_PID"
sleep 20
wait_for_eureka_registration "BORROW-SERVICE"
cd ..

# Step 5: Start Fine Service
echo -e "\n${GREEN}[5/7] Starting Fine Service...${NC}"
check_port 8084
cd fine-service
mvn spring-boot:run > ../logs/fine-service.log 2>&1 &
FINE_SERVICE_PID=$!
echo "Fine Service PID: $FINE_SERVICE_PID"
sleep 20
wait_for_eureka_registration "FINE-SERVICE"
cd ..

# Step 6: Start Notification Service
echo -e "\n${GREEN}[6/7] Starting Notification Service...${NC}"
check_port 8085
cd notification-service
mvn spring-boot:run > ../logs/notification-service.log 2>&1 &
NOTIFICATION_SERVICE_PID=$!
echo "Notification Service PID: $NOTIFICATION_SERVICE_PID"
sleep 20
wait_for_eureka_registration "NOTIFICATION-SERVICE"
cd ..

# Step 7: Start API Gateway
echo -e "\n${GREEN}[7/7] Starting API Gateway...${NC}"
check_port 7000
cd api-gateway
mvn spring-boot:run > ../logs/api-gateway.log 2>&1 &
GATEWAY_PID=$!
echo "API Gateway PID: $GATEWAY_PID"
sleep 20
wait_for_eureka_registration "API-GATEWAY"
cd ..

# Create logs directory if it doesn't exist
mkdir -p logs

# Save PIDs for later cleanup
echo "EUREKA_PID=$EUREKA_PID" > logs/pids.txt
echo "USER_SERVICE_PID=$USER_SERVICE_PID" >> logs/pids.txt
echo "CATALOG_SERVICE_PID=$CATALOG_SERVICE_PID" >> logs/pids.txt
echo "BORROW_SERVICE_PID=$BORROW_SERVICE_PID" >> logs/pids.txt
echo "FINE_SERVICE_PID=$FINE_SERVICE_PID" >> logs/pids.txt
echo "NOTIFICATION_SERVICE_PID=$NOTIFICATION_SERVICE_PID" >> logs/pids.txt
echo "GATEWAY_PID=$GATEWAY_PID" >> logs/pids.txt

echo -e "\n${GREEN}========================================${NC}"
echo -e "${GREEN}All services started successfully!${NC}"
echo -e "${GREEN}========================================${NC}"
echo -e "\n${YELLOW}Service URLs:${NC}"
echo -e "  Eureka Dashboard: http://localhost:8761"
echo -e "  API Gateway: http://localhost:7000"
echo -e "  User Service: http://localhost:8081"
echo -e "  Catalog Service: http://localhost:8082"
echo -e "  Borrow Service: http://localhost:8083"
echo -e "  Fine Service: http://localhost:8084"
echo -e "  Notification Service: http://localhost:8085"
echo -e "\n${YELLOW}Logs are in ./logs/ directory${NC}"
echo -e "\n${YELLOW}To stop all services, run: ./stop-all-services.sh${NC}"

