package com.hashedin.library.borrow.repo;

import com.hashedin.library.borrow.domain.BorrowRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface BorrowRequestRepo extends JpaRepository<BorrowRequest, String> {
    List<BorrowRequest> findByUserIdOrderByRequestDateDesc(String userId);
    List<BorrowRequest> findByStatus(BorrowRequest.Status status);
    List<BorrowRequest> findByBookIdAndStatus(String bookId, BorrowRequest.Status status);
    Optional<BorrowRequest> findByUserIdAndBookIdAndStatus(String userId, String bookId, BorrowRequest.Status status);
}

