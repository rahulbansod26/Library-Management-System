package com.hashedin.library.borrow.client;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

@Component
public class CatalogServiceClient {
    private final RestTemplate restTemplate;
    private static final String CATALOG_SERVICE_NAME = "catalog-service";

    public CatalogServiceClient(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public Map<String, Object> getBook(String bookId) {
        try {
            ResponseEntity<Map<String, Object>> response = restTemplate.exchange(
                    "http://" + CATALOG_SERVICE_NAME + "/api/books/" + bookId,
                    HttpMethod.GET,
                    null,
                    new ParameterizedTypeReference<Map<String, Object>>() {}
            );
            return response.getBody();
        } catch (Exception e) {
            System.err.println("Error fetching book " + bookId + ": " + e.getMessage());
            return null;
        }
    }

    public void updateBookStatus(String bookId, String status) {
        try {
            org.springframework.http.HttpEntity<Map<String, String>> request = 
                new org.springframework.http.HttpEntity<>(Map.of("status", status));
            restTemplate.exchange(
                    "http://" + CATALOG_SERVICE_NAME + "/api/books/" + bookId + "/status",
                    HttpMethod.PATCH,
                    request,
                    new ParameterizedTypeReference<Map<String, Object>>() {}
            );
        } catch (Exception e) {
            System.err.println("Error updating book status for " + bookId + ": " + e.getMessage());
        }
    }
}

