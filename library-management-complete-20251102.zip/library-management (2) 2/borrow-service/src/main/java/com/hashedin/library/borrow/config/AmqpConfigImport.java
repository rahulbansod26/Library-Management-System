package com.hashedin.library.borrow.config;

import com.hashedin.library.common.config.AmqpTopology;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@Import(AmqpTopology.class)
public class AmqpConfigImport {}
