
package com.hashedin.library.borrow.repo;

import com.hashedin.library.borrow.domain.BorrowRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.LocalDate;
import java.util.List;

public interface BorrowRepo extends JpaRepository<BorrowRecord, String> {
    long countByUserIdAndStatus(String userId, BorrowRecord.Status status);
    List<BorrowRecord> findByUserId(String userId);
    List<BorrowRecord> findByUserIdAndStatus(String userId, BorrowRecord.Status status);
    List<BorrowRecord> findByUserIdOrderByStartDateDesc(String userId);
    List<BorrowRecord> findByStatusAndEndDateBefore(BorrowRecord.Status status, LocalDate date);
    List<BorrowRecord> findByStatus(BorrowRecord.Status status);
    List<BorrowRecord> findByStatusAndEndDateBetween(BorrowRecord.Status status, LocalDate startDate, LocalDate endDate);
    List<BorrowRecord> findByStatusAndEndDate(BorrowRecord.Status status, LocalDate date);
}
