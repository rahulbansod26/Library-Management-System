
package com.hashedin.library.borrow.service;

import com.hashedin.library.borrow.client.CatalogServiceClient;
import com.hashedin.library.borrow.domain.BorrowRecord;
import com.hashedin.library.borrow.domain.BorrowRequest;
import com.hashedin.library.borrow.repo.BorrowRepo;
import com.hashedin.library.borrow.repo.BorrowRequestRepo;
import com.hashedin.library.common.exception.BadRequestException;
import com.hashedin.library.common.exception.ResourceNotFoundException;
import com.hashedin.library.common.events.RoutingKeys;
import com.hashedin.library.common.events.BorrowRequestedEvent;
import com.hashedin.library.common.events.BorrowApprovedEvent;
import com.hashedin.library.common.events.BookReturnedEvent;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

@Service
public class BorrowService {
    private final BorrowRepo repo;
    private final BorrowRequestRepo requestRepo;
    private final CatalogServiceClient catalogServiceClient;
    private final RabbitTemplate rabbit;
    private final TopicExchange exchange;
    private final int MAX_BOOKS = 5;
    private static final int DEFAULT_BORROW_DAYS = 14;
    private static final int MAX_BORROW_DAYS = 30;

    public BorrowService(BorrowRepo repo, BorrowRequestRepo requestRepo, 
                        CatalogServiceClient catalogServiceClient,
                        RabbitTemplate rabbit, TopicExchange exchange){
        this.repo = repo;
        this.requestRepo = requestRepo;
        this.catalogServiceClient = catalogServiceClient;
        this.rabbit = rabbit;
        this.exchange = exchange;
    }

    @CacheEvict(cacheNames="active_loans", key="#userId")
    @Transactional
    public BorrowRecord borrow(String userId, String bookId, int days){
        // Check book availability
        Map<String, Object> book = catalogServiceClient.getBook(bookId);
        if (book == null) {
            throw new ResourceNotFoundException("Book", bookId);
        }
        
        String status = (String) book.get("status");
        Integer quantity = (Integer) book.get("quantity");
        
        if (!"AVAILABLE".equals(status) || quantity == null || quantity <= 0) {
            throw new BadRequestException("Book is not available for borrowing");
        }
        
        // Validate borrow limit
        long active = repo.countByUserIdAndStatus(userId, BorrowRecord.Status.ACTIVE);
        if(active >= MAX_BOOKS) {
            throw new BadRequestException("Borrow limit exceeded. Maximum " + MAX_BOOKS + " books allowed.");
        }
        
        // Validate borrowing duration
        if (days <= 0) {
            days = DEFAULT_BORROW_DAYS;
        }
        if (days > MAX_BORROW_DAYS) {
            days = MAX_BORROW_DAYS;
        }
        
        BorrowRecord r = new BorrowRecord();
        r.setUserId(userId); 
        r.setBookId(bookId);
        r.setStartDate(LocalDate.now());
        r.setEndDate(LocalDate.now().plusDays(days));
        r.setStatus(BorrowRecord.Status.ACTIVE);
        r = repo.save(r);
        
        // Update book status to BORROWED
        catalogServiceClient.updateBookStatus(bookId, "BORROWED");
        
        // Publish borrow requested event
        rabbit.convertAndSend(exchange.getName(), RoutingKeys.BORROW_REQUESTED, 
                new BorrowRequestedEvent(userId, bookId));
        
        // Publish borrow approved event (auto-approved for now)
        rabbit.convertAndSend(exchange.getName(), RoutingKeys.BORROW_APPROVED, 
                new BorrowApprovedEvent(userId, bookId, r.getEndDate()));
        
        return r;
    }

    @Async
    @CacheEvict(cacheNames="active_loans", key="#userId")
    @Transactional
    public CompletableFuture<BorrowRecord> borrowAsync(String userId, String bookId, int days){
        return CompletableFuture.completedFuture(borrow(userId, bookId, days));
    }

    @CacheEvict(cacheNames="active_loans", key="#userId")
    @Transactional
    public BorrowRecord returnBook(String userId, String recordId){
        BorrowRecord r = repo.findById(recordId)
                .orElseThrow(() -> new ResourceNotFoundException("Borrow record", recordId));
        
        if (!r.getUserId().equals(userId)) {
            throw new BadRequestException("Borrow record does not belong to user");
        }
        
        if (r.getStatus() == BorrowRecord.Status.RETURNED) {
            throw new BadRequestException("Book has already been returned");
        }
        
        r.setStatus(BorrowRecord.Status.RETURNED);
        r.setReturnDate(LocalDate.now());
        BorrowRecord returned = repo.save(r);
        
        // Update book status to AVAILABLE
        catalogServiceClient.updateBookStatus(r.getBookId(), "AVAILABLE");
        
        // Publish book returned event
        rabbit.convertAndSend(exchange.getName(), RoutingKeys.BOOK_RETURNED, 
                new BookReturnedEvent(userId, r.getBookId()));
        
        return returned;
    }
    
    @CacheEvict(cacheNames="active_loans", key="#userId")
    @Transactional
    public BorrowRecord markBookAsLost(String userId, String recordId){
        BorrowRecord r = repo.findById(recordId)
                .orElseThrow(() -> new ResourceNotFoundException("Borrow record", recordId));
        
        if (!r.getUserId().equals(userId)) {
            throw new BadRequestException("Borrow record does not belong to user");
        }
        
        if (r.getStatus() == BorrowRecord.Status.RETURNED) {
            throw new BadRequestException("Cannot mark returned book as lost");
        }
        
        r.setStatus(BorrowRecord.Status.LOST);
        r.setReturnDate(LocalDate.now()); // Set return date as current date for lost books
        BorrowRecord lost = repo.save(r);
        
        // Update book status to REMOVED (since it's lost)
        catalogServiceClient.updateBookStatus(r.getBookId(), "REMOVED");
        
        // Publish book lost event (can be used for fine calculation)
        rabbit.convertAndSend(exchange.getName(), RoutingKeys.BOOK_OVERDUE, 
                new com.hashedin.library.common.events.BookOverdueEvent(userId, r.getBookId()));
        
        return lost;
    }

    @Async
    @CacheEvict(cacheNames="active_loans", key="#userId")
    @Transactional
    public CompletableFuture<BorrowRecord> returnBookAsync(String userId, String recordId){
        return CompletableFuture.completedFuture(returnBook(userId, recordId));
    }

    @Cacheable(cacheNames="active_loans", key="#userId")
    public List<BorrowRecord> activeForUser(String userId){
        return repo.findByUserIdAndStatus(userId, BorrowRecord.Status.ACTIVE);
    }

    public List<BorrowRecord> getBorrowingHistory(String userId){
        return repo.findByUserIdOrderByStartDateDesc(userId);
    }

    public List<BorrowRecord> getOverdueRecords(){
        return repo.findByStatus(BorrowRecord.Status.OVERDUE);
    }

    public BorrowRecord getById(String recordId){
        return repo.findById(recordId)
                .orElseThrow(() -> new RuntimeException("Borrow record not found: " + recordId));
    }

    public List<BorrowRecord> getActiveBorrows() {
        return repo.findByStatus(BorrowRecord.Status.ACTIVE);
    }

    public List<BorrowRecord> getBorrowsDueInDays(int days) {
        LocalDate targetDate = LocalDate.now().plusDays(days);
        return repo.findByStatusAndEndDate(BorrowRecord.Status.ACTIVE, targetDate);
    }

    public List<BorrowRecord> getBorrowsDueBetween(LocalDate startDate, LocalDate endDate) {
        return repo.findByStatusAndEndDateBetween(BorrowRecord.Status.ACTIVE, startDate, endDate);
    }

    // Borrow Request Management
    public BorrowRequest createBorrowRequest(String userId, String bookId, int days, String reason) {
        // Check for existing pending request
        if (requestRepo.findByUserIdAndBookIdAndStatus(userId, bookId, BorrowRequest.Status.PENDING).isPresent()) {
            throw new BadRequestException("A pending borrow request for this book already exists");
        }
        
        BorrowRequest request = new BorrowRequest();
        request.setUserId(userId);
        request.setBookId(bookId);
        request.setRequestedDays(days > 0 ? days : DEFAULT_BORROW_DAYS);
        request.setReason(reason);
        request.setStatus(BorrowRequest.Status.PENDING);
        return requestRepo.save(request);
    }
    
    @Transactional
    public BorrowRecord approveBorrowRequest(String requestId, String librarianId) {
        BorrowRequest request = requestRepo.findById(requestId)
                .orElseThrow(() -> new ResourceNotFoundException("Borrow request", requestId));
        
        if (request.getStatus() != BorrowRequest.Status.PENDING) {
            throw new BadRequestException("Request is not pending");
        }
        
        request.setStatus(BorrowRequest.Status.APPROVED);
        request.setProcessedBy(librarianId);
        request.setProcessedDate(Instant.now());
        requestRepo.save(request);
        
        // Create borrow record
        return borrow(request.getUserId(), request.getBookId(), request.getRequestedDays());
    }
    
    @Transactional
    public BorrowRequest rejectBorrowRequest(String requestId, String librarianId) {
        BorrowRequest request = requestRepo.findById(requestId)
                .orElseThrow(() -> new ResourceNotFoundException("Borrow request", requestId));
        
        if (request.getStatus() != BorrowRequest.Status.PENDING) {
            throw new BadRequestException("Request is not pending");
        }
        
        request.setStatus(BorrowRequest.Status.REJECTED);
        request.setProcessedBy(librarianId);
        request.setProcessedDate(Instant.now());
        return requestRepo.save(request);
    }
    
    public List<BorrowRequest> getPendingRequests() {
        return requestRepo.findByStatus(BorrowRequest.Status.PENDING);
    }
    
    public List<BorrowRequest> getUserRequests(String userId) {
        return requestRepo.findByUserIdOrderByRequestDateDesc(userId);
    }

    @Scheduled(cron = "0 0 * * * *") // Every hour
    public void markOverdue(){
        List<BorrowRecord> due = repo.findByStatusAndEndDateBefore(BorrowRecord.Status.ACTIVE, LocalDate.now());
        for(BorrowRecord r: due){
            r.setStatus(BorrowRecord.Status.OVERDUE);
            repo.save(r);
            rabbit.convertAndSend(exchange.getName(), RoutingKeys.BOOK_OVERDUE, r);
        }
    }
}
