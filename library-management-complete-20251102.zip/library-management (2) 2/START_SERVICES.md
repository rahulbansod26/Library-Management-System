# Service Startup and Testing Guide

This guide helps you start services one by one, verify Eureka registration, and test the complete flow.

## Quick Start with Automated Testing

**Option 1: Use automated test scripts (Recommended)**
```bash
# Start all services first
./start-all-services.sh

# Wait for services to start, then run comprehensive tests
./test-all-services.sh
```

**Option 2: Test individual services**
```bash
./test-user-service.sh        # Test User Service
./test-catalog-service.sh     # Test Catalog Service
./test-borrow-service.sh      # Test Borrow Service
./test-fine-service.sh        # Test Fine Service
./test-notification-service.sh # Test Notification Service
```

See `TESTING_GUIDE.md` for detailed testing information.

## Prerequisites

Before starting, ensure these services are running:
- ✅ MySQL (port 3306)
- ✅ RabbitMQ (port 5672)
- ✅ Redis (port 6379) - Optional but recommended

## Step-by-Step Service Startup

### Step 1: Start Eureka Service Discovery (Port 8761)

```bash
cd eureka-service
mvn spring-boot:run
```

**Verify:**
- Open browser: http://localhost:8761
- You should see the Eureka dashboard
- Wait for it to fully start (check console logs)

**Expected Log:**
```
Started EurekaServiceApplication in X.XXX seconds
```

---

### Step 2: Start User Service (Port 8081)

**In a NEW terminal:**
```bash
cd user-service
mvn spring-boot:run
```

**Verify Eureka Registration:**
- Go to http://localhost:8761
- Check "Instances currently registered with Eureka"
- Look for **USER-SERVICE** (should appear within 30 seconds)

**Expected Log:**
```
DiscoveryClient_USER-SERVICE - registration status: 204
```

**Test User Service:**
```bash
# Health Check
curl http://localhost:8081/actuator/health

# Register a new user
curl -X POST http://localhost:8081/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Test User",
    "email": "test@example.com",
    "password": "password123",
    "role": "USER"
  }'

# Login
curl -X POST http://localhost:8081/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "password123"
  }'
# Save the JWT token from response
```

---

### Step 3: Start Catalog Service (Port 8082)

**In a NEW terminal:**
```bash
cd catalog-service
mvn spring-boot:run
```

**Verify Eureka Registration:**
- Refresh http://localhost:8761
- Check for **CATALOG-SERVICE**

**Expected Log:**
```
DiscoveryClient_CATALOG-SERVICE - registration status: 204
```

**Test Catalog Service:**
```bash
# Get all books
curl http://localhost:8082/api/books

# Add a book (as librarian - you'll need JWT token)
curl -X POST http://localhost:8082/api/books \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -d '{
    "title": "The Great Gatsby",
    "author": "F. Scott Fitzgerald",
    "genre": "Fiction",
    "isbn": "978-0-7432-7356-5",
    "publisher": "Scribner",
    "publicationYear": 2004,
    "description": "A classic American novel",
    "quantity": 5,
    "status": "AVAILABLE"
  }'

# Get book by ID
curl http://localhost:8082/api/books/{bookId}
```

---

### Step 4: Start Borrow Service (Port 8083)

**In a NEW terminal:**
```bash
cd borrow-service
mvn spring-boot:run
```

**Verify Eureka Registration:**
- Refresh http://localhost:8761
- Check for **BORROW-SERVICE**

**Expected Log:**
```
DiscoveryClient_BORROW-SERVICE - registration status: 204
```

**Test Borrow Service:**
```bash
# Create borrow request
curl -X POST http://localhost:8083/api/borrow/request \
  -H "Content-Type: application/json" \
  -d '{
    "bookId": "BOOK_ID_FROM_STEP_3",
    "days": 14,
    "reason": "For reading"
  }'

# Approve borrow request (as librarian)
curl -X POST http://localhost:8083/api/borrow/request/{requestId}/approve \
  -H "Content-Type: application/json" \
  -d '{
    "librarianId": "librarian-id"
  }'

# Get active borrows for user
curl http://localhost:8083/api/borrow/user/{userId}

# Return book
curl -X POST http://localhost:8083/api/borrow/return/{recordId} \
  -H "Content-Type: application/json" \
  -d '{
    "userId": "user-id"
  }'
```

---

### Step 5: Start Fine Service (Port 8084)

**In a NEW terminal:**
```bash
cd fine-service
mvn spring-boot:run
```

**Verify Eureka Registration:**
- Refresh http://localhost:8761
- Check for **FINE-SERVICE**

**Expected Log:**
```
DiscoveryClient_FINE-SERVICE - registration status: 204
```

**Test Fine Service:**
```bash
# Get user's fines
curl http://localhost:8084/api/fines/{userId}

# Get outstanding fines
curl http://localhost:8084/api/fines/{userId}/outstanding

# Process payment
curl -X POST http://localhost:8084/api/fines/{userId}/pay/{fineId} \
  -H "Content-Type: application/json" \
  -d '{
    "amount": 25.00,
    "paymentMethod": "CREDIT_CARD"
  }'

# Get payment history
curl http://localhost:8084/api/fines/{fineId}/payments

# Manually trigger fine calculation
curl -X POST http://localhost:8084/api/fines/calculate
```

---

### Step 6: Start Notification Service (Port 8085)

**In a NEW terminal:**
```bash
cd notification-service
mvn spring-boot:run
```

**Verify Eureka Registration:**
- Refresh http://localhost:8761
- Check for **NOTIFICATION-SERVICE**

**Expected Log:**
```
DiscoveryClient_NOTIFICATION-SERVICE - registration status: 204
```

**Test Notification Service:**
```bash
# Get user notifications
curl http://localhost:8085/api/notifications/user/{userId}

# Get unread notifications
curl http://localhost:8085/api/notifications/user/{userId}/unread

# Mark notification as read
curl -X PUT http://localhost:8085/api/notifications/{notificationId}/read
```

---

### Step 7: Start API Gateway (Port 7000)

**In a NEW terminal:**
```bash
cd api-gateway
mvn spring-boot:run
```

**Verify Eureka Registration:**
- Refresh http://localhost:8761
- Check for **API-GATEWAY**

**Expected Log:**
```
DiscoveryClient_API-GATEWAY - registration status: 204
```

**Test API Gateway:**
```bash
# Test routing through gateway
curl http://localhost:7000/api/auth/login

# All services should be accessible via gateway:
# http://localhost:7000/api/auth/** -> User Service
# http://localhost:7000/api/books/** -> Catalog Service
# http://localhost:7000/api/borrows/** -> Borrow Service
# http://localhost:7000/api/fines/** -> Fine Service
# http://localhost:7000/api/notifications/** -> Notification Service
```

---

## Complete Flow Testing

### Flow 1: User Registration → Book Borrow → Fine Calculation

```bash
# 1. Register User
curl -X POST http://localhost:7000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "John Doe",
    "email": "john@example.com",
    "password": "password123",
    "role": "USER"
  }'
# Save: userId, token

# 2. Login
curl -X POST http://localhost:7000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "john@example.com",
    "password": "password123"
  }'
# Save: JWT token

# 3. Add Book (as Librarian)
curl -X POST http://localhost:7000/api/books \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer LIBRARIAN_TOKEN" \
  -d '{
    "title": "Test Book",
    "author": "Test Author",
    "isbn": "1234567890",
    "quantity": 1,
    "status": "AVAILABLE"
  }'
# Save: bookId

# 4. Borrow Book
curl -X POST http://localhost:7000/api/borrows \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer USER_TOKEN" \
  -d '{
    "userId": "USER_ID",
    "bookId": "BOOK_ID",
    "days": 14
  }'
# Save: borrowRecordId

# 5. Check Notifications (should see borrow confirmation)
curl http://localhost:7000/api/notifications/user/USER_ID

# 6. Wait for fine calculation (runs hourly at :15) or trigger manually
curl -X POST http://localhost:7000/api/fines/calculate

# 7. Check fines
curl http://localhost:7000/api/fines/USER_ID/outstanding

# 8. Return book
curl -X POST http://localhost:7000/api/borrows/return/BORROW_RECORD_ID \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer USER_TOKEN" \
  -d '{"userId": "USER_ID"}'

# 9. Check notifications (should see return confirmation)
curl http://localhost:7000/api/notifications/user/USER_ID
```

### Flow 2: Lost Book → Fine Calculation

```bash
# 1. Mark book as lost
curl -X POST http://localhost:7000/api/borrows/BORROW_RECORD_ID/lost \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer USER_TOKEN" \
  -d '{"userId": "USER_ID"}'

# 2. Check fines (should show $200 lost book fine)
curl http://localhost:7000/api/fines/USER_ID/outstanding

# 3. Pay fine
curl -X POST http://localhost:7000/api/fines/USER_ID/pay/FINE_ID \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer USER_TOKEN" \
  -d '{
    "amount": 200.00,
    "paymentMethod": "CREDIT_CARD"
  }'

# 4. Check payment confirmation notification
curl http://localhost:7000/api/notifications/user/USER_ID
```

---

## Eureka Dashboard Verification

After starting all services, check http://localhost:8761

**Expected Services:**
1. ✅ USER-SERVICE (1 instance)
2. ✅ CATALOG-SERVICE (1 instance)
3. ✅ BORROW-SERVICE (1 instance)
4. ✅ FINE-SERVICE (1 instance)
5. ✅ NOTIFICATION-SERVICE (1 instance)
6. ✅ API-GATEWAY (1 instance)

**If a service doesn't appear:**
- Check console logs for errors
- Verify database connection
- Verify RabbitMQ connection
- Check if port is already in use
- Wait 30-60 seconds for registration

---

## Troubleshooting

### Service not registering with Eureka:
```bash
# Check if Eureka is running
curl http://localhost:8761

# Check service logs for connection errors
# Verify application.yml has correct eureka config
```

### Database Connection Issues:
```bash
# Verify MySQL is running
mysql -u root -p

# Check database is created (services auto-create)
```

### RabbitMQ Connection Issues:
```bash
# Verify RabbitMQ is running
rabbitmqctl status

# Check if queues are created
rabbitmqctl list_queues
```

### Port Already in Use:
```bash
# Find process using port
lsof -i :8081  # Change port number

# Kill process
kill -9 <PID>
```

---

## Quick Verification Commands

```bash
# Check all services are up
curl http://localhost:8761
curl http://localhost:8081/actuator/health 2>/dev/null || echo "User Service not responding"
curl http://localhost:8082/api/books 2>/dev/null || echo "Catalog Service not responding"
curl http://localhost:8083/api/borrow/overdue 2>/dev/null || echo "Borrow Service not responding"
curl http://localhost:8084/api/fines/calculate 2>/dev/null || echo "Fine Service not responding"
curl http://localhost:8085/api/notifications 2>/dev/null || echo "Notification Service not responding"
curl http://localhost:7000 2>/dev/null || echo "API Gateway not responding"
```

---

## Next Steps

Once all services are running and registered:
1. ✅ Test API endpoints through API Gateway
2. ✅ Verify RabbitMQ event publishing/consumption
3. ✅ Test scheduled tasks (fine calculation, reminders)
4. ✅ Check Redis caching is working
5. ✅ Verify global exception handling

