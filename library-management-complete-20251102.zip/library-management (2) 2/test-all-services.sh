#!/bin/bash

# Master Script: Start Services and Test All APIs in Flow

COLOR_GREEN='\033[0;32m'
COLOR_RED='\033[0;31m'
COLOR_YELLOW='\033[1;33m'
COLOR_BLUE='\033[0;34m'
COLOR_NC='\033[0m'

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

echo -e "${COLOR_GREEN}========================================${COLOR_NC}"
echo -e "${COLOR_GREEN}COMPREHENSIVE SERVICE TESTING${COLOR_NC}"
echo -e "${COLOR_GREEN}========================================${COLOR_NC}"
echo ""

# Check if services are running
check_service() {
    local port=$1
    local name=$2
    
    if curl -s "http://localhost:${port}" > /dev/null 2>&1 || \
       curl -s "http://localhost:${port}/actuator/health" > /dev/null 2>&1 || \
       curl -s "http://localhost:${port}/api" > /dev/null 2>&1; then
        echo -e "${COLOR_GREEN}✓ ${name} is running${COLOR_NC}"
        return 0
    else
        echo -e "${COLOR_RED}✗ ${name} is not responding on port ${port}${COLOR_NC}"
        return 1
    fi
}

# Wait for service to be ready
wait_for_service() {
    local port=$1
    local name=$2
    local max_wait=60
    local waited=0
    
    echo -e "${COLOR_YELLOW}Waiting for ${name} to be ready...${COLOR_NC}"
    while [ $waited -lt $max_wait ]; do
        if check_service "$port" "$name" > /dev/null 2>&1; then
            echo -e "${COLOR_GREEN}✓ ${name} is ready${COLOR_NC}"
            return 0
        fi
        sleep 2
        waited=$((waited + 2))
    done
    
    echo -e "${COLOR_RED}✗ ${name} did not become ready in ${max_wait} seconds${COLOR_NC}"
    return 1
}

echo "========================================="
echo "PHASE 0: Service Health Check"
echo "========================================="

check_service 8761 "Eureka Service Discovery" || {
    echo -e "${COLOR_RED}Please start Eureka Service first!${COLOR_NC}"
    exit 1
}

check_service 8081 "User Service" || wait_for_service 8081 "User Service"
check_service 8082 "Catalog Service" || wait_for_service 8082 "Catalog Service"
check_service 8083 "Borrow Service" || wait_for_service 8083 "Borrow Service"
check_service 8084 "Fine Service" || wait_for_service 8084 "Fine Service"
check_service 8085 "Notification Service" || wait_for_service 8085 "Notification Service"
check_service 7000 "API Gateway" || wait_for_service 7000 "API Gateway"

echo ""
echo "========================================="
echo "PHASE 1: User Service Testing"
echo "========================================="
chmod +x test-user-service.sh
./test-user-service.sh
echo ""

sleep 3

echo "========================================="
echo "PHASE 2: Catalog Service Testing"
echo "========================================="
chmod +x test-catalog-service.sh
./test-catalog-service.sh
echo ""

sleep 3

echo "========================================="
echo "PHASE 3: Borrow Service Testing"
echo "========================================="
chmod +x test-borrow-service.sh
./test-borrow-service.sh
echo ""

sleep 3

echo "========================================="
echo "PHASE 4: Fine Service Testing"
echo "========================================="
chmod +x test-fine-service.sh
./test-fine-service.sh
echo ""

sleep 3

echo "========================================="
echo "PHASE 5: Notification Service Testing"
echo "========================================="
chmod +x test-notification-service.sh
./test-notification-service.sh
echo ""

echo "========================================="
echo "PHASE 6: Eureka Registration Check"
echo "========================================="
echo -e "${COLOR_BLUE}Checking Eureka Dashboard...${COLOR_NC}"
REGISTERED_SERVICES=$(curl -s http://localhost:8761/eureka/apps | grep -o '<name>[^<]*</name>' | sed 's/<name>//;s/<\/name>//' | sort -u)

if [ ! -z "$REGISTERED_SERVICES" ]; then
    echo -e "${COLOR_GREEN}Registered Services:${COLOR_NC}"
    echo "$REGISTERED_SERVICES" | while read service; do
        echo -e "  ${COLOR_GREEN}✓ ${service}${COLOR_NC}"
    done
else
    echo -e "${COLOR_RED}No services found in Eureka${COLOR_NC}"
fi
echo ""

echo "========================================="
echo "PHASE 7: RabbitMQ Monitoring"
echo "========================================="
echo -e "${COLOR_BLUE}Checking RabbitMQ queues...${COLOR_NC}"
QUEUES=$(curl -s -u guest:guest http://localhost:15672/api/queues 2>/dev/null | python3 -m json.tool 2>/dev/null | grep '"name"' | head -10)
if [ ! -z "$QUEUES" ]; then
    echo "$QUEUES"
else
    echo "  RabbitMQ management API not accessible"
fi
echo ""

echo -e "${COLOR_GREEN}========================================${COLOR_NC}"
echo -e "${COLOR_GREEN}ALL TESTS COMPLETED${COLOR_NC}"
echo -e "${COLOR_GREEN}========================================${COLOR_NC}"
echo ""
echo "Summary:"
echo "  ✓ User Service APIs tested"
echo "  ✓ Catalog Service APIs tested"
echo "  ✓ Borrow Service APIs tested"
echo "  ✓ Fine Service APIs tested"
echo "  ✓ Notification Service APIs tested"
echo "  ✓ Eureka registration verified"
echo "  ✓ RabbitMQ queues monitored"
echo ""
echo "View detailed logs in individual test scripts above."

