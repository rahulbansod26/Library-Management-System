#!/bin/bash

# Library Management System - Service Shutdown Script

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${YELLOW}Stopping all services...${NC}"

if [ -f logs/pids.txt ]; then
    while IFS= read -r line; do
        PID=$(echo $line | cut -d'=' -f2)
        SERVICE=$(echo $line | cut -d'=' -f1 | sed 's/_PID//')
        if kill -0 $PID 2>/dev/null; then
            echo -e "Stopping $SERVICE (PID: $PID)..."
            kill $PID
            sleep 2
            if kill -0 $PID 2>/dev/null; then
                kill -9 $PID
            fi
        fi
    done < logs/pids.txt
    rm logs/pids.txt
fi

# Also try to kill by port
for port in 8761 8081 8082 8083 8084 8085 7000; do
    PID=$(lsof -ti:$port 2>/dev/null)
    if [ ! -z "$PID" ]; then
        echo -e "Killing process on port $port (PID: $PID)..."
        kill $PID 2>/dev/null
    fi
done

echo -e "${GREEN}All services stopped.${NC}"

