#!/bin/bash

# Complete User Service API Testing with RabbitMQ and Redis Monitoring

BASE_URL="http://localhost:8081"
GATEWAY_URL="http://localhost:7000"
COLOR_GREEN='\033[0;32m'
COLOR_RED='\033[0;31m'
COLOR_YELLOW='\033[1;33m'
COLOR_BLUE='\033[0;34m'
COLOR_NC='\033[0m'

USER_TOKEN=""
ADMIN_TOKEN=""
USER_ID=""
TEST_USER_EMAIL="testuser_$(date +%s)@example.com"

echo "========================================="
echo "COMPREHENSIVE USER SERVICE API TESTING"
echo "========================================="
echo ""

# Function to test endpoint
test_api() {
    local method=$1
    local endpoint=$2
    local data=$3
    local description=$4
    local token=$5
    local expected_code=${6:-200}
    
    echo -e "${COLOR_YELLOW}[TEST] ${description}${COLOR_NC}"
    echo "  ${method} ${endpoint}"
    
    if [ -z "$token" ]; then
        if [ "$method" = "POST" ]; then
            response=$(curl -s -w "\n%{http_code}" -X POST "${BASE_URL}${endpoint}" \
                -H "Content-Type: application/json" \
                -d "${data}")
        else
            response=$(curl -s -w "\n%{http_code}" -X GET "${BASE_URL}${endpoint}")
        fi
    else
        if [ "$method" = "POST" ]; then
            response=$(curl -s -w "\n%{http_code}" -X POST "${BASE_URL}${endpoint}" \
                -H "Content-Type: application/json" \
                -H "Authorization: Bearer ${token}" \
                -d "${data}")
        elif [ "$method" = "PUT" ]; then
            response=$(curl -s -w "\n%{http_code}" -X PUT "${BASE_URL}${endpoint}" \
                -H "Content-Type: application/json" \
                -H "Authorization: Bearer ${token}" \
                -d "${data}")
        elif [ "$method" = "DELETE" ]; then
            response=$(curl -s -w "\n%{http_code}" -X DELETE "${BASE_URL}${endpoint}" \
                -H "Authorization: Bearer ${token}")
        else
            response=$(curl -s -w "\n%{http_code}" -X GET "${BASE_URL}${endpoint}" \
                -H "Authorization: Bearer ${token}")
        fi
    fi
    
    http_code=$(echo "$response" | tail -n1)
    body=$(echo "$response" | sed '$d')
    
    if [ "$http_code" -eq "$expected_code" ]; then
        echo -e "${COLOR_GREEN}✓ PASS (${http_code})${COLOR_NC}"
        echo "  Response: $body" | head -c 300
        echo ""
        echo "$body" > /tmp/last_response.json
        echo "$body"
        return 0
    else
        echo -e "${COLOR_RED}✗ FAIL (Expected ${expected_code}, Got ${http_code})${COLOR_NC}"
        echo "  Response: $body"
        return 1
    fi
    echo ""
}

# Check RabbitMQ queue
check_rabbitmq() {
    echo -e "${COLOR_BLUE}[RABBITMQ] Checking queue: $1${COLOR_NC}"
    curl -s -u guest:guest http://localhost:15672/api/queues 2>/dev/null | python3 -m json.tool 2>/dev/null | grep -A 5 "$1" || echo "  Queue info not available"
}

# Check Redis cache
check_redis() {
    echo -e "${COLOR_BLUE}[REDIS] Checking key: $1${COLOR_NC}"
    redis-cli GET "$1" 2>/dev/null || echo "  Key not found or Redis not accessible"
}

echo "========================================="
echo "PHASE 1: Authentication APIs"
echo "========================================="

# 1. Register User
REGISTER_DATA="{\"name\":\"John Test Doe\",\"email\":\"${TEST_USER_EMAIL}\",\"password\":\"password123\",\"role\":\"USER\"}"
test_api "POST" "/api/auth/register" "$REGISTER_DATA" "1.1 Register new USER"
USER_ID=$(cat /tmp/last_response.json 2>/dev/null | grep -o '"id":"[^"]*' | head -1 | cut -d'"' -f4)
echo "Registered User ID: $USER_ID"

# 2. Register Admin
ADMIN_EMAIL="admin_$(date +%s)@example.com"
ADMIN_REGISTER_DATA="{\"name\":\"Admin Test User\",\"email\":\"${ADMIN_EMAIL}\",\"password\":\"admin123\",\"role\":\"ADMIN\"}"
test_api "POST" "/api/auth/register" "$ADMIN_REGISTER_DATA" "1.2 Register ADMIN user"

# 3. Login User
LOGIN_DATA="{\"email\":\"${TEST_USER_EMAIL}\",\"password\":\"password123\"}"
echo -e "${COLOR_YELLOW}[TEST] 1.3 User Login${COLOR_NC}"
LOGIN_RESPONSE=$(curl -s -X POST "${BASE_URL}/api/auth/login" \
    -H "Content-Type: application/json" \
    -d "$LOGIN_DATA")
USER_TOKEN=$(echo "$LOGIN_RESPONSE" | grep -o '"token":"[^"]*' | cut -d'"' -f4)
if [ ! -z "$USER_TOKEN" ]; then
    echo -e "${COLOR_GREEN}✓ PASS - Token received${COLOR_NC}"
    echo "  Token: ${USER_TOKEN:0:50}..."
else
    echo -e "${COLOR_RED}✗ FAIL - No token received${COLOR_NC}"
fi
echo ""

# 4. Login Admin
ADMIN_LOGIN_DATA="{\"email\":\"${ADMIN_EMAIL}\",\"password\":\"admin123\"}"
echo -e "${COLOR_YELLOW}[TEST] 1.4 Admin Login${COLOR_NC}"
ADMIN_LOGIN_RESPONSE=$(curl -s -X POST "${BASE_URL}/api/auth/login" \
    -H "Content-Type: application/json" \
    -d "$ADMIN_LOGIN_DATA")
ADMIN_TOKEN=$(echo "$ADMIN_LOGIN_RESPONSE" | grep -o '"token":"[^"]*' | cut -d'"' -f4)
if [ ! -z "$ADMIN_TOKEN" ]; then
    echo -e "${COLOR_GREEN}✓ PASS - Admin token received${COLOR_NC}"
else
    echo -e "${COLOR_RED}✗ FAIL - No admin token received${COLOR_NC}"
fi
echo ""

# Check RabbitMQ for registration events
sleep 2
check_rabbitmq "user.events.q"

echo ""
echo "========================================="
echo "PHASE 2: Gateway Routing Test"
echo "========================================="

# Test via Gateway
echo -e "${COLOR_YELLOW}[TEST] 2.1 Test registration via API Gateway${COLOR_NC}"
GATEWAY_TEST_EMAIL="gateway_$(date +%s)@example.com"
GATEWAY_REGISTER_DATA="{\"name\":\"Gateway Test User\",\"email\":\"${GATEWAY_TEST_EMAIL}\",\"password\":\"pass123\",\"role\":\"USER\"}"
GATEWAY_RESPONSE=$(curl -s -w "\n%{http_code}" -X POST "${GATEWAY_URL}/api/auth/register" \
    -H "Content-Type: application/json" \
    -d "${GATEWAY_REGISTER_DATA}")
GATEWAY_CODE=$(echo "$GATEWAY_RESPONSE" | tail -n1)
if [ "$GATEWAY_CODE" -eq 200 ] || [ "$GATEWAY_CODE" -eq 201 ]; then
    echo -e "${COLOR_GREEN}✓ PASS - Gateway routing working${COLOR_NC}"
else
    echo -e "${COLOR_RED}✗ FAIL - Gateway routing failed (${GATEWAY_CODE})${COLOR_NC}"
fi
echo ""

echo ""
echo "========================================="
echo "USER SERVICE TESTING COMPLETE"
echo "========================================="

