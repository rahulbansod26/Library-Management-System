# Complete Testing Guide - Library Management System

This guide provides comprehensive testing scripts for all services.

## Available Testing Scripts

### Individual Service Tests

1. **test-user-service.sh** - Tests User Service APIs
   - User registration and authentication
   - Profile management
   - Password management
   - JWT token handling

2. **test-catalog-service.sh** - Tests Catalog Service APIs
   - Book CRUD operations
   - Search functionality
   - Book status updates
   - Event publishing verification

3. **test-borrow-service.sh** - Tests Borrow Service APIs
   - Borrow request management
   - Book borrowing and returning
   - Borrowing history
   - Lost book handling

4. **test-fine-service.sh** - Tests Fine Service APIs
   - Fine retrieval
   - Payment processing
   - Payment history
   - Fine calculation

5. **test-notification-service.sh** - Tests Notification Service APIs
   - Notification retrieval
   - Mark as read functionality
   - Event-driven notifications

### Master Test Script

**test-all-services.sh** - Runs all tests in sequence
- Checks service health
- Tests each service in order
- Verifies Eureka registration
- Monitors RabbitMQ queues

## How to Use

### Option 1: Test All Services (Recommended)

```bash
# 1. Start all services first (manually or using start-all-services.sh)
# Wait for all services to start (~2-3 minutes)

# 2. Run comprehensive tests
./test-all-services.sh
```

### Option 2: Test Individual Services

```bash
# Test User Service
./test-user-service.sh

# Test Catalog Service
./test-catalog-service.sh

# Test Borrow Service
./test-borrow-service.sh

# Test Fine Service
./test-fine-service.sh

# Test Notification Service
./test-notification-service.sh
```

### Option 3: Manual Testing with curl

See individual test scripts for exact curl commands.

## Test Flow

### Complete End-to-End Flow

```bash
# 1. Start Eureka
cd eureka-service && mvn spring-boot:run &

# 2. Start User Service
cd user-service && mvn spring-boot:run &

# Wait ~30 seconds, then run:
./test-user-service.sh

# 3. Start Catalog Service
cd catalog-service && mvn spring-boot:run &

# Wait ~30 seconds, then run:
./test-catalog-service.sh

# 4. Start Borrow Service
cd borrow-service && mvn spring-boot:run &

# Wait ~30 seconds, then run:
./test-borrow-service.sh

# 5. Start Fine Service
cd fine-service && mvn spring-boot:run &

# Wait ~30 seconds, then run:
./test-fine-service.sh

# 6. Start Notification Service
cd notification-service && mvn spring-boot:run &

# Wait ~30 seconds, then run:
./test-notification-service.sh

# 7. Start API Gateway
cd api-gateway && mvn spring-boot:run &

# 8. Run all tests
./test-all-services.sh
```

## What Each Script Tests

### User Service (test-user-service.sh)
- ✅ User registration (USER role)
- ✅ User registration (ADMIN role)
- ✅ User login
- ✅ Admin login
- ✅ Gateway routing verification
- ✅ RabbitMQ event monitoring
- ✅ Redis cache checks

### Catalog Service (test-catalog-service.sh)
- ✅ Get all books
- ✅ Add new book
- ✅ Get book by ID
- ✅ Get book by ISBN
- ✅ Update book
- ✅ Search books
- ✅ Get books by author
- ✅ Get books by genre
- ✅ Update book status
- ✅ Delete book
- ✅ RabbitMQ event verification (BookAdded, BookUpdated, BookRemoved)
- ✅ Redis cache verification
- ✅ Gateway routing

### Borrow Service (test-borrow-service.sh)
- ✅ Create borrow request
- ✅ Get pending requests
- ✅ Approve borrow request
- ✅ Get active borrows
- ✅ Get borrowing history
- ✅ Get borrow record by ID
- ✅ Get all active borrows
- ✅ Get overdue records
- ✅ Get borrows due in N days
- ✅ Return book
- ✅ Mark book as lost
- ✅ RabbitMQ event verification (BorrowApproved, BookReturned, BookOverdue)
- ✅ Redis cache verification
- ✅ Gateway routing

### Fine Service (test-fine-service.sh)
- ✅ Get user's fine
- ✅ Get all fines for user
- ✅ Get outstanding fine amount
- ✅ Manually add fine
- ✅ Process payment (async)
- ✅ Get payment history
- ✅ Manually trigger fine calculation
- ✅ RabbitMQ event verification (FineUpdated, PaymentCompleted)
- ✅ Gateway routing

### Notification Service (test-notification-service.sh)
- ✅ Get all notifications
- ✅ Get unread notifications
- ✅ Get unread notification count
- ✅ Mark notification as read
- ✅ Mark all notifications as read
- ✅ RabbitMQ queue monitoring
- ✅ Gateway routing

## Monitoring During Tests

All scripts monitor:
- ✅ **RabbitMQ Queues**: Verifies events are published and queued
- ✅ **Redis Cache**: Checks cache keys and values
- ✅ **Eureka Registration**: Verifies services are registered
- ✅ **Gateway Routing**: Tests API routing through gateway

## Expected Results

### Success Indicators
- ✅ All API calls return HTTP 200/201
- ✅ Services appear in Eureka dashboard
- ✅ RabbitMQ queues show message counts
- ✅ Redis cache contains expected keys
- ✅ Gateway routes requests correctly

### Common Issues

**Service not responding:**
- Check if service is running
- Check service logs for errors
- Verify port is not in use

**Eureka registration failed:**
- Wait 30-60 seconds
- Check Eureka URL in application.yml
- Verify Eureka service is running

**RabbitMQ errors:**
- Verify RabbitMQ is running: `rabbitmqctl status`
- Check queue bindings
- Verify exchange configuration

**Redis errors:**
- Verify Redis is running: `redis-cli ping`
- Check Redis host/port in application.yml

## Example Output

```
=========================================
COMPREHENSIVE USER SERVICE API TESTING
=========================================

[TEST] 1.1 Register new USER
  POST /api/auth/register
✓ PASS (200)

[TEST] 1.2 Register ADMIN user
  POST /api/auth/register
✓ PASS (200)

[RABBITMQ] Checking queue: user.events.q
  {"name":"user.events.q","messages":2}

[REDIS] Checking key: user:profile:123
  {"id":"123","name":"John Doe"}

...
```

## Next Steps

After running all tests:
1. ✅ Verify all services in Eureka dashboard
2. ✅ Check RabbitMQ management console for queues
3. ✅ Monitor Redis for cache keys
4. ✅ Review service logs for any errors
5. ✅ Test end-to-end user flows manually

