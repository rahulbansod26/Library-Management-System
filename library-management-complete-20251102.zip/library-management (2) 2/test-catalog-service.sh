#!/bin/bash

# Complete Catalog Service API Testing

BASE_URL="http://localhost:8082"
GATEWAY_URL="http://localhost:7000"
COLOR_GREEN='\033[0;32m'
COLOR_RED='\033[0;31m'
COLOR_YELLOW='\033[1;33m'
COLOR_BLUE='\033[0;34m'
COLOR_NC='\033[0m'

BOOK_ID=""
BOOK_ISBN="978-$(date +%s)"

echo "========================================="
echo "COMPREHENSIVE CATALOG SERVICE API TESTING"
echo "========================================="
echo ""

# Function to test endpoint
test_api() {
    local method=$1
    local endpoint=$2
    local data=$3
    local description=$4
    local expected_code=${5:-200}
    
    echo -e "${COLOR_YELLOW}[TEST] ${description}${COLOR_NC}"
    echo "  ${method} ${endpoint}"
    
    if [ "$method" = "POST" ]; then
        response=$(curl -s -w "\n%{http_code}" -X POST "${BASE_URL}${endpoint}" \
            -H "Content-Type: application/json" \
            -d "${data}")
    elif [ "$method" = "PUT" ]; then
        response=$(curl -s -w "\n%{http_code}" -X PUT "${BASE_URL}${endpoint}" \
            -H "Content-Type: application/json" \
            -d "${data}")
    elif [ "$method" = "PATCH" ]; then
        response=$(curl -s -w "\n%{http_code}" -X PATCH "${BASE_URL}${endpoint}" \
            -H "Content-Type: application/json" \
            -d "${data}")
    elif [ "$method" = "DELETE" ]; then
        response=$(curl -s -w "\n%{http_code}" -X DELETE "${BASE_URL}${endpoint}")
    else
        response=$(curl -s -w "\n%{http_code}" -X GET "${BASE_URL}${endpoint}")
    fi
    
    http_code=$(echo "$response" | tail -n1)
    body=$(echo "$response" | sed '$d')
    
    if [ "$http_code" -eq "$expected_code" ]; then
        echo -e "${COLOR_GREEN}✓ PASS (${http_code})${COLOR_NC}"
        echo "  Response: $body" | head -c 300
        echo ""
        echo "$body" > /tmp/last_response.json
        return 0
    else
        echo -e "${COLOR_RED}✗ FAIL (Expected ${expected_code}, Got ${http_code})${COLOR_NC}"
        echo "  Response: $body"
        return 1
    fi
}

# Check RabbitMQ queue
check_rabbitmq() {
    echo -e "${COLOR_BLUE}[RABBITMQ] Checking queue: $1${COLOR_NC}"
    curl -s -u guest:guest http://localhost:15672/api/queues 2>/dev/null | python3 -m json.tool 2>/dev/null | grep -A 5 "$1" || echo "  Queue info not available"
}

# Check Redis cache
check_redis() {
    echo -e "${COLOR_BLUE}[REDIS] Checking key: $1${COLOR_NC}"
    redis-cli GET "$1" 2>/dev/null || echo "  Key not found or Redis not accessible"
}

echo "========================================="
echo "PHASE 1: Book Management APIs"
echo "========================================="

# 1. Get all books
test_api "GET" "/api/books" "" "1.1 Get all books"

# 2. Add a book
ADD_BOOK_DATA="{\"title\":\"The Great Gatsby\",\"author\":\"F. Scott Fitzgerald\",\"genre\":\"Fiction\",\"isbn\":\"${BOOK_ISBN}\",\"publisher\":\"Scribner\",\"publicationYear\":2004,\"description\":\"A classic American novel\",\"quantity\":5,\"status\":\"AVAILABLE\"}"
test_api "POST" "/api/books" "$ADD_BOOK_DATA" "1.2 Add new book"
BOOK_ID=$(cat /tmp/last_response.json 2>/dev/null | grep -o '"id":"[^"]*' | head -1 | cut -d'"' -f4)
echo "Created Book ID: $BOOK_ID"

# Check RabbitMQ for book added event
sleep 2
check_rabbitmq "catalog.events.q"

# Check Redis cache
check_redis "book_by_isbn:${BOOK_ISBN}"

# 3. Get book by ID
test_api "GET" "/api/books/${BOOK_ID}" "" "1.3 Get book by ID"

# 4. Get book by ISBN
test_api "GET" "/api/books/isbn/${BOOK_ISBN}" "" "1.4 Get book by ISBN"

# Check Redis cache after ISBN lookup
check_redis "book_by_isbn:${BOOK_ISBN}"

# 5. Update book
UPDATE_BOOK_DATA="{\"title\":\"The Great Gatsby (Updated)\",\"author\":\"F. Scott Fitzgerald\",\"genre\":\"Classic Fiction\",\"isbn\":\"${BOOK_ISBN}\",\"publisher\":\"Scribner\",\"publicationYear\":2004,\"description\":\"An updated description\",\"quantity\":10,\"status\":\"AVAILABLE\"}"
test_api "PUT" "/api/books/${BOOK_ID}" "$UPDATE_BOOK_DATA" "1.5 Update book"

# Check RabbitMQ for book updated event
sleep 2
check_rabbitmq "catalog.events.q"

# 6. Search books by title
SEARCH_DATA="{\"q\":\"Gatsby\"}"
test_api "POST" "/api/books/search" "$SEARCH_DATA" "1.6 Search books by title"

# Check Redis cache for search
check_redis "book_search:Gatsby"

# 7. Get books by author
test_api "GET" "/api/books/author/Fitzgerald" "" "1.7 Get books by author"

# 8. Get books by genre
test_api "GET" "/api/books/genre/Fiction" "" "1.8 Get books by genre"

# 9. Update book status
STATUS_DATA="{\"status\":\"BORROWED\"}"
test_api "PATCH" "/api/books/${BOOK_ID}/status" "$STATUS_DATA" "1.9 Update book status to BORROWED"

# Check RabbitMQ for status update event
sleep 2
check_rabbitmq "catalog.events.q"

# 10. Delete book (204 is correct for DELETE)
test_api "DELETE" "/api/books/${BOOK_ID}" "" "1.10 Delete book" 204

# Check RabbitMQ for book removed event
sleep 2
check_rabbitmq "catalog.events.q"

echo ""
echo "========================================="
echo "PHASE 2: Gateway Routing Test"
echo "========================================="

# Test via Gateway
echo -e "${COLOR_YELLOW}[TEST] 2.1 Test get books via API Gateway${COLOR_NC}"
GATEWAY_RESPONSE=$(curl -s -w "\n%{http_code}" -X GET "${GATEWAY_URL}/api/books")
GATEWAY_CODE=$(echo "$GATEWAY_RESPONSE" | tail -n1)
if [ "$GATEWAY_CODE" -eq 200 ]; then
    echo -e "${COLOR_GREEN}✓ PASS - Gateway routing working${COLOR_NC}"
else
    echo -e "${COLOR_RED}✗ FAIL - Gateway routing failed (${GATEWAY_CODE})${COLOR_NC}"
fi
echo ""

echo ""
echo "========================================="
echo "CATALOG SERVICE TESTING COMPLETE"
echo "========================================="

