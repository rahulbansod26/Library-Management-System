
package com.hashedin.library.user.api;

import com.hashedin.library.common.security.Role;
import com.hashedin.library.user.domain.User;
import com.hashedin.library.user.security.JwtService;
import com.hashedin.library.user.service.UserService;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.Set;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    private final UserService userService;
    private final JwtService jwt;
    private final AuthenticationManager authMgr;

    public AuthController(UserService userService, JwtService jwt, AuthenticationManager authMgr) {
        this.userService = userService; this.jwt = jwt; this.authMgr = authMgr;
    }

    record RegisterReq(@Email String email, @NotBlank String name, @NotBlank String password, Set<Role> roles){}
    record LoginReq(@Email String email, @NotBlank String password){}
    record TokenRes(String token){}
    record LoginSuccessRes(String message, String email, String name){}


    @PostMapping("/register")
    public ResponseEntity<User> register(@RequestBody RegisterReq req){
        User u = userService.register(req.email(), req.name(), req.password(), req.roles());
        return ResponseEntity.ok(u);
    }

    @PostMapping("/User-login")
    public ResponseEntity<LoginSuccessRes> simpleLogin(@RequestBody LoginReq req){
        // Authenticate user with email and password (required for security)
        authMgr.authenticate(new UsernamePasswordAuthenticationToken(req.email(), req.password()));
        
        // Get user details from database
        User user = userService.findByEmail(req.email())
                .orElseThrow(() -> new RuntimeException("User not found"));
        
        return ResponseEntity.ok(new LoginSuccessRes(
                "Login successfully",
                user.getEmail(),
                user.getName()
        ));
    }

    @PostMapping("/login")
    public ResponseEntity<TokenRes> login(@RequestBody LoginReq req){
        Authentication a = authMgr.authenticate(new UsernamePasswordAuthenticationToken(req.email(), req.password()));
        UserDetails ud = (UserDetails)a.getPrincipal();
        String token = jwt.generateToken(ud.getUsername(), Map.of("roles", ud.getAuthorities().toString()));
        return ResponseEntity.ok(new TokenRes(token));
    }

    @PostMapping("/password/forgot")
    public ResponseEntity<Map<String,String>> forgot(@RequestParam("email") String email){
        String token = userService.createResetToken(email);
        return ResponseEntity.ok(Map.of("resetToken", token));
    }

    @PostMapping("/password/reset")
    public ResponseEntity<Map<String, String>> reset(
            @RequestParam("token") String token,
            @RequestParam("newPassword") String newPassword) {

        userService.resetPassword(token, newPassword);
        return ResponseEntity.ok(Map.of("message", "Password successfully reset"));
    }

}
