
package com.hashedin.library.user.api;

import com.hashedin.library.user.domain.User;
import com.hashedin.library.user.repo.UserRepo;
import com.hashedin.library.user.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/profile")
public class ProfileController {
    private final UserService userService;
    private final UserRepo repo;

    public ProfileController(UserService userService, UserRepo repo){ this.userService=userService; this.repo=repo; }

    @GetMapping
    public ResponseEntity<User> getByEmail(@RequestParam("email") String email){
        return repo.findByEmail(email).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    /*@GetMapping
    public ResponseEntity<User> getById(@RequestParam("id") String id){
        return repo.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }*/

    @PutMapping
    public ResponseEntity<User> update(@RequestParam("email") String email, @RequestParam("name") String name){
        User user = repo.findByEmail(email).orElseThrow(() -> new RuntimeException("User not found"));
        return ResponseEntity.ok(userService.updateProfile(user.getId(), name));
    }
}


