
package com.hashedin.library.user.domain;

import com.hashedin.library.common.security.Role;
import jakarta.persistence.*;
import java.time.Instant;
import java.util.Set;

@Entity
@Table(name="users")
public class User {
    @Id @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    @Column(unique = true, nullable = false)
    private String email;
    private String name;
    private String passwordHash;
    @ElementCollection(fetch = FetchType.EAGER)
    @Enumerated(EnumType.STRING)
    private Set<Role> roles;
    private Instant createdAt = Instant.now();

    public String getId(){return id;}
    public String getEmail(){return email;} public void setEmail(String e){this.email=e;}
    public String getName(){return name;} public void setName(String n){this.name=n;}
    public String getPasswordHash(){return passwordHash;} public void setPasswordHash(String p){this.passwordHash=p;}
    public Set<Role> getRoles(){return roles;} public void setRoles(Set<Role> r){this.roles=r;}
    public Instant getCreatedAt(){return createdAt;}
}
