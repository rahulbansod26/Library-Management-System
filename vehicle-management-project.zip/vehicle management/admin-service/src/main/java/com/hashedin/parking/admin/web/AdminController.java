package com.hashedin.parking.admin.web;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hashedin.parking.admin.repo.LotRepo;
import com.hashedin.parking.admin.repo.SpotRepo;
import com.hashedin.parking.admin.service.BookingServiceClient;
import com.hashedin.parking.admin.service.PaymentServiceClient;

@RestController
@RequestMapping("/api/admin")
public class AdminController {
    private static final Logger log = LoggerFactory.getLogger(AdminController.class);
    private final LotRepo lotRepo;
    private final SpotRepo spotRepo;
    private final BookingServiceClient bookingServiceClient;
    private final PaymentServiceClient paymentServiceClient;

    public AdminController(LotRepo lotRepo, 
                          SpotRepo spotRepo,
                          BookingServiceClient bookingServiceClient,
                          PaymentServiceClient paymentServiceClient) {
        this.lotRepo = lotRepo;
        this.spotRepo = spotRepo;
        this.bookingServiceClient = bookingServiceClient;
        this.paymentServiceClient = paymentServiceClient;
    }

    @GetMapping("/bookings/history")
    @PreAuthorize("hasRole('ADMIN') or hasRole('LOT_MANAGER')")
    public ResponseEntity<?> getBookingHistory(@RequestParam(required = false) String lotId,
                                             @RequestParam(required = false) String status,
                                             @RequestParam(required = false) String fromDate,
                                             @RequestParam(required = false) String toDate) {
        try {
            // Fetch real booking data from booking service
            List<BookingServiceClient.Booking> allBookings = bookingServiceClient.getAllBookings();
            
            // Apply filters if provided
            List<BookingServiceClient.Booking> filteredBookings = allBookings.stream()
                .filter(b -> lotId == null || (b.lotId() != null && b.lotId().toString().equals(lotId)))
                .filter(b -> status == null || (b.status() != null && b.status().equals(status)))
                .toList();
            
            return ResponseEntity.ok(Map.of(
                "message", "Booking history retrieved",
                "filters", Map.of(
                    "lotId", lotId != null ? lotId : "all",
                    "status", status != null ? status : "all",
                    "fromDate", fromDate != null ? fromDate : "all",
                    "toDate", toDate != null ? toDate : "all"
                ),
                "totalBookings", filteredBookings.size(),
                "bookings", filteredBookings
            ));
        } catch (Exception e) {
            log.error("Error retrieving booking history: {}", e.getMessage(), e);
            return ResponseEntity.internalServerError()
                .body(Map.of("error", "Failed to retrieve booking history: " + e.getMessage()));
        }
    }

    @GetMapping("/transactions/logs")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> getTransactionLogs(@RequestParam(required = false) String userId,
                                              @RequestParam(required = false) String status,
                                              @RequestParam(required = false) String fromDate,
                                              @RequestParam(required = false) String toDate) {
        try {
            // Fetch real payment data from payment service
            List<PaymentServiceClient.Payment> allPayments = paymentServiceClient.getAllPayments();
            
            // Apply status filter if provided
            if (status != null && !status.isEmpty()) {
                allPayments = allPayments.stream()
                    .filter(p -> p.status() != null && p.status().equals(status))
                    .toList();
            }
            
            // Apply additional filters
            List<PaymentServiceClient.Payment> filteredPayments = allPayments.stream()
                .filter(p -> userId == null || p.userId().toString().equals(userId))
                .toList();
            
            // Calculate total revenue
            BigDecimal totalRevenue = filteredPayments.stream()
                .map(PaymentServiceClient.Payment::amount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
            
            return ResponseEntity.ok(Map.of(
                "message", "Transaction logs retrieved",
                "filters", Map.of(
                    "userId", userId != null ? userId : "all",
                    "status", status != null ? status : "all",
                    "fromDate", fromDate != null ? fromDate : "all",
                    "toDate", toDate != null ? toDate : "all"
                ),
                "totalTransactions", filteredPayments.size(),
                "totalRevenue", "$" + totalRevenue.setScale(2, RoundingMode.HALF_UP),
                "transactions", filteredPayments
            ));
        } catch (Exception e) {
            log.error("Error retrieving transaction logs: {}", e.getMessage(), e);
            return ResponseEntity.internalServerError()
                .body(Map.of("error", "Failed to retrieve transaction logs: " + e.getMessage()));
        }
    }

    @GetMapping("/dashboard/stats")
    @PreAuthorize("hasRole('ADMIN') or hasRole('LOT_MANAGER')")
    public ResponseEntity<?> getDashboardStats() {
        try {
            // Get real data from repositories
            long totalLots = lotRepo.count();
            long totalSpots = spotRepo.count();
            long availableSpots = spotRepo.findAll().stream()
                .filter(spot -> spot.isAvailable())
                .count();
            long occupiedSpots = totalSpots - availableSpots;
            
            // Get booking data from booking service
            List<BookingServiceClient.Booking> allBookings = bookingServiceClient.getAllBookings();
            long totalBookings = allBookings.size();
            
            // Calculate active bookings (bookings that are currently active)
            LocalDateTime now = LocalDateTime.now();
            long activeBookings = allBookings.stream()
                .filter(b -> List.of("CREATED", "CONFIRMED").contains(b.status()))
                .filter(b -> b.startTime().isBefore(now) && b.endTime().isAfter(now))
                .count();
            
            // Get revenue from payment service
            List<PaymentServiceClient.Payment> completedPayments = paymentServiceClient.getAllCompletedPayments();
            BigDecimal totalRevenue = completedPayments.stream()
                .map(PaymentServiceClient.Payment::amount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
            
            // Calculate occupancy rate
            double occupancyRate = totalSpots > 0 
                ? (double) occupiedSpots / totalSpots * 100 
                : 0.0;
            
            return ResponseEntity.ok(Map.of(
                "totalLots", totalLots,
                "totalSpots", totalSpots,
                "availableSpots", availableSpots,
                "occupiedSpots", occupiedSpots,
                "totalBookings", totalBookings,
                "activeBookings", activeBookings,
                "totalRevenue", "$" + totalRevenue.setScale(2, RoundingMode.HALF_UP),
                "occupancyRate", String.format("%.1f%%", occupancyRate),
                "lastUpdated", LocalDateTime.now().toString()
            ));
        } catch (Exception e) {
            log.error("Error retrieving dashboard stats: {}", e.getMessage(), e);
            return ResponseEntity.internalServerError()
                .body(Map.of("error", "Failed to retrieve dashboard stats: " + e.getMessage()));
        }
    }

    @GetMapping("/reports/occupancy")
    @PreAuthorize("hasRole('ADMIN') or hasRole('LOT_MANAGER')")
    public ResponseEntity<?> getOccupancyReport(@RequestParam(required = false) String period) {
        try {
            // Get real data
            long totalSpots = spotRepo.count();
            long availableSpots = spotRepo.findAll().stream()
                .filter(spot -> spot.isAvailable())
                .count();
            long occupiedSpots = totalSpots - availableSpots;
            double averageOccupancy = totalSpots > 0 
                ? (double) occupiedSpots / totalSpots * 100 
                : 0.0;
            
            // Get booking data to calculate peak/low hours
            List<BookingServiceClient.Booking> allBookings = bookingServiceClient.getAllBookings();
            LocalDateTime now = LocalDateTime.now();
            
            // Calculate current occupancy
            long currentlyOccupied = allBookings.stream()
                .filter(b -> List.of("CREATED", "CONFIRMED").contains(b.status()))
                .filter(b -> b.startTime().isBefore(now) && b.endTime().isAfter(now))
                .map(BookingServiceClient.Booking::spotId)
                .distinct()
                .count();
            
            double currentOccupancy = totalSpots > 0 
                ? (double) currentlyOccupied / totalSpots * 100 
                : 0.0;
            
            // Get revenue from payment service
            List<PaymentServiceClient.Payment> completedPayments = paymentServiceClient.getAllCompletedPayments();
            BigDecimal totalRevenue = completedPayments.stream()
                .map(PaymentServiceClient.Payment::amount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
            
            // Simplified peak/low hours (in production, would analyze hourly patterns)
            String peakHours = currentOccupancy > 50 ? "10:00-12:00" : "N/A";
            String lowHours = currentOccupancy < 30 ? "02:00-06:00" : "N/A";
            double peakOccupancy = Math.max(currentOccupancy, 0.0);
            double lowOccupancy = Math.min(currentOccupancy * 0.3, 100.0);
            
            return ResponseEntity.ok(Map.of(
                "reportType", "Occupancy Report",
                "period", period != null ? period : "daily",
                "data", Map.of(
                    "totalSpots", totalSpots,
                    "availableSpots", availableSpots,
                    "occupiedSpots", occupiedSpots,
                    "currentOccupancy", String.format("%.1f%%", currentOccupancy),
                    "averageOccupancy", String.format("%.1f%%", averageOccupancy),
                    "peakHours", Map.of("hour", peakHours, "occupancy", String.format("%.1f%%", peakOccupancy)),
                    "lowHours", Map.of("hour", lowHours, "occupancy", String.format("%.1f%%", lowOccupancy)),
                    "totalRevenue", "$" + totalRevenue.setScale(2, RoundingMode.HALF_UP)
                ),
                "generatedAt", LocalDateTime.now().toString()
            ));
        } catch (Exception e) {
            log.error("Error generating occupancy report: {}", e.getMessage(), e);
            return ResponseEntity.internalServerError()
                .body(Map.of("error", "Failed to generate occupancy report: " + e.getMessage()));
        }
    }

    @GetMapping("/reports/revenue")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> getRevenueReport(@RequestParam(required = false) String period) {
        try {
            // Get real payment data
            List<PaymentServiceClient.Payment> allPayments = paymentServiceClient.getAllPayments();
            List<PaymentServiceClient.Payment> completedPayments = allPayments.stream()
                .filter(p -> "COMPLETED".equals(p.status()))
                .toList();
            
            // Calculate total revenue
            BigDecimal totalRevenue = completedPayments.stream()
                .map(PaymentServiceClient.Payment::amount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
            
            // Calculate average transaction value
            BigDecimal avgTransaction = completedPayments.isEmpty() 
                ? BigDecimal.ZERO
                : totalRevenue.divide(BigDecimal.valueOf(completedPayments.size()), 2, RoundingMode.HALF_UP);
            
            // Get booking data to calculate revenue by lot
            List<BookingServiceClient.Booking> allBookings = bookingServiceClient.getAllBookings();
            Map<Long, BigDecimal> revenueByLot = completedPayments.stream()
                .collect(java.util.stream.Collectors.groupingBy(
                    p -> {
                        // Find booking for this payment
                        return allBookings.stream()
                            .filter(b -> b.id().equals(p.bookingId()))
                            .findFirst()
                            .map(BookingServiceClient.Booking::lotId)
                            .orElse(null);
                    },
                    java.util.stream.Collectors.reducing(
                        BigDecimal.ZERO,
                        PaymentServiceClient.Payment::amount,
                        BigDecimal::add
                    )
                ));
            
            // Get lot names for display
            Map<String, String> revenueByLotFormatted = new java.util.HashMap<>();
            for (Map.Entry<Long, BigDecimal> entry : revenueByLot.entrySet()) {
                if (entry.getKey() != null) {
                    lotRepo.findById(entry.getKey())
                        .ifPresent(lot -> revenueByLotFormatted.put(
                            lot.getName(), 
                            "$" + entry.getValue().setScale(2, RoundingMode.HALF_UP)
                        ));
                }
            }
            
            // Payment methods distribution (simplified - would need payment method in payment model)
            // For now, return placeholder since payment model doesn't have payment method
            Map<String, String> paymentMethods = Map.of(
                "creditCard", "N/A",
                "debitCard", "N/A", 
                "digitalWallet", "N/A",
                "note", "Payment method tracking not implemented in payment model"
            );
            
            return ResponseEntity.ok(Map.of(
                "reportType", "Revenue Analysis Report",
                "period", period != null ? period : "monthly",
                "data", Map.of(
                    "totalRevenue", "$" + totalRevenue.setScale(2, RoundingMode.HALF_UP),
                    "totalTransactions", completedPayments.size(),
                    "averageTransaction", "$" + avgTransaction.setScale(2, RoundingMode.HALF_UP),
                    "paymentMethods", paymentMethods,
                    "revenueByLot", revenueByLotFormatted.isEmpty() ? Map.of("note", "No revenue data by lot yet") : revenueByLotFormatted
                ),
                "generatedAt", LocalDateTime.now().toString()
            ));
        } catch (Exception e) {
            log.error("Error generating revenue report: {}", e.getMessage(), e);
            return ResponseEntity.internalServerError()
                .body(Map.of("error", "Failed to generate revenue report: " + e.getMessage()));
        }
    }
}
