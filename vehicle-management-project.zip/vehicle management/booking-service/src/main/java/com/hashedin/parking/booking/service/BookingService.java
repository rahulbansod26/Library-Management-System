package com.hashedin.parking.booking.service;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hashedin.parking.booking.model.Booking;
import com.hashedin.parking.booking.model.Waitlist;
import com.hashedin.parking.booking.repo.BookingRepo;
import com.hashedin.parking.common.events.Events;

@Service
public class BookingService {
    private static final Logger log = LoggerFactory.getLogger(BookingService.class);

    private final BookingRepo bookingRepo;
    private final AvailabilityCache availabilityCache;
    private final WaitlistService waitlistService;
    private final RabbitTemplate rabbitTemplate;
    private final String exchange;
    private final String bookingCreatedRoutingKey;
    private final String bookingCancelledRoutingKey;

    public BookingService(BookingRepo bookingRepo,
                         AvailabilityCache availabilityCache,
                         WaitlistService waitlistService,
                         RabbitTemplate rabbitTemplate,
                         @Value("${app.rabbit.exchange}") String exchange,
                         @Value("${app.rabbit.routing.bookingCreated}") String bookingCreatedRoutingKey,
                         @Value("${app.rabbit.routing.bookingCancelled}") String bookingCancelledRoutingKey) {
        this.bookingRepo = bookingRepo;
        this.availabilityCache = availabilityCache;
        this.waitlistService = waitlistService;
        this.rabbitTemplate = rabbitTemplate;
        this.exchange = exchange;
        this.bookingCreatedRoutingKey = bookingCreatedRoutingKey;
        this.bookingCancelledRoutingKey = bookingCancelledRoutingKey;
    }

    public List<Booking> getUserBookings(UUID userId) {
        return bookingRepo.findByUserId(userId);
    }

    public Optional<Booking> getBookingById(UUID bookingId, UUID userId) {
        return bookingRepo.findById(bookingId).map(booking -> {
            if (!booking.getUserId().equals(userId)) {
                throw new IllegalArgumentException("Forbidden");
            }
            return booking;
        });
    }

    @Transactional
    public Map<String, Object> createBooking(UUID userId, Long lotId, Long spotId, 
                                           LocalDateTime startTime, LocalDateTime endTime) {
        String windowKey = startTime + ":" + endTime;
        
        // Check cache for availability
        if (availabilityCache.isUnavailable(spotId, windowKey)) {
            throw new IllegalArgumentException("Spot unavailable for window");
        }
        
        // Check database for conflicts
        boolean dbConflict = bookingRepo.existsBySpotIdAndStatusInAndStartTimeLessThanEqualAndEndTimeGreaterThanEqual(
                spotId, List.of("CREATED", "CONFIRMED"), endTime, startTime);
        
        if (dbConflict) {
            // Add to waitlist instead of failing
            try {
                Waitlist waitlistEntry = waitlistService.addToWaitlist(
                    userId, lotId, spotId, startTime, endTime
                );
                return Map.of(
                    "message", "spot unavailable, added to waitlist",
                    "waitlistId", waitlistEntry.getId(),
                    "position", waitlistService.getUserWaitlist(userId).size()
                );
            } catch (IllegalArgumentException e) {
                throw new IllegalArgumentException(e.getMessage());
            }
        }

        Booking booking = new Booking();
        booking.setUserId(userId);
        booking.setLotId(lotId);
        booking.setSpotId(spotId);
        booking.setStartTime(startTime);
        booking.setEndTime(endTime);
        booking.setStatus("CREATED");
        
        Booking savedBooking = bookingRepo.save(booking);

        // Update cache
        long ttl = Math.max(Duration.between(LocalDateTime.now(), endTime).toSeconds(), 60);
        availabilityCache.setUnavailable(spotId, windowKey, ttl);

        // Process booking confirmation asynchronously
        confirmBookingAsync(savedBooking);

        return Map.of("booking", savedBooking);
    }

    @Transactional
    public Map<String, Object> updateBooking(UUID bookingId, UUID userId, Long lotId, Long spotId,
                                           LocalDateTime startTime, LocalDateTime endTime) {
        Booking booking = bookingRepo.findById(bookingId)
            .orElseThrow(() -> new IllegalArgumentException("Booking not found"));
            
        if (!booking.getUserId().equals(userId)) {
            throw new IllegalArgumentException("Forbidden");
        }
        
        // Only allow updates for CREATED bookings
        if (!"CREATED".equals(booking.getStatus())) {
            throw new IllegalArgumentException("Can only update CREATED bookings");
        }
        
        boolean hasChanges = false;
        
        if (lotId != null && !lotId.equals(booking.getLotId())) {
            booking.setLotId(lotId);
            hasChanges = true;
        }
        
        if (spotId != null && !spotId.equals(booking.getSpotId())) {
            // Clear old cache entry
            String oldWindowKey = booking.getStartTime() + ":" + booking.getEndTime();
            availabilityCache.evict(booking.getSpotId(), oldWindowKey);
            
            booking.setSpotId(spotId);
            hasChanges = true;
        }
        
        if (startTime != null && !startTime.equals(booking.getStartTime())) {
            booking.setStartTime(startTime);
            hasChanges = true;
        }
        
        if (endTime != null && !endTime.equals(booking.getEndTime())) {
            booking.setEndTime(endTime);
            hasChanges = true;
        }
        
        if (!hasChanges) {
            return Map.of("message", "no changes detected");
        }
        
        // Validate new time slot availability
        String newWindowKey = booking.getStartTime() + ":" + booking.getEndTime();
        if (availabilityCache.isUnavailable(booking.getSpotId(), newWindowKey)) {
            throw new IllegalArgumentException("Spot unavailable for new time window");
        }
        
        // Check for conflicts with new time slot
        boolean dbConflict = bookingRepo.existsBySpotIdAndStatusInAndStartTimeLessThanEqualAndEndTimeGreaterThanEqual(
                booking.getSpotId(), List.of("CREATED", "CONFIRMED"), 
                booking.getEndTime(), booking.getStartTime());
        
        // Exclude current booking from conflict check
        if (dbConflict) {
            List<Booking> conflictingBookings = bookingRepo.findAll().stream()
                .filter(b -> b.getSpotId().equals(booking.getSpotId()) &&
                           List.of("CREATED", "CONFIRMED").contains(b.getStatus()) &&
                           !b.getId().equals(booking.getId()) &&
                           b.getStartTime().isBefore(booking.getEndTime()) &&
                           b.getEndTime().isAfter(booking.getStartTime()))
                .toList();
            
            if (!conflictingBookings.isEmpty()) {
                throw new IllegalArgumentException("Spot conflict with existing booking");
            }
        }
        
        Booking savedBooking = bookingRepo.save(booking);
        
        // Update cache with new availability
        long ttl = Math.max(Duration.between(LocalDateTime.now(), booking.getEndTime()).toSeconds(), 60);
        availabilityCache.setUnavailable(booking.getSpotId(), newWindowKey, ttl);
        
        // Publish booking updated event
        rabbitTemplate.convertAndSend(
                exchange,
                bookingCreatedRoutingKey,
                new Events.BookingCreated(
                        savedBooking.getId(),
                        savedBooking.getUserId(),
                        savedBooking.getLotId(),
                        savedBooking.getSpotId(),
                        savedBooking.getStartTime(),
                        savedBooking.getEndTime()
                )
        );
        
        return Map.of("message", "booking updated successfully", "booking", savedBooking);
    }

    @Transactional
    public Map<String, Object> cancelBooking(UUID bookingId, UUID userId) {
        Booking booking = bookingRepo.findById(bookingId)
            .orElseThrow(() -> new IllegalArgumentException("Booking not found"));
            
        if (!booking.getUserId().equals(userId)) {
            throw new IllegalArgumentException("Forbidden");
        }

        booking.setStatus("CANCELLED");
        bookingRepo.save(booking);

        // Process cancellation asynchronously (cache cleanup, waitlist, events)
        cancelBookingAsync(booking);

        return Map.of("message", "Booking cancellation initiated. Processing in background.");
    }

    public List<Booking> getPastBookings(UUID userId) {
        return bookingRepo.findByEndTimeBeforeAndUserId(LocalDateTime.now(), userId);
    }

    public List<Booking> getFutureBookings(UUID userId) {
        return bookingRepo.findByStartTimeAfterAndUserId(LocalDateTime.now(), userId);
    }

    public List<Waitlist> getUserWaitlist(UUID userId) {
        return waitlistService.getUserWaitlist(userId);
    }

    @Transactional
    public Map<String, Object> addToWaitlist(UUID userId, Long lotId, Long spotId,
                                           LocalDateTime startTime, LocalDateTime endTime) {
        try {
            Waitlist waitlistEntry = waitlistService.addToWaitlist(
                userId, lotId, spotId, startTime, endTime
            );
            return Map.of(
                "message", "added to waitlist",
                "waitlistId", waitlistEntry.getId(),
                "position", waitlistService.getUserWaitlist(userId).size()
            );
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException(e.getMessage());
        }
    }

    public Map<String, Object> cancelWaitlistEntry(UUID userId, UUID waitlistId) {
        waitlistService.cancelWaitlistEntry(userId, waitlistId);
        return Map.of("message", "waitlist entry cancelled");
    }

    public List<Booking> getUpcomingBookings(int hours) {
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime future = now.plusHours(hours);
        
        // Get all bookings starting between now and future time
        // Only return CREATED or CONFIRMED bookings
        return bookingRepo.findAll().stream()
            .filter(b -> List.of("CREATED", "CONFIRMED").contains(b.getStatus()))
            .filter(b -> b.getStartTime().isAfter(now) && b.getStartTime().isBefore(future))
            .toList();
    }

    @Async("bookingTaskExecutor")
    @Transactional
    public void confirmBookingAsync(Booking booking) {
        try {
            log.info("Processing async booking confirmation for booking: {}", booking.getId());
            
            // Update booking status to CONFIRMED if it's still CREATED
            Booking currentBooking = bookingRepo.findById(booking.getId())
                .orElseThrow(() -> new IllegalArgumentException("Booking not found during async confirmation"));
            
            if ("CREATED".equals(currentBooking.getStatus())) {
                currentBooking.setStatus("CONFIRMED");
                bookingRepo.save(currentBooking);
                log.info("Booking {} confirmed", booking.getId());
            }

            // Publish booking created/confirmed event asynchronously
            rabbitTemplate.convertAndSend(
                    exchange,
                    bookingCreatedRoutingKey,
                    new Events.BookingCreated(
                            currentBooking.getId(),
                            currentBooking.getUserId(),
                            currentBooking.getLotId(),
                            currentBooking.getSpotId(),
                            currentBooking.getStartTime(),
                            currentBooking.getEndTime()
                    )
            );
            
            log.info("Booking confirmation event published for booking: {}", booking.getId());
        } catch (Exception e) {
            log.error("Error confirming booking {}: {}", booking.getId(), e.getMessage(), e);
        }
    }

    @Async("bookingTaskExecutor")
    @Transactional
    public void cancelBookingAsync(Booking booking) {
        try {
            log.info("Processing async booking cancellation for booking: {}", booking.getId());
            
            // Clear cache entry for this booking
            String windowKey = booking.getStartTime() + ":" + booking.getEndTime();
            availabilityCache.evict(booking.getSpotId(), windowKey);
            log.debug("Cleared availability cache for booking {}", booking.getId());

            // Process waitlist for this spot and time window
            waitlistService.processWaitlistForSpot(
                booking.getSpotId(),
                booking.getStartTime(),
                booking.getEndTime()
            );
            log.debug("Processed waitlist for cancelled booking {}", booking.getId());

            // Publish booking cancelled event
            rabbitTemplate.convertAndSend(
                    exchange,
                    bookingCancelledRoutingKey,
                    new Events.BookingCancelled(booking.getId(), booking.getUserId())
            );
            
            log.info("Booking cancellation event published for booking: {}", booking.getId());
        } catch (Exception e) {
            log.error("Error cancelling booking {}: {}", booking.getId(), e.getMessage(), e);
        }
    }
}
