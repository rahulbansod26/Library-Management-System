package com.hashedin.parking.booking.mq;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.hashedin.parking.booking.model.Booking;
import com.hashedin.parking.booking.repo.BookingRepo;
import com.hashedin.parking.booking.service.BookingService;
import com.hashedin.parking.common.events.Events;

@Component
public class PaymentStatusListener {
    private static final Logger log = LoggerFactory.getLogger(PaymentStatusListener.class);
    
    private final BookingRepo bookingRepo;
    private final BookingService bookingService;

    public PaymentStatusListener(BookingRepo bookingRepo, BookingService bookingService) {
        this.bookingRepo = bookingRepo;
        this.bookingService = bookingService;
    }

    @RabbitListener(queues = "${app.rabbit.queues.bookingService.paymentStatus}")
    @Transactional
    public void onPaymentStatusChanged(Events.PaymentStatusChanged ev) {
        log.info("Received payment status changed event: paymentId={}, bookingId={}, status={}", 
            ev.paymentId(), ev.bookingId(), ev.status());
        
        // If payment failed, cancel the booking and make slot available
        if ("FAILED".equals(ev.status())) {
            try {
                Booking booking = bookingRepo.findById(ev.bookingId())
                    .orElse(null);
                
                if (booking == null) {
                    log.warn("Booking {} not found for failed payment {}", ev.bookingId(), ev.paymentId());
                    return;
                }
                
                // Only cancel if booking is still active (CREATED or CONFIRMED)
                if ("CREATED".equals(booking.getStatus()) || "CONFIRMED".equals(booking.getStatus())) {
                    log.info("Cancelling booking {} due to failed payment {}", booking.getId(), ev.paymentId());
                    
                    // Use the booking service's cancel method to handle cleanup properly
                    // This will trigger cache cleanup, waitlist processing, and events
                    booking.setStatus("CANCELLED");
                    bookingRepo.save(booking);
                    
                    // Trigger async cancellation processing (cache cleanup, waitlist, events)
                    bookingService.cancelBookingAsync(booking);
                    
                    log.info("Booking {} cancelled successfully due to failed payment. Slot is now available.", booking.getId());
                } else {
                    log.info("Booking {} is already in status {}, not cancelling", booking.getId(), booking.getStatus());
                }
            } catch (Exception e) {
                log.error("Error cancelling booking {} for failed payment {}: {}", 
                    ev.bookingId(), ev.paymentId(), e.getMessage(), e);
            }
        }
    }
}

