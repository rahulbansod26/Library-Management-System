module.exports = {
  webpack: {
    configure: (webpackConfig) => {
      webpackConfig.ignoreWarnings = [
        {
          module: /source-map-loader/,
        },
      ];
      return webpackConfig;
    },
  },
};
