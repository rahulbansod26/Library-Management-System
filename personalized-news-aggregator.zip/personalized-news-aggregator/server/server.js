const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const fs = require('fs').promises;
const path = require('path');
const jwt = require('jsonwebtoken');
const axios = require('axios');
const nodemailer = require('nodemailer');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3001;
const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production';
const NEWSAPI_KEY = process.env.NEWSAPI_KEY || process.env.REACT_APP_NEWSAPI_KEY;

const DB_PATH = path.join(__dirname, '..', 'server_db.json');

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Helper function to read/write DB
async function readDB() {
  try {
    const data = await fs.readFile(DB_PATH, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    return { users: [] };
  }
}

async function writeDB(data) {
  await fs.writeFile(DB_PATH, JSON.stringify(data, null, 2));
}

// Auth middleware
function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.sendStatus(401);
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) return res.sendStatus(403);
    req.user = user;
    next();
  });
}

// News API Proxy
app.get('/api/news', async (req, res) => {
  try {
    const { q = 'latest', pageSize = 20, sortBy = 'publishedAt' } = req.query;
    
    if (!NEWSAPI_KEY) {
      return res.status(500).json({ error: 'NewsAPI key not configured' });
    }

    const url = `https://newsapi.org/v2/everything?q=${encodeURIComponent(q)}&pageSize=${pageSize}&sortBy=${sortBy}&apiKey=${NEWSAPI_KEY}`;
    const response = await axios.get(url);
    
    res.json(response.data);
  } catch (error) {
    console.error('News API error:', error);
    res.status(500).json({ error: 'Failed to fetch news' });
  }
});

// Auth endpoints
app.post('/api/auth/register', async (req, res) => {
  try {
    const { email, password, name } = req.body;
    const db = await readDB();
    
    if (db.users.find(u => u.email === email)) {
      return res.status(400).json({ error: 'User already exists' });
    }

    const user = {
      id: Date.now().toString(),
      email,
      password, // In production, hash this!
      name,
      createdAt: new Date().toISOString()
    };

    db.users.push(user);
    await writeDB(db);

    const token = jwt.sign({ id: user.id, email: user.email }, JWT_SECRET);
    res.json({ token, user: { id: user.id, email: user.email, name: user.name } });
  } catch (error) {
    console.error('Register error:', error);
    res.status(500).json({ error: 'Registration failed' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const db = await readDB();
    
    const user = db.users.find(u => u.email === email && u.password === password);
    if (!user) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const token = jwt.sign({ id: user.id, email: user.email }, JWT_SECRET);
    res.json({ token, user: { id: user.id, email: user.email, name: user.name } });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Login failed' });
  }
});

// User preferences endpoints
app.get('/api/user/preferences', authenticateToken, async (req, res) => {
  try {
    const db = await readDB();
    const user = db.users.find(u => u.id === req.user.id);
    res.json(user?.preferences || {});
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch preferences' });
  }
});

app.put('/api/user/preferences', authenticateToken, async (req, res) => {
  try {
    const db = await readDB();
    const user = db.users.find(u => u.id === req.user.id);
    if (user) {
      user.preferences = { ...user.preferences, ...req.body };
      await writeDB(db);
      res.json(user.preferences);
    } else {
      res.status(404).json({ error: 'User not found' });
    }
  } catch (error) {
    res.status(500).json({ error: 'Failed to update preferences' });
  }
});

// Bookmarks endpoints
app.get('/api/user/bookmarks', authenticateToken, async (req, res) => {
  try {
    const db = await readDB();
    const user = db.users.find(u => u.id === req.user.id);
    res.json(user?.bookmarks || []);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch bookmarks' });
  }
});

app.post('/api/user/bookmarks', authenticateToken, async (req, res) => {
  try {
    const db = await readDB();
    const user = db.users.find(u => u.id === req.user.id);
    if (user) {
      if (!user.bookmarks) user.bookmarks = [];
      user.bookmarks.push(req.body);
      await writeDB(db);
      res.json(user.bookmarks);
    } else {
      res.status(404).json({ error: 'User not found' });
    }
  } catch (error) {
    res.status(500).json({ error: 'Failed to add bookmark' });
  }
});

app.delete('/api/user/bookmarks/:id', authenticateToken, async (req, res) => {
  try {
    const db = await readDB();
    const user = db.users.find(u => u.id === req.user.id);
    if (user && user.bookmarks) {
      user.bookmarks = user.bookmarks.filter(b => b.id !== req.params.id);
      await writeDB(db);
      res.json(user.bookmarks);
    } else {
      res.status(404).json({ error: 'Bookmark not found' });
    }
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete bookmark' });
  }
});

// Email notification endpoint
app.post('/api/notifications/email', async (req, res) => {
  try {
    const { email, title, message, article } = req.body;

    if (!email || !title || !message) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    // Configure email transporter (using Gmail as example - you'll need to set up your own)
    // For production, use environment variables for email credentials
    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: process.env.EMAIL_USER || 'your-email@gmail.com',
        pass: process.env.EMAIL_PASS || 'your-app-password',
      },
    });

    // If email credentials are not configured, log the notification instead
    if (!process.env.EMAIL_USER || !process.env.EMAIL_PASS) {
      console.log('📧 Email Notification (not sent - credentials not configured):');
      console.log(`   To: ${email}`);
      console.log(`   Subject: ${title}`);
      console.log(`   Message: ${message}`);
      if (article) {
        console.log(`   Article: ${article.title} - ${article.url}`);
      }
      return res.json({ 
        success: true, 
        message: 'Email notification logged (credentials not configured)',
        note: 'To enable email sending, set EMAIL_USER and EMAIL_PASS environment variables'
      });
    }

    // Build email content
    let htmlContent = `
      <h2>${title}</h2>
      <p>${message}</p>
    `;

    if (article) {
      htmlContent += `
        <hr>
        <h3>${article.title}</h3>
        ${article.source ? `<p><strong>Source:</strong> ${article.source}</p>` : ''}
        <p><a href="${article.url}" target="_blank">Read Article →</a></p>
      `;
    }

    htmlContent += `
      <hr>
      <p style="color: #666; font-size: 12px;">
        You're receiving this because you enabled email notifications in your Personalized News account.
        <br>
        <a href="http://localhost:3000/profile">Manage notification settings</a>
      </p>
    `;

    // Send email
    const mailOptions = {
      from: process.env.EMAIL_USER,
      to: email,
      subject: `🔔 ${title} - Personalized News`,
      html: htmlContent,
      text: `${title}\n\n${message}${article ? `\n\n${article.title}\n${article.url}` : ''}`,
    };

    await transporter.sendMail(mailOptions);
    
    res.json({ success: true, message: 'Email notification sent successfully' });
  } catch (error) {
    console.error('Email notification error:', error);
    res.status(500).json({ 
      error: 'Failed to send email notification',
      details: error.message 
    });
  }
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
  console.log(`NewsAPI Key configured: ${NEWSAPI_KEY ? 'Yes' : 'No'}`);
  console.log(`📧 Email notifications: ${process.env.EMAIL_USER ? 'Configured' : 'Not configured (set EMAIL_USER and EMAIL_PASS)'}`);
});

