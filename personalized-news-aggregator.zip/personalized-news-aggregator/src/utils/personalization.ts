// src/utils/personalization.ts
import { Article } from "../types";
import { UserProfile } from "../types";

/**
 * Calculate personalized score for an article based on user preferences and engagement
 */
export function calculateArticleScore(article: Article, user: UserProfile | null): number {
  if (!user || !user.preferences) return 0;

  let score = 0;
  const weights = user.preferences.weights || {};
  const excludedCategories = user.preferences.excludedCategories || [];
  const excludedSources = user.preferences.excludedSources || [];
  const excludedKeywords = user.preferences.excludedKeywords || [];

  // Check if article should be excluded
  const articleSource = article.source?.name?.toLowerCase() || '';
  const articleTitle = article.title?.toLowerCase() || '';
  const articleDescription = article.description?.toLowerCase() || '';
  const articleText = `${articleTitle} ${articleDescription}`;
  const articleCategory = article.category?.toLowerCase() || '';

  // Exclude if category is in excluded list (check both explicit category and text content)
  if (excludedCategories.length > 0) {
    // Check explicit category field
    if (articleCategory && excludedCategories.some(ex => ex.toLowerCase() === articleCategory)) {
      return -1000; // Strong negative score to filter out
    }
    
    // Also check if category name appears in article text (fallback for articles without category field)
    if (excludedCategories.some(ex => {
      const cat = ex.toLowerCase().trim();
      if (!cat) return false;
      // Match whole word to avoid false positives
      const pattern = new RegExp(`\\b${cat}\\b`, 'i');
      return pattern.test(articleText);
    })) {
      return -1000;
    }
  }

  // Exclude if source is in excluded list
  if (excludedSources.some(ex => articleSource.includes(ex.toLowerCase()))) {
    return -1000; // Strong negative score to filter out
  }

  // Exclude if keywords match excluded keywords
  // Match whole words and common variations (e.g., "india" matches "India", "Indian", "Indians")
  if (excludedKeywords.some(ex => {
    const keyword = ex.toLowerCase().trim();
    if (!keyword) return false;
    
    // Create regex pattern to match whole word and common variations
    // e.g., "india" will match "india", "indian", "indians", "india's"
    const baseWord = keyword.replace(/s$/, ''); // Remove trailing 's' for plurals
    const pattern = new RegExp(`\\b${baseWord}[a-z]*\\b`, 'i'); // Match word boundary + base + optional letters
    
    return pattern.test(articleText);
  })) {
    return -1000;
  }

  // Score based on interest weights
  // Check source weight
  if (articleSource && weights[articleSource]) {
    score += weights[articleSource] * 0.4;
  }

  // Check keyword weights in title and description
  const words = articleText.split(/\s+/).filter(w => w.length > 3);
  words.forEach(word => {
    if (weights[word]) {
      score += weights[word] * 0.1;
    }
  });

  // Boost score if article matches preferred categories
  if (user.preferences.categories && user.preferences.categories.length > 0) {
    // This is a simplified check - in a real app, you'd map articles to categories
    const preferredCategories = user.preferences.categories.map(c => c.toLowerCase());
    if (preferredCategories.some(cat => articleText.includes(cat))) {
      score += 0.3;
    }
  }

  // Boost score if article matches preferred sources
  if (user.preferences.sources && user.preferences.sources.length > 0) {
    const preferredSources = user.preferences.sources.map(s => s.toLowerCase());
    if (preferredSources.some(src => articleSource.includes(src))) {
      score += 0.3;
    }
  }

  // Boost score if article matches preferred keywords
  if (user.preferences.keywords && user.preferences.keywords.length > 0) {
    const preferredKeywords = user.preferences.keywords.map(k => k.toLowerCase());
    const matches = preferredKeywords.filter(kw => articleText.includes(kw)).length;
    score += matches * 0.2;
  }

  // Check if user has already read this article (slight penalty)
  const hasRead = user.history.some(h => h.id === article.id);
  if (hasRead) {
    score -= 0.1;
  }

  // Check if user has bookmarked this article (boost)
  const isBookmarked = user.bookmarks.some(b => b.id === article.id);
  if (isBookmarked) {
    score += 0.2;
  }

  // Analyze reading history to refine recommendations
  // Boost articles similar to what the user has read
  if (user.history && user.history.length > 0) {
    // Extract patterns from reading history
    const readSources = new Map<string, number>();
    const readKeywords = new Map<string, number>();
    const readCategories = new Map<string, number>();
    
    // Analyze reading history to find patterns
    user.history.forEach((readEvent) => {
      // Count sources
      if (readEvent.source) {
        const source = readEvent.source.toLowerCase();
        readSources.set(source, (readSources.get(source) || 0) + 1);
      }
      
      // Extract keywords from titles (what they've been reading about)
      if (readEvent.title) {
        const titleWords = readEvent.title.toLowerCase().split(/\s+/).filter(w => w.length > 3);
        titleWords.forEach(word => {
          readKeywords.set(word, (readKeywords.get(word) || 0) + 1);
        });
      }
    });

    // Boost score if article source matches frequently read sources
    if (articleSource && readSources.has(articleSource)) {
      const readCount = readSources.get(articleSource) || 0;
      // More reads = higher boost (capped at 0.5)
      score += Math.min(readCount * 0.1, 0.5);
    }

    // Boost score if article keywords match frequently read keywords
    const articleWords = articleText.split(/\s+/).filter(w => w.length > 3);
    articleWords.forEach(word => {
      if (readKeywords.has(word)) {
        const readCount = readKeywords.get(word) || 0;
        // Boost based on how often this keyword appears in reading history
        score += Math.min(readCount * 0.05, 0.3);
      }
    });

    // Boost articles from sources the user frequently reads
    // (even if not explicitly preferred, reading behavior shows interest)
    if (articleSource) {
      const sourceReadCount = readSources.get(articleSource) || 0;
      if (sourceReadCount >= 2) {
        // User has read 2+ articles from this source - show preference
        score += 0.2;
      }
    }
  }

  return score;
}

/**
 * Rank and deduplicate articles based on personalized scores
 */
export function rankAndDeduplicateArticles(
  articles: Article[],
  user: UserProfile | null
): Article[] {
  // Deduplicate by URL
  const seenUrls = new Set<string>();
  const uniqueArticles = articles.filter(article => {
    if (!article.url) return false;
    if (seenUrls.has(article.url)) return false;
    seenUrls.add(article.url);
    return true;
  });

  // Calculate scores and sort
  const scoredArticles = uniqueArticles.map(article => ({
    article,
    score: calculateArticleScore(article, user),
  }));

  // Sort by score (descending)
  scoredArticles.sort((a, b) => b.score - a.score);

  // Return articles with scores attached
  return scoredArticles.map(({ article, score }) => ({
    ...article,
    score,
  }));
}

