// src/utils/storage.ts
import { UserProfile } from "../types";

export function readCurrentUser(): UserProfile | null {
  const ref = JSON.parse(localStorage.getItem("user") || "null");
  if (!ref?.email) return null;
  const users = JSON.parse(localStorage.getItem("users") || "{}");
  return users[ref.email] ?? null;
}

export function saveUser(user: UserProfile) {
  const all = JSON.parse(localStorage.getItem("users") || "{}");
  all[user.email] = user;
  localStorage.setItem("users", JSON.stringify(all));
  localStorage.setItem("user", JSON.stringify({ email: user.email }));
}

export function removeCurrentUserPointer() {
  localStorage.removeItem("user");
}
