// src/api/newsApi.ts
import axios from 'axios';

const API_KEY = process.env.REACT_APP_NEWSAPI_KEY;
const BASE_URL = 'https://newsapi.org/v2/everything';

interface FetchNewsParams {
  q?: string;
  pageSize?: number;
  sortBy?: 'relevancy' | 'popularity' | 'publishedAt';
}

export async function fetchNews({ q = 'latest', pageSize = 20, sortBy = 'publishedAt' }: FetchNewsParams) {
  const url = `${BASE_URL}?q=${encodeURIComponent(q)}&pageSize=${pageSize}&sortBy=${sortBy}&apiKey=${API_KEY}`;
  const response = await axios.get(url);
  return response.data;
}
