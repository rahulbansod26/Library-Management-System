// src/App.tsx
import React from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import Feed from "./features/news/Feed";
import Bookmarks from "./features/bookmarks/Bookmarks";
import Analytics from "./features/analytics/Analytics";
import Profile from "./features/profile/Profile";
import Preferences from "./features/preferences/Preferences";
import ArticleDetail from "./features/article/ArticleDetail";
import Login from "./features/auth/Login";
import Header from "./components/Header";
import NotificationToast from "./components/NotificationToast";
import { ThemeProvider } from "./context/ThemeContext";
import { UserProvider } from "./context/UserContext";
import { NotificationProvider } from "./context/NotificationContext";

export default function App() {
  return (
    <ThemeProvider>
      <UserProvider>
        <NotificationProvider>
          <Router>
            <Header />
            <NotificationToast />
            <main className="min-h-screen transition-all duration-300">
              <Routes>
                <Route path="/" element={<Navigate to="/feed" replace />} />
                <Route path="/feed" element={<Feed />} />
                <Route path="/article/:articleId" element={<ArticleDetail />} />
                <Route path="/bookmarks" element={<Bookmarks />} />
                <Route path="/analytics" element={<Analytics />} />
                <Route path="/profile" element={<Profile />} />
                <Route path="/preferences" element={<Preferences />} />
                <Route path="/login" element={<Login />} />
              </Routes>
            </main>
          </Router>
        </NotificationProvider>
      </UserProvider>
    </ThemeProvider>
  );
}
