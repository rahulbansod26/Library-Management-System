import { configureStore } from '@reduxjs/toolkit';
import authReducer from '../features/auth/authSlice';
import newsReducer from '../features/news/newsSlice';
import prefsReducer from '../features/prefs/prefsSlice';
import bookmarksReducer from '../features/bookmarks/bookmarksSlice';

export const store = configureStore({
  reducer: {
    auth: authReducer,
    news: newsReducer,
    prefs: prefsReducer,
    bookmarks: bookmarksReducer
  }
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
