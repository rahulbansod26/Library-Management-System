import { configureStore } from '@reduxjs/toolkit';
import newsReducer from '../features/news/newsSlice';
import bookmarksReducer from '../features/bookmarks/bookmarksSlice';
import prefsReducer from '../features/prefs/prefsSlice';
import authReducer from '../features/auth/authSlice';

const store = configureStore({
  reducer: {
     auth: authReducer,
    news: newsReducer,
    bookmarks: bookmarksReducer,
    prefs: prefsReducer,
  },
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
export default store;
