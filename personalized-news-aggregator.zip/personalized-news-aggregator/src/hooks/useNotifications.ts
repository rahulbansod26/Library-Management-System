export type Article = {
  id: string;
  title: string;
  description?: string;
  content?: string;
  url: string;
  urlToImage?: string;
  publishedAt?: string;
  source: { id?: string | null; name: string };
  category?: string;
};

export type UserPreferences = {
  categories: string[];
  keywords: string[];
  sources: string[];
};

export type UserProfile = {
  name: string;
  email: string;
  password: string;
  bookmarks: Article[];
  history: Article[];
  preferences: UserPreferences;
};
