// src/components/NotificationToast.tsx
import React from "react";
import { useNotifications } from "../context/NotificationContext";

export default function NotificationToast() {
  const { notifications, dismissNotification } = useNotifications();

  return (
    <div className="fixed top-20 left-1/2 transform -translate-x-1/2 z-50 space-y-2">
      {notifications.map((notification) => (
        <div
          key={notification.id}
          className={`min-w-[400px] max-w-md w-full shadow-xl rounded-lg pointer-events-auto ring-2 ring-black ring-opacity-10 overflow-hidden animate-in slide-in-from-top-5 duration-300 ${
            notification.type === "success"
              ? "bg-white dark:bg-gray-800 border-l-4 border-green-500"
              : notification.type === "error"
              ? "bg-white dark:bg-gray-800 border-l-4 border-red-500"
              : notification.type === "warning"
              ? "bg-white dark:bg-gray-800 border-l-4 border-yellow-500"
              : "bg-white dark:bg-gray-800 border-l-4 border-blue-500"
          }`}
        >
          <div className="p-5">
            <div className="flex items-start">
              <div className="flex-shrink-0 text-2xl">
                {notification.type === "success" && "✅"}
                {notification.type === "error" && "❌"}
                {notification.type === "warning" && "⚠️"}
                {notification.type === "info" && "ℹ️"}
              </div>
              <div className="ml-4 w-0 flex-1 pt-0.5">
                <p className="text-base font-bold text-gray-900 dark:text-gray-100">
                  {notification.title}
                </p>
                <p className="mt-2 text-sm text-gray-700 dark:text-gray-300 leading-relaxed">
                  {notification.message}
                </p>
              </div>
              <div className="ml-4 flex-shrink-0 flex">
                <button
                  className="inline-flex text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 transition-colors"
                  onClick={() => dismissNotification(notification.id)}
                  aria-label="Close notification"
                >
                  <span className="sr-only">Close</span>
                  <svg
                    className="h-6 w-6"
                    viewBox="0 0 20 20"
                    fill="currentColor"
                  >
                    <path
                      fillRule="evenodd"
                      d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                      clipRule="evenodd"
                    />
                  </svg>
                </button>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

