// src/components/NotificationToast.tsx
import React from "react";
import { useNotifications } from "../context/NotificationContext";

export default function NotificationToast() {
  const { notifications, dismissNotification } = useNotifications();

  return (
    <div className="fixed top-20 right-4 z-50 space-y-2">
      {notifications.map((notification) => (
        <div
          key={notification.id}
          className={`max-w-sm w-full shadow-lg rounded-lg pointer-events-auto ring-1 ring-black ring-opacity-5 overflow-hidden animate-in slide-in-from-top-5 duration-300 ${
            notification.type === "success"
              ? "bg-green-50 dark:bg-green-900 border-l-4 border-green-500"
              : notification.type === "error"
              ? "bg-red-50 dark:bg-red-900 border-l-4 border-red-500"
              : notification.type === "warning"
              ? "bg-yellow-50 dark:bg-yellow-900 border-l-4 border-yellow-500"
              : "bg-blue-50 dark:bg-blue-900 border-l-4 border-blue-500"
          }`}
        >
          <div className="p-4">
            <div className="flex items-start">
              <div className="flex-shrink-0">
                {notification.type === "success" && "✅"}
                {notification.type === "error" && "❌"}
                {notification.type === "warning" && "⚠️"}
                {notification.type === "info" && "ℹ️"}
              </div>
              <div className="ml-3 w-0 flex-1 pt-0.5">
                <p className="text-sm font-semibold text-gray-900 dark:text-gray-100">
                  {notification.title}
                </p>
                <p className="mt-1 text-sm text-gray-600 dark:text-gray-200">
                  {notification.message}
                </p>
              </div>
              <div className="ml-4 flex-shrink-0 flex">
                <button
                  className="inline-flex text-gray-400 hover:text-gray-500 dark:hover:text-gray-300"
                  onClick={() => dismissNotification(notification.id)}
                >
                  <span className="sr-only">Close</span>
                  <svg
                    className="h-5 w-5"
                    viewBox="0 0 20 20"
                    fill="currentColor"
                  >
                    <path
                      fillRule="evenodd"
                      d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                      clipRule="evenodd"
                    />
                  </svg>
                </button>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

