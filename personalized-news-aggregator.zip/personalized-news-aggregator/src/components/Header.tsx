import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "react-bootstrap";
import { useTheme } from "../context/ThemeContext";
import { useUser } from "../context/UserContext";

export default function Header() {
  const navigate = useNavigate();
  const { theme, toggleTheme } = useTheme();
  const { user, logout } = useUser();
  const isDark = theme === "dark";

  const handleLogout = () => {
    logout(); // use context logout (clears session + storage)
    navigate("/login");
  };

  return (
    <header className="w-full border-b border-gray-200 dark:border-gray-700 py-3 px-6 bg-white dark:bg-gray-900">
      <div className="max-w-6xl mx-auto flex items-center justify-between gap-6">
        {/* Left section: Logo */}
        <div>
          <Link to="/feed" className="no-underline">
            <div className="text-2xl font-extrabold text-indigo-600 dark:text-indigo-400">
              Personalized News
            </div>
            <div className="text-sm text-gray-700 dark:text-gray-300">
              Tailored reading, smarter day
            </div>
          </Link>
        </div>

        {/* Right section: Nav + Buttons */}
        <nav className="flex items-center gap-4">
          <Link to="/feed" className="text-sm hover:underline text-gray-900 dark:text-gray-100">
            Feed
          </Link>
          <Link to="/bookmarks" className="text-sm hover:underline text-gray-900 dark:text-gray-100">
            Bookmarks
          </Link>
          <Link to="/analytics" className="text-sm hover:underline text-gray-900 dark:text-gray-100">
            Analytics
          </Link>
          <Link to="/profile" className="text-sm hover:underline text-gray-900 dark:text-gray-100">
            Profile
          </Link>
          {user && (
            <Link to="/preferences" className="text-sm hover:underline text-gray-900 dark:text-gray-100">
              Preferences
            </Link>
          )}

          {/* Theme Toggle */}
          <Button
            variant={isDark ? "outline-light" : "outline-dark"}
            size="sm"
            onClick={toggleTheme}
          >
            {isDark ? "🌞 Light" : "🌙 Dark"}
          </Button>

          {/* Auth Button */}
          {user ? (
            <Button
              variant={isDark ? "outline-light" : "danger"}
              size="sm"
              onClick={handleLogout}
            >
              Logout
            </Button>
          ) : (
            <Link to="/login" className="btn btn-outline-primary btn-sm">
              Login / Register
            </Link>
          )}
        </nav>
      </div>
    </header>
  );
}
