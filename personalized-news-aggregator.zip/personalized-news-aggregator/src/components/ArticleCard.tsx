import React from "react";
import { useNavigate } from "react-router-dom";
import { Article } from "../types";
import { Bookmark, BookmarkCheck, Share2, ExternalLink } from "lucide-react";
import { useUser } from "../context/UserContext";

type Props = {
  article: Article;
  isBookmarked?: boolean;
  onBookmark: (article: Article) => void;
  onOpen: (article: Article) => void;
};

export default function ArticleCard({
  article,
  isBookmarked = false,
  onBookmark,
  onOpen,
}: Props) {
  const { markReadStart, markReadEnd } = useUser();
  const navigate = useNavigate();

  const published = article.publishedAt ? new Date(article.publishedAt).toLocaleString() : "";

  // open article in new tab and track time spent by polling tab.closed
  const handleOpen = () => {
    // record start
    markReadStart(article);

    const newTab = window.open(article.url, "_blank");

    if (newTab) {
      const startTime = Date.now();
      let timeTracked = false;
      let interval: NodeJS.Timeout | null = null;

      // Function to save time and cleanup
      const saveTimeAndCleanup = () => {
        if (timeTracked) return; // Prevent double tracking
        timeTracked = true;
        
        if (interval) {
          clearInterval(interval);
          interval = null;
        }
        
        const endTime = Date.now();
        const timeSpentSeconds = Math.max(0, Math.floor((endTime - startTime) / 1000));
        
        // Always save time, even if it's short (user might have just opened and closed quickly)
        if (timeSpentSeconds > 0) {
          markReadEnd(article.id, timeSpentSeconds, true); // true = final call
        } else {
          // Even if 0, mark as read (they opened it)
          markReadEnd(article.id, 1, true); // Minimum 1 second, true = final call
        }
      };

      // Track time and save periodically
      let lastSavedTime = 0;
      interval = setInterval(() => {
        try {
          const elapsed = Math.floor((Date.now() - startTime) / 1000);
          
          if (newTab.closed) {
            // Tab closed - save final time
            saveTimeAndCleanup();
          } else {
            // Tab still open - save time every 5 seconds as backup
            if (elapsed > 0 && elapsed > lastSavedTime && elapsed % 5 === 0) {
              // Save intermediate time every 5 seconds (this accumulates)
              const timeToSave = elapsed - lastSavedTime;
              if (timeToSave > 0) {
                markReadEnd(article.id, timeToSave, false); // false = not final, keep tracking
                lastSavedTime = elapsed;
              }
            }
          }
        } catch (e) {
          // Cross-origin or closed tab - calculate time based on elapsed time
          const elapsed = Math.floor((Date.now() - startTime) / 1000);
          if (elapsed > lastSavedTime) {
            markReadEnd(article.id, elapsed - lastSavedTime);
          }
          saveTimeAndCleanup();
        }
      }, 1000); // Check every second

      // Fallback 1: Track when user switches back to our tab
      // Also track time periodically while user is on the article tab
      let lastActiveTime = startTime;
      const handleVisibilityChange = () => {
        if (document.hidden) {
          // User switched away - save time so far
          lastActiveTime = Date.now();
        } else {
          // User came back to our tab - check if article tab is still open
          try {
            if (newTab.closed) {
              saveTimeAndCleanup();
              document.removeEventListener("visibilitychange", handleVisibilityChange);
            } else {
              // Tab still open - user might come back to it, so don't save yet
              // But track that they were away
              const timeAway = Date.now() - lastActiveTime;
              if (timeAway > 30000) { // If away for more than 30 seconds, save time so far
                const timeSpent = Math.floor((lastActiveTime - startTime) / 1000);
                if (timeSpent > 0) {
                  markReadEnd(article.id, timeSpent);
                  // Reset start time for when they come back
                  lastActiveTime = Date.now();
                }
              }
            }
          } catch (e) {
            // Tab is closed or cross-origin
            saveTimeAndCleanup();
            document.removeEventListener("visibilitychange", handleVisibilityChange);
          }
        }
      };

      document.addEventListener("visibilitychange", handleVisibilityChange);

      // Fallback 2: Save time when page is about to unload (user closes browser/tab)
      const handleBeforeUnload = () => {
        saveTimeAndCleanup();
      };
      window.addEventListener("beforeunload", handleBeforeUnload);

      // Fallback 3: Save time after 5 minutes max (in case user never closes the tab)
      const maxTimeTimeout = setTimeout(() => {
        if (!timeTracked) {
          const elapsed = Math.floor((Date.now() - startTime) / 1000);
          if (elapsed > 0) {
            markReadEnd(article.id, Math.min(elapsed, 300)); // Cap at 5 minutes
          }
          timeTracked = true;
        }
      }, 5 * 60 * 1000); // 5 minutes

      // Store cleanup function globally for this article (in case component unmounts)
      const cleanupKey = `article_timer_${article.id}`;
      (window as any)[cleanupKey] = () => {
        if (interval) clearInterval(interval);
        if (maxTimeTimeout) clearTimeout(maxTimeTimeout);
        document.removeEventListener("visibilitychange", handleVisibilityChange);
        window.removeEventListener("beforeunload", handleBeforeUnload);
        delete (window as any)[cleanupKey];
      };
    }

    // still call provided onOpen handler (if used elsewhere)
    onOpen(article);
  };

  const handleShare = () => {
    const payload = { title: article.title, url: article.url };
    if (navigator.share) {
      navigator.share(payload).catch(() => {});
    } else {
      navigator.clipboard?.writeText(article.url);
      alert("Article URL copied to clipboard.");
    }
  };

  const handleCardClick = (e: React.MouseEvent) => {
    // Don't open if clicking on action buttons
    const target = e.target as HTMLElement;
    if (target.closest('button') || target.closest('svg')) {
      return;
    }
    
    // Open article directly in new tab
    handleOpen();
  };

  const handleRelatedNewsClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    // Store article in sessionStorage for ArticleDetail to use
    sessionStorage.setItem('currentArticle', JSON.stringify(article));
    // Navigate to article detail page with related news
    navigate(`/article/${encodeURIComponent(article.url)}`);
  };

  const handleBookmarkClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    console.log("Bookmark clicked for article:", article.title);
    onBookmark(article);
  };

  const handleShareClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    handleShare();
  };

  return (
    <article 
      className="bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden transition-all hover:shadow-md cursor-pointer border border-gray-200 dark:border-gray-700"
      onClick={handleCardClick}
    >
      {article.urlToImage && (
        <div
          className="h-44 bg-cover bg-center"
          style={{ backgroundImage: `url(${article.urlToImage})` }}
        />
      )}
      <div className="p-4">
        <h3 className="text-lg font-semibold mb-2 text-gray-900 dark:text-white">{article.title}</h3>
        {article.description && (
          <p className="text-sm mb-3 line-clamp-3 text-gray-800 dark:text-gray-200">{article.description}</p>
        )}

        <div className="flex items-center justify-between text-xs text-gray-700 dark:text-gray-300">
          <small className="text-gray-700 dark:text-gray-300">
            {article.source?.name} {published && ` • ${published}`}
          </small>

          <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
            <button
              className="p-1 rounded hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-600 dark:text-gray-300 transition-colors"
              aria-label="Related News"
              title="View Related News"
              onClick={handleRelatedNewsClick}
            >
              <ExternalLink size={16} />
            </button>

            <button
              className="p-1 rounded hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-600 dark:text-gray-300 transition-colors"
              aria-label="Share"
              title="Share"
              onClick={handleShareClick}
            >
              <Share2 size={16} />
            </button>

            <button
              type="button"
              onClick={handleBookmarkClick}
              className="p-1 rounded hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-600 dark:text-gray-300 transition-colors"
              aria-label="Bookmark"
              title={isBookmarked ? "Remove bookmark" : "Add bookmark"}
            >
              {isBookmarked ? <BookmarkCheck size={16} fill="currentColor" /> : <Bookmark size={16} />}
            </button>
          </div>
        </div>
      </div>
    </article>
  );
}
