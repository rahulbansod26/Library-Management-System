// src/types.ts
export type UserPreferences = {
  categories: string[];
  sources: string[];
  keywords: string[];
  excludedCategories?: string[]; // Categories to exclude
  excludedSources?: string[]; // Sources to exclude
  excludedKeywords?: string[]; // Keywords to exclude
  // Interest weights based on engagement
  weights?: Record<string, number>; // e.g., { "technology": 0.8, "sports": 0.3 }
  // Notification preferences
  notifications?: {
    browser?: boolean; // Browser notifications enabled
    email?: boolean; // Email notifications enabled
    breakingNews?: boolean; // Breaking news notifications
    newArticles?: boolean; // New relevant articles notifications
  };
};

export type ReadEvent = {
  id: string; // article id or url key
  title?: string;
  source?: string;
  readAt: string; // ISO string
  timeSpent: number; // seconds
};

export type Article = {
  id: string;
  title: string;
  description?: string;
  url: string;
  urlToImage?: string;
  publishedAt?: string;
  source?: {
    id?: string | null;
    name?: string;
  };
  author?: string;
  score?: number;
  category?: string; // Category of the article (e.g., "technology", "sports")
};

export type UserProfile = {
  id: string;
  name: string;
  email: string;
  bookmarks: Article[]; // saved articles
  history: ReadEvent[]; // read events (per-article)
  preferences?: UserPreferences;
};
