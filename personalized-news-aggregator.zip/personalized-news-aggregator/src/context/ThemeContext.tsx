// src/context/ThemeContext.tsx
import React, { createContext, useContext, useEffect, useState } from "react";

type Theme = "light" | "dark";

interface ThemeContextType {
  theme: Theme;
  toggleTheme: () => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [theme, setTheme] = useState<Theme>(
    (localStorage.getItem("theme") as Theme) || "light"
  );

  const toggleTheme = () => setTheme((prev) => (prev === "light" ? "dark" : "light"));

  useEffect(() => {
    localStorage.setItem("theme", theme);
    
    // Apply theme to html and body for full screen coverage
    const html = document.documentElement;
    const body = document.body;
    
    if (theme === "dark") {
      html.classList.add("dark");
      html.style.backgroundColor = "#111827"; // gray-900
      html.style.color = "#f3f4f6"; // gray-100
      body.style.backgroundColor = "#111827";
      body.style.color = "#f3f4f6";
    } else {
      html.classList.remove("dark");
      html.style.backgroundColor = "#ffffff"; // white
      html.style.color = "#111827"; // gray-900
      body.style.backgroundColor = "#ffffff";
      body.style.color = "#111827";
    }
    
    // Cleanup function
    return () => {
      html.style.backgroundColor = "";
      html.style.color = "";
      body.style.backgroundColor = "";
      body.style.color = "";
    };
  }, [theme]);

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      <div
        className={`min-h-screen ${
          theme === "dark"
            ? "bg-gray-900 text-gray-100 transition-colors duration-300"
            : "bg-white text-gray-900 transition-colors duration-300"
        }`}
      >
        {children}
      </div>
    </ThemeContext.Provider>
  );
};

export const useTheme = () => {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error("useTheme must be used within ThemeProvider");
  return ctx;
};
