// src/context/NotificationContext.tsx
import React, { createContext, useContext, useState, useCallback, useEffect } from "react";
import { useUser } from "./UserContext";
import { Article } from "../types";

// Email notifications are not available without a backend server
// This is a client-side only app using localStorage
async function sendEmailNotification(
  email: string,
  title: string,
  message: string,
  article?: Article
) {
  // Email notifications require a backend server
  // In a client-side only app, we can only show browser notifications
  console.log("Email notification requested (not sent - no backend):", {
    email,
    title,
    message,
    article: article?.title,
  });
  
  // Optionally, you could use a third-party service like EmailJS for client-side emails
  // For now, we'll just log it
}

type Notification = {
  id: string;
  title: string;
  message: string;
  type: "info" | "success" | "warning" | "error";
  timestamp: number;
  article?: Article;
};

type NotificationContextType = {
  notifications: Notification[];
  showNotification: (title: string, message: string, type?: Notification["type"], article?: Article) => void;
  dismissNotification: (id: string) => void;
  clearAll: () => void;
};

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

export const NotificationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const { user } = useUser();

  const showNotification = useCallback(
    (title: string, message: string, type: Notification["type"] = "info", article?: Article) => {
      const id = `notif-${Date.now()}-${Math.random()}`;
      const notification: Notification = {
        id,
        title,
        message,
        type,
        timestamp: Date.now(),
        article,
      };

      setNotifications((prev) => [...prev, notification]);

      // Auto-dismiss after 5 seconds
      setTimeout(() => {
        setNotifications((prev) => prev.filter((n) => n.id !== id));
      }, 5000);

      // Show browser notification if enabled
      if (
        user?.preferences?.notifications?.browser &&
        "Notification" in window &&
        Notification.permission === "granted"
      ) {
        new Notification(title, {
          body: message,
          icon: "/favicon.ico",
        });
      }

      // Send email notification if enabled
      if (user?.preferences?.notifications?.email && user?.email) {
        sendEmailNotification(user.email, title, message, article).catch((err) => {
          console.error("Failed to send email notification:", err);
        });
      }
    },
    [user]
  );

  const dismissNotification = useCallback((id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  }, []);

  const clearAll = useCallback(() => {
    setNotifications([]);
  }, []);

  // Check for new relevant articles periodically (simplified - in production, this would be server-side)
  useEffect(() => {
    if (!user?.preferences?.notifications?.newArticles) return;

    const checkInterval = setInterval(() => {
      // This is a placeholder - in a real app, you'd check for new articles from an API
      // For now, we'll just show a demo notification occasionally
      if (Math.random() > 0.95) {
        showNotification(
          "New Article Available",
          "A new article matching your interests has been published!",
          "info"
        );
      }
    }, 60000); // Check every minute

    return () => clearInterval(checkInterval);
  }, [user, showNotification]);

  return (
    <NotificationContext.Provider
      value={{
        notifications,
        showNotification,
        dismissNotification,
        clearAll,
      }}
    >
      {children}
    </NotificationContext.Provider>
  );
};

export function useNotifications() {
  const ctx = useContext(NotificationContext);
  if (!ctx) throw new Error("useNotifications must be used within NotificationProvider");
  return ctx;
}

