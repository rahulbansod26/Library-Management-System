import React, { createContext, useContext, useEffect, useRef, useState } from "react";
import { Article, UserProfile, ReadEvent, UserPreferences } from "../types";

type UserContextType = {
  user: UserProfile | null;
  setUser: (u: UserProfile | null) => void;
  toggleBookmark: (article: Article) => void;
  markReadStart: (article: Article) => void;
  markReadEnd: (articleId: string, seconds?: number, isFinal?: boolean) => void;
  updatePreferences: (prefs: Partial<UserPreferences>) => void;
  login: (email: string, password: string) => boolean;
  logout: () => void;
  register: (name: string, email: string, password: string) => boolean;
};

const UserContext = createContext<UserContextType | undefined>(undefined);

const LOCAL_USERS_KEY = "pna_users";
const LOCAL_CURRENT_KEY = "pna_current_user_id";

function loadAllUsers(): Record<string, UserProfile> {
  try {
    return JSON.parse(localStorage.getItem(LOCAL_USERS_KEY) || "{}");
  } catch {
    return {};
  }
}

function persistAllUsers(users: Record<string, UserProfile>) {
  localStorage.setItem(LOCAL_USERS_KEY, JSON.stringify(users));
}

export const UserProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUserRaw] = useState<UserProfile | null>(null);

  // Use a ref to keep start times across renders
  const startTimesRef = useRef<Map<string, number>>(new Map());

  // Load active user when app starts or when storage changes
  const loadCurrentUser = () => {
    const users = loadAllUsers();
    const currentId = localStorage.getItem(LOCAL_CURRENT_KEY);

    if (currentId && users[currentId]) {
      setUserRaw(users[currentId]);
      return;
    }

    // If no current user, create fallback local user if nothing found
    if (!Object.keys(users).length) {
      const id = "local-user";
      const localUser: UserProfile = {
        id,
        name: "Local User",
        email: "local@local",
        bookmarks: [],
        history: [],
        preferences: {
          categories: [],
          sources: [],
          keywords: [],
          excludedCategories: [],
          excludedSources: [],
          excludedKeywords: [],
          weights: {},
          notifications: {
            browser: false,
            email: false,
            breakingNews: false,
            newArticles: false,
          },
        },
      };
      users[id] = localUser;
      persistAllUsers(users);
      localStorage.setItem(LOCAL_CURRENT_KEY, id);
      setUserRaw(localUser);
    } else {
      setUserRaw(null);
    }
  };

  useEffect(() => {
    loadCurrentUser();
    window.addEventListener("storage", loadCurrentUser);
    return () => window.removeEventListener("storage", loadCurrentUser);
  }, []);

  // Persist user whenever it changes (keeps local state synced)
  useEffect(() => {
    if (!user) return;
    const users = loadAllUsers();
    users[user.id] = user;
    persistAllUsers(users);
    localStorage.setItem(LOCAL_CURRENT_KEY, user.id);
  }, [user]);

  const setUser = (u: UserProfile | null) => {
    if (u) {
      const users = loadAllUsers();
      users[u.id] = u;
      persistAllUsers(users);
      localStorage.setItem(LOCAL_CURRENT_KEY, u.id);
      setUserRaw(u);
    } else {
      localStorage.removeItem(LOCAL_CURRENT_KEY);
      setUserRaw(null);
    }
  };

  // Register a new user
  const register = (name: string, email: string, password: string): boolean => {
    const users = loadAllUsers();
    if (users[email]) {
      alert("User already exists. Please log in instead.");
      return false;
    }
    const newUser: UserProfile = {
      id: email,
      name,
      email,
      bookmarks: [],
      history: [],
      preferences: {
        categories: [],
        sources: [],
        keywords: [],
        excludedCategories: [],
        excludedSources: [],
        excludedKeywords: [],
        weights: {},
        notifications: {
          browser: false,
          email: false,
          breakingNews: false,
          newArticles: false,
        },
      },
    };
    (newUser as any).password = password;

    users[email] = newUser;
    persistAllUsers(users);
    localStorage.setItem(LOCAL_CURRENT_KEY, email);
    setUserRaw(newUser);
    return true;
  };

  // Login existing user
  const login = (email: string, password: string): boolean => {
    const users = loadAllUsers();
    const found = users[email];

    // Check if user exists first
    if (!found) {
      // Don't show alert - let the component handle the error message
      return false;
    }

    // Check password
    if ((found as any).password !== password) {
      // Don't show alert - let the component handle the error message
      return false;
    }

    localStorage.setItem(LOCAL_CURRENT_KEY, email);
    setUserRaw({ ...found });
    return true;
  };

  // Logout
  const logout = () => {
    localStorage.removeItem(LOCAL_CURRENT_KEY);
    setUserRaw(null);
  };

  // Update interest weights based on engagement
  const updateInterestWeights = (article: Article, engagementType: 'bookmark' | 'read' | 'time', value: number = 1) => {
    if (!user) return;
    
    const weights = user.preferences?.weights || {};
    const updatedWeights = { ...weights };
    
    // Extract categories and keywords from article
    const categories = article.source?.name ? [article.source.name.toLowerCase()] : [];
    const keywords = [
      ...(article.title?.toLowerCase().split(/\s+/) || []),
      ...(article.description?.toLowerCase().split(/\s+/) || []),
    ].filter(k => k.length > 3); // Only meaningful keywords
    
    // Weight factors based on engagement type
    const weightFactors: Record<string, number> = {
      bookmark: 0.3, // Bookmarking shows strong interest
      read: 0.2, // Reading shows interest
      time: 0.1, // Time spent shows engagement (value is minutes)
    };
    
    const factor = weightFactors[engagementType] * (engagementType === 'time' ? Math.min(value / 5, 1) : 1);
    
    // Update weights for categories and keywords
    categories.forEach(cat => {
      updatedWeights[cat] = (updatedWeights[cat] || 0) + factor;
      updatedWeights[cat] = Math.min(updatedWeights[cat], 1); // Cap at 1.0
    });
    
    keywords.slice(0, 5).forEach(keyword => {
      updatedWeights[keyword] = (updatedWeights[keyword] || 0) + factor * 0.5;
      updatedWeights[keyword] = Math.min(updatedWeights[keyword], 1);
    });
    
    // Update user preferences
    const updated = {
      ...user,
      preferences: {
        ...user.preferences,
        categories: user.preferences?.categories || [],
        sources: user.preferences?.sources || [],
        keywords: user.preferences?.keywords || [],
        weights: updatedWeights,
      },
    };
    setUser(updated);
  };

  // Bookmark toggle
  const toggleBookmark = (article: Article) => {
    if (!user) {
      console.warn("Cannot bookmark: No user logged in");
      alert("Please log in to bookmark articles.");
      return;
    }
    
    // Check by both ID and URL to handle cases where articles might have different IDs but same URL
    const exists = user.bookmarks.find((b) => b.id === article.id || b.url === article.url);
    const updated = { ...user };
    updated.bookmarks = exists
      ? updated.bookmarks.filter((b) => b.id !== article.id && b.url !== article.url)
      : [article, ...updated.bookmarks];
    
    // Update interest weights when bookmarking (before updating user state)
    if (!exists) {
      // Temporarily update user for weight calculation, then merge back
      const tempUser = { ...updated };
      const weights = tempUser.preferences?.weights || {};
      const updatedWeights = { ...weights };
      
      // Extract categories and keywords from article
      const categories = article.source?.name ? [article.source.name.toLowerCase()] : [];
      const keywords = [
        ...(article.title?.toLowerCase().split(/\s+/) || []),
        ...(article.description?.toLowerCase().split(/\s+/) || []),
      ].filter(k => k.length > 3);
      
      const factor = 0.3; // Bookmarking shows strong interest
      
      categories.forEach(cat => {
        updatedWeights[cat] = (updatedWeights[cat] || 0) + factor;
        updatedWeights[cat] = Math.min(updatedWeights[cat], 1);
      });
      
      keywords.slice(0, 5).forEach(keyword => {
        updatedWeights[keyword] = (updatedWeights[keyword] || 0) + factor * 0.5;
        updatedWeights[keyword] = Math.min(updatedWeights[keyword], 1);
      });
      
      updated.preferences = {
        ...updated.preferences,
        categories: updated.preferences?.categories || [],
        sources: updated.preferences?.sources || [],
        keywords: updated.preferences?.keywords || [],
        weights: updatedWeights,
      };
    }
    
    // Persist to localStorage
    const allUsers = loadAllUsers();
    allUsers[updated.id] = updated;
    persistAllUsers(allUsers);
    localStorage.setItem(LOCAL_CURRENT_KEY, updated.id);
    
    // Update state
    setUserRaw(updated);
  };

  // Mark read start: store start-time in ref map and optionally create history event
  const markReadStart = (article: Article) => {
    // Always get the latest user from localStorage to avoid stale state
    const currentUserId = localStorage.getItem(LOCAL_CURRENT_KEY);
    if (!currentUserId) {
      console.warn("No user logged in, cannot track reading");
      return;
    }
    
    const allUsers = loadAllUsers();
    const currentUser = allUsers[currentUserId];
    if (!currentUser) {
      console.warn("User not found in localStorage");
      return;
    }
    
    const id = article.id;
    // store start time (overwrite if present)
    startTimesRef.current.set(id, Date.now());

    // create history event if missing
    const found = currentUser.history.find((h) => h.id === id);
    if (!found) {
      console.log("Creating new read history entry for article:", article.title);
      const newEvent: ReadEvent = {
        id,
        title: article.title,
        source: article.source?.name,
        readAt: new Date().toISOString(),
        timeSpent: 0,
      };
      const updatedUser = { ...currentUser, history: [newEvent, ...currentUser.history] };
      
      // Persist immediately to localStorage
      allUsers[updatedUser.id] = updatedUser;
      persistAllUsers(allUsers);
      localStorage.setItem(LOCAL_CURRENT_KEY, updatedUser.id);
      
      // Update state first
      setUserRaw(updatedUser);
      
      // Update interest weights when starting to read (use updatedUser to avoid stale state)
      // We need to update weights on the updated user, not the old one
      const weights = updatedUser.preferences?.weights || {};
      const updatedWeights = { ...weights };
      
      // Extract categories and keywords from article
      const categories = article.source?.name ? [article.source.name.toLowerCase()] : [];
      const keywords = [
        ...(article.title?.toLowerCase().split(/\s+/) || []),
        ...(article.description?.toLowerCase().split(/\s+/) || []),
      ].filter(k => k.length > 3);
      
      const factor = 0.2; // Reading shows interest
      
      categories.forEach(cat => {
        updatedWeights[cat] = (updatedWeights[cat] || 0) + factor;
        updatedWeights[cat] = Math.min(updatedWeights[cat], 1);
      });
      
      keywords.slice(0, 5).forEach(keyword => {
        updatedWeights[keyword] = (updatedWeights[keyword] || 0) + factor * 0.5;
        updatedWeights[keyword] = Math.min(updatedWeights[keyword], 1);
      });
      
      const finalUser = {
        ...updatedUser,
        preferences: {
          ...updatedUser.preferences,
          categories: updatedUser.preferences?.categories || [],
          sources: updatedUser.preferences?.sources || [],
          keywords: updatedUser.preferences?.keywords || [],
          weights: updatedWeights,
        },
      };
      
      // Persist the final user with updated weights
      const allUsersFinal = loadAllUsers();
      allUsersFinal[finalUser.id] = finalUser;
      persistAllUsers(allUsersFinal);
      localStorage.setItem(LOCAL_CURRENT_KEY, finalUser.id);
      setUserRaw(finalUser);
      console.log("Read history entry created. Total reads:", finalUser.history.length);
    } else {
      console.log("Article already in read history:", article.title);
    }
  };

  // Mark read end: use explicit seconds if provided else compute from startTimesRef
  const markReadEnd = (articleId: string, seconds?: number, isFinal: boolean = false) => {
    // Always get the latest user from localStorage to avoid stale state
    const currentUserId = localStorage.getItem(LOCAL_CURRENT_KEY);
    if (!currentUserId || !articleId) {
      console.warn("markReadEnd: No user ID or article ID");
      return;
    }
    
    const allUsers = loadAllUsers();
    const currentUser = allUsers[currentUserId];
    if (!currentUser) {
      console.warn("markReadEnd: User not found");
      return;
    }

    let secondsToAdd = 0;

    if (typeof seconds === "number" && !isNaN(seconds)) {
      secondsToAdd = Math.max(0, Math.floor(seconds));
    } else {
      const start = startTimesRef.current.get(articleId);
      if (start) {
        secondsToAdd = Math.max(0, Math.floor((Date.now() - start) / 1000));
      }
    }

    // Only remove stored start time if this is the final call
    if (isFinal) {
      startTimesRef.current.delete(articleId);
    }

    // update user history & persist immediately
    const updatedUser = { ...currentUser };
    const idx = updatedUser.history.findIndex((h) => h.id === articleId);

    if (idx !== -1) {
      const ev = { ...updatedUser.history[idx] };
      const oldTimeSpent = ev.timeSpent || 0;
      // Always update timeSpent, even if secondsToAdd is 0 (accumulate time)
      ev.timeSpent = oldTimeSpent + secondsToAdd;
      updatedUser.history[idx] = ev;

      // Update interest weights based on reading time (if significant time spent)
      if (secondsToAdd > 30) { // Only update if spent more than 30 seconds
        const article: Article = {
          id: articleId,
          title: ev.title || '',
          url: '',
          source: ev.source ? { name: ev.source } : undefined,
        };
        const minutesSpent = secondsToAdd / 60;
        
        // Update weights inline to avoid stale state
        const weights = updatedUser.preferences?.weights || {};
        const updatedWeights = { ...weights };
        
        const categories = article.source?.name ? [article.source.name.toLowerCase()] : [];
        const keywords = [
          ...(ev.title?.toLowerCase().split(/\s+/) || []),
        ].filter(k => k.length > 3);
        
        const factor = 0.1 * Math.min(minutesSpent / 5, 1); // Time spent shows engagement
        
        categories.forEach(cat => {
          updatedWeights[cat] = (updatedWeights[cat] || 0) + factor;
          updatedWeights[cat] = Math.min(updatedWeights[cat], 1);
        });
        
        keywords.slice(0, 5).forEach(keyword => {
          updatedWeights[keyword] = (updatedWeights[keyword] || 0) + factor * 0.5;
          updatedWeights[keyword] = Math.min(updatedWeights[keyword], 1);
        });
        
        updatedUser.preferences = {
          ...updatedUser.preferences,
          categories: updatedUser.preferences?.categories || [],
          sources: updatedUser.preferences?.sources || [],
          keywords: updatedUser.preferences?.keywords || [],
          weights: updatedWeights,
        };
      }

      // Persist right away so a reload / analytics read sees the change
      allUsers[updatedUser.id] = updatedUser;
      persistAllUsers(allUsers);
      localStorage.setItem(LOCAL_CURRENT_KEY, updatedUser.id);

      // update React state
      setUserRaw(updatedUser);
      console.log(`Time updated for article ${articleId}: ${ev.timeSpent} seconds total`);
    } else {
      // If history entry doesn't exist, create it (shouldn't happen, but safety check)
      console.warn(`History entry not found for article ${articleId}, creating one`);
      const newEvent: ReadEvent = {
        id: articleId,
        title: '',
        source: '',
        readAt: new Date().toISOString(),
        timeSpent: secondsToAdd,
      };
      const updatedUserWithNew = { ...currentUser, history: [newEvent, ...currentUser.history] };
      allUsers[updatedUserWithNew.id] = updatedUserWithNew;
      persistAllUsers(allUsers);
      localStorage.setItem(LOCAL_CURRENT_KEY, updatedUserWithNew.id);
      setUserRaw(updatedUserWithNew);
    }
  };

  const updatePreferences = (prefs: Partial<UserPreferences>) => {
    if (!user) return;
    const updated: UserProfile = {
      ...user,
      preferences: {
        categories: prefs.categories ?? user.preferences?.categories ?? [],
        sources: prefs.sources ?? user.preferences?.sources ?? [],
        keywords: prefs.keywords ?? user.preferences?.keywords ?? [],
        excludedCategories: prefs.excludedCategories ?? user.preferences?.excludedCategories ?? [],
        excludedSources: prefs.excludedSources ?? user.preferences?.excludedSources ?? [],
        excludedKeywords: prefs.excludedKeywords ?? user.preferences?.excludedKeywords ?? [],
        weights: prefs.weights ?? user.preferences?.weights ?? {},
        notifications: prefs.notifications ?? user.preferences?.notifications ?? {
          browser: false,
          email: false,
          breakingNews: false,
          newArticles: false,
        },
      },
    };
    setUser(updated);
  };

  return (
    <UserContext.Provider
      value={{
        user,
        setUser,
        toggleBookmark,
        markReadStart,
        markReadEnd,
        updatePreferences,
        login,
        logout,
        register,
      }}
    >
      {children}
    </UserContext.Provider>
  );
};

export function useUser() {
  const ctx = useContext(UserContext);
  if (!ctx) throw new Error("useUser must be used within UserProvider");
  return ctx;
}
