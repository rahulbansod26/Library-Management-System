import { Article, UserProfile } from "../types";
import { parseISO, differenceInDays } from "date-fns";

export function recommendArticles(articles: Article[], user?: UserProfile) {
  const now = new Date();

  return articles.map((a) => {
    let score = 0;
    const title = (a.title || "").toLowerCase();
    const desc = (a.description || "").toLowerCase();

    const prefs = user?.preferences;
    if (prefs) {
      for (const kw of prefs.keywords || []) {
        if (kw && (title.includes(kw.toLowerCase()) || desc.includes(kw.toLowerCase())))
          score += (prefs.weights?.[kw] || 5);
      }

      for (const cat of prefs.categories || []) {
        if (cat && title.includes(cat.toLowerCase()))
          score += (prefs.weights?.[cat] || 3);
      }

      if (prefs.sources?.some((s) => s && s === a.source?.name))
        score += 10;
    }

    if (a.publishedAt) {
      const days = Math.max(0, differenceInDays(now, parseISO(a.publishedAt)));
      score += Math.max(0, 30 - days);
    }

    return { ...a, score };
  }).sort((x, y) => (y.score || 0) - (x.score || 0));
}
