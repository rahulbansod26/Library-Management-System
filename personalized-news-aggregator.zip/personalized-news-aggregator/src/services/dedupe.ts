import { Article } from '../types';

export function normalizeTitle(t = '') { return t.toLowerCase().replace(/[^a-z0-9 ]/g,'').trim(); }

export function dedupeArticles(articles: Article[]) {
  const map = new Map<string, Article>();
  for (const a of articles) {
    const key = normalizeTitle(a.title || '') + '|' + (a.url || '');
    if (!map.has(key)) map.set(key, a);
  }
  return Array.from(map.values());
}
