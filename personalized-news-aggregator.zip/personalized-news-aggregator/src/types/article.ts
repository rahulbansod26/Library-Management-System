export interface Article {
  id: string;
  title: string;
  description?: string;
  url: string;
  urlToImage?: string;
  publishedAt?: string;
  author?: string;
  source?: {
    id?: string;
    name: string;
  };
  score?: number;
  readAt?: string;
  timeSpent?: number;
}
