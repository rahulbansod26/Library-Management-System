// src/features/dashboard/Dashboard.tsx
import React, { useEffect, useState } from "react";
import { Card, Row, Col } from "react-bootstrap";

export default function Dashboard() {
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    const ref = JSON.parse(localStorage.getItem("user") || "{}");
    const users = JSON.parse(localStorage.getItem("users") || "{}");
    if (ref?.email && users?.[ref.email]) setUser(users[ref.email]);
  }, []);

  return (
    <div className="container mt-4">
      <h2>Welcome to Personalized News Aggregator</h2>
      <p className="text-muted">Quick overview of your account</p>
      <Row xs={1} md={3} className="g-4">
        <Col>
          <Card className="p-3 shadow-sm">
            <h6>Total Bookmarks</h6>
            <div style={{ fontSize: 22 }}>{(user?.bookmarks || []).length}</div>
          </Card>
        </Col>
        <Col>
          <Card className="p-3 shadow-sm">
            <h6>Total Reads</h6>
            <div style={{ fontSize: 22 }}>{(user?.history || []).length}</div>
          </Card>
        </Col>
        <Col>
          <Card className="p-3 shadow-sm">
            <h6>Preferences</h6>
            <div>{(user?.preferences?.categories || []).join(", ") || "—"}</div>
          </Card>
        </Col>
      </Row>
    </div>
  );
}
