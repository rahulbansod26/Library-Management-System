import React, { useState, useEffect, useMemo } from "react";
import { useUser } from "../../context/UserContext";
import { useNotifications } from "../../context/NotificationContext";

export default function Profile() {
  const { user, setUser, updatePreferences } = useUser();
  const { showNotification } = useNotifications();
  const [isEditing, setIsEditing] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);
  
  // Force refresh user data from localStorage periodically
  useEffect(() => {
    const interval = setInterval(() => {
      // Reload user from localStorage to get latest data
      const users = JSON.parse(localStorage.getItem("pna_users") || "{}");
      const currentId = localStorage.getItem("pna_current_user_id");
      if (currentId && users[currentId] && setUser) {
        setUser(users[currentId]);
      }
      setRefreshKey(prev => prev + 1);
    }, 2000); // Check every 2 seconds
    
    return () => clearInterval(interval);
  }, [setUser]);
  const [form, setForm] = useState({
    name: user?.name || "",
    email: user?.email || "",
    password: (user as any)?.password || "",
  });

  // Update form when user changes
  useEffect(() => {
    if (user) {
      setForm({
        name: user.name || "",
        email: user.email || "",
        password: (user as any)?.password || "",
      });
    }
  }, [user]);

  // Use useMemo to recalculate when user.history changes
  // MUST be called before any conditional returns (React Hooks rule)
  const totalMinutes = useMemo(() => {
    if (!user) return 0;
    return Math.round(
      (user.history.reduce((acc, h) => acc + (h.timeSpent || 0), 0) || 0) / 60
    );
  }, [user?.history]);

  const articlesRead = useMemo(() => {
    return user?.history?.length || 0;
  }, [user?.history]);

  // Removed inline style approach - using CSS classes instead for better reliability

  if (!user) return <div className="text-center py-10">Loading profile...</div>;

  // Handle input changes
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
  };

  // Save updates
  const handleSave = () => {
    if (!form.name.trim() || !form.email.trim() || !form.password.trim()) {
      alert("Please fill out all fields before saving.");
      return;
    }

    // Create updated user object
    const updatedUser = {
      ...user,
      name: form.name,
      email: form.email,
      password: form.password,
    };

    // Update localStorage users
    const users = JSON.parse(localStorage.getItem("pna_users") || "{}");

    // If email changed, handle key migration
    if (user.email !== form.email) {
      delete users[user.email];
    }

    users[form.email] = updatedUser;
    localStorage.setItem("pna_users", JSON.stringify(users));

    // Update current user ID and context
    localStorage.setItem("pna_current_user_id", form.email);
    setUser(updatedUser);

    setIsEditing(false);
    alert("Profile updated successfully!");
  };

  return (
    <div className="container mx-auto py-8 px-4">
      {/* Welcome header */}
      <h2 className="text-3xl font-semibold mb-2 text-gray-900 dark:text-gray-100">
        Welcome,{" "}
        <span className="text-blue-600 dark:text-blue-400">{user.name}</span> 👋
      </h2>
      <p className="text-gray-500 dark:text-gray-400 mb-8">
        Manage your account and review your activity summary.
      </p>

      {/* Stats cards */}
      <div className="grid md:grid-cols-3 gap-6 mb-10">
        <div className="bg-white dark:bg-gray-800 shadow-md rounded-xl p-6 text-center hover:shadow-lg transition-all border border-gray-200 dark:border-gray-700">
          <p className="text-gray-500 dark:text-gray-400 mb-2">Bookmarks</p>
          <h3 className="text-3xl font-semibold mt-2 profile-stat-number">
            {user.bookmarks?.length || 0}
          </h3>
        </div>

        <div className="bg-white dark:bg-gray-800 shadow-md rounded-xl p-6 text-center hover:shadow-lg transition-all border border-gray-200 dark:border-gray-700">
          <p className="text-gray-500 dark:text-gray-400 mb-2">Articles Read</p>
          <h3 className="text-3xl font-semibold mt-2 profile-stat-number">
            {articlesRead}
          </h3>
        </div>

        <div className="bg-white dark:bg-gray-800 shadow-md rounded-xl p-6 text-center hover:shadow-lg transition-all border border-gray-200 dark:border-gray-700">
          <p className="text-gray-500 dark:text-gray-400 mb-2">
            Total Time Spent (minutes)
          </p>
          <h3 className="text-3xl font-semibold mt-2 profile-stat-number">
            {totalMinutes}
          </h3>
        </div>
      </div>

      {/* Settings Section */}
      <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-md max-w-2xl mx-auto border border-gray-200 dark:border-gray-700">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-xl font-semibold text-gray-800 dark:text-gray-100">
            Account Settings ⚙️
          </h3>
          {!isEditing ? (
            <button
              onClick={() => setIsEditing(true)}
              className="text-blue-600 dark:text-blue-400 font-medium hover:underline"
            >
              Edit
            </button>
          ) : null}
        </div>

        {/* View mode */}
        {!isEditing ? (
          <div className="space-y-4">
            <div>
              <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">
                Full Name
              </p>
              <p className="text-lg font-medium profile-account-value">
                {user.name || "Not provided"}
              </p>
            </div>

            <div>
              <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">Email</p>
              <p className="text-lg font-medium profile-account-value">
                {user.email || "Not provided"}
              </p>
            </div>

            <div>
              <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">
                Password
              </p>
              <p className="text-lg font-medium profile-account-value">
                {"*".repeat(form.password.length || 8)}
              </p>
            </div>
          </div>
        ) : (
          /* Edit mode */
          <div className="space-y-4">
            <div>
              <label className="block text-sm text-gray-600 dark:text-gray-300">
                Full Name
              </label>
              <input
                type="text"
                name="name"
                value={form.name}
                onChange={handleChange}
                className="mt-1 w-full border border-gray-300 dark:border-gray-600 rounded-md p-2 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 placeholder-gray-500 dark:placeholder-gray-400 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-sm text-gray-600 dark:text-gray-300">
                Email
              </label>
              <input
                type="email"
                name="email"
                value={form.email}
                onChange={handleChange}
                className="mt-1 w-full border border-gray-300 dark:border-gray-600 rounded-md p-2 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 placeholder-gray-500 dark:placeholder-gray-400 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-sm text-gray-600 dark:text-gray-300">
                Password
              </label>
              <input
                type="password"
                name="password"
                value={form.password}
                onChange={handleChange}
                placeholder="Enter new password"
                className="mt-1 w-full border border-gray-300 dark:border-gray-600 rounded-md p-2 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 placeholder-gray-500 dark:placeholder-gray-400 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
              />
            </div>

            <div className="flex justify-end gap-3 mt-4">
              <button
                onClick={() => setIsEditing(false)}
                className="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-md transition-colors font-medium"
              >
                Cancel
              </button>
              <button
                onClick={handleSave}
                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md transition-colors font-medium"
              >
                Save Changes
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Notification Preferences */}
      <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-md max-w-2xl mx-auto mt-6 border border-gray-200 dark:border-gray-700">
        <h3 className="text-xl font-semibold mb-4 text-gray-900 dark:text-gray-100">
          Notification Settings 🔔
        </h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium text-gray-900 dark:text-gray-100">Browser Notifications</p>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                Receive notifications in your browser for breaking news
              </p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={user.preferences?.notifications?.browser || false}
                onChange={(e) => {
                  updatePreferences({
                    notifications: {
                      ...user.preferences?.notifications,
                      browser: e.target.checked,
                    },
                  });
                  if (e.target.checked) {
                    // Request notification permission
                    if ("Notification" in window && Notification.permission === "default") {
                      Notification.requestPermission();
                    }
                  }
                }}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
            </label>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium text-gray-900 dark:text-gray-100">Email Notifications</p>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                Receive email notifications for breaking news
              </p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={user.preferences?.notifications?.email || false}
                onChange={(e) => {
                  updatePreferences({
                    notifications: {
                      ...user.preferences?.notifications,
                      email: e.target.checked,
                    },
                  });
                }}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
            </label>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium text-gray-900 dark:text-gray-100">Breaking News</p>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                Get notified about breaking news matching your interests
              </p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={user.preferences?.notifications?.breakingNews || false}
                onChange={(e) => {
                  updatePreferences({
                    notifications: {
                      ...user.preferences?.notifications,
                      breakingNews: e.target.checked,
                    },
                  });
                }}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
            </label>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium text-gray-900 dark:text-gray-100">New Articles</p>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                Get notified about new relevant articles
              </p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={user.preferences?.notifications?.newArticles || false}
                onChange={(e) => {
                  updatePreferences({
                    notifications: {
                      ...user.preferences?.notifications,
                      newArticles: e.target.checked,
                    },
                  });
                }}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
            </label>
          </div>
        </div>

        {/* Test Notification Button */}
        <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
          <p className="text-sm text-gray-500 dark:text-gray-400 mb-3">
            Test your notification settings:
          </p>
          <button
            onClick={() => {
              showNotification(
                "Test Notification",
                "This is a test notification to verify your settings are working!",
                "info"
              );
            }}
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
          >
            🔔 Test Notification
          </button>
        </div>
      </div>
    </div>
  );
}
