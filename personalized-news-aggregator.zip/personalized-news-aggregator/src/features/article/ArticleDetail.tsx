// src/features/article/ArticleDetail.tsx
import React, { useEffect, useState } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import axios from "axios";
import { Article } from "../../types";
import { useUser } from "../../context/UserContext";
import ArticleCard from "../../components/ArticleCard";
import { ExternalLink, ArrowLeft } from "lucide-react";

const API_KEY = process.env.REACT_APP_NEWS_API_KEY || "128e8032f11f4fdebe7e010c442700cf";

export default function ArticleDetail() {
  const { articleId } = useParams<{ articleId: string }>();
  const navigate = useNavigate();
  const { user, toggleBookmark, markReadStart } = useUser();
  const [article, setArticle] = useState<Article | null>(null);
  const [relatedArticles, setRelatedArticles] = useState<Article[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingRelated, setLoadingRelated] = useState(false);

  // Decode article ID (it's a URL-encoded article URL)
  const articleUrl = articleId ? decodeURIComponent(articleId) : null;

  useEffect(() => {
    if (!articleUrl) {
      navigate("/feed");
      return;
    }

    // Fetch article details and related articles
    const fetchArticleAndRelated = async () => {
      setLoading(true);
      try {
        // First, try to get article from sessionStorage (stored when clicking from feed)
        let foundArticle: Article | null = null;
        try {
          const stored = sessionStorage.getItem('currentArticle');
          if (stored) {
            const parsed = JSON.parse(stored);
            if (parsed.url === articleUrl) {
              foundArticle = parsed;
            }
          }
        } catch (e) {
          // Ignore sessionStorage errors
        }

        // Extract keywords for related article search
        let searchKeywords = "";
        if (foundArticle) {
          // Use article title and description for better related articles
          const titleWords = (foundArticle.title || "").toLowerCase().split(/\s+/).filter(w => w.length > 4).slice(0, 5);
          const descWords = (foundArticle.description || "").toLowerCase().split(/\s+/).filter(w => w.length > 4).slice(0, 3);
          searchKeywords = [...titleWords, ...descWords].join(" ");
        }
        
        if (!searchKeywords) {
          // Fallback to URL-based keywords
          searchKeywords = extractKeywordsFromUrl(articleUrl);
        }
        
        // Fetch related articles
        setLoadingRelated(true);
        const searchUrl = `https://newsapi.org/v2/everything?language=en&pageSize=20&sortBy=relevancy&apiKey=${API_KEY}&q=${encodeURIComponent(searchKeywords)}`;
        const res = await axios.get(searchUrl);
        const data = res.data?.articles || [];

        const normalized: Article[] = data.map((a: any, idx: number) => ({
          id: a.url || `article-${idx}`,
          title: a.title || "Untitled",
          description: a.description,
          url: a.url,
          urlToImage: a.urlToImage,
          publishedAt: a.publishedAt,
          author: a.author,
          source: a.source ? { id: a.source.id ?? null, name: a.source.name ?? "" } : undefined,
        }));

        // If we didn't find article in sessionStorage, try to find it in the search results
        if (!foundArticle) {
          foundArticle = normalized.find((a) => a.url === articleUrl) || null;
        }
        
        // If still not found, create a basic article object
        if (!foundArticle) {
          foundArticle = {
            id: articleUrl,
            title: "Article",
            url: articleUrl,
            description: "Click 'Read Full Article' to view the complete story.",
          };
        }

        setArticle(foundArticle);

        // Get related articles (exclude current article)
        const related = normalized
          .filter((a: Article) => a.url !== articleUrl)
          .slice(0, 6); // Show 6 related articles

        setRelatedArticles(related);
        setLoadingRelated(false);
      } catch (err) {
        console.error("Error fetching article and related articles:", err);
        setRelatedArticles([]);
        // Create a basic article object even on error
        setArticle({
          id: articleUrl,
          title: "Article",
          url: articleUrl,
          description: "Click 'Read Full Article' to view the complete story.",
        });
      } finally {
        setLoading(false);
      }
    };

    fetchArticleAndRelated();
  }, [articleUrl, navigate]);

  // Extract keywords from URL for related article search
  const extractKeywordsFromUrl = (url: string): string => {
    try {
      const urlObj = new URL(url);
      const hostname = urlObj.hostname.replace("www.", "");
      const pathParts = urlObj.pathname
        .split("/")
        .filter(p => p.length > 2)
        .map(p => p.replace(/-/g, " ")); // Convert hyphens to spaces
      
      // Combine hostname and path parts for better search
      const keywords = [...pathParts.slice(-3), hostname.split(".")[0]].join(" ");
      return keywords || "news";
    } catch {
      return "news";
    }
  };

  const handleOpenOriginal = () => {
    if (article) {
      markReadStart(article);
      window.open(article.url, "_blank");
    }
  };

  const isBookmarked = article ? user?.bookmarks.some((b) => b.id === article.id || b.url === article.url) : false;

  if (loading) {
    return (
      <div className="container mx-auto py-8 px-4">
        <div className="text-center py-12 text-gray-500 dark:text-gray-300">Loading article...</div>
      </div>
    );
  }

  if (!article) {
    return (
      <div className="container mx-auto py-8 px-4">
        <div className="text-center py-12 text-gray-500 dark:text-gray-300">Article not found.</div>
        <Link to="/feed" className="text-blue-600 dark:text-blue-400 hover:underline">
          ← Back to Feed
        </Link>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 px-4 max-w-6xl">
      {/* Back button */}
      <button
        onClick={() => navigate("/feed")}
        className="mb-6 flex items-center gap-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100 transition-colors"
      >
        <ArrowLeft size={20} />
        <span>Back to Feed</span>
      </button>

      {/* Article Details */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6 mb-8 border border-gray-200 dark:border-gray-700">
        {article.urlToImage && (
          <div
            className="w-full h-64 md:h-96 bg-cover bg-center rounded-lg mb-6"
            style={{ backgroundImage: `url(${article.urlToImage})` }}
          />
        )}

        <h1 className="text-3xl md:text-4xl font-bold mb-4 text-gray-900 dark:text-gray-100">
          {article.title}
        </h1>

        {article.description && (
          <p className="text-lg text-gray-700 dark:text-gray-300 mb-4">{article.description}</p>
        )}

        <div className="flex items-center justify-between mb-6 pt-4 border-t border-gray-200 dark:border-gray-700">
          <div className="text-sm text-gray-600 dark:text-gray-400">
            {article.source?.name && <span className="font-medium">{article.source.name}</span>}
            {article.publishedAt && (
              <span className="ml-2">
                • {new Date(article.publishedAt).toLocaleString()}
              </span>
            )}
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => article && toggleBookmark(article)}
              className={`px-4 py-2 rounded-md transition-colors ${
                isBookmarked
                  ? "bg-blue-600 text-white"
                  : "bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-300 dark:hover:bg-gray-600"
              }`}
            >
              {isBookmarked ? "✓ Bookmarked" : "Bookmark"}
            </button>

            <button
              onClick={handleOpenOriginal}
              className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors flex items-center gap-2"
            >
              <ExternalLink size={18} />
              Read Full Article
            </button>
          </div>
        </div>
      </div>

      {/* Related News Section */}
      <div className="mb-8">
        <h2 className="text-2xl font-semibold mb-6 text-gray-900 dark:text-gray-100">
          Related News
        </h2>

        {loadingRelated ? (
          <div className="text-center py-8 text-gray-500 dark:text-gray-300">
            Loading related articles...
          </div>
        ) : relatedArticles.length === 0 ? (
          <div className="text-center py-8 text-gray-500 dark:text-gray-300">
            No related articles found.
          </div>
        ) : (
          <div className="grid md:grid-cols-3 sm:grid-cols-2 gap-6">
            {relatedArticles.map((relatedArticle) => (
              <ArticleCard
                key={relatedArticle.id}
                article={relatedArticle}
                isBookmarked={!!user?.bookmarks.find((b) => b.id === relatedArticle.id || b.url === relatedArticle.url)}
                onBookmark={toggleBookmark}
                onOpen={() => {
                  // Navigate to related article detail page
                  navigate(`/article/${encodeURIComponent(relatedArticle.url)}`);
                }}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

