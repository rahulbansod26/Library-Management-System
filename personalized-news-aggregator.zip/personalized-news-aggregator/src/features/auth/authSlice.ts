// src/features/auth/authSlice.ts
import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { UserProfile } from '../../types';

interface AuthState {
  user: UserProfile | null;
}

const loadUser = (): UserProfile | null => {
  const u = localStorage.getItem('user');
  return u ? JSON.parse(u) : null;
};

const initialState: AuthState = {
  user: loadUser(),
};

const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    registerUser(state, action: PayloadAction<UserProfile>) {
      const users = JSON.parse(localStorage.getItem('users') || '{}');
      users[action.payload.email] = action.payload;
      localStorage.setItem('users', JSON.stringify(users));
      state.user = action.payload;
      localStorage.setItem('user', JSON.stringify(action.payload));
    },
    loginUser(state, action: PayloadAction<{ email: string; password: string }>) {
      const users = JSON.parse(localStorage.getItem('users') || '{}');
      const found = users[action.payload.email];
      if (found && found.password === action.payload.password) {
        state.user = found;
        localStorage.setItem('user', JSON.stringify(found));
      } else {
        alert('Invalid email or password');
      }
    },
    logout(state) {
      state.user = null;
      localStorage.removeItem('user');
    },
    updateUser(state, action: PayloadAction<UserProfile>) {
      state.user = action.payload;
      localStorage.setItem('user', JSON.stringify(action.payload));
      const users = JSON.parse(localStorage.getItem('users') || '{}');
      users[action.payload.email] = action.payload;
      localStorage.setItem('users', JSON.stringify(users));
    },
  },
});

export const { registerUser, loginUser, logout, updateUser } = authSlice.actions;
export default authSlice.reducer;
