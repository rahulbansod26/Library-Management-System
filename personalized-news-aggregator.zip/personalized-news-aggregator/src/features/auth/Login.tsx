import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useUser } from "../../context/UserContext";

const Login: React.FC = () => {
  const { login, register } = useUser();
  const navigate = useNavigate();

  // Toggle between login and register
  const [isRegister, setIsRegister] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  
  // Error states
  const [emailError, setEmailError] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const [nameError, setNameError] = useState("");

  // Email validation function
  const validateEmail = (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const handleEmailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setEmail(value);
    // Clear error when user starts typing
    if (emailError) {
      setEmailError("");
    }
  };

  const handlePasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setPassword(value);
    // Clear error when user starts typing
    if (passwordError) {
      setPasswordError("");
    }
  };

  const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setName(value);
    // Clear error when user starts typing
    if (nameError) {
      setNameError("");
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Reset errors
    setEmailError("");
    setPasswordError("");
    setNameError("");

    // Validate fields
    let hasErrors = false;

    if (isRegister && !name.trim()) {
      setNameError("Name is required");
      hasErrors = true;
    }

    if (!email.trim()) {
      setEmailError("Email is required");
      hasErrors = true;
    } else if (!validateEmail(email)) {
      setEmailError("Please enter a valid email address");
      hasErrors = true;
    }

    if (!password) {
      setPasswordError("Password is required");
      hasErrors = true;
    } else if (isRegister && password.length < 6) {
      setPasswordError("Password must be at least 6 characters");
      hasErrors = true;
    }

    if (hasErrors) {
      return;
    }

    let success = false;
    
    if (isRegister) {
      success = register(name, email, password);
      if (!success) {
        setEmailError("Email already exists. Please login instead.");
      }
    } else {
      success = login(email, password);
      if (!success) {
        // Check if user exists by trying to get error message
        // The login function uses alert, so we need to check localStorage
        const users = JSON.parse(localStorage.getItem("pna_users") || "{}");
        if (!users[email]) {
          setEmailError("User not found. Please register first or check your email address.");
        } else {
          setPasswordError("Invalid password. Please check your password and try again.");
        }
      }
    }

    if (success) {
      navigate("/feed");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="bg-white dark:bg-gray-800 shadow-xl rounded-2xl p-8 w-full max-w-md">
        <h2 className="text-2xl font-bold mb-6 text-center text-purple-600">
          {isRegister ? "Create Account" : "Welcome Back"}
        </h2>

        <form onSubmit={handleSubmit} className="space-y-4">
          {isRegister && (
            <div>
              <label className="block mb-1 font-medium text-gray-900 dark:text-gray-200">Full Name</label>
              <input
                type="text"
                value={name}
                onChange={handleNameChange}
                placeholder="Enter your name"
                className={`w-full border rounded-md px-3 py-2 focus:ring-2 focus:ring-purple-500 outline-none bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 placeholder-gray-600 dark:placeholder-gray-400 ${
                  nameError
                    ? "border-red-500 dark:border-red-500 focus:ring-red-500"
                    : "border-gray-300 dark:border-gray-600"
                }`}
              />
              {nameError && (
                <p className="mt-1 text-sm text-red-600 dark:text-red-400" style={{ color: '#dc2626' }}>{nameError}</p>
              )}
            </div>
          )}

          <div>
            <label className="block mb-1 font-medium text-gray-900 dark:text-gray-200">Email</label>
            <input
              type="email"
              value={email}
              onChange={handleEmailChange}
              placeholder="Enter your email"
              className={`w-full border rounded-md px-3 py-2 focus:ring-2 focus:ring-purple-500 outline-none bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 placeholder-gray-600 dark:placeholder-gray-400 ${
                emailError
                  ? "border-red-500 dark:border-red-500 focus:ring-red-500"
                  : "border-gray-300 dark:border-gray-600"
              }`}
            />
            {emailError && (
              <p className="mt-1 text-sm text-red-600 dark:text-red-400" style={{ color: '#dc2626' }}>{emailError}</p>
            )}
          </div>

          <div>
            <label className="block mb-1 font-medium text-gray-900 dark:text-gray-200">Password</label>
            <input
              type="password"
              value={password}
              onChange={handlePasswordChange}
              placeholder="Enter your password"
              className={`w-full border rounded-md px-3 py-2 focus:ring-2 focus:ring-purple-500 outline-none bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 placeholder-gray-600 dark:placeholder-gray-400 ${
                passwordError
                  ? "border-red-500 dark:border-red-500 focus:ring-red-500"
                  : "border-gray-300 dark:border-gray-600"
              }`}
            />
            {passwordError && (
              <p className="mt-1 text-sm text-red-600 dark:text-red-400" style={{ color: '#dc2626' }}>{passwordError}</p>
            )}
          </div>

          <button
            type="submit"
            className="w-full bg-purple-600 text-white py-2 rounded-md hover:bg-purple-700 transition-colors"
          >
            {isRegister ? "Register" : "Login"}
          </button>
        </form>

        <p className="mt-6 text-center text-sm text-gray-700 dark:text-gray-300">
          {isRegister ? "Already have an account?" : "New user?"}{" "}
          <button
            type="button"
            onClick={() => {
              setIsRegister(!isRegister);
              // Clear errors when switching modes
              setEmailError("");
              setPasswordError("");
              setNameError("");
            }}
            className="text-purple-600 dark:text-purple-400 font-semibold hover:underline"
          >
            {isRegister ? "Login here" : "Register here"}
          </button>
        </p>
      </div>
    </div>
  );
};

export default Login;
