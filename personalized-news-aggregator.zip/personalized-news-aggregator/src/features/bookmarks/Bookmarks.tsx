// src/features/bookmarks/Bookmarks.tsx
import React from "react";
import { useUser } from "../../context/UserContext";
import ArticleCard from "../../components/ArticleCard";
import { Article } from "../../types";

export default function Bookmarks() {
  const { user, toggleBookmark } = useUser();

  const handleShare = (article: Article) => {
    if (navigator.share) {
      navigator.share({ title: article.title, url: article.url }).catch(() => {});
    } else {
      navigator.clipboard?.writeText(article.url);
      alert("Link copied to clipboard");
    }
  };

  if (!user) return null;

  return (
    <div className="container mx-auto py-8 px-4">
      <h2 className="text-2xl font-semibold mb-4 text-gray-900 dark:text-gray-100">Bookmarks</h2>
      {user.bookmarks.length === 0 ? (
        <div className="text-gray-700 dark:text-gray-300">You have no bookmarks yet.</div>
      ) : (
        <div className="grid md:grid-cols-3 sm:grid-cols-2 gap-6">
          {user.bookmarks.map((a) => (
            <div key={a.id}>
              <ArticleCard
                article={a}
                isBookmarked={true}
                onBookmark={() => toggleBookmark(a)}
                onOpen={() => window.open(a.url, "_blank")}
              />
              <div className="mt-2 flex gap-2">
                <button className="btn btn-outline-secondary btn-sm" onClick={() => handleShare(a)}>
                  Share
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
