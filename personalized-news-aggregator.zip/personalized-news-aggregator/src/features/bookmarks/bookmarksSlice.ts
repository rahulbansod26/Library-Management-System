// src/features/bookmarks/bookmarksSlice.ts
import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { Article } from '../../types';

type State = { bookmarks: Article[] };

const initialState: State = {
  bookmarks: JSON.parse(localStorage.getItem('bookmarks') || '[]'),
};

const slice = createSlice({
  name: 'bookmarks',
  initialState,
  reducers: {
    addBookmark(state, action: PayloadAction<Article>) {
      const exists = state.bookmarks.find(b => b.url === action.payload.url);
      if (!exists) state.bookmarks.unshift(action.payload);
      localStorage.setItem('bookmarks', JSON.stringify(state.bookmarks));
    },
    removeBookmark(state, action: PayloadAction<string>) {
      state.bookmarks = state.bookmarks.filter(b => b.url !== action.payload);
      localStorage.setItem('bookmarks', JSON.stringify(state.bookmarks));
    },
    setBookmarks(state, action: PayloadAction<Article[]>) {
      state.bookmarks = action.payload;
      localStorage.setItem('bookmarks', JSON.stringify(state.bookmarks));
    }
  }
});

export const { addBookmark, removeBookmark, setBookmarks } = slice.actions;
export default slice.reducer;
