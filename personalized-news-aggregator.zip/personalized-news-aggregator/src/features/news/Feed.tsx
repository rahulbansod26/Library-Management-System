// src/features/news/Feed.tsx
import React, { useCallback, useEffect, useMemo, useState } from "react";
import axios from "axios";
import ArticleCard from "../../components/ArticleCard";
import { Article } from "../../types";
import { Button } from "react-bootstrap";
import { useUser } from "../../context/UserContext";
import { rankAndDeduplicateArticles } from "../../utils/personalization";

const API_KEY = process.env.REACT_APP_NEWS_API_KEY || "128e8032f11f4fdebe7e010c442700cf";
type Timeframe = "all" | "today" | "week" | "month";
type SortBy = "relevancy" | "popularity" | "publishedAt";

export default function Feed() {
  const { user, toggleBookmark, markReadStart } = useUser();
  const [articles, setArticles] = useState<Article[]>([]);
  const [sources, setSources] = useState<{ id: string; name: string }[]>([]);
  const [category, setCategory] = useState<string>("all");
  const [sourceFilter, setSourceFilter] = useState<string>("all");
  const [timeframe, setTimeframe] = useState<Timeframe>("all");
  const [sortBy, setSortBy] = useState<SortBy>("publishedAt");
  const [keyword, setKeyword] = useState<string>("");
  const [loading, setLoading] = useState(false);
  const [refreshFlag, setRefreshFlag] = useState(0);

  const categories = useMemo(
    () => [
      "all",
      "business",
      "entertainment",
      "general",
      "health",
      "science",
      "sports",
      "technology",
    ],
    []
  );

  // ✅ Fetch available sources globally
  const fetchSources = useCallback(async () => {
    try {
      const res = await axios.get(
        `https://newsapi.org/v2/top-headlines/sources?language=en&apiKey=${API_KEY}`
      );
      if (res.data?.sources?.length) {
        const list = res.data.sources.map((s: any) => ({
          id: s.id,
          name: s.name,
        }));
        setSources(list);
      }
    } catch (err) {
      console.error("Error fetching sources:", err);
      setSources([]);
    }
  }, []);

  // ✅ Build and fetch articles dynamically based on filters
  const fetchNews = useCallback(async () => {
    setLoading(true);
    try {
      let url = "";

      // 🟣 Use `everything` when keyword or sorting by relevance/popularity
      if (keyword.trim() || sortBy !== "publishedAt") {
        url = `https://newsapi.org/v2/everything?language=en&pageSize=40&sortBy=${sortBy}&apiKey=${API_KEY}`;

        if (keyword.trim()) url += `&q=${encodeURIComponent(keyword)}`;
        if (sourceFilter !== "all") {
          const selectedSource = sources.find((s) => s.id === sourceFilter);
          if (selectedSource?.id) url += `&sources=${encodeURIComponent(selectedSource.id)}`;
        }
      } else {
        // 🟢 Use top-headlines for category/source-based filtering
        url = `https://newsapi.org/v2/top-headlines?language=en&pageSize=40&apiKey=${API_KEY}`;
        if (category !== "all") url += `&category=${encodeURIComponent(category)}`;
        if (sourceFilter !== "all") {
          const selectedSource = sources.find((s) => s.id === sourceFilter);
          if (selectedSource?.id) url += `&sources=${encodeURIComponent(selectedSource.id)}`;
        }
      }

      const res = await axios.get(url);
      const data = res.data?.articles || [];

      // Store the category from the API call for later use
      const currentCategory = category !== "all" ? category : undefined;
      
      const normalized: Article[] = data.map((a: any, idx: number) => ({
        id: a.url || `article-${idx}`,
        title: a.title || "Untitled",
        description: a.description,
        url: a.url,
        urlToImage: a.urlToImage,
        publishedAt: a.publishedAt,
        author: a.author,
        source: a.source ? { id: a.source.id ?? null, name: a.source.name ?? "" } : undefined,
        category: currentCategory, // Add category from the API call
      }));

      // Apply personalized ranking and deduplication
      const personalizedArticles = rankAndDeduplicateArticles(normalized, user);
      
      // Filter out articles with negative scores (excluded)
      const filteredArticles = personalizedArticles.filter(a => (a.score || 0) > -100);
      
      setArticles(filteredArticles);
    } catch (err) {
      console.error("Error fetching news:", err);
      setArticles([]);
    } finally {
      setLoading(false);
    }
  }, [category, sourceFilter, keyword, sortBy, refreshFlag, sources, user]);

  useEffect(() => {
    fetchSources();
  }, [fetchSources]);

  useEffect(() => {
    fetchNews();
  }, [fetchNews]);

  // 🕒 Filter by time on client side
  const timeFilteredArticles = useMemo(() => {
    if (timeframe === "all") return articles;
    const now = Date.now();
    return articles.filter((a) => {
      if (!a.publishedAt) return false;
      const t = new Date(a.publishedAt).getTime();
      if (timeframe === "today") {
        const start = new Date();
        start.setHours(0, 0, 0, 0);
        return t >= start.getTime();
      }
      if (timeframe === "week") return t >= now - 7 * 24 * 3600 * 1000;
      if (timeframe === "month") return t >= now - 30 * 24 * 3600 * 1000;
      return true;
    });
  }, [articles, timeframe]);

  const handleBookmark = (article: Article) => toggleBookmark(article);

  // Note: ArticleCard handles its own opening and time tracking
  const handleOpen = (article: Article) => {
    // This is called by ArticleCard after it sets up tracking
    // No need to do anything here - ArticleCard handles everything
  };

  return (
    <div className="container mx-auto py-8 px-4">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-semibold flex items-center gap-2 text-gray-900 dark:text-gray-100">
            📰 Personalized News Feed
          </h2>
          <p className="text-gray-700 dark:text-gray-300 text-sm">
            Tailored reading, smarter day
          </p>
        </div>

        <Button
          variant="outline-secondary"
          size="sm"
          onClick={() => setRefreshFlag((s) => s + 1)}
        >
          🔄 Refresh Feed
        </Button>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3 mb-6 items-center">
        {/* Category */}
        <select
          className="border border-gray-300 dark:border-gray-600 rounded-md p-2 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
          value={category}
          onChange={(e) => setCategory(e.target.value)}
        >
          {categories.map((c) => (
            <option key={c} value={c}>
              {c === "all" ? "All Categories" : c.charAt(0).toUpperCase() + c.slice(1)}
            </option>
          ))}
        </select>

        {/* Source */}
        <select
          className="border border-gray-300 dark:border-gray-600 rounded-md p-2 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
          value={sourceFilter}
          onChange={(e) => setSourceFilter(e.target.value)}
        >
          <option value="all">All Sources</option>
          {sources.map((s) => (
            <option key={s.id} value={s.id}>
              {s.name}
            </option>
          ))}
        </select>

        {/* Timeframe */}
        <select
          className="border border-gray-300 dark:border-gray-600 rounded-md p-2 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
          value={timeframe}
          onChange={(e) => setTimeframe(e.target.value as Timeframe)}
        >
          <option value="all">Time: all</option>
          <option value="today">Time: today</option>
          <option value="week">Time: last week</option>
          <option value="month">Time: last month</option>
        </select>

        {/* Sorting */}
        <select
          className="border border-gray-300 dark:border-gray-600 rounded-md p-2 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value as SortBy)}
        >
          <option value="publishedAt">Sort by: Recency</option>
          <option value="relevancy">Sort by: Relevance</option>
          <option value="popularity">Sort by: Popularity</option>
        </select>

        {/* Keyword search */}
        <input
          type="text"
          className="border border-gray-300 dark:border-gray-600 rounded-md p-2 flex-grow bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 placeholder-gray-400 dark:placeholder-gray-400"
          placeholder="Search by keyword..."
          value={keyword}
          onChange={(e) => setKeyword(e.target.value)}
        />

        <Button onClick={fetchNews} variant="primary" size="sm">
          🔍 Search
        </Button>
      </div>

      {/* Articles */}
      {loading ? (
        <div className="text-center py-8 text-gray-500 dark:text-gray-300">Loading…</div>
      ) : timeFilteredArticles.length === 0 ? (
        <div className="text-center py-12 text-gray-500 dark:text-gray-300">No news articles available.</div>
      ) : (
        <div className="grid md:grid-cols-3 sm:grid-cols-2 gap-6">
          {timeFilteredArticles.map((article) => (
            <ArticleCard
              key={article.id}
              article={article}
                isBookmarked={!!user?.bookmarks.find((b) => b.id === article.id || b.url === article.url)}
              onBookmark={handleBookmark}
              onOpen={handleOpen}
            />
          ))}
        </div>
      )}
    </div>
  );
}
