import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { Article, UserProfile } from '../../types';
import { fetchNews as fetchNewsFromApi } from '../../api/newsApi';
import { dedupeArticles } from '../../services/dedupe';
import { recommendArticles } from '../../services/recommendation';


export const fetchNews = createAsyncThunk(
  'news/fetch',
  async ({ q, user }: { q?: string; user?: UserProfile | null }) => {
    const source = await fetchNewsFromApi({ q: q || '' });
    const deduped = dedupeArticles(source.articles || []);
  const scored = recommendArticles(deduped, user || undefined);

  
  return scored;
  }
);

const newsSlice = createSlice({
  name: 'news',
  initialState: {
    articles: [] as Article[],
    loading: false,
    error: null as string | null,
  },
  reducers: {},
  extraReducers: builder => {
    builder
      .addCase(fetchNews.pending, state => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchNews.fulfilled, (state, action) => {
        state.loading = false;
        state.articles = action.payload;
      })
      .addCase(fetchNews.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || 'Failed to load news';
      });
  },
});

export default newsSlice.reducer;
