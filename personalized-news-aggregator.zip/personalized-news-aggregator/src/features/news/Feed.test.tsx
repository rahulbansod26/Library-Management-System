import '@testing-library/jest-dom';
import React from 'react';
import { render, screen } from '@testing-library/react';
import Feed from './Feed';
import { Provider } from 'react-redux';
import { store } from '../../store/store';

test('renders feed heading', () => {
  render(<Provider store={store}><Feed /></Provider>);
  expect(screen.getByPlaceholderText(/Search/i)).toBeInTheDocument();
});

test('renders search input', () => {
  render(<Provider store={store}><Feed/></Provider>);
  expect(screen.getByPlaceholderText(/Search/i)).toBeInTheDocument();
});
