// src/features/preferences/Preferences.tsx
import React, { useState, useEffect } from "react";
import { useUser } from "../../context/UserContext";

const CATEGORIES = [
  "business",
  "entertainment",
  "general",
  "health",
  "science",
  "sports",
  "technology",
];

export default function Preferences() {
  const { user, updatePreferences } = useUser();
  const [excludedCategories, setExcludedCategories] = useState<string[]>([]);
  const [excludedSources, setExcludedSources] = useState<string[]>([]);
  const [newSource, setNewSource] = useState("");
  const [excludedKeyword, setExcludedKeyword] = useState("");
  const [excludedKeywords, setExcludedKeywords] = useState<string[]>([]);

  useEffect(() => {
    if (user?.preferences) {
      setExcludedCategories(user.preferences.excludedCategories || []);
      setExcludedSources(user.preferences.excludedSources || []);
      setExcludedKeywords(user.preferences.excludedKeywords || []);
    }
  }, [user]);

  const handleCategoryToggle = (category: string) => {
    const updated = excludedCategories.includes(category)
      ? excludedCategories.filter((c) => c !== category)
      : [...excludedCategories, category];
    setExcludedCategories(updated);
    updatePreferences({ excludedCategories: updated });
  };

  const handleSourceAdd = () => {
    if (newSource.trim() && !excludedSources.includes(newSource.trim())) {
      const updated = [...excludedSources, newSource.trim()];
      setExcludedSources(updated);
      setNewSource("");
      updatePreferences({ excludedSources: updated });
    }
  };

  const handleSourceRemove = (source: string) => {
    const updated = excludedSources.filter((s) => s !== source);
    setExcludedSources(updated);
    updatePreferences({ excludedSources: updated });
  };

  const handleKeywordAdd = () => {
    if (excludedKeyword.trim() && !excludedKeywords.includes(excludedKeyword.trim())) {
      const updated = [...excludedKeywords, excludedKeyword.trim()];
      setExcludedKeywords(updated);
      setExcludedKeyword("");
      updatePreferences({ excludedKeywords: updated });
    }
  };

  const handleKeywordRemove = (keyword: string) => {
    const updated = excludedKeywords.filter((k) => k !== keyword);
    setExcludedKeywords(updated);
    updatePreferences({ excludedKeywords: updated });
  };

  if (!user) {
    return <div className="text-center py-10 text-gray-500 dark:text-gray-300">Please log in to manage preferences.</div>;
  }

  return (
    <div className="container mx-auto py-8 px-4 max-w-4xl">
      <h2 className="text-3xl font-semibold mb-2 text-gray-900 dark:text-gray-100">
        Content Preferences
      </h2>
      <p className="text-gray-500 dark:text-gray-400 mb-8">
        Customize your news feed by excluding topics, sources, or keywords you don't want to see.
      </p>

      {/* Excluded Categories */}
      <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-md mb-6 border border-gray-200 dark:border-gray-700">
        <h3 className="text-xl font-semibold mb-4 text-gray-900 dark:text-gray-100">
          Exclude Categories
        </h3>
        <div className="flex flex-wrap gap-3">
          {CATEGORIES.map((category) => (
            <button
              key={category}
              onClick={() => handleCategoryToggle(category)}
              className={`px-4 py-2 rounded-md transition-colors ${
                excludedCategories.includes(category)
                  ? "bg-red-500 text-white"
                  : "bg-gray-200 dark:bg-gray-700 text-gray-900 dark:text-gray-100 hover:bg-gray-300 dark:hover:bg-gray-600"
              }`}
            >
              {category.charAt(0).toUpperCase() + category.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Excluded Sources */}
      <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-md mb-6 border border-gray-200 dark:border-gray-700">
        <h3 className="text-xl font-semibold mb-4 text-gray-900 dark:text-gray-100">
          Exclude Sources
        </h3>
        <div className="flex gap-2 mb-4">
          <input
            type="text"
            placeholder="Enter source name to exclude"
            value={newSource}
            onChange={(e) => setNewSource(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && handleSourceAdd()}
            className="flex-1 border border-gray-300 dark:border-gray-600 rounded-md p-2 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 placeholder-gray-500 dark:placeholder-gray-400"
          />
          <button
            onClick={handleSourceAdd}
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
          >
            Add
          </button>
        </div>
        <div className="flex flex-wrap gap-2">
          {excludedSources.map((source) => (
            <span
              key={source}
              className="inline-flex items-center gap-2 px-3 py-1 bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 rounded-full"
            >
              {source}
              <button
                onClick={() => handleSourceRemove(source)}
                className="text-red-600 dark:text-red-300 hover:text-red-800 dark:hover:text-red-100"
              >
                ×
              </button>
            </span>
          ))}
        </div>
      </div>

      {/* Excluded Keywords */}
      <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-md border border-gray-200 dark:border-gray-700">
        <h3 className="text-xl font-semibold mb-2 text-gray-900 dark:text-gray-100">
          Exclude Keywords
        </h3>
        <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
          Articles containing these keywords in their title or description will be excluded.
          <br />
          <span className="text-xs text-gray-400 dark:text-gray-500">
            Example: Excluding "india" will filter out articles mentioning "India", "Indian", "Indians", etc.
          </span>
        </p>
        <div className="flex gap-2 mb-4">
          <input
            type="text"
            placeholder="Enter keyword to exclude (e.g., india, politics, sports)"
            value={excludedKeyword}
            onChange={(e) => setExcludedKeyword(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && handleKeywordAdd()}
            className="flex-1 border border-gray-300 dark:border-gray-600 rounded-md p-2 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 placeholder-gray-500 dark:placeholder-gray-400"
          />
          <button
            onClick={handleKeywordAdd}
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
          >
            Add
          </button>
        </div>
        {excludedKeywords.length > 0 && (
          <div className="mb-4">
            <p className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Excluded keywords ({excludedKeywords.length}):
            </p>
            <div className="flex flex-wrap gap-2">
              {excludedKeywords.map((keyword) => (
                <span
                  key={keyword}
                  className="inline-flex items-center gap-2 px-3 py-1 bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 rounded-full"
                >
                  {keyword}
                  <button
                    onClick={() => handleKeywordRemove(keyword)}
                    className="text-red-600 dark:text-red-300 hover:text-red-800 dark:hover:text-red-100"
                    title="Remove keyword"
                  >
                    ×
                  </button>
                </span>
              ))}
            </div>
          </div>
        )}
        {excludedKeywords.length === 0 && (
          <p className="text-sm text-gray-400 dark:text-gray-500 italic">
            No keywords excluded. Add keywords above to filter out articles.
          </p>
        )}
      </div>
    </div>
  );
}

