import { createSlice, PayloadAction } from '@reduxjs/toolkit';

const initialPrefs = {
  categories: ['general'],
  keywords: [] as string[],
  sources: [] as string[],
  excludedTopics: [] as string[],
  weights: {} as Record<string, number>
};

const prefsSlice = createSlice({
  name: 'prefs',
  initialState: initialPrefs,
  reducers: {
    setCategories(state, action: PayloadAction<string[]>) { state.categories = action.payload; },
    addKeyword(state, action: PayloadAction<string>) { state.keywords.push(action.payload); state.weights[action.payload] = 5; },
    removeKeyword(state, action: PayloadAction<string>) { state.keywords = state.keywords.filter(k=>k!==action.payload); delete state.weights[action.payload]; },
    bumpWeight(state, action: PayloadAction<string>) {
      const k = action.payload;
      state.weights[k] = (state.weights[k] || 5) + 2;
    }
  }
});

export const { setCategories, addKeyword, removeKeyword, bumpWeight } = prefsSlice.actions;
export default prefsSlice.reducer;

type WeightMap = { [keyword: string]: number };

const initial = {
  preferences: { categories: [], keywords: [], weights: {} as WeightMap }
};
