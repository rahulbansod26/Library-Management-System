// src/features/analytics/Analytics.tsx
import React, { useMemo } from "react";
import { useUser } from "../../context/UserContext";
import {
  PieChart,
  Pie,
  Cell,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
} from "recharts";
import Papa from "papaparse";
import { saveAs } from "file-saver";

const COLORS = ["#6C5CE7", "#00B894", "#FFB86B", "#FF7675", "#74B9FF", "#FD79A8", "#00cec9"];

// Custom label renderer for pie charts - makes labels more visible
const renderCustomLabel = (entry: any) => {
  const { cx, cy, midAngle, innerRadius, outerRadius, percent, value, name } = entry;
  if (value === 0) return null; // Don't show label for zero values
  
  // Calculate position on the segment
  const RADIAN = Math.PI / 180;
  const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
  const x = cx + radius * Math.cos(-midAngle * RADIAN);
  const y = cy + radius * Math.sin(-midAngle * RADIAN);
  
  return (
    <text
      x={x}
      y={y}
      fill="white"
      textAnchor="middle"
      dominantBaseline="middle"
      fontSize="16"
      fontWeight="bold"
      style={{
        textShadow: "2px 2px 4px rgba(0,0,0,0.9), -2px -2px 4px rgba(0,0,0,0.9), 0 0 8px rgba(0,0,0,0.9)",
        pointerEvents: "none",
      }}
    >
      {`${value}`}
    </text>
  );
};

export default function Analytics() {
  const { user } = useUser();

  // ✅ Always define hooks before any return
  const bookmarksVsReads = useMemo(() => {
    const bookmarks = user?.bookmarks?.length || 0;
    const reads = user?.history?.length || 0;
    return [
      { name: "Bookmarks", value: bookmarks },
      { name: "Reads", value: reads },
    ];
  }, [user]);

  const topSourcesMap = useMemo(() => {
    if (!user) return [];
    const m: Record<string, number> = {};
    for (const h of user.history) {
      const s = h.source || "Unknown";
      m[s] = (m[s] || 0) + 1;
    }
    return Object.entries(m)
      .sort((a, b) => b[1] - a[1])
      .map(([name, value]) => ({ name, value }));
  }, [user]);

  const readsByDate = useMemo(() => {
    if (!user) return [];
    const map: Record<string, number> = {};
    for (const h of user.history) {
      const d = new Date(h.readAt).toLocaleDateString();
      map[d] = (map[d] || 0) + 1;
    }
    return Object.entries(map)
      .map(([date, count]) => ({ date, count }))
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  }, [user]);

  const timeSpentByDate = useMemo(() => {
    if (!user) return [];
    const map: Record<string, number> = {};
    for (const h of user.history) {
      const d = new Date(h.readAt).toLocaleDateString();
      map[d] = (map[d] || 0) + (h.timeSpent || 0);
    }
    return Object.entries(map)
      .map(([date, seconds]) => ({
        date,
        minutes: Math.round((seconds / 60) * 100) / 100,
      }))
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  }, [user]);

  if (!user) return <div className="text-center py-8">No user data.</div>;

  // ✅ Flattened CSV data (works perfectly)
  const exportCsv = () => {
    const combined = [
      ...user.bookmarks.map((b) => ({
        type: "bookmark",
        id: b.id,
        title: b.title,
        source: b.source?.name || "",
        url: b.url,
      })),
      ...user.history.map((h) => ({
        type: "read",
        id: h.id,
        title: h.title,
        source: h.source,
        readAt: h.readAt,
        timeSpent: h.timeSpent,
      })),
    ];
    const csv = Papa.unparse(combined);
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    saveAs(blob, "analytics.csv");
  };

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-semibold text-gray-900 dark:text-gray-100">Analytics</h2>
        <div>
          <button className="btn btn-outline-secondary btn-sm" onClick={exportCsv}>
            Export CSV
          </button>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="card p-4">
          <h3 className="font-semibold mb-2 text-gray-900 dark:text-gray-100">Bookmarks vs Reads</h3>
          <div style={{ height: 240 }}>
            <ResponsiveContainer>
              <PieChart>
                <Pie 
                  dataKey="value" 
                  data={bookmarksVsReads} 
                  cx="50%" 
                  cy="50%" 
                  outerRadius={80} 
                  label={renderCustomLabel}
                  labelLine={false}
                >
                  {bookmarksVsReads.map((entry, idx) => (
                    <Cell key={idx} fill={COLORS[idx % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="card p-4">
          <h3 className="font-semibold mb-2 text-gray-900 dark:text-gray-100">Top Sources Visited</h3>
          <div style={{ height: 240 }}>
            <ResponsiveContainer>
              <PieChart>
                <Pie 
                  dataKey="value" 
                  data={topSourcesMap} 
                  cx="50%" 
                  cy="50%" 
                  outerRadius={80} 
                  label={renderCustomLabel}
                  labelLine={false}
                >
                  {topSourcesMap.map((entry, idx) => (
                    <Cell key={idx} fill={COLORS[idx % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="card p-4">
          <h3 className="font-semibold mb-2 text-gray-900 dark:text-gray-100">Reading Activity Over Time (Articles Read)</h3>
          <div style={{ height: 260 }}>
            <ResponsiveContainer>
              <LineChart data={readsByDate}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="count" stroke="#6C5CE7" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="card p-4">
          <h3 className="font-semibold mb-2 text-gray-900 dark:text-gray-100">Time Spent Reading (Minutes)</h3>
          {timeSpentByDate.length === 0 ? (
            <div className="flex items-center justify-center h-64 text-gray-500 dark:text-gray-400">
              <p>No reading time data yet. Open and read some articles to see your reading time graph.</p>
            </div>
          ) : (
            <div style={{ height: 260 }}>
              <ResponsiveContainer>
                <LineChart data={timeSpentByDate}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip formatter={(value: any) => [`${value} min`, "Time Spent"]} />
                  <Line type="monotone" dataKey="minutes" stroke="#00B894" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
