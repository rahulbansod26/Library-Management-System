# Personalized News Aggregator (React + TypeScript — CRA)

This project is an MVP implementation of the Personalized News Aggregator & Recommendation System.

**Notes**
- Built with Create React App style (react-scripts) — per request no Vite.
- Use `.env` or server proxy to hold API keys. The project includes a simple express proxy in `server/server.js`.
- Start the server: `npm run start:server` (provides proxy & simple persistence via JSON)
- Start the app: `npm start`

