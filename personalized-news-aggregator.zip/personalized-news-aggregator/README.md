# Personalized News Aggregator (React + TypeScript — CRA)

This project is an MVP implementation of the Personalized News Aggregator & Recommendation System.

**Notes**
- Built with Create React App style (react-scripts) — per request no Vite.
- **Pure React app** - All data stored in localStorage (no backend server required)
- Uses NewsAPI directly from the frontend (set `REACT_APP_NEWS_API_KEY` in `.env`)
- Start the app: `npm start`
- Build for production: `npm run build`

**Features:**
- ✅ User authentication (localStorage-based)
- ✅ Personalized news feed with ranking
- ✅ Bookmarks and reading history
- ✅ Analytics and charts
- ✅ User preferences and exclusions
- ✅ Browser notifications (email notifications require backend)
- ✅ Dark/Light theme

