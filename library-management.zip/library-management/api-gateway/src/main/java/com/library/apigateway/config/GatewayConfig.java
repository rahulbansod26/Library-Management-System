package com.library.apigateway.config;

import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class GatewayConfig {
    
    @Bean
    public RouteLocator customRouteLocator(RouteLocatorBuilder builder) {
        return builder.routes()
                // User Service routes
                .route("user-service", r -> r.path("/api/users/**")
                        .uri("http://localhost:8081"))
                
                // Catalog Service routes
                .route("catalog-service", r -> r.path("/api/books/**")
                        .uri("http://localhost:8082"))
                
                // Borrowing Service routes
                .route("borrowing-service", r -> r.path("/api/borrowings/**")
                        .uri("http://localhost:8083"))
                
                // Fine Service routes
                .route("fine-service", r -> r.path("/api/fines/**")
                        .uri("http://localhost:8084"))
                
                // Notification Service routes
                .route("notification-service", r -> r.path("/api/notifications/**")
                        .uri("http://localhost:8085"))
                
                .build();
    }
}

