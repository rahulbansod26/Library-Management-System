#!/usr/bin/env python3
import http.server
import socketserver
import json
import urllib.parse
from datetime import datetime, timedelta
import threading
import time

class LibraryAPIHandler(http.server.BaseHTTPRequestHandler):
    
    def do_GET(self):
        if self.path == '/api/users':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            users = [
                {"id": 1, "username": "john_doe", "email": "john@example.com", "firstName": "John", "lastName": "Doe", "role": "USER", "active": True},
                {"id": 2, "username": "jane_smith", "email": "jane@example.com", "firstName": "Jane", "lastName": "Smith", "role": "LIBRARIAN", "active": True},
                {"id": 3, "username": "admin_user", "email": "admin@example.com", "firstName": "Admin", "lastName": "User", "role": "ADMIN", "active": True}
            ]
            self.wfile.write(json.dumps(users).encode())
        elif self.path == '/api/books':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            books = [
                {"id": 1, "title": "The Great Gatsby", "author": "F. Scott Fitzgerald", "isbn": "9780743273565", "genre": "Fiction", "description": "A classic American novel", "status": "AVAILABLE", "active": True},
                {"id": 2, "title": "To Kill a Mockingbird", "author": "Harper Lee", "isbn": "9780061120084", "genre": "Fiction", "description": "A story of racial injustice", "status": "BORROWED", "active": True},
                {"id": 3, "title": "1984", "author": "George Orwell", "isbn": "9780451524935", "genre": "Dystopian", "description": "A dystopian social science fiction novel", "status": "AVAILABLE", "active": True},
                {"id": 4, "title": "Pride and Prejudice", "author": "Jane Austen", "isbn": "9780141439518", "genre": "Romance", "description": "A romantic novel of manners", "status": "RESERVED", "active": True}
            ]
            self.wfile.write(json.dumps(books).encode())
        elif self.path == '/api/books/available':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            available_books = [
                {"id": 1, "title": "The Great Gatsby", "author": "F. Scott Fitzgerald", "isbn": "9780743273565", "genre": "Fiction", "status": "AVAILABLE"},
                {"id": 3, "title": "1984", "author": "George Orwell", "isbn": "9780451524935", "genre": "Dystopian", "status": "AVAILABLE"}
            ]
            self.wfile.write(json.dumps(available_books).encode())
        elif self.path == '/api/books/search':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            search_results = [
                {"id": 1, "title": "The Great Gatsby", "author": "F. Scott Fitzgerald", "isbn": "9780743273565", "genre": "Fiction", "status": "AVAILABLE"},
                {"id": 3, "title": "1984", "author": "George Orwell", "isbn": "9780451524935", "genre": "Dystopian", "status": "AVAILABLE"}
            ]
            self.wfile.write(json.dumps(search_results).encode())
        elif self.path == '/api/borrowings/user/1':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            borrowings = [
                {"id": 1, "userId": 1, "bookId": 2, "borrowDate": "2024-01-15T10:00:00", "dueDate": "2024-01-29T10:00:00", "status": "ACTIVE"},
                {"id": 2, "userId": 1, "bookId": 3, "borrowDate": "2024-01-20T14:30:00", "dueDate": "2024-02-03T14:30:00", "status": "ACTIVE"}
            ]
            self.wfile.write(json.dumps(borrowings).encode())
        elif self.path == '/api/borrowings/user/1/active':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            active_borrowings = [
                {"id": 1, "userId": 1, "bookId": 2, "borrowDate": "2024-01-15T10:00:00", "dueDate": "2024-01-29T10:00:00", "status": "ACTIVE"},
                {"id": 2, "userId": 1, "bookId": 3, "borrowDate": "2024-01-20T14:30:00", "dueDate": "2024-02-03T14:30:00", "status": "ACTIVE"}
            ]
            self.wfile.write(json.dumps(active_borrowings).encode())
        elif self.path == '/api/fines/user/1':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            fines = [
                {"id": 1, "userId": 1, "borrowingId": 1, "amount": 5.00, "reason": "Overdue book", "status": "PENDING", "dueDate": "2024-02-15T10:00:00"},
                {"id": 2, "userId": 1, "borrowingId": 2, "amount": 2.50, "reason": "Late return", "status": "PAID", "paidDate": "2024-01-25T09:00:00"}
            ]
            self.wfile.write(json.dumps(fines).encode())
        elif self.path == '/api/fines/user/1/pending':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            pending_fines = [
                {"id": 1, "userId": 1, "borrowingId": 1, "amount": 5.00, "reason": "Overdue book", "status": "PENDING", "dueDate": "2024-02-15T10:00:00"}
            ]
            self.wfile.write(json.dumps(pending_fines).encode())
        elif self.path == '/api/notifications/user/1':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            notifications = [
                {"id": 1, "userId": 1, "subject": "Book Due Soon", "message": "Your book 'To Kill a Mockingbird' is due in 2 days", "type": "DUE_DATE_REMINDER", "channel": "EMAIL", "sent": True, "sentAt": "2024-01-27T10:00:00"},
                {"id": 2, "userId": 1, "subject": "Welcome to Library", "message": "Welcome to our library management system!", "type": "REGISTRATION", "channel": "EMAIL", "sent": True, "sentAt": "2024-01-15T09:00:00"}
            ]
            self.wfile.write(json.dumps(notifications).encode())
        elif self.path == '/api/notifications/user/1/pending':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            pending_notifications = [
                {"id": 3, "userId": 1, "subject": "Overdue Alert", "message": "You have an overdue book", "type": "OVERDUE_ALERT", "channel": "EMAIL", "sent": False}
            ]
            self.wfile.write(json.dumps(pending_notifications).encode())
        elif self.path == '/health':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            health = {"status": "UP", "timestamp": datetime.now().isoformat(), "services": ["user-service", "catalog-service", "borrowing-service", "fine-service", "notification-service"]}
            self.wfile.write(json.dumps(health).encode())
        else:
            self.send_response(404)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            error = {"error": "Not Found", "path": self.path, "message": "The requested endpoint does not exist"}
            self.wfile.write(json.dumps(error).encode())
    
    def do_POST(self):
        content_length = int(self.headers.get('Content-Length', 0))
        post_data = self.rfile.read(content_length) if content_length > 0 else b'{}'
        
        if self.path == '/api/users/register':
            self.send_response(201)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            user = {"id": 4, "username": "new_user", "email": "new@example.com", "firstName": "New", "lastName": "User", "role": "USER", "active": True, "createdAt": datetime.now().isoformat()}
            self.wfile.write(json.dumps(user).encode())
        elif self.path == '/api/users/login':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            login = {
                "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJqb2huX2RvZSIsInJvbGUiOiJVU0VSIn0...",
                "tokenType": "Bearer",
                "user": {"id": 1, "username": "john_doe", "role": "USER"}
            }
            self.wfile.write(json.dumps(login).encode())
        elif self.path == '/api/books':
            self.send_response(201)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            book = {"id": 5, "title": "New Book", "author": "New Author", "isbn": "9781234567890", "genre": "Fiction", "description": "A new book", "status": "AVAILABLE", "active": True, "createdAt": datetime.now().isoformat()}
            self.wfile.write(json.dumps(book).encode())
        elif self.path == '/api/borrowings/borrow':
            self.send_response(201)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            borrowing = {
                "id": 3,
                "userId": 1,
                "bookId": 1,
                "borrowDate": datetime.now().isoformat(),
                "dueDate": (datetime.now() + timedelta(days=14)).isoformat(),
                "status": "ACTIVE",
                "createdAt": datetime.now().isoformat()
            }
            self.wfile.write(json.dumps(borrowing).encode())
        elif self.path == '/api/borrowings/1/return':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            borrowing = {
                "id": 1,
                "userId": 1,
                "bookId": 2,
                "borrowDate": "2024-01-15T10:00:00",
                "dueDate": "2024-01-29T10:00:00",
                "returnDate": datetime.now().isoformat(),
                "status": "RETURNED",
                "updatedAt": datetime.now().isoformat()
            }
            self.wfile.write(json.dumps(borrowing).encode())
        elif self.path == '/api/fines':
            self.send_response(201)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            fine = {
                "id": 3,
                "userId": 1,
                "borrowingId": 1,
                "amount": 10.00,
                "reason": "Lost book",
                "status": "PENDING",
                "dueDate": (datetime.now() + timedelta(days=30)).isoformat(),
                "createdAt": datetime.now().isoformat()
            }
            self.wfile.write(json.dumps(fine).encode())
        elif self.path == '/api/fines/1/pay':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            fine = {
                "id": 1,
                "userId": 1,
                "borrowingId": 1,
                "amount": 5.00,
                "reason": "Overdue book",
                "status": "PAID",
                "paidDate": datetime.now().isoformat(),
                "updatedAt": datetime.now().isoformat()
            }
            self.wfile.write(json.dumps(fine).encode())
        elif self.path == '/api/notifications':
            self.send_response(201)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            notification = {
                "id": 4,
                "userId": 1,
                "subject": "New Notification",
                "message": "Test notification",
                "type": "REGISTRATION",
                "channel": "EMAIL",
                "sent": False,
                "createdAt": datetime.now().isoformat()
            }
            self.wfile.write(json.dumps(notification).encode())
        else:
            self.send_response(404)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            error = {"error": "Not Found", "path": self.path, "message": "The requested endpoint does not exist"}
            self.wfile.write(json.dumps(error).encode())

if __name__ == "__main__":
    PORT = 8080
    with socketserver.TCPServer(("", PORT), LibraryAPIHandler) as httpd:
        print(f"🚀 Library Management System API Demo Server")
        print(f"🌐 Server running on: http://localhost:{PORT}")
        print(f"📚 Available API endpoints:")
        print(f"  GET  /health - System health check")
        print(f"  GET  /api/users - Get all users")
        print(f"  POST /api/users/register - Register new user")
        print(f"  POST /api/users/login - User login")
        print(f"  GET  /api/books - Get all books")
        print(f"  GET  /api/books/available - Get available books")
        print(f"  GET  /api/books/search - Search books")
        print(f"  POST /api/books - Add new book")
        print(f"  GET  /api/borrowings/user/1 - Get user borrowings")
        print(f"  GET  /api/borrowings/user/1/active - Get active borrowings")
        print(f"  POST /api/borrowings/borrow - Borrow a book")
        print(f"  POST /api/borrowings/1/return - Return a book")
        print(f"  GET  /api/fines/user/1 - Get user fines")
        print(f"  GET  /api/fines/user/1/pending - Get pending fines")
        print(f"  POST /api/fines - Create fine")
        print(f"  POST /api/fines/1/pay - Pay fine")
        print(f"  GET  /api/notifications/user/1 - Get user notifications")
        print(f"  GET  /api/notifications/user/1/pending - Get pending notifications")
        print(f"  POST /api/notifications - Send notification")
        print(f"")
        print(f"🎯 Test the APIs using curl or any HTTP client!")
        print(f"Press Ctrl+C to stop the server")
        httpd.serve_forever()

