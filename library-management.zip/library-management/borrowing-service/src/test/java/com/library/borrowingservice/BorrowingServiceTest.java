package com.library.borrowingservice;

import com.library.common.dto.BorrowingDto;
import com.library.borrowingservice.entity.Borrowing;
import com.library.borrowingservice.repository.BorrowingRepository;
import com.library.borrowingservice.service.BookServiceClient;
import com.library.borrowingservice.service.BorrowingService;
import com.library.borrowingservice.service.UserServiceClient;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@SpringBootTest
@ActiveProfiles("test")
class BorrowingServiceTest {

    @Autowired
    private BorrowingService borrowingService;

    @MockBean
    private BorrowingRepository borrowingRepository;

    @MockBean
    private BookServiceClient bookServiceClient;

    @MockBean
    private UserServiceClient userServiceClient;

    private Borrowing testBorrowing;
    private BorrowingDto testBorrowingDto;

    @BeforeEach
    void setUp() {
        testBorrowing = Borrowing.builder()
                .id(1L)
                .userId(1L)
                .bookId(1L)
                .borrowDate(LocalDateTime.now())
                .dueDate(LocalDateTime.now().plusDays(14))
                .status(BorrowingDto.BorrowingStatus.ACTIVE)
                .build();

        testBorrowingDto = BorrowingDto.builder()
                .id(1L)
                .userId(1L)
                .bookId(1L)
                .borrowDate(LocalDateTime.now())
                .dueDate(LocalDateTime.now().plusDays(14))
                .status(BorrowingDto.BorrowingStatus.ACTIVE)
                .build();
    }

    @Test
    void testBorrowBook_Success() {
        // Given
        when(userServiceClient.isUserActive(1L)).thenReturn(true);
        when(borrowingRepository.countActiveBorrowingsByUser(1L, BorrowingDto.BorrowingStatus.ACTIVE)).thenReturn(0L);
        when(borrowingRepository.existsByUserIdAndBookIdAndStatus(1L, 1L, BorrowingDto.BorrowingStatus.ACTIVE)).thenReturn(false);
        when(bookServiceClient.isBookAvailable(1L)).thenReturn(true);
        when(borrowingRepository.save(any(Borrowing.class))).thenReturn(testBorrowing);

        // When
        BorrowingDto result = borrowingService.borrowBook(1L, 1L);

        // Then
        assertNotNull(result);
        assertEquals(1L, result.getUserId());
        assertEquals(1L, result.getBookId());
        assertEquals(BorrowingDto.BorrowingStatus.ACTIVE, result.getStatus());

        verify(userServiceClient).isUserActive(1L);
        verify(borrowingRepository).countActiveBorrowingsByUser(1L, BorrowingDto.BorrowingStatus.ACTIVE);
        verify(borrowingRepository).existsByUserIdAndBookIdAndStatus(1L, 1L, BorrowingDto.BorrowingStatus.ACTIVE);
        verify(bookServiceClient).isBookAvailable(1L);
        verify(borrowingRepository).save(any(Borrowing.class));
    }

    @Test
    void testBorrowBook_UserNotActive() {
        // Given
        when(userServiceClient.isUserActive(1L)).thenReturn(false);

        // When & Then
        assertThrows(RuntimeException.class, () -> {
            borrowingService.borrowBook(1L, 1L);
        });

        verify(userServiceClient).isUserActive(1L);
        verify(borrowingRepository, never()).save(any(Borrowing.class));
    }

    @Test
    void testBorrowBook_MaxBooksReached() {
        // Given
        when(userServiceClient.isUserActive(1L)).thenReturn(true);
        when(borrowingRepository.countActiveBorrowingsByUser(1L, BorrowingDto.BorrowingStatus.ACTIVE)).thenReturn(5L);

        // When & Then
        assertThrows(RuntimeException.class, () -> {
            borrowingService.borrowBook(1L, 1L);
        });

        verify(userServiceClient).isUserActive(1L);
        verify(borrowingRepository).countActiveBorrowingsByUser(1L, BorrowingDto.BorrowingStatus.ACTIVE);
        verify(borrowingRepository, never()).save(any(Borrowing.class));
    }

    @Test
    void testBorrowBook_BookNotAvailable() {
        // Given
        when(userServiceClient.isUserActive(1L)).thenReturn(true);
        when(borrowingRepository.countActiveBorrowingsByUser(1L, BorrowingDto.BorrowingStatus.ACTIVE)).thenReturn(0L);
        when(borrowingRepository.existsByUserIdAndBookIdAndStatus(1L, 1L, BorrowingDto.BorrowingStatus.ACTIVE)).thenReturn(false);
        when(bookServiceClient.isBookAvailable(1L)).thenReturn(false);

        // When & Then
        assertThrows(RuntimeException.class, () -> {
            borrowingService.borrowBook(1L, 1L);
        });

        verify(userServiceClient).isUserActive(1L);
        verify(borrowingRepository).countActiveBorrowingsByUser(1L, BorrowingDto.BorrowingStatus.ACTIVE);
        verify(borrowingRepository).existsByUserIdAndBookIdAndStatus(1L, 1L, BorrowingDto.BorrowingStatus.ACTIVE);
        verify(bookServiceClient).isBookAvailable(1L);
        verify(borrowingRepository, never()).save(any(Borrowing.class));
    }

    @Test
    void testReturnBook_Success() {
        // Given
        Borrowing returnedBorrowing = Borrowing.builder()
                .id(1L)
                .userId(1L)
                .bookId(1L)
                .borrowDate(LocalDateTime.now().minusDays(5))
                .dueDate(LocalDateTime.now().plusDays(9))
                .returnDate(LocalDateTime.now())
                .status(BorrowingDto.BorrowingStatus.RETURNED)
                .build();

        when(borrowingRepository.findById(1L)).thenReturn(Optional.of(testBorrowing));
        when(borrowingRepository.save(any(Borrowing.class))).thenReturn(returnedBorrowing);

        // When
        BorrowingDto result = borrowingService.returnBook(1L);

        // Then
        assertNotNull(result);
        assertEquals(BorrowingDto.BorrowingStatus.RETURNED, result.getStatus());
        assertNotNull(result.getReturnDate());

        verify(borrowingRepository).findById(1L);
        verify(borrowingRepository).save(any(Borrowing.class));
        verify(bookServiceClient).updateBookStatus(1L, BorrowingDto.BookStatus.AVAILABLE);
    }

    @Test
    void testReturnBook_NotFound() {
        // Given
        when(borrowingRepository.findById(999L)).thenReturn(Optional.empty());

        // When & Then
        assertThrows(RuntimeException.class, () -> {
            borrowingService.returnBook(999L);
        });

        verify(borrowingRepository).findById(999L);
        verify(borrowingRepository, never()).save(any(Borrowing.class));
    }

    @Test
    void testGetUserBorrowings_Success() {
        // Given
        List<Borrowing> borrowings = Arrays.asList(testBorrowing);
        when(borrowingRepository.findByUserId(1L)).thenReturn(borrowings);

        // When
        List<BorrowingDto> result = borrowingService.getUserBorrowings(1L);

        // Then
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals(1L, result.get(0).getUserId());
        assertEquals(1L, result.get(0).getBookId());

        verify(borrowingRepository).findByUserId(1L);
    }

    @Test
    void testGetUserActiveBorrowings_Success() {
        // Given
        List<Borrowing> activeBorrowings = Arrays.asList(testBorrowing);
        when(borrowingRepository.findByUserIdAndStatus(1L, BorrowingDto.BorrowingStatus.ACTIVE))
                .thenReturn(activeBorrowings);

        // When
        List<BorrowingDto> result = borrowingService.getUserActiveBorrowings(1L);

        // Then
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals(BorrowingDto.BorrowingStatus.ACTIVE, result.get(0).getStatus());

        verify(borrowingRepository).findByUserIdAndStatus(1L, BorrowingDto.BorrowingStatus.ACTIVE);
    }

    @Test
    void testGetBorrowingById_Success() {
        // Given
        when(borrowingRepository.findById(1L)).thenReturn(Optional.of(testBorrowing));

        // When
        BorrowingDto result = borrowingService.getBorrowingById(1L);

        // Then
        assertNotNull(result);
        assertEquals(1L, result.getId());
        assertEquals(1L, result.getUserId());
        assertEquals(1L, result.getBookId());

        verify(borrowingRepository).findById(1L);
    }

    @Test
    void testCancelBorrowing_Success() {
        // Given
        when(borrowingRepository.findById(1L)).thenReturn(Optional.of(testBorrowing));
        when(borrowingRepository.save(any(Borrowing.class))).thenReturn(testBorrowing);

        // When
        borrowingService.cancelBorrowing(1L);

        // Then
        verify(borrowingRepository).findById(1L);
        verify(borrowingRepository).save(any(Borrowing.class));
        verify(bookServiceClient).updateBookStatus(1L, BorrowingDto.BookStatus.AVAILABLE);
    }
}

