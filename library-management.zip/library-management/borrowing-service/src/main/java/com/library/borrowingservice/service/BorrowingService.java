package com.library.borrowingservice.service;

import com.library.common.dto.BorrowingDto;
import com.library.common.event.BorrowingEvent;
import com.library.common.util.EventPublisher;
import com.library.borrowingservice.entity.Borrowing;
import com.library.borrowingservice.repository.BorrowingRepository;
import com.library.borrowingservice.util.BorrowingMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class BorrowingService {
    
    private final BorrowingRepository borrowingRepository;
    private final EventPublisher eventPublisher;
    private final BookServiceClient bookServiceClient;
    private final UserServiceClient userServiceClient;
    
    private static final int MAX_BOOKS_PER_USER = 5;
    private static final int BORROWING_DURATION_DAYS = 14;
    
    @Async
    public BorrowingDto borrowBook(Long userId, Long bookId) {
        log.info("Processing borrow request - User: {}, Book: {}", userId, bookId);
        
        // Validate user exists and is active
        if (!userServiceClient.isUserActive(userId)) {
            throw new RuntimeException("User not found or inactive");
        }
        
        // Check borrowing limits
        long activeBorrowings = borrowingRepository.countActiveBorrowingsByUser(userId, BorrowingDto.BorrowingStatus.ACTIVE);
        if (activeBorrowings >= MAX_BOOKS_PER_USER) {
            throw new RuntimeException("User has reached maximum borrowing limit");
        }
        
        // Check if user already has this book borrowed
        if (borrowingRepository.existsByUserIdAndBookIdAndStatus(userId, bookId, BorrowingDto.BorrowingStatus.ACTIVE)) {
            throw new RuntimeException("User already has this book borrowed");
        }
        
        // Validate book is available
        if (!bookServiceClient.isBookAvailable(bookId)) {
            throw new RuntimeException("Book is not available for borrowing");
        }
        
        // Create borrowing record
        LocalDateTime borrowDate = LocalDateTime.now();
        LocalDateTime dueDate = borrowDate.plusDays(BORROWING_DURATION_DAYS);
        
        Borrowing borrowing = Borrowing.builder()
                .userId(userId)
                .bookId(bookId)
                .borrowDate(borrowDate)
                .dueDate(dueDate)
                .status(BorrowingDto.BorrowingStatus.ACTIVE)
                .build();
        
        Borrowing savedBorrowing = borrowingRepository.save(borrowing);
        BorrowingDto borrowingDto = BorrowingMapper.toDto(savedBorrowing);
        
        // Update book status to borrowed
        bookServiceClient.updateBookStatus(bookId, BorrowingDto.BookStatus.BORROWED);
        
        // Publish borrowing event
        eventPublisher.publishBorrowingEvent(BorrowingEvent.EventType.BOOK_BORROWED, 
                savedBorrowing.getId(), userId, bookId, borrowingDto);
        
        log.info("Book borrowed successfully - Borrowing ID: {}", savedBorrowing.getId());
        return borrowingDto;
    }
    
    @Async
    public BorrowingDto returnBook(Long borrowingId) {
        log.info("Processing return request - Borrowing ID: {}", borrowingId);
        
        Borrowing borrowing = borrowingRepository.findById(borrowingId)
                .orElseThrow(() -> new RuntimeException("Borrowing record not found"));
        
        if (borrowing.getStatus() != BorrowingDto.BorrowingStatus.ACTIVE) {
            throw new RuntimeException("Book is not currently borrowed");
        }
        
        // Update borrowing record
        borrowing.setReturnDate(LocalDateTime.now());
        borrowing.setStatus(BorrowingDto.BorrowingStatus.RETURNED);
        Borrowing savedBorrowing = borrowingRepository.save(borrowing);
        BorrowingDto borrowingDto = BorrowingMapper.toDto(savedBorrowing);
        
        // Update book status to available
        bookServiceClient.updateBookStatus(borrowing.getBookId(), BorrowingDto.BookStatus.AVAILABLE);
        
        // Publish return event
        eventPublisher.publishBorrowingEvent(BorrowingEvent.EventType.BOOK_RETURNED, 
                savedBorrowing.getId(), borrowing.getUserId(), borrowing.getBookId(), borrowingDto);
        
        log.info("Book returned successfully - Borrowing ID: {}", borrowingId);
        return borrowingDto;
    }
    
    @Cacheable(value = "userBorrowings", key = "#userId")
    public List<BorrowingDto> getUserBorrowings(Long userId) {
        log.info("Fetching borrowings for user: {}", userId);
        
        return borrowingRepository.findByUserId(userId)
                .stream()
                .map(BorrowingMapper::toDto)
                .toList();
    }
    
    @Cacheable(value = "activeBorrowings", key = "#userId")
    public List<BorrowingDto> getUserActiveBorrowings(Long userId) {
        log.info("Fetching active borrowings for user: {}", userId);
        
        return borrowingRepository.findByUserIdAndStatus(userId, BorrowingDto.BorrowingStatus.ACTIVE)
                .stream()
                .map(BorrowingMapper::toDto)
                .toList();
    }
    
    @Cacheable(value = "borrowing", key = "#id")
    public BorrowingDto getBorrowingById(Long id) {
        log.info("Fetching borrowing by ID: {}", id);
        
        Borrowing borrowing = borrowingRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Borrowing not found"));
        
        return BorrowingMapper.toDto(borrowing);
    }
    
    @CacheEvict(value = {"userBorrowings", "activeBorrowings", "borrowing"}, allEntries = true)
    public void cancelBorrowing(Long borrowingId) {
        log.info("Cancelling borrowing: {}", borrowingId);
        
        Borrowing borrowing = borrowingRepository.findById(borrowingId)
                .orElseThrow(() -> new RuntimeException("Borrowing record not found"));
        
        if (borrowing.getStatus() != BorrowingDto.BorrowingStatus.ACTIVE) {
            throw new RuntimeException("Only active borrowings can be cancelled");
        }
        
        borrowing.setStatus(BorrowingDto.BorrowingStatus.CANCELLED);
        borrowingRepository.save(borrowing);
        
        // Update book status to available
        bookServiceClient.updateBookStatus(borrowing.getBookId(), BorrowingDto.BookStatus.AVAILABLE);
        
        // Publish cancellation event
        BorrowingDto borrowingDto = BorrowingMapper.toDto(borrowing);
        eventPublisher.publishBorrowingEvent(BorrowingEvent.EventType.BORROWING_CANCELLED, 
                borrowingId, borrowing.getUserId(), borrowing.getBookId(), borrowingDto);
        
        log.info("Borrowing cancelled successfully: {}", borrowingId);
    }
    
    @Scheduled(fixedRate = 3600000) // Run every hour
    public void checkOverdueBooks() {
        log.info("Checking for overdue books");
        
        LocalDateTime now = LocalDateTime.now();
        List<Borrowing> overdueBorrowings = borrowingRepository.findOverdueBorrowings(
                BorrowingDto.BorrowingStatus.ACTIVE, now);
        
        for (Borrowing borrowing : overdueBorrowings) {
            borrowing.setStatus(BorrowingDto.BorrowingStatus.OVERDUE);
            borrowingRepository.save(borrowing);
            
            BorrowingDto borrowingDto = BorrowingMapper.toDto(borrowing);
            eventPublisher.publishBorrowingEvent(BorrowingEvent.EventType.BOOK_OVERDUE, 
                    borrowing.getId(), borrowing.getUserId(), borrowing.getBookId(), borrowingDto);
            
            log.info("Marked borrowing as overdue: {}", borrowing.getId());
        }
        
        log.info("Overdue check completed. Found {} overdue books", overdueBorrowings.size());
    }
}

