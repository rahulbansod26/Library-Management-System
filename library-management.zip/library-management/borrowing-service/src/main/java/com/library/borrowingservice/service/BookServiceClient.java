package com.library.borrowingservice.service;

import com.library.common.dto.BookDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@RequiredArgsConstructor
@Slf4j
public class BookServiceClient {
    
    private final RestTemplate restTemplate;
    
    @Value("${services.catalog.url:http://localhost:8082}")
    private String catalogServiceUrl;
    
    public boolean isBookAvailable(Long bookId) {
        try {
            String url = catalogServiceUrl + "/api/books/" + bookId;
            BookDto book = restTemplate.getForObject(url, BookDto.class);
            return book != null && book.getStatus() == BookDto.BookStatus.AVAILABLE && book.isActive();
        } catch (Exception e) {
            log.error("Error checking book availability for ID: {}", bookId, e);
            return false;
        }
    }
    
    @CacheEvict(value = "books", allEntries = true)
    public void updateBookStatus(Long bookId, BookDto.BookStatus status) {
        try {
            String url = catalogServiceUrl + "/api/books/" + bookId + "/status?status=" + status;
            restTemplate.patchForObject(url, null, Void.class);
            log.info("Updated book status for ID: {} to {}", bookId, status);
        } catch (Exception e) {
            log.error("Error updating book status for ID: {}", bookId, e);
        }
    }
}

