package com.library.borrowingservice.util;

import com.library.common.dto.BorrowingDto;
import com.library.borrowingservice.entity.Borrowing;

public class BorrowingMapper {
    
    public static BorrowingDto toDto(Borrowing borrowing) {
        return BorrowingDto.builder()
                .id(borrowing.getId())
                .userId(borrowing.getUserId())
                .bookId(borrowing.getBookId())
                .borrowDate(borrowing.getBorrowDate())
                .dueDate(borrowing.getDueDate())
                .returnDate(borrowing.getReturnDate())
                .status(borrowing.getStatus())
                .createdAt(borrowing.getCreatedAt())
                .updatedAt(borrowing.getUpdatedAt())
                .build();
    }
    
    public static Borrowing toEntity(BorrowingDto borrowingDto) {
        return Borrowing.builder()
                .id(borrowingDto.getId())
                .userId(borrowingDto.getUserId())
                .bookId(borrowingDto.getBookId())
                .borrowDate(borrowingDto.getBorrowDate())
                .dueDate(borrowingDto.getDueDate())
                .returnDate(borrowingDto.getReturnDate())
                .status(borrowingDto.getStatus())
                .createdAt(borrowingDto.getCreatedAt())
                .updatedAt(borrowingDto.getUpdatedAt())
                .build();
    }
}

