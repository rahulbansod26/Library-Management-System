package com.library.borrowingservice.repository;

import com.library.borrowingservice.entity.Borrowing;
import com.library.common.dto.BorrowingDto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface BorrowingRepository extends JpaRepository<Borrowing, Long> {
    
    List<Borrowing> findByUserId(Long userId);
    
    List<Borrowing> findByUserIdAndStatus(Long userId, BorrowingDto.BorrowingStatus status);
    
    List<Borrowing> findByBookId(Long bookId);
    
    Optional<Borrowing> findByUserIdAndBookIdAndStatus(Long userId, Long bookId, BorrowingDto.BorrowingStatus status);
    
    @Query("SELECT b FROM Borrowing b WHERE b.status = :status AND b.dueDate < :currentDate")
    List<Borrowing> findOverdueBorrowings(@Param("status") BorrowingDto.BorrowingStatus status, 
                                       @Param("currentDate") LocalDateTime currentDate);
    
    @Query("SELECT b FROM Borrowing b WHERE b.status = :status AND b.dueDate BETWEEN :startDate AND :endDate")
    List<Borrowing> findBorrowingsDueBetween(@Param("status") BorrowingDto.BorrowingStatus status,
                                           @Param("startDate") LocalDateTime startDate,
                                           @Param("endDate") LocalDateTime endDate);
    
    @Query("SELECT COUNT(b) FROM Borrowing b WHERE b.userId = :userId AND b.status = :status")
    long countActiveBorrowingsByUser(@Param("userId") Long userId, @Param("status") BorrowingDto.BorrowingStatus status);
    
    boolean existsByUserIdAndBookIdAndStatus(Long userId, Long bookId, BorrowingDto.BorrowingStatus status);
}

