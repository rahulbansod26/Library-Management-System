package com.library.borrowingservice.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@RequiredArgsConstructor
@Slf4j
public class UserServiceClient {
    
    private final RestTemplate restTemplate;
    
    @Value("${services.user.url:http://localhost:8081}")
    private String userServiceUrl;
    
    public boolean isUserActive(Long userId) {
        try {
            String url = userServiceUrl + "/api/users/" + userId;
            Object user = restTemplate.getForObject(url, Object.class);
            return user != null;
        } catch (Exception e) {
            log.error("Error checking user status for ID: {}", userId, e);
            return false;
        }
    }
}

