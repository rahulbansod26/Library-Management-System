package com.library.borrowingservice.controller;

import com.library.common.dto.BorrowingDto;
import com.library.borrowingservice.service.BorrowingService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/borrowings")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Borrowing Management", description = "Book borrowing and lending operations")
public class BorrowingController {
    
    private final BorrowingService borrowingService;
    
    @PostMapping("/borrow")
    @Operation(summary = "Borrow a book")
    public ResponseEntity<BorrowingDto> borrowBook(@RequestParam Long userId, @RequestParam Long bookId) {
        log.info("Borrow book request - User: {}, Book: {}", userId, bookId);
        BorrowingDto borrowing = borrowingService.borrowBook(userId, bookId);
        return ResponseEntity.status(HttpStatus.CREATED).body(borrowing);
    }
    
    @PostMapping("/{id}/return")
    @Operation(summary = "Return a book")
    public ResponseEntity<BorrowingDto> returnBook(@PathVariable Long id) {
        log.info("Return book request for borrowing ID: {}", id);
        BorrowingDto borrowing = borrowingService.returnBook(id);
        return ResponseEntity.ok(borrowing);
    }
    
    @GetMapping("/user/{userId}")
    @Operation(summary = "Get user's borrowings")
    public ResponseEntity<List<BorrowingDto>> getUserBorrowings(@PathVariable Long userId) {
        log.info("Get user borrowings request for user: {}", userId);
        List<BorrowingDto> borrowings = borrowingService.getUserBorrowings(userId);
        return ResponseEntity.ok(borrowings);
    }
    
    @GetMapping("/user/{userId}/active")
    @Operation(summary = "Get user's active borrowings")
    public ResponseEntity<List<BorrowingDto>> getUserActiveBorrowings(@PathVariable Long userId) {
        log.info("Get user active borrowings request for user: {}", userId);
        List<BorrowingDto> borrowings = borrowingService.getUserActiveBorrowings(userId);
        return ResponseEntity.ok(borrowings);
    }
    
    @GetMapping("/{id}")
    @Operation(summary = "Get borrowing by ID")
    public ResponseEntity<BorrowingDto> getBorrowingById(@PathVariable Long id) {
        log.info("Get borrowing request for ID: {}", id);
        BorrowingDto borrowing = borrowingService.getBorrowingById(id);
        return ResponseEntity.ok(borrowing);
    }
    
    @DeleteMapping("/{id}")
    @Operation(summary = "Cancel borrowing")
    public ResponseEntity<Void> cancelBorrowing(@PathVariable Long id) {
        log.info("Cancel borrowing request for ID: {}", id);
        borrowingService.cancelBorrowing(id);
        return ResponseEntity.noContent().build();
    }
}

