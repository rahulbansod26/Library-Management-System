package com.library.catalogservice.service;

import com.library.common.dto.BookDto;
import com.library.common.event.BookEvent;
import com.library.common.util.EventPublisher;
import com.library.catalogservice.entity.Book;
import com.library.catalogservice.repository.BookRepository;
import com.library.catalogservice.util.BookMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class BookService {
    
    private final BookRepository bookRepository;
    private final EventPublisher eventPublisher;
    
    @CacheEvict(value = {"books", "availableBooks"}, allEntries = true)
    public BookDto addBook(BookDto bookDto) {
        log.info("Adding new book: {}", bookDto.getTitle());
        
        // Check if ISBN already exists
        if (bookRepository.existsByIsbn(bookDto.getIsbn())) {
            throw new RuntimeException("Book with ISBN " + bookDto.getIsbn() + " already exists");
        }
        
        Book book = Book.builder()
                .title(bookDto.getTitle())
                .author(bookDto.getAuthor())
                .isbn(bookDto.getIsbn())
                .genre(bookDto.getGenre())
                .description(bookDto.getDescription())
                .status(bookDto.getStatus())
                .active(true)
                .build();
        
        Book savedBook = bookRepository.save(book);
        BookDto savedBookDto = BookMapper.toDto(savedBook);
        
        // Publish book added event
        eventPublisher.publishBookEvent(BookEvent.EventType.BOOK_ADDED, savedBook.getId(), savedBookDto);
        
        log.info("Book added successfully: {}", savedBook.getId());
        return savedBookDto;
    }
    
    @Cacheable(value = "books", key = "#id")
    public BookDto getBookById(Long id) {
        log.info("Fetching book by ID: {}", id);
        
        Book book = bookRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Book not found"));
        
        return BookMapper.toDto(book);
    }
    
    @Cacheable(value = "books", key = "#isbn")
    public BookDto getBookByIsbn(String isbn) {
        log.info("Fetching book by ISBN: {}", isbn);
        
        Book book = bookRepository.findByIsbn(isbn)
                .orElseThrow(() -> new RuntimeException("Book not found"));
        
        return BookMapper.toDto(book);
    }
    
    @Cacheable(value = "availableBooks")
    public List<BookDto> getAvailableBooks() {
        log.info("Fetching all available books");
        
        return bookRepository.findByStatusAndActiveTrue(BookDto.BookStatus.AVAILABLE)
                .stream()
                .map(BookMapper::toDto)
                .toList();
    }
    
    public List<BookDto> getAllBooks() {
        log.info("Fetching all books");
        
        return bookRepository.findAllActiveBooksOrderByTitle()
                .stream()
                .map(BookMapper::toDto)
                .toList();
    }
    
    public List<BookDto> searchBooks(String title, String author, String genre, BookDto.BookStatus status) {
        log.info("Searching books with filters - title: {}, author: {}, genre: {}, status: {}", 
                title, author, genre, status);
        
        return bookRepository.searchBooks(title, author, genre, status)
                .stream()
                .map(BookMapper::toDto)
                .toList();
    }
    
    public Page<BookDto> getBooksPaginated(int page, int size) {
        log.info("Fetching books paginated - page: {}, size: {}", page, size);
        
        Pageable pageable = PageRequest.of(page, size);
        Page<Book> bookPage = bookRepository.findAll(pageable);
        
        return bookPage.map(BookMapper::toDto);
    }
    
    @CacheEvict(value = {"books", "availableBooks"}, allEntries = true)
    public BookDto updateBook(Long id, BookDto bookDto) {
        log.info("Updating book: {}", id);
        
        Book book = bookRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Book not found"));
        
        // Check if ISBN is being changed and if it already exists
        if (!book.getIsbn().equals(bookDto.getIsbn()) && 
            bookRepository.existsByIsbnAndIdNot(bookDto.getIsbn(), id)) {
            throw new RuntimeException("Book with ISBN " + bookDto.getIsbn() + " already exists");
        }
        
        book.setTitle(bookDto.getTitle());
        book.setAuthor(bookDto.getAuthor());
        book.setIsbn(bookDto.getIsbn());
        book.setGenre(bookDto.getGenre());
        book.setDescription(bookDto.getDescription());
        book.setStatus(bookDto.getStatus());
        
        Book savedBook = bookRepository.save(book);
        BookDto updatedBookDto = BookMapper.toDto(savedBook);
        
        // Publish book updated event
        eventPublisher.publishBookEvent(BookEvent.EventType.BOOK_UPDATED, savedBook.getId(), updatedBookDto);
        
        log.info("Book updated successfully: {}", id);
        return updatedBookDto;
    }
    
    @CacheEvict(value = {"books", "availableBooks"}, allEntries = true)
    public BookDto updateBookStatus(Long id, BookDto.BookStatus status) {
        log.info("Updating book status: {} to {}", id, status);
        
        Book book = bookRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Book not found"));
        
        book.setStatus(status);
        Book savedBook = bookRepository.save(book);
        BookDto updatedBookDto = BookMapper.toDto(savedBook);
        
        // Publish book status changed event
        eventPublisher.publishBookEvent(BookEvent.EventType.BOOK_STATUS_CHANGED, savedBook.getId(), updatedBookDto);
        
        log.info("Book status updated successfully: {} to {}", id, status);
        return updatedBookDto;
    }
    
    @CacheEvict(value = {"books", "availableBooks"}, allEntries = true)
    public void removeBook(Long id) {
        log.info("Removing book: {}", id);
        
        Book book = bookRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Book not found"));
        
        book.setActive(false);
        book.setStatus(BookDto.BookStatus.REMOVED);
        Book savedBook = bookRepository.save(book);
        BookDto removedBookDto = BookMapper.toDto(savedBook);
        
        // Publish book removed event
        eventPublisher.publishBookEvent(BookEvent.EventType.BOOK_REMOVED, savedBook.getId(), removedBookDto);
        
        log.info("Book removed successfully: {}", id);
    }
}

