package com.library.catalogservice.controller;

import com.library.common.dto.BookDto;
import com.library.catalogservice.service.BookService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/books")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Book Catalog Management", description = "Book catalog management operations")
public class BookController {
    
    private final BookService bookService;
    
    @PostMapping
    @Operation(summary = "Add a new book")
    public ResponseEntity<BookDto> addBook(@Valid @RequestBody BookDto bookDto) {
        log.info("Add book request received: {}", bookDto.getTitle());
        BookDto book = bookService.addBook(bookDto);
        return ResponseEntity.status(HttpStatus.CREATED).body(book);
    }
    
    @GetMapping("/{id}")
    @Operation(summary = "Get book by ID")
    public ResponseEntity<BookDto> getBookById(@PathVariable Long id) {
        log.info("Get book request for ID: {}", id);
        BookDto book = bookService.getBookById(id);
        return ResponseEntity.ok(book);
    }
    
    @GetMapping("/isbn/{isbn}")
    @Operation(summary = "Get book by ISBN")
    public ResponseEntity<BookDto> getBookByIsbn(@PathVariable String isbn) {
        log.info("Get book request for ISBN: {}", isbn);
        BookDto book = bookService.getBookByIsbn(isbn);
        return ResponseEntity.ok(book);
    }
    
    @GetMapping("/available")
    @Operation(summary = "Get all available books")
    public ResponseEntity<List<BookDto>> getAvailableBooks() {
        log.info("Get available books request");
        List<BookDto> books = bookService.getAvailableBooks();
        return ResponseEntity.ok(books);
    }
    
    @GetMapping
    @Operation(summary = "Get all books")
    public ResponseEntity<List<BookDto>> getAllBooks() {
        log.info("Get all books request");
        List<BookDto> books = bookService.getAllBooks();
        return ResponseEntity.ok(books);
    }
    
    @GetMapping("/search")
    @Operation(summary = "Search books")
    public ResponseEntity<List<BookDto>> searchBooks(
            @RequestParam(required = false) String title,
            @RequestParam(required = false) String author,
            @RequestParam(required = false) String genre,
            @RequestParam(required = false) BookDto.BookStatus status) {
        log.info("Search books request - title: {}, author: {}, genre: {}, status: {}", 
                title, author, genre, status);
        List<BookDto> books = bookService.searchBooks(title, author, genre, status);
        return ResponseEntity.ok(books);
    }
    
    @GetMapping("/paginated")
    @Operation(summary = "Get books with pagination")
    public ResponseEntity<Page<BookDto>> getBooksPaginated(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        log.info("Get books paginated request - page: {}, size: {}", page, size);
        Page<BookDto> books = bookService.getBooksPaginated(page, size);
        return ResponseEntity.ok(books);
    }
    
    @PutMapping("/{id}")
    @Operation(summary = "Update book")
    public ResponseEntity<BookDto> updateBook(@PathVariable Long id, @Valid @RequestBody BookDto bookDto) {
        log.info("Update book request for ID: {}", id);
        BookDto book = bookService.updateBook(id, bookDto);
        return ResponseEntity.ok(book);
    }
    
    @PatchMapping("/{id}/status")
    @Operation(summary = "Update book status")
    public ResponseEntity<BookDto> updateBookStatus(@PathVariable Long id, @RequestParam BookDto.BookStatus status) {
        log.info("Update book status request for ID: {} to {}", id, status);
        BookDto book = bookService.updateBookStatus(id, status);
        return ResponseEntity.ok(book);
    }
    
    @DeleteMapping("/{id}")
    @Operation(summary = "Remove book")
    public ResponseEntity<Void> removeBook(@PathVariable Long id) {
        log.info("Remove book request for ID: {}", id);
        bookService.removeBook(id);
        return ResponseEntity.noContent().build();
    }
}

