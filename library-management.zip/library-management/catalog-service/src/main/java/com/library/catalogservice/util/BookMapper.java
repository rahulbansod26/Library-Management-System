package com.library.catalogservice.util;

import com.library.common.dto.BookDto;
import com.library.catalogservice.entity.Book;

public class BookMapper {
    
    public static BookDto toDto(Book book) {
        return BookDto.builder()
                .id(book.getId())
                .title(book.getTitle())
                .author(book.getAuthor())
                .isbn(book.getIsbn())
                .genre(book.getGenre())
                .description(book.getDescription())
                .status(book.getStatus())
                .active(book.isActive())
                .createdAt(book.getCreatedAt())
                .updatedAt(book.getUpdatedAt())
                .build();
    }
    
    public static Book toEntity(BookDto bookDto) {
        return Book.builder()
                .id(bookDto.getId())
                .title(bookDto.getTitle())
                .author(bookDto.getAuthor())
                .isbn(bookDto.getIsbn())
                .genre(bookDto.getGenre())
                .description(bookDto.getDescription())
                .status(bookDto.getStatus())
                .active(bookDto.isActive())
                .createdAt(bookDto.getCreatedAt())
                .updatedAt(bookDto.getUpdatedAt())
                .build();
    }
}

