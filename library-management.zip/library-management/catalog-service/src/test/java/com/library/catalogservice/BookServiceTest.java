package com.library.catalogservice;

import com.library.common.dto.BookDto;
import com.library.catalogservice.entity.Book;
import com.library.catalogservice.repository.BookRepository;
import com.library.catalogservice.service.BookService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.test.context.ActiveProfiles;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@SpringBootTest
@ActiveProfiles("test")
class BookServiceTest {

    @Autowired
    private BookService bookService;

    @MockBean
    private BookRepository bookRepository;

    private Book testBook;
    private BookDto testBookDto;

    @BeforeEach
    void setUp() {
        testBook = Book.builder()
                .id(1L)
                .title("Test Book")
                .author("Test Author")
                .isbn("1234567890")
                .genre("Fiction")
                .description("A test book")
                .status(BookDto.BookStatus.AVAILABLE)
                .active(true)
                .build();

        testBookDto = BookDto.builder()
                .id(1L)
                .title("Test Book")
                .author("Test Author")
                .isbn("1234567890")
                .genre("Fiction")
                .description("A test book")
                .status(BookDto.BookStatus.AVAILABLE)
                .active(true)
                .build();
    }

    @Test
    void testAddBook_Success() {
        // Given
        when(bookRepository.existsByIsbn("1234567890")).thenReturn(false);
        when(bookRepository.save(any(Book.class))).thenReturn(testBook);

        // When
        BookDto result = bookService.addBook(testBookDto);

        // Then
        assertNotNull(result);
        assertEquals("Test Book", result.getTitle());
        assertEquals("Test Author", result.getAuthor());
        assertEquals("1234567890", result.getIsbn());
        assertEquals(BookDto.BookStatus.AVAILABLE, result.getStatus());

        verify(bookRepository).existsByIsbn("1234567890");
        verify(bookRepository).save(any(Book.class));
    }

    @Test
    void testAddBook_IsbnExists() {
        // Given
        when(bookRepository.existsByIsbn("1234567890")).thenReturn(true);

        // When & Then
        assertThrows(RuntimeException.class, () -> {
            bookService.addBook(testBookDto);
        });

        verify(bookRepository).existsByIsbn("1234567890");
        verify(bookRepository, never()).save(any(Book.class));
    }

    @Test
    void testGetBookById_Success() {
        // Given
        when(bookRepository.findById(1L)).thenReturn(Optional.of(testBook));

        // When
        BookDto result = bookService.getBookById(1L);

        // Then
        assertNotNull(result);
        assertEquals(1L, result.getId());
        assertEquals("Test Book", result.getTitle());
        assertEquals("Test Author", result.getAuthor());

        verify(bookRepository).findById(1L);
    }

    @Test
    void testGetBookById_NotFound() {
        // Given
        when(bookRepository.findById(999L)).thenReturn(Optional.empty());

        // When & Then
        assertThrows(RuntimeException.class, () -> {
            bookService.getBookById(999L);
        });

        verify(bookRepository).findById(999L);
    }

    @Test
    void testGetAvailableBooks_Success() {
        // Given
        List<Book> availableBooks = Arrays.asList(testBook);
        when(bookRepository.findByStatusAndActiveTrue(BookDto.BookStatus.AVAILABLE))
                .thenReturn(availableBooks);

        // When
        List<BookDto> result = bookService.getAvailableBooks();

        // Then
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("Test Book", result.get(0).getTitle());
        assertEquals(BookDto.BookStatus.AVAILABLE, result.get(0).getStatus());

        verify(bookRepository).findByStatusAndActiveTrue(BookDto.BookStatus.AVAILABLE);
    }

    @Test
    void testSearchBooks_Success() {
        // Given
        List<Book> searchResults = Arrays.asList(testBook);
        when(bookRepository.searchBooks("Test", "Author", "Fiction", BookDto.BookStatus.AVAILABLE))
                .thenReturn(searchResults);

        // When
        List<BookDto> result = bookService.searchBooks("Test", "Author", "Fiction", BookDto.BookStatus.AVAILABLE);

        // Then
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("Test Book", result.get(0).getTitle());

        verify(bookRepository).searchBooks("Test", "Author", "Fiction", BookDto.BookStatus.AVAILABLE);
    }

    @Test
    void testUpdateBook_Success() {
        // Given
        BookDto updatedBookDto = BookDto.builder()
                .id(1L)
                .title("Updated Book")
                .author("Updated Author")
                .isbn("1234567890")
                .genre("Fiction")
                .description("Updated description")
                .status(BookDto.BookStatus.AVAILABLE)
                .active(true)
                .build();

        Book updatedBook = Book.builder()
                .id(1L)
                .title("Updated Book")
                .author("Updated Author")
                .isbn("1234567890")
                .genre("Fiction")
                .description("Updated description")
                .status(BookDto.BookStatus.AVAILABLE)
                .active(true)
                .build();

        when(bookRepository.findById(1L)).thenReturn(Optional.of(testBook));
        when(bookRepository.existsByIsbnAndIdNot("1234567890", 1L)).thenReturn(false);
        when(bookRepository.save(any(Book.class))).thenReturn(updatedBook);

        // When
        BookDto result = bookService.updateBook(1L, updatedBookDto);

        // Then
        assertNotNull(result);
        assertEquals("Updated Book", result.getTitle());
        assertEquals("Updated Author", result.getAuthor());

        verify(bookRepository).findById(1L);
        verify(bookRepository).existsByIsbnAndIdNot("1234567890", 1L);
        verify(bookRepository).save(any(Book.class));
    }

    @Test
    void testRemoveBook_Success() {
        // Given
        when(bookRepository.findById(1L)).thenReturn(Optional.of(testBook));
        when(bookRepository.save(any(Book.class))).thenReturn(testBook);

        // When
        bookService.removeBook(1L);

        // Then
        verify(bookRepository).findById(1L);
        verify(bookRepository).save(any(Book.class));
    }
}

