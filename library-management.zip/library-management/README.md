# Library Management System

A comprehensive microservices-based Library Management System built with Spring Boot, featuring event-driven architecture, caching, and modern development practices.

## 🏗️ Architecture

The system is built using a microservices architecture with the following services:

- **API Gateway** (Port 8080) - Central entry point with routing and security
- **User Service** (Port 8081) - User registration, authentication, and profile management
- **Catalog Service** (Port 8082) - Book catalog management with caching
- **Borrowing Service** (Port 8083) - Book borrowing and lending with async processing
- **Fine Service** (Port 8084) - Fine calculation and payment processing
- **Notification Service** (Port 8085) - Async notification dispatch and email integration

## 🚀 Features

### Core Functionality
- **User Management**: Registration, authentication, profile management with JWT
- **Book Catalog**: Add, update, search, and manage books with caching
- **Borrowing System**: Borrow/return books with borrowing limits and rules
- **Fine Management**: Automatic fine calculation and payment processing
- **Notifications**: Email notifications for various events

### Advanced Features
- **Event-Driven Architecture**: RabbitMQ for async communication
- **Caching**: Redis for frequently accessed data
- **Scheduling**: Automated tasks for overdue checks and reminders
- **Security**: JWT authentication with role-based access control
- **API Documentation**: Swagger/OpenAPI for all services

## 🛠️ Technology Stack

- **Backend**: Spring Boot 3.2.0, Spring Cloud Gateway
- **Database**: MySQL 8.0
- **Caching**: Redis
- **Message Broker**: RabbitMQ
- **Security**: Spring Security, JWT
- **Documentation**: Swagger/OpenAPI 3
- **Build Tool**: Maven

## 📋 Prerequisites

- Java 17+
- Maven 3.6+
- Docker and Docker Compose
- MySQL 8.0
- Redis
- RabbitMQ

## 🚀 Quick Start

### 1. Start Infrastructure Services

```bash
# Start MySQL, Redis, and RabbitMQ using Docker Compose
docker-compose up -d
```

### 2. Build and Run Services

```bash
# Build all modules
mvn clean install

# Run services in order (each in a separate terminal)
# 1. User Service
cd user-service && mvn spring-boot:run

# 2. Catalog Service  
cd catalog-service && mvn spring-boot:run

# 3. Borrowing Service
cd borrowing-service && mvn spring-boot:run

# 4. Fine Service
cd fine-service && mvn spring-boot:run

# 5. Notification Service
cd notification-service && mvn spring-boot:run

# 6. API Gateway
cd api-gateway && mvn spring-boot:run
```

### 3. Access Services

- **API Gateway**: http://localhost:8080
- **User Service**: http://localhost:8081
- **Catalog Service**: http://localhost:8082
- **Borrowing Service**: http://localhost:8083
- **Fine Service**: http://localhost:8084
- **Notification Service**: http://localhost:8085

### 4. API Documentation

- **Swagger UI**: http://localhost:8080/swagger-ui.html
- **Individual Service Docs**:
  - User Service: http://localhost:8081/swagger-ui.html
  - Catalog Service: http://localhost:8082/swagger-ui.html
  - Borrowing Service: http://localhost:8083/swagger-ui.html
  - Fine Service: http://localhost:8084/swagger-ui.html
  - Notification Service: http://localhost:8085/swagger-ui.html

## 📚 API Endpoints

### User Service
- `POST /api/users/register` - Register new user
- `POST /api/users/login` - User login
- `GET /api/users/{id}` - Get user by ID
- `PUT /api/users/{id}` - Update user
- `DELETE /api/users/{id}` - Deactivate user

### Catalog Service
- `POST /api/books` - Add new book
- `GET /api/books` - Get all books
- `GET /api/books/{id}` - Get book by ID
- `GET /api/books/available` - Get available books
- `GET /api/books/search` - Search books
- `PUT /api/books/{id}` - Update book
- `DELETE /api/books/{id}` - Remove book

### Borrowing Service
- `POST /api/borrowings/borrow` - Borrow a book
- `POST /api/borrowings/{id}/return` - Return a book
- `GET /api/borrowings/user/{userId}` - Get user's borrowings
- `DELETE /api/borrowings/{id}` - Cancel borrowing

### Fine Service
- `POST /api/fines` - Create a fine
- `GET /api/fines/user/{userId}` - Get user's fines
- `POST /api/fines/{id}/pay` - Pay a fine
- `DELETE /api/fines/{id}` - Cancel fine

### Notification Service
- `POST /api/notifications` - Send notification
- `GET /api/notifications/user/{userId}` - Get user's notifications

## 🔧 Configuration

### Database Configuration
All services use MySQL with the following default configuration:
- Host: localhost:3306
- Database: library_management
- Username: root
- Password: password

### Redis Configuration
- Host: localhost:6379
- Used for caching frequently accessed data

### RabbitMQ Configuration
- Host: localhost:5672
- Management UI: http://localhost:15672
- Username: guest
- Password: guest

## 🏃‍♂️ Running Tests

```bash
# Run tests for all modules
mvn test

# Run tests for specific module
cd user-service && mvn test
```

## 📊 Monitoring

- **Actuator Endpoints**: Available at `/actuator` for each service
- **Health Checks**: `/actuator/health`
- **Metrics**: `/actuator/metrics`

## 🔒 Security

- JWT-based authentication
- Role-based access control (USER, LIBRARIAN, ADMIN)
- Password encryption using BCrypt
- Input validation and sanitization

## 🚀 Deployment

### Docker Deployment
```bash
# Build Docker images
docker build -t library-user-service ./user-service
docker build -t library-catalog-service ./catalog-service
docker build -t library-borrowing-service ./borrowing-service
docker build -t library-fine-service ./fine-service
docker build -t library-notification-service ./notification-service
docker build -t library-api-gateway ./api-gateway

# Run with Docker Compose
docker-compose -f docker-compose.prod.yml up -d
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🆘 Support

For support and questions:
- Email: support@library.com
- Documentation: https://library.com/docs
- Issues: GitHub Issues

## 🔄 Event Flow

The system uses event-driven architecture with the following event flow:

1. **User Registration** → User Service → Notification Service
2. **Book Borrowing** → Borrowing Service → Catalog Service + Notification Service
3. **Overdue Books** → Borrowing Service → Fine Service → Notification Service
4. **Fine Payment** → Fine Service → Notification Service

## 📈 Performance Features

- **Caching**: Redis for frequently accessed data
- **Async Processing**: Non-blocking operations for better performance
- **Connection Pooling**: Optimized database connections
- **Event-Driven**: Decoupled services for scalability

