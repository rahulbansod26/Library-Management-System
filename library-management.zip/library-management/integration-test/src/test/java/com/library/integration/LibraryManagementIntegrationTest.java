package com.library.integration;

import com.library.common.dto.BookDto;
import com.library.common.dto.BorrowingDto;
import com.library.common.dto.FineDto;
import com.library.common.dto.UserDto;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("test")
class LibraryManagementIntegrationTest {

    @LocalServerPort
    private int port;

    @Autowired
    private TestRestTemplate restTemplate;

    private String getBaseUrl() {
        return "http://localhost:" + port;
    }

    @Test
    void testCompleteLibraryWorkflow() {
        // Step 1: Register a new user
        UserDto.UserRegistrationRequest registrationRequest = UserDto.UserRegistrationRequest.builder()
                .username("testuser")
                .email("test@example.com")
                .password("password123")
                .firstName("Test")
                .lastName("User")
                .role(UserDto.UserRole.USER)
                .build();

        ResponseEntity<UserDto> userResponse = restTemplate.postForEntity(
                getBaseUrl() + "/api/users/register",
                registrationRequest,
                UserDto.class
        );

        assertEquals(201, userResponse.getStatusCodeValue());
        assertNotNull(userResponse.getBody());
        assertEquals("testuser", userResponse.getBody().getUsername());

        Long userId = userResponse.getBody().getId();

        // Step 2: Login user
        UserDto.LoginRequest loginRequest = UserDto.LoginRequest.builder()
                .username("testuser")
                .password("password123")
                .build();

        ResponseEntity<UserDto.LoginResponse> loginResponse = restTemplate.postForEntity(
                getBaseUrl() + "/api/users/login",
                loginRequest,
                UserDto.LoginResponse.class
        );

        assertEquals(200, loginResponse.getStatusCodeValue());
        assertNotNull(loginResponse.getBody().getToken());

        String token = loginResponse.getBody().getToken();

        // Step 3: Add a book
        BookDto bookDto = BookDto.builder()
                .title("Test Book")
                .author("Test Author")
                .isbn("1234567890")
                .genre("Fiction")
                .description("A test book")
                .status(BookDto.BookStatus.AVAILABLE)
                .active(true)
                .build();

        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + token);

        HttpEntity<BookDto> bookEntity = new HttpEntity<>(bookDto, headers);

        ResponseEntity<BookDto> bookResponse = restTemplate.exchange(
                getBaseUrl() + "/api/books",
                HttpMethod.POST,
                bookEntity,
                BookDto.class
        );

        assertEquals(201, bookResponse.getStatusCodeValue());
        assertNotNull(bookResponse.getBody());
        assertEquals("Test Book", bookResponse.getBody().getTitle());

        Long bookId = bookResponse.getBody().getId();

        // Step 4: Borrow the book
        ResponseEntity<BorrowingDto> borrowResponse = restTemplate.exchange(
                getBaseUrl() + "/api/borrowings/borrow?userId=" + userId + "&bookId=" + bookId,
                HttpMethod.POST,
                new HttpEntity<>(headers),
                BorrowingDto.class
        );

        assertEquals(201, borrowResponse.getStatusCodeValue());
        assertNotNull(borrowResponse.getBody());
        assertEquals(userId, borrowResponse.getBody().getUserId());
        assertEquals(bookId, borrowResponse.getBody().getBookId());
        assertEquals(BorrowingDto.BorrowingStatus.ACTIVE, borrowResponse.getBody().getStatus());

        Long borrowingId = borrowResponse.getBody().getId();

        // Step 5: Get user's borrowings
        ResponseEntity<BorrowingDto[]> borrowingsResponse = restTemplate.exchange(
                getBaseUrl() + "/api/borrowings/user/" + userId,
                HttpMethod.GET,
                new HttpEntity<>(headers),
                BorrowingDto[].class
        );

        assertEquals(200, borrowingsResponse.getStatusCodeValue());
        assertNotNull(borrowingsResponse.getBody());
        assertEquals(1, borrowingsResponse.getBody().length);

        // Step 6: Return the book
        ResponseEntity<BorrowingDto> returnResponse = restTemplate.exchange(
                getBaseUrl() + "/api/borrowings/" + borrowingId + "/return",
                HttpMethod.POST,
                new HttpEntity<>(headers),
                BorrowingDto.class
        );

        assertEquals(200, returnResponse.getStatusCodeValue());
        assertNotNull(returnResponse.getBody());
        assertEquals(BorrowingDto.BorrowingStatus.RETURNED, returnResponse.getBody().getStatus());
        assertNotNull(returnResponse.getBody().getReturnDate());

        // Step 7: Create a fine
        ResponseEntity<FineDto> fineResponse = restTemplate.exchange(
                getBaseUrl() + "/api/fines?userId=" + userId + "&borrowingId=" + borrowingId + "&reason=Overdue",
                HttpMethod.POST,
                new HttpEntity<>(headers),
                FineDto.class
        );

        assertEquals(201, fineResponse.getStatusCodeValue());
        assertNotNull(fineResponse.getBody());
        assertEquals(userId, fineResponse.getBody().getUserId());
        assertEquals(borrowingId, fineResponse.getBody().getBorrowingId());
        assertEquals(FineDto.FineStatus.PENDING, fineResponse.getBody().getStatus());

        Long fineId = fineResponse.getBody().getId();

        // Step 8: Pay the fine
        ResponseEntity<FineDto> payResponse = restTemplate.exchange(
                getBaseUrl() + "/api/fines/" + fineId + "/pay?paymentMethod=credit_card",
                HttpMethod.POST,
                new HttpEntity<>(headers),
                FineDto.class
        );

        assertEquals(200, payResponse.getStatusCodeValue());
        assertNotNull(payResponse.getBody());
        assertEquals(FineDto.FineStatus.PAID, payResponse.getBody().getStatus());
        assertNotNull(payResponse.getBody().getPaidDate());

        // Step 9: Get user's fines
        ResponseEntity<FineDto[]> finesResponse = restTemplate.exchange(
                getBaseUrl() + "/api/fines/user/" + userId,
                HttpMethod.GET,
                new HttpEntity<>(headers),
                FineDto[].class
        );

        assertEquals(200, finesResponse.getStatusCodeValue());
        assertNotNull(finesResponse.getBody());
        assertEquals(1, finesResponse.getBody().length);
    }

    @Test
    void testSearchBooks() {
        // Add multiple books
        BookDto book1 = BookDto.builder()
                .title("Java Programming")
                .author("John Doe")
                .isbn("1111111111")
                .genre("Programming")
                .description("Learn Java programming")
                .status(BookDto.BookStatus.AVAILABLE)
                .active(true)
                .build();

        BookDto book2 = BookDto.builder()
                .title("Python Basics")
                .author("Jane Smith")
                .isbn("2222222222")
                .genre("Programming")
                .description("Learn Python programming")
                .status(BookDto.BookStatus.AVAILABLE)
                .active(true)
                .build();

        // Add books
        restTemplate.postForEntity(getBaseUrl() + "/api/books", book1, BookDto.class);
        restTemplate.postForEntity(getBaseUrl() + "/api/books", book2, BookDto.class);

        // Search by genre
        ResponseEntity<BookDto[]> searchResponse = restTemplate.getForEntity(
                getBaseUrl() + "/api/books/search?genre=Programming",
                BookDto[].class
        );

        assertEquals(200, searchResponse.getStatusCodeValue());
        assertNotNull(searchResponse.getBody());
        assertTrue(searchResponse.getBody().length >= 2);

        // Search by author
        ResponseEntity<BookDto[]> authorSearchResponse = restTemplate.getForEntity(
                getBaseUrl() + "/api/books/search?author=John",
                BookDto[].class
        );

        assertEquals(200, authorSearchResponse.getStatusCodeValue());
        assertNotNull(authorSearchResponse.getBody());
        assertTrue(authorSearchResponse.getBody().length >= 1);
    }

    @Test
    void testBorrowingLimits() {
        // Register user
        UserDto.UserRegistrationRequest registrationRequest = UserDto.UserRegistrationRequest.builder()
                .username("limittestuser")
                .email("limit@example.com")
                .password("password123")
                .firstName("Limit")
                .lastName("Test")
                .role(UserDto.UserRole.USER)
                .build();

        ResponseEntity<UserDto> userResponse = restTemplate.postForEntity(
                getBaseUrl() + "/api/users/register",
                registrationRequest,
                UserDto.class
        );

        Long userId = userResponse.getBody().getId();

        // Login
        UserDto.LoginRequest loginRequest = UserDto.LoginRequest.builder()
                .username("limittestuser")
                .password("password123")
                .build();

        ResponseEntity<UserDto.LoginResponse> loginResponse = restTemplate.postForEntity(
                getBaseUrl() + "/api/users/login",
                loginRequest,
                UserDto.LoginResponse.class
        );

        String token = loginResponse.getBody().getToken();
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + token);

        // Add multiple books
        for (int i = 0; i < 6; i++) {
            BookDto book = BookDto.builder()
                    .title("Test Book " + i)
                    .author("Test Author " + i)
                    .isbn("123456789" + i)
                    .genre("Fiction")
                    .description("Test book " + i)
                    .status(BookDto.BookStatus.AVAILABLE)
                    .active(true)
                    .build();

            ResponseEntity<BookDto> bookResponse = restTemplate.exchange(
                    getBaseUrl() + "/api/books",
                    HttpMethod.POST,
                    new HttpEntity<>(book, headers),
                    BookDto.class
            );

            Long bookId = bookResponse.getBody().getId();

            // Try to borrow book
            if (i < 5) {
                // First 5 books should succeed
                ResponseEntity<BorrowingDto> borrowResponse = restTemplate.exchange(
                        getBaseUrl() + "/api/borrowings/borrow?userId=" + userId + "&bookId=" + bookId,
                        HttpMethod.POST,
                        new HttpEntity<>(headers),
                        BorrowingDto.class
                );

                assertEquals(201, borrowResponse.getStatusCodeValue());
            } else {
                // 6th book should fail due to borrowing limit
                ResponseEntity<String> borrowResponse = restTemplate.exchange(
                        getBaseUrl() + "/api/borrowings/borrow?userId=" + userId + "&bookId=" + bookId,
                        HttpMethod.POST,
                        new HttpEntity<>(headers),
                        String.class
                );

                assertEquals(500, borrowResponse.getStatusCodeValue());
            }
        }
    }
}

