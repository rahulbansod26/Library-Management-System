#!/usr/bin/env python3
import http.server
import socketserver
import json
import urllib.parse
from datetime import datetime
import threading
import time

class LibraryAPIHandler(http.server.BaseHTTPRequestHandler):
    
    def do_GET(self):
        if self.path == '/api/users':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            users = [
                {"id": 1, "username": "john_doe", "email": "john@example.com", "firstName": "John", "lastName": "Doe", "role": "USER"},
                {"id": 2, "username": "jane_smith", "email": "jane@example.com", "firstName": "Jane", "lastName": "Smith", "role": "LIBRARIAN"}
            ]
            self.wfile.write(json.dumps(users).encode())
        elif self.path == '/api/books':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            books = [
                {"id": 1, "title": "The Great Gatsby", "author": "F. Scott Fitzgerald", "isbn": "9780743273565", "genre": "Fiction", "status": "AVAILABLE"},
                {"id": 2, "title": "To Kill a Mockingbird", "author": "Harper Lee", "isbn": "9780061120084", "genre": "Fiction", "status": "BORROWED"},
                {"id": 3, "title": "1984", "author": "George Orwell", "isbn": "9780451524935", "genre": "Dystopian", "status": "AVAILABLE"}
            ]
            self.wfile.write(json.dumps(books).encode())
        elif self.path == '/api/borrowings/user/1':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            borrowings = [
                {"id": 1, "userId": 1, "bookId": 2, "borrowDate": "2024-01-15T10:00:00", "dueDate": "2024-01-29T10:00:00", "status": "ACTIVE"}
            ]
            self.wfile.write(json.dumps(borrowings).encode())
        elif self.path == '/api/fines/user/1':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            fines = [
                {"id": 1, "userId": 1, "amount": 5.00, "reason": "Overdue book", "status": "PENDING"}
            ]
            self.wfile.write(json.dumps(fines).encode())
        elif self.path == '/api/notifications/user/1':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            notifications = [
                {"id": 1, "userId": 1, "subject": "Book Due Soon", "message": "Your book is due in 2 days", "type": "DUE_DATE_REMINDER", "sent": True}
            ]
            self.wfile.write(json.dumps(notifications).encode())
        elif self.path == '/health':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            health = {"status": "UP", "timestamp": datetime.now().isoformat()}
            self.wfile.write(json.dumps(health).encode())
        else:
            self.send_response(404)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            error = {"error": "Not Found", "path": self.path}
            self.wfile.write(json.dumps(error).encode())
    
    def do_POST(self):
        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length)
        
        if self.path == '/api/users/register':
            self.send_response(201)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            user = {"id": 3, "username": "new_user", "email": "new@example.com", "firstName": "New", "lastName": "User", "role": "USER"}
            self.wfile.write(json.dumps(user).encode())
        elif self.path == '/api/users/login':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            login = {"token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...", "tokenType": "Bearer", "user": {"id": 1, "username": "john_doe"}}
            self.wfile.write(json.dumps(login).encode())
        elif self.path == '/api/books':
            self.send_response(201)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            book = {"id": 4, "title": "New Book", "author": "New Author", "isbn": "9781234567890", "genre": "Fiction", "status": "AVAILABLE"}
            self.wfile.write(json.dumps(book).encode())
        elif self.path == '/api/borrowings/borrow':
            self.send_response(201)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            borrowing = {"id": 2, "userId": 1, "bookId": 1, "borrowDate": datetime.now().isoformat(), "dueDate": "2024-02-15T10:00:00", "status": "ACTIVE"}
            self.wfile.write(json.dumps(borrowing).encode())
        elif self.path == '/api/fines':
            self.send_response(201)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            fine = {"id": 2, "userId": 1, "amount": 10.00, "reason": "Lost book", "status": "PENDING"}
            self.wfile.write(json.dumps(fine).encode())
        elif self.path == '/api/notifications':
            self.send_response(201)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            notification = {"id": 2, "userId": 1, "subject": "New Notification", "message": "Test notification", "type": "REGISTRATION", "sent": False}
            self.wfile.write(json.dumps(notification).encode())
        else:
            self.send_response(404)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            error = {"error": "Not Found", "path": self.path}
            self.wfile.write(json.dumps(error).encode())

if __name__ == "__main__":
    PORT = 8080
    with socketserver.TCPServer(("", PORT), LibraryAPIHandler) as httpd:
        print(f"🚀 Library Management System Demo Server running on port {PORT}")
        print(f"🌐 Access the API at: http://localhost:{PORT}")
        print("📚 Available endpoints:")
        print("  GET  /health - System health")
        print("  GET  /api/users - Get all users")
        print("  POST /api/users/register - Register user")
        print("  POST /api/users/login - User login")
        print("  GET  /api/books - Get all books")
        print("  POST /api/books - Add book")
        print("  GET  /api/borrowings/user/1 - Get user borrowings")
        print("  POST /api/borrowings/borrow - Borrow book")
        print("  GET  /api/fines/user/1 - Get user fines")
        print("  POST /api/fines - Create fine")
        print("  GET  /api/notifications/user/1 - Get user notifications")
        print("  POST /api/notifications - Send notification")
        print("")
        print("Press Ctrl+C to stop the server")
        httpd.serve_forever()