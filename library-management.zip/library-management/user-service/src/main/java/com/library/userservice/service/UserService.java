package com.library.userservice.service;

import com.library.common.dto.UserDto;
import com.library.common.event.UserEvent;
import com.library.common.util.EventPublisher;
import com.library.userservice.dto.LoginRequest;
import com.library.userservice.dto.LoginResponse;
import com.library.userservice.dto.PasswordResetRequest;
import com.library.userservice.dto.UserRegistrationRequest;
import com.library.userservice.entity.User;
import com.library.userservice.repository.UserRepository;
import com.library.userservice.util.UserMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class UserService {
    
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;
    private final EmailService emailService;
    private final EventPublisher eventPublisher;
    
    public UserDto registerUser(UserRegistrationRequest request) {
        log.info("Registering new user: {}", request.getUsername());
        
        // Check if user already exists
        if (userRepository.existsByUsername(request.getUsername())) {
            throw new RuntimeException("Username already exists");
        }
        
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new RuntimeException("Email already exists");
        }
        
        // Create new user
        User user = User.builder()
                .username(request.getUsername())
                .email(request.getEmail())
                .password(passwordEncoder.encode(request.getPassword()))
                .firstName(request.getFirstName())
                .lastName(request.getLastName())
                .role(request.getRole())
                .active(true)
                .build();
        
        User savedUser = userRepository.save(user);
        UserDto userDto = UserMapper.toDto(savedUser);
        
        // Publish user registered event
        eventPublisher.publishUserEvent(UserEvent.EventType.USER_REGISTERED, savedUser.getId(), userDto);
        
        // Send welcome email asynchronously
        emailService.sendWelcomeEmail(savedUser.getEmail(), savedUser.getFirstName());
        
        log.info("User registered successfully: {}", savedUser.getId());
        return userDto;
    }
    
    public LoginResponse login(LoginRequest request) {
        log.info("User login attempt: {}", request.getUsername());
        
        User user = userRepository.findByUsername(request.getUsername())
                .orElseThrow(() -> new RuntimeException("Invalid credentials"));
        
        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            throw new RuntimeException("Invalid credentials");
        }
        
        if (!user.isActive()) {
            throw new RuntimeException("Account is deactivated");
        }
        
        String token = jwtService.generateToken(user.getUsername(), user.getRole().name());
        
        log.info("User logged in successfully: {}", user.getId());
        return LoginResponse.builder()
                .token(token)
                .user(UserMapper.toDto(user))
                .build();
    }
    
    @Cacheable(value = "users", key = "#id")
    public UserDto getUserById(Long id) {
        log.info("Fetching user by ID: {}", id);
        
        User user = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));
        
        return UserMapper.toDto(user);
    }
    
    @Cacheable(value = "users", key = "#username")
    public UserDto getUserByUsername(String username) {
        log.info("Fetching user by username: {}", username);
        
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found"));
        
        return UserMapper.toDto(user);
    }
    
    public List<UserDto> getAllUsers() {
        log.info("Fetching all users");
        
        return userRepository.findAll().stream()
                .map(UserMapper::toDto)
                .toList();
    }
    
    @CacheEvict(value = "users", key = "#id")
    public UserDto updateUser(Long id, UserDto userDto) {
        log.info("Updating user: {}", id);
        
        User user = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));
        
        user.setFirstName(userDto.getFirstName());
        user.setLastName(userDto.getLastName());
        user.setEmail(userDto.getEmail());
        user.setRole(userDto.getRole());
        user.setActive(userDto.isActive());
        
        User savedUser = userRepository.save(user);
        UserDto updatedUserDto = UserMapper.toDto(savedUser);
        
        // Publish user updated event
        eventPublisher.publishUserEvent(UserEvent.EventType.USER_UPDATED, savedUser.getId(), updatedUserDto);
        
        log.info("User updated successfully: {}", id);
        return updatedUserDto;
    }
    
    @CacheEvict(value = "users", key = "#id")
    public void deactivateUser(Long id) {
        log.info("Deactivating user: {}", id);
        
        User user = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));
        
        user.setActive(false);
        userRepository.save(user);
        
        UserDto userDto = UserMapper.toDto(user);
        
        // Publish user deactivated event
        eventPublisher.publishUserEvent(UserEvent.EventType.USER_DEACTIVATED, user.getId(), userDto);
        
        log.info("User deactivated successfully: {}", id);
    }
    
    public void requestPasswordReset(PasswordResetRequest request) {
        log.info("Password reset requested for email: {}", request.getEmail());
        
        Optional<User> userOpt = userRepository.findByEmail(request.getEmail());
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            String resetToken = UUID.randomUUID().toString();
            
            // In a real implementation, you would store this token with expiration
            // For now, we'll just send the email
            emailService.sendPasswordResetEmail(user.getEmail(), user.getFirstName(), resetToken);
            
            // Publish password reset requested event
            eventPublisher.publishUserEvent(UserEvent.EventType.PASSWORD_RESET_REQUESTED, user.getId(), UserMapper.toDto(user));
        }
        
        // Always return success for security (don't reveal if email exists)
        log.info("Password reset email sent to: {}", request.getEmail());
    }
}

