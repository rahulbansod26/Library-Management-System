package com.library.userservice.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class EmailService {
    
    private final JavaMailSender mailSender;
    
    @Value("${app.mail.from:noreply@library.com}")
    private String fromEmail;
    
    @Async
    public void sendWelcomeEmail(String to, String firstName) {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setTo(to);
            message.setFrom(fromEmail);
            message.setSubject("Welcome to Library Management System");
            message.setText(String.format(
                "Dear %s,\n\n" +
                "Welcome to the Library Management System! Your account has been successfully created.\n\n" +
                "You can now log in and start borrowing books.\n\n" +
                "Best regards,\nLibrary Management Team",
                firstName
            ));
            
            mailSender.send(message);
            log.info("Welcome email sent to: {}", to);
        } catch (Exception e) {
            log.error("Failed to send welcome email to: {}", to, e);
        }
    }
    
    @Async
    public void sendPasswordResetEmail(String to, String firstName, String resetToken) {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setTo(to);
            message.setFrom(fromEmail);
            message.setSubject("Password Reset Request");
            message.setText(String.format(
                "Dear %s,\n\n" +
                "You have requested a password reset for your Library Management System account.\n\n" +
                "Reset Token: %s\n\n" +
                "Please use this token to reset your password. This token will expire in 24 hours.\n\n" +
                "If you did not request this reset, please ignore this email.\n\n" +
                "Best regards,\nLibrary Management Team",
                firstName, resetToken
            ));
            
            mailSender.send(message);
            log.info("Password reset email sent to: {}", to);
        } catch (Exception e) {
            log.error("Failed to send password reset email to: {}", to, e);
        }
    }
}

