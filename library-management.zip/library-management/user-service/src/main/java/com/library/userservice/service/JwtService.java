package com.library.userservice.service;

import com.library.common.util.JwtUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class JwtService {
    
    private final JwtUtil jwtUtil;
    
    public String generateToken(String username, String role) {
        return jwtUtil.generateToken(username, role);
    }
    
    public boolean validateToken(String token, String username) {
        return jwtUtil.validateToken(token, username);
    }
    
    public String extractUsername(String token) {
        return jwtUtil.extractUsername(token);
    }
    
    public String extractRole(String token) {
        return jwtUtil.extractRole(token);
    }
}

