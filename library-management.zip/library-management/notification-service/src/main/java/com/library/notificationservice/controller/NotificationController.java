package com.library.notificationservice.controller;

import com.library.common.dto.NotificationDto;
import com.library.notificationservice.service.NotificationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/notifications")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Notification Management", description = "Notification dispatch and management operations")
public class NotificationController {
    
    private final NotificationService notificationService;
    
    @PostMapping
    @Operation(summary = "Send a notification")
    public ResponseEntity<NotificationDto> sendNotification(
            @RequestParam Long userId,
            @RequestParam String subject,
            @RequestParam String message,
            @RequestParam NotificationDto.NotificationType type,
            @RequestParam NotificationDto.NotificationChannel channel) {
        log.info("Send notification request for user: {}", userId);
        NotificationDto notification = notificationService.sendNotification(
                userId, subject, message, type, channel);
        return ResponseEntity.status(HttpStatus.CREATED).body(notification);
    }
    
    @GetMapping("/user/{userId}")
    @Operation(summary = "Get user's notifications")
    public ResponseEntity<List<NotificationDto>> getUserNotifications(@PathVariable Long userId) {
        log.info("Get user notifications request for user: {}", userId);
        List<NotificationDto> notifications = notificationService.getUserNotifications(userId);
        return ResponseEntity.ok(notifications);
    }
    
    @GetMapping("/user/{userId}/pending")
    @Operation(summary = "Get user's pending notifications")
    public ResponseEntity<List<NotificationDto>> getUserPendingNotifications(@PathVariable Long userId) {
        log.info("Get user pending notifications request for user: {}", userId);
        List<NotificationDto> notifications = notificationService.getUserPendingNotifications(userId);
        return ResponseEntity.ok(notifications);
    }
    
    @GetMapping("/{id}")
    @Operation(summary = "Get notification by ID")
    public ResponseEntity<NotificationDto> getNotificationById(@PathVariable Long id) {
        log.info("Get notification request for ID: {}", id);
        NotificationDto notification = notificationService.getNotificationById(id);
        return ResponseEntity.ok(notification);
    }
}

