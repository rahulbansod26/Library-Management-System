package com.library.notificationservice.repository;

import com.library.notificationservice.entity.Notification;
import com.library.common.dto.NotificationDto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface NotificationRepository extends JpaRepository<Notification, Long> {
    
    List<Notification> findByUserId(Long userId);
    
    List<Notification> findByUserIdAndSent(Long userId, boolean sent);
    
    List<Notification> findBySent(boolean sent);
    
    List<Notification> findByType(NotificationDto.NotificationType type);
    
    @Query("SELECT n FROM Notification n WHERE n.sent = false AND n.createdAt < :cutoffTime")
    List<Notification> findPendingNotifications(@Param("cutoffTime") LocalDateTime cutoffTime);
    
    @Query("SELECT COUNT(n) FROM Notification n WHERE n.userId = :userId AND n.sent = false")
    long countPendingNotificationsByUser(@Param("userId") Long userId);
}

