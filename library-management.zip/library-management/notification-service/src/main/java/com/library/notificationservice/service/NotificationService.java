package com.library.notificationservice.service;

import com.library.common.dto.NotificationDto;
import com.library.notificationservice.entity.Notification;
import com.library.notificationservice.repository.NotificationRepository;
import com.library.notificationservice.util.NotificationMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class NotificationService {
    
    private final NotificationRepository notificationRepository;
    private final EmailNotificationService emailNotificationService;
    private final SmsNotificationService smsNotificationService;
    
    @Async
    public NotificationDto sendNotification(Long userId, String subject, String message, 
                                          NotificationDto.NotificationType type, 
                                          NotificationDto.NotificationChannel channel) {
        log.info("Sending notification to user: {} via {}", userId, channel);
        
        Notification notification = Notification.builder()
                .userId(userId)
                .subject(subject)
                .message(message)
                .type(type)
                .channel(channel)
                .sent(false)
                .build();
        
        Notification savedNotification = notificationRepository.save(notification);
        
        // Send notification asynchronously
        sendNotificationAsync(savedNotification);
        
        return NotificationMapper.toDto(savedNotification);
    }
    
    @Async
    private void sendNotificationAsync(Notification notification) {
        try {
            boolean success = false;
            
            switch (notification.getChannel()) {
                case EMAIL:
                    success = emailNotificationService.sendEmail(notification);
                    break;
                case SMS:
                    success = smsNotificationService.sendSms(notification);
                    break;
                case PUSH:
                    // Push notification implementation would go here
                    success = true; // Mock implementation
                    break;
            }
            
            if (success) {
                notification.setSent(true);
                notification.setSentAt(LocalDateTime.now());
                notificationRepository.save(notification);
                log.info("Notification sent successfully: {}", notification.getId());
            } else {
                log.error("Failed to send notification: {}", notification.getId());
            }
        } catch (Exception e) {
            log.error("Error sending notification: {}", notification.getId(), e);
        }
    }
    
    @Cacheable(value = "userNotifications", key = "#userId")
    public List<NotificationDto> getUserNotifications(Long userId) {
        log.info("Fetching notifications for user: {}", userId);
        
        return notificationRepository.findByUserId(userId)
                .stream()
                .map(NotificationMapper::toDto)
                .toList();
    }
    
    @Cacheable(value = "pendingNotifications", key = "#userId")
    public List<NotificationDto> getUserPendingNotifications(Long userId) {
        log.info("Fetching pending notifications for user: {}", userId);
        
        return notificationRepository.findByUserIdAndSent(userId, false)
                .stream()
                .map(NotificationMapper::toDto)
                .toList();
    }
    
    @Cacheable(value = "notification", key = "#id")
    public NotificationDto getNotificationById(Long id) {
        log.info("Fetching notification by ID: {}", id);
        
        Notification notification = notificationRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Notification not found"));
        
        return NotificationMapper.toDto(notification);
    }
    
    @Scheduled(fixedRate = 300000) // Run every 5 minutes
    public void processPendingNotifications() {
        log.info("Processing pending notifications");
        
        LocalDateTime cutoffTime = LocalDateTime.now().minusMinutes(5);
        List<Notification> pendingNotifications = notificationRepository.findPendingNotifications(cutoffTime);
        
        for (Notification notification : pendingNotifications) {
            sendNotificationAsync(notification);
        }
        
        log.info("Processed {} pending notifications", pendingNotifications.size());
    }
    
    @Scheduled(cron = "0 0 9 * * ?") // Run daily at 9 AM
    public void sendDailyReminders() {
        log.info("Sending daily reminders");
        
        // This would typically query for users with books due soon
        // and send reminder notifications
        log.info("Daily reminders sent");
    }
}

