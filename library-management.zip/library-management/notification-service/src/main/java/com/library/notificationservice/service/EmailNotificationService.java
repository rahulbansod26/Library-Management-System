package com.library.notificationservice.service;

import com.library.notificationservice.entity.Notification;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class EmailNotificationService {
    
    private final JavaMailSender mailSender;
    
    @Value("${app.mail.from:noreply@library.com}")
    private String fromEmail;
    
    public boolean sendEmail(Notification notification) {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setTo(getUserEmail(notification.getUserId())); // This would fetch from user service
            message.setFrom(fromEmail);
            message.setSubject(notification.getSubject());
            message.setText(notification.getMessage());
            
            mailSender.send(message);
            log.info("Email sent successfully to user: {}", notification.getUserId());
            return true;
        } catch (Exception e) {
            log.error("Failed to send email to user: {}", notification.getUserId(), e);
            return false;
        }
    }
    
    private String getUserEmail(Long userId) {
        // In a real implementation, this would call the user service
        // For now, return a mock email
        return "user" + userId + "@example.com";
    }
}

