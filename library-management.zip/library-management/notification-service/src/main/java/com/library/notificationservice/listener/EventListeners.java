package com.library.notificationservice.listener;

import com.library.common.event.BorrowingEvent;
import com.library.common.event.FineEvent;
import com.library.common.event.UserEvent;
import com.library.common.dto.NotificationDto;
import com.library.notificationservice.service.NotificationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class EventListeners {
    
    private final NotificationService notificationService;
    
    @RabbitListener(queues = "user.registered")
    public void handleUserRegistered(UserEvent event) {
        log.info("Received user registered event: {}", event.getUserId());
        
        notificationService.sendNotification(
                event.getUserId(),
                "Welcome to Library Management System",
                "Your account has been successfully created. You can now start borrowing books!",
                NotificationDto.NotificationType.REGISTRATION,
                NotificationDto.NotificationChannel.EMAIL
        );
    }
    
    @RabbitListener(queues = "borrowing.book_borrowed")
    public void handleBookBorrowed(BorrowingEvent event) {
        log.info("Received book borrowed event: {}", event.getBorrowingId());
        
        notificationService.sendNotification(
                event.getUserId(),
                "Book Borrowed Successfully",
                "You have successfully borrowed a book. Due date: " + event.getBorrowingData().getDueDate(),
                NotificationDto.NotificationType.BORROWING_CONFIRMATION,
                NotificationDto.NotificationChannel.EMAIL
        );
    }
    
    @RabbitListener(queues = "borrowing.book_returned")
    public void handleBookReturned(BorrowingEvent event) {
        log.info("Received book returned event: {}", event.getBorrowingId());
        
        notificationService.sendNotification(
                event.getUserId(),
                "Book Returned Successfully",
                "Thank you for returning the book on time!",
                NotificationDto.NotificationType.BORROWING_CONFIRMATION,
                NotificationDto.NotificationChannel.EMAIL
        );
    }
    
    @RabbitListener(queues = "borrowing.book_overdue")
    public void handleBookOverdue(BorrowingEvent event) {
        log.info("Received book overdue event: {}", event.getBorrowingId());
        
        notificationService.sendNotification(
                event.getUserId(),
                "Book Overdue Alert",
                "You have an overdue book. Please return it as soon as possible to avoid additional fines.",
                NotificationDto.NotificationType.OVERDUE_ALERT,
                NotificationDto.NotificationChannel.EMAIL
        );
    }
    
    @RabbitListener(queues = "fine.fine_created")
    public void handleFineCreated(FineEvent event) {
        log.info("Received fine created event: {}", event.getFineId());
        
        notificationService.sendNotification(
                event.getUserId(),
                "Fine Issued",
                "A fine of $" + event.getAmount() + " has been issued. Please pay it within 30 days.",
                NotificationDto.NotificationType.FINE_NOTIFICATION,
                NotificationDto.NotificationChannel.EMAIL
        );
    }
    
    @RabbitListener(queues = "fine.fine_paid")
    public void handleFinePaid(FineEvent event) {
        log.info("Received fine paid event: {}", event.getFineId());
        
        notificationService.sendNotification(
                event.getUserId(),
                "Fine Payment Confirmed",
                "Your fine payment of $" + event.getAmount() + " has been processed successfully.",
                NotificationDto.NotificationType.PAYMENT_CONFIRMATION,
                NotificationDto.NotificationChannel.EMAIL
        );
    }
}

