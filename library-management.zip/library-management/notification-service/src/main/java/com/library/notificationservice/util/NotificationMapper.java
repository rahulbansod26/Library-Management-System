package com.library.notificationservice.util;

import com.library.common.dto.NotificationDto;
import com.library.notificationservice.entity.Notification;

public class NotificationMapper {
    
    public static NotificationDto toDto(Notification notification) {
        return NotificationDto.builder()
                .id(notification.getId())
                .userId(notification.getUserId())
                .subject(notification.getSubject())
                .message(notification.getMessage())
                .type(notification.getType())
                .channel(notification.getChannel())
                .sent(notification.isSent())
                .sentAt(notification.getSentAt())
                .createdAt(notification.getCreatedAt())
                .build();
    }
    
    public static Notification toEntity(NotificationDto notificationDto) {
        return Notification.builder()
                .id(notificationDto.getId())
                .userId(notificationDto.getUserId())
                .subject(notificationDto.getSubject())
                .message(notificationDto.getMessage())
                .type(notificationDto.getType())
                .channel(notificationDto.getChannel())
                .sent(notificationDto.isSent())
                .sentAt(notificationDto.getSentAt())
                .createdAt(notificationDto.getCreatedAt())
                .build();
    }
}

