package com.library.notificationservice.service;

import com.library.notificationservice.entity.Notification;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class SmsNotificationService {
    
    public boolean sendSms(Notification notification) {
        try {
            // Mock SMS service implementation
            // In a real implementation, this would integrate with SMS providers like Twilio
            log.info("SMS sent to user: {} - {}", notification.getUserId(), notification.getMessage());
            
            // Simulate SMS sending delay
            Thread.sleep(1000);
            
            return true;
        } catch (Exception e) {
            log.error("Failed to send SMS to user: {}", notification.getUserId(), e);
            return false;
        }
    }
}

