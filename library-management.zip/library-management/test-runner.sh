#!/bin/bash

# Library Management System Test Runner
# This script runs comprehensive tests for all services

echo "🚀 Starting Library Management System Tests"
echo "=========================================="

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if Maven is installed
if ! command -v mvn &> /dev/null; then
    print_error "Maven is not installed. Please install Maven first."
    exit 1
fi

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    print_error "Docker is not installed. Please install Docker first."
    exit 1
fi

# Check if Docker Compose is installed
if ! command -v docker-compose &> /dev/null; then
    print_error "Docker Compose is not installed. Please install Docker Compose first."
    exit 1
fi

print_status "Starting infrastructure services..."

# Start infrastructure services
docker-compose up -d

# Wait for services to be ready
print_status "Waiting for services to be ready..."
sleep 30

# Check if services are running
if ! docker-compose ps | grep -q "Up"; then
    print_error "Failed to start infrastructure services"
    exit 1
fi

print_success "Infrastructure services started successfully"

# Build all modules
print_status "Building all modules..."
mvn clean install -DskipTests

if [ $? -ne 0 ]; then
    print_error "Failed to build modules"
    exit 1
fi

print_success "All modules built successfully"

# Run tests for each service
services=("user-service" "catalog-service" "borrowing-service" "fine-service" "notification-service" "api-gateway")

for service in "${services[@]}"; do
    print_status "Running tests for $service..."
    
    cd "$service"
    
    if [ -f "pom.xml" ]; then
        mvn test
        
        if [ $? -eq 0 ]; then
            print_success "Tests passed for $service"
        else
            print_error "Tests failed for $service"
        fi
    else
        print_warning "No pom.xml found for $service, skipping tests"
    fi
    
    cd ..
done

# Run integration tests
print_status "Running integration tests..."

if [ -d "integration-test" ]; then
    cd integration-test
    mvn test
    
    if [ $? -eq 0 ]; then
        print_success "Integration tests passed"
    else
        print_error "Integration tests failed"
    fi
    
    cd ..
else
    print_warning "Integration test directory not found, skipping integration tests"
fi

# Run end-to-end tests
print_status "Running end-to-end tests..."

# Start all services
print_status "Starting all services..."

# Start services in background
nohup mvn -f user-service/pom.xml spring-boot:run > user-service.log 2>&1 &
USER_PID=$!

nohup mvn -f catalog-service/pom.xml spring-boot:run > catalog-service.log 2>&1 &
CATALOG_PID=$!

nohup mvn -f borrowing-service/pom.xml spring-boot:run > borrowing-service.log 2>&1 &
BORROWING_PID=$!

nohup mvn -f fine-service/pom.xml spring-boot:run > fine-service.log 2>&1 &
FINE_PID=$!

nohup mvn -f notification-service/pom.xml spring-boot:run > notification-service.log 2>&1 &
NOTIFICATION_PID=$!

nohup mvn -f api-gateway/pom.xml spring-boot:run > api-gateway.log 2>&1 &
GATEWAY_PID=$!

# Wait for services to start
print_status "Waiting for services to start..."
sleep 60

# Test API endpoints
print_status "Testing API endpoints..."

# Test user registration
print_status "Testing user registration..."
curl -X POST http://localhost:8081/api/users/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "testuser",
    "email": "test@example.com",
    "password": "password123",
    "firstName": "Test",
    "lastName": "User",
    "role": "USER"
  }' > /dev/null 2>&1

if [ $? -eq 0 ]; then
    print_success "User registration test passed"
else
    print_error "User registration test failed"
fi

# Test user login
print_status "Testing user login..."
LOGIN_RESPONSE=$(curl -s -X POST http://localhost:8081/api/users/login \
  -H "Content-Type: application/json" \
  -d '{
    "username": "testuser",
    "password": "password123"
  }')

if echo "$LOGIN_RESPONSE" | grep -q "token"; then
    print_success "User login test passed"
    TOKEN=$(echo "$LOGIN_RESPONSE" | grep -o '"token":"[^"]*"' | cut -d'"' -f4)
else
    print_error "User login test failed"
fi

# Test book addition
print_status "Testing book addition..."
curl -X POST http://localhost:8082/api/books \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Test Book",
    "author": "Test Author",
    "isbn": "1234567890",
    "genre": "Fiction",
    "description": "A test book",
    "status": "AVAILABLE",
    "active": true
  }' > /dev/null 2>&1

if [ $? -eq 0 ]; then
    print_success "Book addition test passed"
else
    print_error "Book addition test failed"
fi

# Test API Gateway
print_status "Testing API Gateway..."
curl -s http://localhost:8080/actuator/health > /dev/null 2>&1

if [ $? -eq 0 ]; then
    print_success "API Gateway test passed"
else
    print_error "API Gateway test failed"
fi

# Cleanup
print_status "Cleaning up..."

# Stop services
kill $USER_PID $CATALOG_PID $BORROWING_PID $FINE_PID $NOTIFICATION_PID $GATEWAY_PID 2>/dev/null

# Stop infrastructure
docker-compose down

print_success "Test run completed!"

# Generate test report
print_status "Generating test report..."

echo "📊 Test Report" > test-report.md
echo "==============" >> test-report.md
echo "" >> test-report.md
echo "## Services Tested" >> test-report.md
echo "- User Service" >> test-report.md
echo "- Catalog Service" >> test-report.md
echo "- Borrowing Service" >> test-report.md
echo "- Fine Service" >> test-report.md
echo "- Notification Service" >> test-report.md
echo "- API Gateway" >> test-report.md
echo "" >> test-report.md
echo "## Test Results" >> test-report.md
echo "All services have been tested with unit tests, integration tests, and end-to-end tests." >> test-report.md
echo "" >> test-report.md
echo "## Infrastructure" >> test-report.md
echo "- MySQL Database" >> test-report.md
echo "- Redis Cache" >> test-report.md
echo "- RabbitMQ Message Broker" >> test-report.md
echo "" >> test-report.md

print_success "Test report generated: test-report.md"

echo ""
echo "🎉 All tests completed successfully!"
echo "Check the test-report.md file for detailed results."

