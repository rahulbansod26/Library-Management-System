package com.library.fineservice.util;

import com.library.common.dto.FineDto;
import com.library.fineservice.entity.Fine;

public class FineMapper {
    
    public static FineDto toDto(Fine fine) {
        return FineDto.builder()
                .id(fine.getId())
                .userId(fine.getUserId())
                .borrowingId(fine.getBorrowingId())
                .amount(fine.getAmount())
                .status(fine.getStatus())
                .reason(fine.getReason())
                .dueDate(fine.getDueDate())
                .paidDate(fine.getPaidDate())
                .createdAt(fine.getCreatedAt())
                .updatedAt(fine.getUpdatedAt())
                .build();
    }
    
    public static Fine toEntity(FineDto fineDto) {
        return Fine.builder()
                .id(fineDto.getId())
                .userId(fineDto.getUserId())
                .borrowingId(fineDto.getBorrowingId())
                .amount(fineDto.getAmount())
                .status(fineDto.getStatus())
                .reason(fineDto.getReason())
                .dueDate(fineDto.getDueDate())
                .paidDate(fineDto.getPaidDate())
                .createdAt(fineDto.getCreatedAt())
                .updatedAt(fineDto.getUpdatedAt())
                .build();
    }
}

