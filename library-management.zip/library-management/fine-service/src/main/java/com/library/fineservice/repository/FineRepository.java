package com.library.fineservice.repository;

import com.library.fineservice.entity.Fine;
import com.library.common.dto.FineDto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface FineRepository extends JpaRepository<Fine, Long> {
    
    List<Fine> findByUserId(Long userId);
    
    List<Fine> findByUserIdAndStatus(Long userId, FineDto.FineStatus status);
    
    List<Fine> findByStatus(FineDto.FineStatus status);
    
    Optional<Fine> findByBorrowingId(Long borrowingId);
    
    @Query("SELECT f FROM Fine f WHERE f.status = :status AND f.dueDate < :currentDate")
    List<Fine> findOverdueFines(@Param("status") FineDto.FineStatus status, 
                               @Param("currentDate") LocalDateTime currentDate);
    
    @Query("SELECT SUM(f.amount) FROM Fine f WHERE f.userId = :userId AND f.status = :status")
    BigDecimal calculateTotalFinesByUser(@Param("userId") Long userId, @Param("status") FineDto.FineStatus status);
    
    @Query("SELECT COUNT(f) FROM Fine f WHERE f.userId = :userId AND f.status = :status")
    long countFinesByUser(@Param("userId") Long userId, @Param("status") FineDto.FineStatus status);
}

