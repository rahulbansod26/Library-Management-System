package com.library.fineservice.controller;

import com.library.common.dto.FineDto;
import com.library.fineservice.service.FineService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;

@RestController
@RequestMapping("/api/fines")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Fine Management", description = "Fine calculation and payment operations")
public class FineController {
    
    private final FineService fineService;
    
    @PostMapping
    @Operation(summary = "Create a fine")
    public ResponseEntity<FineDto> createFine(@RequestParam Long userId, 
                                            @RequestParam Long borrowingId, 
                                            @RequestParam String reason) {
        log.info("Create fine request - User: {}, Borrowing: {}", userId, borrowingId);
        FineDto fine = fineService.createFine(userId, borrowingId, reason);
        return ResponseEntity.status(HttpStatus.CREATED).body(fine);
    }
    
    @GetMapping("/user/{userId}")
    @Operation(summary = "Get user's fines")
    public ResponseEntity<List<FineDto>> getUserFines(@PathVariable Long userId) {
        log.info("Get user fines request for user: {}", userId);
        List<FineDto> fines = fineService.getUserFines(userId);
        return ResponseEntity.ok(fines);
    }
    
    @GetMapping("/user/{userId}/pending")
    @Operation(summary = "Get user's pending fines")
    public ResponseEntity<List<FineDto>> getUserPendingFines(@PathVariable Long userId) {
        log.info("Get user pending fines request for user: {}", userId);
        List<FineDto> fines = fineService.getUserPendingFines(userId);
        return ResponseEntity.ok(fines);
    }
    
    @GetMapping("/{id}")
    @Operation(summary = "Get fine by ID")
    public ResponseEntity<FineDto> getFineById(@PathVariable Long id) {
        log.info("Get fine request for ID: {}", id);
        FineDto fine = fineService.getFineById(id);
        return ResponseEntity.ok(fine);
    }
    
    @PostMapping("/{id}/pay")
    @Operation(summary = "Pay a fine")
    public ResponseEntity<FineDto> payFine(@PathVariable Long id, @RequestParam String paymentMethod) {
        log.info("Pay fine request for ID: {} with method: {}", id, paymentMethod);
        FineDto fine = fineService.payFine(id, paymentMethod);
        return ResponseEntity.ok(fine);
    }
    
    @DeleteMapping("/{id}")
    @Operation(summary = "Cancel fine")
    public ResponseEntity<Void> cancelFine(@PathVariable Long id) {
        log.info("Cancel fine request for ID: {}", id);
        fineService.cancelFine(id);
        return ResponseEntity.noContent().build();
    }
    
    @GetMapping("/user/{userId}/total")
    @Operation(summary = "Get user's total pending fines")
    public ResponseEntity<BigDecimal> getUserTotalFines(@PathVariable Long userId) {
        log.info("Get user total fines request for user: {}", userId);
        BigDecimal total = fineService.getUserTotalFines(userId);
        return ResponseEntity.ok(total);
    }
}

