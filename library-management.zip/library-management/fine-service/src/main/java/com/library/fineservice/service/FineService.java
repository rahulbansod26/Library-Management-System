package com.library.fineservice.service;

import com.library.common.dto.FineDto;
import com.library.common.event.FineEvent;
import com.library.common.util.EventPublisher;
import com.library.fineservice.entity.Fine;
import com.library.fineservice.repository.FineRepository;
import com.library.fineservice.util.FineMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class FineService {
    
    private final FineRepository fineRepository;
    private final EventPublisher eventPublisher;
    private final PaymentService paymentService;
    
    private static final BigDecimal DAILY_FINE_RATE = new BigDecimal("1.00");
    private static final BigDecimal MAX_FINE_AMOUNT = new BigDecimal("50.00");
    
    @Async
    public FineDto createFine(Long userId, Long borrowingId, String reason) {
        log.info("Creating fine for user: {}, borrowing: {}", userId, borrowingId);
        
        // Check if fine already exists for this borrowing
        if (fineRepository.findByBorrowingId(borrowingId).isPresent()) {
            throw new RuntimeException("Fine already exists for this borrowing");
        }
        
        // Calculate fine amount based on overdue days
        BigDecimal amount = calculateFineAmount(borrowingId);
        LocalDateTime dueDate = LocalDateTime.now().plusDays(30); // 30 days to pay
        
        Fine fine = Fine.builder()
                .userId(userId)
                .borrowingId(borrowingId)
                .amount(amount)
                .status(FineDto.FineStatus.PENDING)
                .reason(reason)
                .dueDate(dueDate)
                .build();
        
        Fine savedFine = fineRepository.save(fine);
        FineDto fineDto = FineMapper.toDto(savedFine);
        
        // Publish fine created event
        eventPublisher.publishFineEvent(FineEvent.EventType.FINE_CREATED, 
                savedFine.getId(), userId, amount, fineDto);
        
        log.info("Fine created successfully: {}", savedFine.getId());
        return fineDto;
    }
    
    @Cacheable(value = "userFines", key = "#userId")
    public List<FineDto> getUserFines(Long userId) {
        log.info("Fetching fines for user: {}", userId);
        
        return fineRepository.findByUserId(userId)
                .stream()
                .map(FineMapper::toDto)
                .toList();
    }
    
    @Cacheable(value = "pendingFines", key = "#userId")
    public List<FineDto> getUserPendingFines(Long userId) {
        log.info("Fetching pending fines for user: {}", userId);
        
        return fineRepository.findByUserIdAndStatus(userId, FineDto.FineStatus.PENDING)
                .stream()
                .map(FineMapper::toDto)
                .toList();
    }
    
    @Cacheable(value = "fine", key = "#id")
    public FineDto getFineById(Long id) {
        log.info("Fetching fine by ID: {}", id);
        
        Fine fine = fineRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Fine not found"));
        
        return FineMapper.toDto(fine);
    }
    
    @CacheEvict(value = {"userFines", "pendingFines", "fine"}, allEntries = true)
    public FineDto payFine(Long fineId, String paymentMethod) {
        log.info("Processing payment for fine: {}", fineId);
        
        Fine fine = fineRepository.findById(fineId)
                .orElseThrow(() -> new RuntimeException("Fine not found"));
        
        if (fine.getStatus() != FineDto.FineStatus.PENDING) {
            throw new RuntimeException("Fine is not pending payment");
        }
        
        // Process payment asynchronously
        boolean paymentSuccess = paymentService.processPayment(fine.getAmount(), paymentMethod);
        
        if (paymentSuccess) {
            fine.setStatus(FineDto.FineStatus.PAID);
            fine.setPaidDate(LocalDateTime.now());
            Fine savedFine = fineRepository.save(fine);
            FineDto fineDto = FineMapper.toDto(savedFine);
            
            // Publish fine paid event
            eventPublisher.publishFineEvent(FineEvent.EventType.FINE_PAID, 
                    savedFine.getId(), fine.getUserId(), fine.getAmount(), fineDto);
            
            log.info("Fine paid successfully: {}", fineId);
            return fineDto;
        } else {
            throw new RuntimeException("Payment processing failed");
        }
    }
    
    @CacheEvict(value = {"userFines", "pendingFines", "fine"}, allEntries = true)
    public void cancelFine(Long fineId) {
        log.info("Cancelling fine: {}", fineId);
        
        Fine fine = fineRepository.findById(fineId)
                .orElseThrow(() -> new RuntimeException("Fine not found"));
        
        if (fine.getStatus() != FineDto.FineStatus.PENDING) {
            throw new RuntimeException("Only pending fines can be cancelled");
        }
        
        fine.setStatus(FineDto.FineStatus.CANCELLED);
        fineRepository.save(fine);
        
        // Publish fine cancelled event
        FineDto fineDto = FineMapper.toDto(fine);
        eventPublisher.publishFineEvent(FineEvent.EventType.FINE_CANCELLED, 
                fineId, fine.getUserId(), fine.getAmount(), fineDto);
        
        log.info("Fine cancelled successfully: {}", fineId);
    }
    
    public BigDecimal getUserTotalFines(Long userId) {
        log.info("Calculating total fines for user: {}", userId);
        
        return fineRepository.calculateTotalFinesByUser(userId, FineDto.FineStatus.PENDING);
    }
    
    @Scheduled(fixedRate = 86400000) // Run daily
    public void calculateOverdueFines() {
        log.info("Calculating overdue fines");
        
        // This would typically query overdue borrowings and create fines
        // For now, we'll just log the scheduled task
        log.info("Overdue fines calculation completed");
    }
    
    @Scheduled(fixedRate = 3600000) // Run hourly
    public void checkOverdueFines() {
        log.info("Checking for overdue fines");
        
        LocalDateTime now = LocalDateTime.now();
        List<Fine> overdueFines = fineRepository.findOverdueFines(FineDto.FineStatus.PENDING, now);
        
        for (Fine fine : overdueFines) {
            // Update fine status or send reminders
            log.info("Found overdue fine: {}", fine.getId());
        }
        
        log.info("Overdue fines check completed. Found {} overdue fines", overdueFines.size());
    }
    
    private BigDecimal calculateFineAmount(Long borrowingId) {
        // This would typically calculate based on overdue days
        // For now, return a fixed amount
        return DAILY_FINE_RATE;
    }
}

