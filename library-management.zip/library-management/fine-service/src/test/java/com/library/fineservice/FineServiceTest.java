package com.library.fineservice;

import com.library.common.dto.FineDto;
import com.library.fineservice.entity.Fine;
import com.library.fineservice.repository.FineRepository;
import com.library.fineservice.service.FineService;
import com.library.fineservice.service.PaymentService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@SpringBootTest
@ActiveProfiles("test")
class FineServiceTest {

    @Autowired
    private FineService fineService;

    @MockBean
    private FineRepository fineRepository;

    @MockBean
    private PaymentService paymentService;

    private Fine testFine;
    private FineDto testFineDto;

    @BeforeEach
    void setUp() {
        testFine = Fine.builder()
                .id(1L)
                .userId(1L)
                .borrowingId(1L)
                .amount(new BigDecimal("10.00"))
                .status(FineDto.FineStatus.PENDING)
                .reason("Overdue book")
                .dueDate(LocalDateTime.now().plusDays(30))
                .build();

        testFineDto = FineDto.builder()
                .id(1L)
                .userId(1L)
                .borrowingId(1L)
                .amount(new BigDecimal("10.00"))
                .status(FineDto.FineStatus.PENDING)
                .reason("Overdue book")
                .dueDate(LocalDateTime.now().plusDays(30))
                .build();
    }

    @Test
    void testCreateFine_Success() {
        // Given
        when(fineRepository.findByBorrowingId(1L)).thenReturn(Optional.empty());
        when(fineRepository.save(any(Fine.class))).thenReturn(testFine);

        // When
        FineDto result = fineService.createFine(1L, 1L, "Overdue book");

        // Then
        assertNotNull(result);
        assertEquals(1L, result.getUserId());
        assertEquals(1L, result.getBorrowingId());
        assertEquals(new BigDecimal("10.00"), result.getAmount());
        assertEquals(FineDto.FineStatus.PENDING, result.getStatus());
        assertEquals("Overdue book", result.getReason());

        verify(fineRepository).findByBorrowingId(1L);
        verify(fineRepository).save(any(Fine.class));
    }

    @Test
    void testCreateFine_AlreadyExists() {
        // Given
        when(fineRepository.findByBorrowingId(1L)).thenReturn(Optional.of(testFine));

        // When & Then
        assertThrows(RuntimeException.class, () -> {
            fineService.createFine(1L, 1L, "Overdue book");
        });

        verify(fineRepository).findByBorrowingId(1L);
        verify(fineRepository, never()).save(any(Fine.class));
    }

    @Test
    void testGetUserFines_Success() {
        // Given
        List<Fine> fines = Arrays.asList(testFine);
        when(fineRepository.findByUserId(1L)).thenReturn(fines);

        // When
        List<FineDto> result = fineService.getUserFines(1L);

        // Then
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals(1L, result.get(0).getUserId());
        assertEquals(new BigDecimal("10.00"), result.get(0).getAmount());

        verify(fineRepository).findByUserId(1L);
    }

    @Test
    void testGetUserPendingFines_Success() {
        // Given
        List<Fine> pendingFines = Arrays.asList(testFine);
        when(fineRepository.findByUserIdAndStatus(1L, FineDto.FineStatus.PENDING))
                .thenReturn(pendingFines);

        // When
        List<FineDto> result = fineService.getUserPendingFines(1L);

        // Then
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals(FineDto.FineStatus.PENDING, result.get(0).getStatus());

        verify(fineRepository).findByUserIdAndStatus(1L, FineDto.FineStatus.PENDING);
    }

    @Test
    void testGetFineById_Success() {
        // Given
        when(fineRepository.findById(1L)).thenReturn(Optional.of(testFine));

        // When
        FineDto result = fineService.getFineById(1L);

        // Then
        assertNotNull(result);
        assertEquals(1L, result.getId());
        assertEquals(1L, result.getUserId());
        assertEquals(new BigDecimal("10.00"), result.getAmount());

        verify(fineRepository).findById(1L);
    }

    @Test
    void testGetFineById_NotFound() {
        // Given
        when(fineRepository.findById(999L)).thenReturn(Optional.empty());

        // When & Then
        assertThrows(RuntimeException.class, () -> {
            fineService.getFineById(999L);
        });

        verify(fineRepository).findById(999L);
    }

    @Test
    void testPayFine_Success() {
        // Given
        Fine paidFine = Fine.builder()
                .id(1L)
                .userId(1L)
                .borrowingId(1L)
                .amount(new BigDecimal("10.00"))
                .status(FineDto.FineStatus.PAID)
                .reason("Overdue book")
                .paidDate(LocalDateTime.now())
                .build();

        when(fineRepository.findById(1L)).thenReturn(Optional.of(testFine));
        when(paymentService.processPayment(new BigDecimal("10.00"), "credit_card")).thenReturn(true);
        when(fineRepository.save(any(Fine.class))).thenReturn(paidFine);

        // When
        FineDto result = fineService.payFine(1L, "credit_card");

        // Then
        assertNotNull(result);
        assertEquals(FineDto.FineStatus.PAID, result.getStatus());
        assertNotNull(result.getPaidDate());

        verify(fineRepository).findById(1L);
        verify(paymentService).processPayment(new BigDecimal("10.00"), "credit_card");
        verify(fineRepository).save(any(Fine.class));
    }

    @Test
    void testPayFine_PaymentFailed() {
        // Given
        when(fineRepository.findById(1L)).thenReturn(Optional.of(testFine));
        when(paymentService.processPayment(new BigDecimal("10.00"), "credit_card")).thenReturn(false);

        // When & Then
        assertThrows(RuntimeException.class, () -> {
            fineService.payFine(1L, "credit_card");
        });

        verify(fineRepository).findById(1L);
        verify(paymentService).processPayment(new BigDecimal("10.00"), "credit_card");
        verify(fineRepository, never()).save(any(Fine.class));
    }

    @Test
    void testCancelFine_Success() {
        // Given
        when(fineRepository.findById(1L)).thenReturn(Optional.of(testFine));
        when(fineRepository.save(any(Fine.class))).thenReturn(testFine);

        // When
        fineService.cancelFine(1L);

        // Then
        verify(fineRepository).findById(1L);
        verify(fineRepository).save(any(Fine.class));
    }

    @Test
    void testGetUserTotalFines_Success() {
        // Given
        when(fineRepository.calculateTotalFinesByUser(1L, FineDto.FineStatus.PENDING))
                .thenReturn(new BigDecimal("25.00"));

        // When
        BigDecimal result = fineService.getUserTotalFines(1L);

        // Then
        assertNotNull(result);
        assertEquals(new BigDecimal("25.00"), result);

        verify(fineRepository).calculateTotalFinesByUser(1L, FineDto.FineStatus.PENDING);
    }
}

