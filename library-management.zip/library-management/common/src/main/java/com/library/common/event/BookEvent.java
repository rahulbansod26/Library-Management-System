package com.library.common.event;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.library.common.dto.BookDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BookEvent {
    private String eventId;
    private String eventType;
    private Long bookId;
    private BookDto bookData;
    
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime timestamp;
    
    public enum EventType {
        BOOK_ADDED, BOOK_UPDATED, BOOK_REMOVED, BOOK_STATUS_CHANGED
    }
}

