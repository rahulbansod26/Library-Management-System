package com.library.common.config;

import org.springframework.amqp.core.*;
import org.springframework.amqp.rabbit.config.SimpleRabbitListenerContainerFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitMQConfig {
    
    // User Service Exchanges and Queues
    @Bean
    public TopicExchange userExchange() {
        return new TopicExchange("user.exchange");
    }
    
    @Bean
    public Queue userRegisteredQueue() {
        return new Queue("user.registered", true);
    }
    
    @Bean
    public Queue userUpdatedQueue() {
        return new Queue("user.updated", true);
    }
    
    @Bean
    public Queue userDeactivatedQueue() {
        return new Queue("user.deactivated", true);
    }
    
    @Bean
    public Queue passwordResetRequestedQueue() {
        return new Queue("user.password_reset_requested", true);
    }
    
    @Bean
    public Binding userRegisteredBinding() {
        return BindingBuilder.bind(userRegisteredQueue())
                .to(userExchange())
                .with("user.registered");
    }
    
    @Bean
    public Binding userUpdatedBinding() {
        return BindingBuilder.bind(userUpdatedQueue())
                .to(userExchange())
                .with("user.updated");
    }
    
    @Bean
    public Binding userDeactivatedBinding() {
        return BindingBuilder.bind(userDeactivatedQueue())
                .to(userExchange())
                .with("user.deactivated");
    }
    
    @Bean
    public Binding passwordResetRequestedBinding() {
        return BindingBuilder.bind(passwordResetRequestedQueue())
                .to(userExchange())
                .with("user.password_reset_requested");
    }
    
    // Book Service Exchanges and Queues
    @Bean
    public TopicExchange bookExchange() {
        return new TopicExchange("book.exchange");
    }
    
    @Bean
    public Queue bookAddedQueue() {
        return new Queue("book.added", true);
    }
    
    @Bean
    public Queue bookUpdatedQueue() {
        return new Queue("book.updated", true);
    }
    
    @Bean
    public Queue bookRemovedQueue() {
        return new Queue("book.removed", true);
    }
    
    @Bean
    public Queue bookStatusChangedQueue() {
        return new Queue("book.status_changed", true);
    }
    
    @Bean
    public Binding bookAddedBinding() {
        return BindingBuilder.bind(bookAddedQueue())
                .to(bookExchange())
                .with("book.added");
    }
    
    @Bean
    public Binding bookUpdatedBinding() {
        return BindingBuilder.bind(bookUpdatedQueue())
                .to(bookExchange())
                .with("book.updated");
    }
    
    @Bean
    public Binding bookRemovedBinding() {
        return BindingBuilder.bind(bookRemovedQueue())
                .to(bookExchange())
                .with("book.removed");
    }
    
    @Bean
    public Binding bookStatusChangedBinding() {
        return BindingBuilder.bind(bookStatusChangedQueue())
                .to(bookExchange())
                .with("book.status_changed");
    }
    
    // Borrowing Service Exchanges and Queues
    @Bean
    public TopicExchange borrowingExchange() {
        return new TopicExchange("borrowing.exchange");
    }
    
    @Bean
    public Queue bookBorrowedQueue() {
        return new Queue("borrowing.book_borrowed", true);
    }
    
    @Bean
    public Queue bookReturnedQueue() {
        return new Queue("borrowing.book_returned", true);
    }
    
    @Bean
    public Queue bookOverdueQueue() {
        return new Queue("borrowing.book_overdue", true);
    }
    
    @Bean
    public Queue borrowingCancelledQueue() {
        return new Queue("borrowing.borrowing_cancelled", true);
    }
    
    @Bean
    public Binding bookBorrowedBinding() {
        return BindingBuilder.bind(bookBorrowedQueue())
                .to(borrowingExchange())
                .with("borrowing.book_borrowed");
    }
    
    @Bean
    public Binding bookReturnedBinding() {
        return BindingBuilder.bind(bookReturnedQueue())
                .to(borrowingExchange())
                .with("borrowing.book_returned");
    }
    
    @Bean
    public Binding bookOverdueBinding() {
        return BindingBuilder.bind(bookOverdueQueue())
                .to(borrowingExchange())
                .with("borrowing.book_overdue");
    }
    
    @Bean
    public Binding borrowingCancelledBinding() {
        return BindingBuilder.bind(borrowingCancelledQueue())
                .to(borrowingExchange())
                .with("borrowing.borrowing_cancelled");
    }
    
    // Fine Service Exchanges and Queues
    @Bean
    public TopicExchange fineExchange() {
        return new TopicExchange("fine.exchange");
    }
    
    @Bean
    public Queue fineCreatedQueue() {
        return new Queue("fine.fine_created", true);
    }
    
    @Bean
    public Queue fineUpdatedQueue() {
        return new Queue("fine.fine_updated", true);
    }
    
    @Bean
    public Queue finePaidQueue() {
        return new Queue("fine.fine_paid", true);
    }
    
    @Bean
    public Queue fineCancelledQueue() {
        return new Queue("fine.fine_cancelled", true);
    }
    
    @Bean
    public Binding fineCreatedBinding() {
        return BindingBuilder.bind(fineCreatedQueue())
                .to(fineExchange())
                .with("fine.fine_created");
    }
    
    @Bean
    public Binding fineUpdatedBinding() {
        return BindingBuilder.bind(fineUpdatedQueue())
                .to(fineExchange())
                .with("fine.fine_updated");
    }
    
    @Bean
    public Binding finePaidBinding() {
        return BindingBuilder.bind(finePaidQueue())
                .to(fineExchange())
                .with("fine.fine_paid");
    }
    
    @Bean
    public Binding fineCancelledBinding() {
        return BindingBuilder.bind(fineCancelledQueue())
                .to(fineExchange())
                .with("fine.fine_cancelled");
    }
    
    // Message Converter
    @Bean
    public Jackson2JsonMessageConverter messageConverter() {
        return new Jackson2JsonMessageConverter();
    }
    
    @Bean
    public RabbitTemplate rabbitTemplate(ConnectionFactory connectionFactory) {
        RabbitTemplate template = new RabbitTemplate(connectionFactory);
        template.setMessageConverter(messageConverter());
        return template;
    }
    
    @Bean
    public SimpleRabbitListenerContainerFactory rabbitListenerContainerFactory(ConnectionFactory connectionFactory) {
        SimpleRabbitListenerContainerFactory factory = new SimpleRabbitListenerContainerFactory();
        factory.setConnectionFactory(connectionFactory);
        factory.setMessageConverter(messageConverter());
        return factory;
    }
}

