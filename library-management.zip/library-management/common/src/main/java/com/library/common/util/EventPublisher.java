package com.library.common.util;

import com.library.common.event.BookEvent;
import com.library.common.event.BorrowingEvent;
import com.library.common.event.FineEvent;
import com.library.common.event.UserEvent;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.UUID;

@Component
public class EventPublisher {
    
    @Autowired
    private RabbitTemplate rabbitTemplate;
    
    public void publishUserEvent(UserEvent.EventType eventType, Long userId, Object userData) {
        UserEvent event = new UserEvent();
        event.setEventId(UUID.randomUUID().toString());
        event.setEventType(eventType.name());
        event.setUserId(userId);
        event.setUserData((com.library.common.dto.UserDto) userData);
        event.setTimestamp(LocalDateTime.now());
        
        rabbitTemplate.convertAndSend("user.exchange", "user." + eventType.name().toLowerCase(), event);
    }
    
    public void publishBookEvent(BookEvent.EventType eventType, Long bookId, Object bookData) {
        BookEvent event = new BookEvent();
        event.setEventId(UUID.randomUUID().toString());
        event.setEventType(eventType.name());
        event.setBookId(bookId);
        event.setBookData((com.library.common.dto.BookDto) bookData);
        event.setTimestamp(LocalDateTime.now());
        
        rabbitTemplate.convertAndSend("book.exchange", "book." + eventType.name().toLowerCase(), event);
    }
    
    public void publishBorrowingEvent(BorrowingEvent.EventType eventType, Long borrowingId, Long userId, Long bookId, Object borrowingData) {
        BorrowingEvent event = new BorrowingEvent();
        event.setEventId(UUID.randomUUID().toString());
        event.setEventType(eventType.name());
        event.setBorrowingId(borrowingId);
        event.setUserId(userId);
        event.setBookId(bookId);
        event.setBorrowingData((com.library.common.dto.BorrowingDto) borrowingData);
        event.setTimestamp(LocalDateTime.now());
        
        rabbitTemplate.convertAndSend("borrowing.exchange", "borrowing." + eventType.name().toLowerCase(), event);
    }
    
    public void publishFineEvent(FineEvent.EventType eventType, Long fineId, Long userId, java.math.BigDecimal amount, Object fineData) {
        FineEvent event = new FineEvent();
        event.setEventId(UUID.randomUUID().toString());
        event.setEventType(eventType.name());
        event.setFineId(fineId);
        event.setUserId(userId);
        event.setAmount(amount);
        event.setFineData((com.library.common.dto.FineDto) fineData);
        event.setTimestamp(LocalDateTime.now());
        
        rabbitTemplate.convertAndSend("fine.exchange", "fine." + eventType.name().toLowerCase(), event);
    }
}
