package com.library.common.event;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.library.common.dto.BorrowingDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BorrowingEvent {
    private String eventId;
    private String eventType;
    private Long borrowingId;
    private Long userId;
    private Long bookId;
    private BorrowingDto borrowingData;
    
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime timestamp;
    
    public enum EventType {
        BOOK_BORROWED, BOOK_RETURNED, BOOK_OVERDUE, BORROWING_CANCELLED
    }
}

