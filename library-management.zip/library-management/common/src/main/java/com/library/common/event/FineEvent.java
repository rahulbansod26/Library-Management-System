package com.library.common.event;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.library.common.dto.FineDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FineEvent {
    private String eventId;
    private String eventType;
    private Long fineId;
    private Long userId;
    private BigDecimal amount;
    private FineDto fineData;
    
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime timestamp;
    
    public enum EventType {
        FINE_CREATED, FINE_UPDATED, FINE_PAID, FINE_CANCELLED
    }
}

